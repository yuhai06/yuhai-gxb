/* 今日概览（日常运营主视图） */
import { icon } from '../icons.js?v=e2c064c209';
import { api } from '../api.js?v=9540edd950';
import { store } from '../store.js?v=dd9f0e78d7';
import {
  nfmt, lineChart, bar, badge, pageHead,
  ago, $, $$, toast, copyText,
} from '../ui.js?v=0770c29dda';

let recentOrders = [];
let autoExpanded = false;
let envsExpanded = false;

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '今日概览',
      desc: '素材库存、环境在线、最近发布与风险提醒一屏掌握',
      actions: [
        `<button class="btn sm" data-act="sync"><span data-icon="refresh"></span>刷新数据</button>`,
        `<button class="btn sm" data-go="agent"><span data-icon="sparkle"></span>雨海 Agent</button>`,
        `<button class="btn sm primary" data-go="publish"><span data-icon="send"></span>去发布中心</button>`,
      ],
    })}
    <div id="db-body"></div>
  `;
  $$('[data-act="sync"]', root).forEach((b) => (b.onclick = () => load(root, true)));
  $$('[data-go]', root).forEach((b) => (b.onclick = () => { location.hash = `#/${b.dataset.go}`; }));
  paint(root);
  load(root);
}

async function load(root, manual = false) {
  try {
    await store.loadCore();
    const [, , , , ord] = await Promise.all([
      store.loadOverview(14),
      store.loadJobs(),
      store.loadGuard(),
      store.loadAuto().catch(() => {}),
      api.publishOrders(6).catch(() => ({ items: [] })),
    ]);
    recentOrders = (ord && ord.items) || [];
    if (manual) toast('已刷新', '数据已更新', 'ok', 1600);
  } catch (e) {
    toast('刷新失败', e.message, 'err');
  }
  paint(root);
}

/* 将自动任务 note 里的原始 JSON 转为可读中文（例如评论区维护结果） */
function formatAutoNote(note) {
  if (!note) return '';
  const s = String(note).trim();
  if (s.startsWith('{') && s.endsWith('}')) {
    try {
      const o = JSON.parse(s);
      const parts = [];
      if (o.pages != null && o.totalPages != null) parts.push(`覆盖 ${o.pages}/${o.totalPages} 主页`);
      if (o.reply != null) parts.push(`回复 ${o.reply}`);
      if (o.delete != null) parts.push(`删评 ${o.delete}`);
      if (Array.isArray(o.errors) && o.errors.length) parts.push(`异常 ${o.errors.length}`);
      if (parts.length) return parts.join(' · ');
    } catch { /* fallback */ }
  }
  return s;
}

function orderStateMeta(st) {
  const s = String(st || '').toUpperCase();
  if (s === 'COMPLETED' || s === 'DONE') return ['已完成', 'ok'];
  if (s === 'RUNNING' || s === 'PENDING') return ['执行中', 'info'];
  if (s === 'FAILED') return ['失败', 'danger'];
  if (s === 'CANCELLED') return ['已停止', 'mute'];
  if (s === 'ATTENTION') return ['需关注', 'warn'];
  return [s || '未知', 'mute'];
}

function kpiCard({ label, value, unit = '', foot = '', iconName, route, tone = '' }) {
  return `
    <div class="stat dash-kpi ${tone}" data-go="${route}">
      <div class="stat-label">${icon(iconName, 14)}<span>${label}</span><span class="dash-kpi-arr">›</span></div>
      <div class="stat-value">${value}${unit ? `<span class="unit">${unit}</span>` : ''}</div>
      <div class="stat-foot">${foot}</div>
    </div>`;
}

function autoBar(a) {
  if (!a || !a.items) {
    return `<div class="card dash-auto-bar"><div class="card-body" style="color:var(--tx-3)">全自动状态加载中…</div></div>`;
  }
  const on = !!a.enabled;
  const obs = !!a.observeOnly;
  return `
    <div class="card dash-auto-bar ${on ? 'is-on' : ''}">
      <div class="card-head dash-auto-head">
        <div class="dash-auto-left">
          <span class="dot ${on ? 'ok' : ''}"></span>
          <strong class="dash-auto-title">全自动后台</strong>
          <span class="badge ${on ? 'ok' : 'mute'}">${on ? `运行中 · ${a.activeCount}/${a.totalCount}` : '已停止'}</span>
          ${obs ? '<span class="badge warn">只观察</span>' : ''}
          <span class="dash-auto-hint">排期、发布、建主页、授权永远保持手动</span>
        </div>
        <div class="dash-auto-right">
          ${(a.quickActions || []).map((q) => `
            <button class="btn xs ghost" data-quick="${esc(q.key)}" title="${esc(q.desc)}">${esc(q.name)}</button>
          `).join('')}
          ${on ? '<button class="btn xs danger" id="auto-stop">急停</button>' : ''}
          <button class="btn xs ghost" id="auto-toggle-detail">${autoExpanded ? '收起子项 ▴' : '展开子项 ▾'}</button>
          <label class="switch" title="${on ? '关闭全部自动流程' : '开启全部自动流程'}">
            <input type="checkbox" id="auto-master" ${on ? 'checked' : ''} />
            <span class="track"></span>
          </label>
        </div>
      </div>
      ${autoExpanded ? `
      <div class="card-body">
        <div class="grid g2" style="gap:6px 22px">
          ${a.items.map((it) => {
            const note = formatAutoNote(it.note);
            return `
            <div class="litem" style="padding:8px 4px;opacity:${on ? '1' : '.68'}">
              <span class="dot ${it.active ? 'ok' : ''}"></span>
              <div class="litem-main">
                <div class="litem-title" style="display:flex;align-items:center;gap:6px">
                  ${esc(it.name)}
                  ${it.intervalMin ? `<span class="chip ghost">${it.intervalMin >= 60 ? (it.intervalMin / 60) + 'h' : it.intervalMin + 'm'}</span>` : ''}
                </div>
                <div class="litem-sub">
                  ${esc(it.desc)}${note ? ` · <span style="color:var(--tx-1)">${esc(note)}</span>` : ''}
                </div>
              </div>
              <label class="switch">
                <input type="checkbox" class="auto-item" data-key="${esc(it.key)}"
                       ${it.subOn ? 'checked' : ''} ${on ? '' : 'disabled'} />
                <span class="track"></span>
              </label>
            </div>`;
          }).join('')}
        </div>
      </div>` : ''}
    </div>`;
}

function paint(root) {
  const body = $('#db-body', root);
  if (!body) return;
  const s = store.summary || {};
  const ov = store.overview || {};
  const auto = store.auto || {};
  const daily = ov.daily || [];
  const jobs = store.jobs || [];
  const pages = store.pages || [];
  const envs = store.envs || [];
  const g = store.guard || {};

  const playsTotal = daily.reduce((a, d) => a + (d.plays || 0), 0);
  const runningEnvs = envs.filter((e) => e.status === 'running');
  const skippedPages = pages.filter((p) => p.skipPublish || p.skip_publish).length;
  const activePages = Math.max(0, pages.length - skippedPages);
  const libGb = s.libMb ? (s.libMb / 1024).toFixed(1) + ' GB' : '0 GB';
  const latestOrd = recentOrders[0];
  const latestOrdFoot = latestOrd
    ? `最近：${orderStateMeta(latestOrd.state)[0]}（成 ${latestOrd.ok_count || 0} / 败 ${latestOrd.fail_count || 0}）`
    : '暂无发布记录';

  const keyEnvs = envs.filter((e) => e.status === 'running' || e.role === 'publisher' || e.role === 'backup');
  const shownEnvs = envsExpanded ? envs : (keyEnvs.length ? keyEnvs : envs.slice(0, 4));
  const hiddenEnvCount = Math.max(0, envs.length - shownEnvs.length);

  const todos = buildTodos(pages, g, jobs);
  const recentCodes = (store.mails || []).filter((m) => m.code).slice(0, 4);

  body.innerHTML = `
    ${g.blocked ? `
    <div class="card dash-alert" style="margin-bottom:14px">
      <div class="card-body" style="display:flex;gap:12px;align-items:center">
        <span style="color:var(--danger)">${icon('warn', 18)}</span>
        <div style="flex:1">
          <b style="color:var(--danger)">风控熔断中</b>：${esc(g.latest?.message || '请前往风控中心核对并解除')}
        </div>
        <button class="btn sm danger" data-go="guard">去处理</button>
      </div>
    </div>` : ''}

    <!-- 1. 核心 4 指标（点击直达） -->
    <div class="grid g4" style="margin-bottom:14px">
      ${kpiCard({
        label: '可发素材',
        value: nfmt(s.libReady ?? 0),
        unit: '条',
        foot: `${libGb} · 队列待发 ${s.queueReady ?? 0} 条`,
        iconName: 'layers',
        route: 'library',
        tone: (s.libReady || 0) < 30 ? 'warn' : 'ok',
      })}
      ${kpiCard({
        label: '环境与主页',
        value: `${runningEnvs.length}/${envs.length}`,
        unit: '在线',
        foot: `可发主页 ${activePages} 个${skippedPages ? ` · 已跳过 ${skippedPages} 个` : ''}`,
        iconName: 'monitor',
        route: 'envs',
        tone: runningEnvs.length ? 'ok' : 'warn',
      })}
      ${kpiCard({
        label: '累计发布',
        value: nfmt(s.published ?? 0),
        unit: '条',
        foot: esc(latestOrdFoot),
        iconName: 'send',
        route: 'publish',
      })}
      ${kpiCard({
        label: '14 天播放',
        value: nfmt(playsTotal),
        unit: '次',
        foot: g.blocked ? `⚠ 风控 ${g.count || 0} 项待处理` : `${s.videoCount || 0} 条视频 · 风控正常`,
        iconName: g.blocked ? 'warn' : 'chart',
        route: g.blocked ? 'guard' : 'analytics',
        tone: g.blocked ? 'danger' : '',
      })}
    </div>

    <!-- 2. 常用工作流快捷入口 -->
    <div class="dash-quick" style="margin-bottom:14px">
      <button class="dash-qbtn" data-go="agent">
        <span class="dash-qico purple">${icon('sparkle', 16)}</span>
        <span><b>雨海 Agent 总控</b><small>对话调度全站：查切片、发视频、管账号</small></span>
      </button>
      <button class="dash-qbtn" data-go="publish">
        <span class="dash-qico ac">${icon('send', 16)}</span>
        <span><b>新建发布单</b><small>先提取最新主页，预览文案并排期</small></span>
      </button>
      <button class="dash-qbtn" data-go="library">
        <span class="dash-qico ok">${icon('layers', 16)}</span>
        <span><b>管理素材库</b><small>扫描入库、整理归档、推队列</small></span>
      </button>
      <button class="dash-qbtn" data-go="envs">
        <span class="dash-qico info">${icon('monitor', 16)}</span>
        <span><b>指纹浏览器</b><small>启停环境、死号一键交接与换号</small></span>
      </button>
    </div>

    <!-- 3. 主内容双栏 -->
    <div class="grid" style="grid-template-columns:1.45fr 1fr;margin-bottom:14px;align-items:start">
      <div style="display:flex;flex-direction:column;gap:14px;min-width:0">
        <!-- 最近发布单 -->
        <div class="card">
          <div class="card-head">
            <div class="card-title">最近发布单 <span class="sub">最新 6 笔</span></div>
            <button class="btn xs ghost" data-go="publish">进入发布中心 ›</button>
          </div>
          <div class="card-body tight">
            ${recentOrders.length ? recentOrders.map((o) => {
              const [lbl, kind] = orderStateMeta(o.state);
              const title = o.title || o.id;
              return `
                <div class="litem dash-order-row" data-go="publish">
                  <div class="litem-main">
                    <div class="litem-title">${esc(title)} ${badge(lbl, kind, kind === 'info')}</div>
                    <div class="litem-sub">${esc(o.stage || '')} · 环境 ${esc(o.env_code || '—')} · ${ago(o.created_at)}</div>
                  </div>
                  <div class="dash-order-stat">
                    <span class="ok">成 ${o.ok_count || 0}</span>
                    ${(o.fail_count || 0) ? `<span class="bad">败 ${o.fail_count}</span>` : ''}
                  </div>
                </div>`;
            }).join('') : '<div class="litem" style="justify-content:center;color:var(--tx-3)">暂无发布单</div>'}
          </div>
        </div>

        <!-- 播放趋势 -->
        <div class="card">
          <div class="card-head">
            <div class="card-title">播放趋势 <span class="sub">近 14 天</span></div>
            <button class="btn xs ghost" data-go="analytics">查看视频数据 ›</button>
          </div>
          <div class="card-body">
            ${daily.length >= 2
              ? lineChart(daily.map((d) => ({ date: d.date, views: d.plays || 0 })), { key: 'views', hgt: 155 })
              : `<div style="padding:30px 16px;text-align:center;color:var(--tx-2)">
                   ${daily.length === 1
                     ? `今天已采集 <b>${nfmt(daily[0].plays)}</b> 次播放（需 ≥2 天快照才会生成曲线）`
                     : '暂无播放趋势，可到「视频数据」页点击采集'}
                 </div>`}
          </div>
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:14px;min-width:0">
        <!-- 待办与异常 -->
        <div class="card">
          <div class="card-head">
            <div class="card-title">待处理与提醒</div>
            ${todos.length ? `<span class="badge warn">${todos.length} 项</span>` : '<span class="badge ok">全部正常</span>'}
          </div>
          <div class="card-body tight">
            ${todos.length ? todos.map(([t, d, k, go]) => `
              <div class="litem ${go ? 'clickable' : ''}" ${go ? `data-go="${go}"` : ''}>
                <span class="dot ${k === 'danger' ? 'bad' : k === 'warn' ? 'warn' : 'ok'}"></span>
                <div class="litem-main">
                  <div class="litem-title">${esc(t)}</div>
                  <div class="litem-sub">${esc(d)}</div>
                </div>
                ${go ? '<span style="color:var(--tx-3)">›</span>' : ''}
              </div>`).join('') : '<div class="litem" style="justify-content:center;color:var(--tx-3)">当前无异常待办</div>'}
          </div>
        </div>

        <!-- 浏览器环境 -->
        <div class="card">
          <div class="card-head">
            <div class="card-title">关键环境 <span class="sub">${runningEnvs.length} / ${envs.length} 运行中</span></div>
            <div style="display:flex;gap:6px">
              ${hiddenEnvCount > 0 || envsExpanded
                ? `<button class="btn xs ghost" id="btn-env-more">${envsExpanded ? '仅看关键' : `全部 (${envs.length})`}</button>`
                : ''}
              <button class="btn xs ghost" data-go="envs">管理 ›</button>
            </div>
          </div>
          <div class="card-body tight">
            ${shownEnvs.map((e) => `
              <div class="litem clickable" data-go="envs">
                <span class="dot ${e.status === 'running' ? 'ok' : ''}"></span>
                <div class="litem-main">
                  <div class="litem-title">${esc(e.name)}
                    ${badge(e.roleLabel || e.role || '备用', e.role === 'publisher' ? 'info' : e.role === 'backup' ? 'purple' : 'mute')}
                  </div>
                  <div class="litem-sub">${esc(e.containerCode)}${e.cdpPort ? ' · CDP ' + e.cdpPort : ''} · ${e.status === 'running' ? '运行中' : '未启动'}</div>
                </div>
              </div>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">无环境</div>'}
          </div>
        </div>

        <!-- 最近验证码 -->
        <div class="card">
          <div class="card-head">
            <div class="card-title">最近验证码</div>
            <button class="btn xs ghost" data-go="mail">邮箱 ›</button>
          </div>
          <div class="card-body tight">
            ${recentCodes.length ? recentCodes.map((m) => `
              <div class="litem">
                <div class="litem-main">
                  <div class="litem-title">${esc((m.mailbox || '').split('@')[0])} <span class="badge mute">${esc(m.source || '')}</span></div>
                  <div class="litem-sub">${esc((m.subject || '').slice(0, 32))}</div>
                </div>
                <button class="mail-code dash-code-btn" data-copy="${esc(m.code)}" title="点击复制">${esc(m.code)}</button>
              </div>`).join('') : '<div class="litem" style="justify-content:center;color:var(--tx-3)">暂无新验证码</div>'}
          </div>
        </div>
      </div>
    </div>

    <!-- 4. 全自动后台（紧凑折叠条，不占首屏） -->
    ${autoBar(auto)}
  `;

  $$('[data-go]', body).forEach((el) => {
    el.onclick = () => { location.hash = `#/${el.dataset.go}`; };
  });
  $$('[data-copy]', body).forEach((el) => {
    el.onclick = (e) => { e.stopPropagation(); copyText(el.dataset.copy); };
  });
  const envMore = $('#btn-env-more', body);
  if (envMore) envMore.onclick = () => { envsExpanded = !envsExpanded; paint(root); };
  bindAuto(root);
}

function bindAuto(root) {
  const toggleBtn = document.getElementById('auto-toggle-detail');
  if (toggleBtn) {
    toggleBtn.onclick = () => { autoExpanded = !autoExpanded; paint(root); };
  }
  const master = document.getElementById('auto-master');
  if (master) {
    master.onchange = async () => {
      const on = master.checked;
      master.disabled = true;
      try {
        store.auto = await api.autoMaster(on);
        toast(on ? '全自动已开启' : '全自动已关闭',
          on ? '评论维护 / 数据采集 / 风控巡检已启动' : '所有自动流程已暂停', 'ok', 4000);
        paint(root);
      } catch (e) {
        master.checked = !on;
        toast('切换失败', e.message, 'err', 5000);
      } finally { master.disabled = false; }
    };
  }
  document.querySelectorAll('.auto-item').forEach((el) => {
    el.onchange = async () => {
      const key = el.dataset.key;
      el.disabled = true;
      try {
        store.auto = await api.autoItem(key, el.checked);
        paint(root);
      } catch (e) {
        el.checked = !el.checked;
        toast('切换失败', e.message, 'err', 5000);
      } finally { el.disabled = false; }
    };
  });
  const stop = document.getElementById('auto-stop');
  if (stop) {
    stop.onclick = async () => {
      if (!confirm('一键急停：关闭所有自动流程，并开启「只观察」模式？')) return;
      try {
        store.auto = await api.autoStop();
        toast('已急停', '全部自动关闭 + 只观察已开', 'ok', 5000);
        paint(root);
      } catch (e) { toast('急停失败', e.message, 'err', 5000); }
    };
  }
  document.querySelectorAll('[data-quick]').forEach((b) => {
    b.onclick = async () => {
      const key = b.dataset.quick;
      const name = b.textContent.trim();
      const old = b.textContent;
      b.disabled = true; b.textContent = '执行中…';
      toast('已开始', name + '（后台执行，完成后提示）', 'info', 4000);
      try {
        const r = await api.autoQuick(key);
        const jobId = r.jobId;
        if (!jobId) throw new Error('提交失败');
        const t0 = Date.now();
        while (Date.now() - t0 < 1800000) {
          await new Promise((res) => setTimeout(res, 6000));
          const j = await api.job(jobId);
          if (j.status === 'done') {
            const inner = (j.result && j.result.result) || j.result || {};
            let detail = key === 'comments'
              ? `${inner.reply || 0} 回复 · ${inner.delete || 0} 删除 · ${inner.pages || 0} 主页`
              : key === 'metrics'
                ? `${inner.ok || 0} 成功 · ${inner.fail || 0} 失败`
                : `${inner.checked || 0} 主页检查 · ${inner.blocked || 0} 异常`;
            toast('完成', detail, 'ok', 8000);
            break;
          }
          if (j.status === 'failed') {
            toast('执行失败', j.error || '未知错误', 'err', 8000);
            break;
          }
        }
        await store.loadAuto();
        paint(root);
      } catch (e) {
        toast('执行失败', e.message, 'err', 6000);
      } finally { b.disabled = false; b.textContent = old; }
    };
  });
}

function buildTodos(pages, g, jobs) {
  const out = [];
  if (g.blocked) out.push(['风控熔断待处理', g.latest?.message || '点击去风控中心解除', 'danger', 'guard']);
  const noAsset = pages.filter((p) => !p.assetId);
  if (noAsset.length) out.push([`${noAsset.length} 个主页缺 asset_id`, '无法发布与采集，需重新提取', 'warn', 'authz']);
  const skipped = pages.filter((p) => p.skipPublish || p.skip_publish);
  if (skipped.length) out.push([`${skipped.length} 个主页已暂停自动发布`, skipped.map((p) => p.name).slice(0, 5).join('、'), 'warn', 'authz']);
  const restricted = pages.filter((p) => p.health && p.health !== 'ok');
  if (restricted.length) out.push([`${restricted.length} 个主页状态异常`, '建议检查账号或退避', 'warn', 'authz']);
  const failedJobs = (jobs || []).filter((j) => j.status === 'failed').slice(0, 1);
  if (failedJobs.length) out.push(['最近有后台任务失败', `${failedJobs[0].title || failedJobs[0].id}`, 'warn', 'logs']);
  return out.slice(0, 5);
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

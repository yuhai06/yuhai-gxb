/* 素材库（真实数据）
   目录按 日期/剧名/文件 组织；剧名写入标签，发布时带剧名。 */
import { icon } from '../icons.js?v=e2c064c209';
import { api } from '../api.js?v=9540edd950';
import { store } from '../store.js?v=dd9f0e78d7';
import {
  badge, pageHead, statCard, $, $$, toast, modal, bar, ts, ago, nfmt, emptyState,
} from '../ui.js?v=0770c29dda';

let tab = 'library';       // library | pipeline
let filter = { q: '', line: 'all', state: 'all', drama: '*', copyright: 'all' };
let selected = new Set();

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '素材库',
      desc: '按剧名归档管理成品视频；高频操作直接露出，低频维护收在「更多维护」',
      actions: [
        `<button class="btn sm" data-act="scan"><span data-icon="refresh"></span>扫描目录</button>`,
        `<button class="btn sm primary" data-act="organize"><span data-icon="layers"></span>整理素材</button>`,
        `<button class="btn sm ok" data-act="push"><span data-icon="send"></span>推入队列</button>`,
        `<button class="btn sm danger" data-act="del"><span data-icon="trash"></span>删除选中</button>`,
        `<div class="menu-wrap" id="lb-more-wrap">
           <button class="btn sm ghost" id="lb-more-btn">更多维护 ▾</button>
           <div class="menu-pop" id="lb-more-pop" hidden>
             <button class="menu-item" data-act="import"><span data-icon="upload"></span>导入素材</button>
             <button class="menu-item" data-act="export"><span data-icon="down"></span>导出素材</button>
             <div class="menu-sep"></div>
             <button class="menu-item" data-act="qc"><span data-icon="check"></span>批量质检</button>
             <button class="menu-item" data-act="audit"><span data-icon="shield"></span>体检清理</button>
             <button class="menu-item" data-act="split"><span data-icon="layers"></span>成品/原始分离</button>
             <button class="menu-item danger" data-act="purge"><span data-icon="trash"></span>清理版权不过</button>
           </div>
         </div>`,
      ],
    })}
    <div id="lb-body"></div>
  `;
  const moreBtn = $('#lb-more-btn', root);
  const morePop = $('#lb-more-pop', root);
  if (moreBtn && morePop) {
    moreBtn.onclick = (e) => { e.stopPropagation(); morePop.hidden = !morePop.hidden; };
    const onDocClick = () => {
      if (!document.contains(morePop)) {
        document.removeEventListener('click', onDocClick);
        return;
      }
      morePop.hidden = true;
    };
    document.addEventListener('click', onDocClick);
    morePop.addEventListener('click', () => { morePop.hidden = true; });
  }
  $$('[data-act="scan"]', root).forEach((b) => (b.onclick = () => doScan(b)));
  $$('[data-act="organize"]', root).forEach((b) => (b.onclick = () => openOrganize(root)));
  $$('[data-act="export"]', root).forEach((b) => (b.onclick = () => openExport()));
  $$('[data-act="import"]', root).forEach((b) => (b.onclick = () => openImport(root)));
  $$('[data-act="setroot"]', root).forEach((b) => (b.onclick = () => openSetRoot()));
  $$('[data-act="audit"]', root).forEach((b) => (b.onclick = () => openAudit(root)));
  $$('[data-act="split"]', root).forEach((b) => (b.onclick = () => openMaterialSplit(root)));
  $$('[data-act="qc"]', root).forEach((b) => (b.onclick = () => doQcBatch(b)));
  $$('[data-act="purge"]', root).forEach((b) => (b.onclick = () => doPurgeCopyright(root)));
  $$('[data-act="del"]', root).forEach((b) => (b.onclick = () => doDelete(root)));
  $$('[data-act="push"]', root).forEach((b) => (b.onclick = () => openPush()));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    const d = await api.library({});
    store.library = d.items || [];
    store.libGroups = d.groups || [];
    store.dramaTypes = d.types || {};
    store.libCopyright = d.copyright || { ok: 0, fail: 0, unchecked: 0 };
    store.libraryRoot = d.root || '';
    store.libraryRoots = d.roots || [];
  } catch (e) {
    toast('加载失败', e.message, 'err');
  }
  paint(root);
}

function paint(root) {
  const body = $('#lb-body', root);
  if (!body) return;
  const items = store.library || [];
  const types = store.dramaTypes || {};

  const ready = items.filter((x) => x.state === 'ready').length;
  const blocked = items.filter((x) => x.state === 'blocked').length;
  const used = items.filter((x) => x.state === 'used').length;
  const totalMb = Math.round(items.reduce((a, x) => a + (+x.size_mb || 0), 0));
  const cop = (store.libCopyright || { ok: 0, fail: 0, unchecked: 0 });

  // 过滤
  let list = items.slice();
  if (filter.q) {
    const k = filter.q.toLowerCase();
    list = list.filter((x) => (x.file || '').toLowerCase().includes(k)
      || (x.drama || '').toLowerCase().includes(k));
  }
  if (filter.line !== 'all') list = list.filter((x) => x.line === filter.line);
  if (filter.state !== 'all') list = list.filter((x) => x.state === filter.state);
  if (filter.drama && filter.drama !== '*') list = list.filter((x) => x.drama === filter.drama);
  if (filter.copyright === 'ok') list = list.filter((x) => x.copyright_ok === 1);
  if (filter.copyright === 'fail') list = list.filter((x) => x.copyright_ok === 0);
  if (filter.copyright === 'unchecked') list = list.filter((x) => x.copyright_ok == null);

  // 按剧名分组
  const groups = {};
  list.forEach((x) => {
    const k = x.drama || '未分类';
    (groups[k] = groups[k] || []).push(x);
  });

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '成品总数', value: items.length, unit: '条', iconName: 'layers',
                   foot: `${totalMb} MB` })}
      ${statCard({ label: '可发布', value: ready, unit: '条', iconName: 'check' })}
      ${statCard({ label: '版权不过', value: cop.fail, unit: '条', iconName: 'warn',
                   foot: cop.unchecked ? `${cop.unchecked} 条未检` : '全部已检' })}
      ${statCard({ label: '已入队/已发', value: used, unit: '条', iconName: 'send' })}
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="tabs" style="border:none;padding:0;margin:0">
          <div class="tab ${tab === 'library' ? 'active' : ''}" data-tab="library">
            成品库 <span class="cnt">${items.length}</span>
          </div>
          <div class="tab ${tab === 'source' ? 'active' : ''}" data-tab="source">
            原始素材
          </div>
        </div>
        <div id="lb-tools"></div>
      </div>
      <div class="card-body" id="lb-inner"></div>
    </div>
  `;

  $$('[data-tab]', root).forEach((t) => {
    t.onclick = () => { tab = t.dataset.tab; paint(root); };
  });

  const tools = $('#lb-tools', root);
  const inner = $('#lb-inner', root);

  if (tab === 'source') {
    // 原始素材（下载的未处理视频）—— 2026-11-13 用户要求加进来
    // 与「成品库」分开：这里只读展示 + 快捷入口，不参与发布
    tools.innerHTML = `<span class="chip">原始素材目录 · 下载的未处理视频</span>`;
    inner.innerHTML = '<div style="padding:14px;color:var(--tx-3);font-size:11.5px">加载中…</div>';
    renderSourceTab(inner);   // async 函数（paint 本身非 async，不能直接 await）
    return;
  }

  if (tab === 'pipeline') {
    tools.innerHTML = `<span class="chip">5 步流程 · 转录→语音→分类→打分→出片</span>`;
    inner.innerHTML = `
      <div style="padding:14px">
        <div class="card" style="margin-bottom:13px;border-color:rgba(79,70,229,.28)">
          <div class="card-body" style="display:flex;gap:10px;align-items:flex-start">
            <span style="color:var(--ac);flex:0 0 auto">${icon('bolt', 15)}</span>
            <div style="font-size:11.5px;color:var(--tx-2);line-height:1.75">
              真实接驳 <code style="font-family:var(--mono)">tools/</code> 目录下已验证的脚本
              （路径见「设置 → 路径」）。
              顺序不可调换，每步失败会停下并报错，不会硬着头皮往下跑。
            </div>
          </div>
        </div>

        <div class="steps" style="margin-bottom:16px">
          ${[
            ['① 台词转录 whisper', 'transcribe_audio.py', '逐句时间戳，medium 模型'],
            ['② 语音检测', 'voice_check3.py', '过滤无声段，标出有声区间'],
            ['③ 类型判定', 'classify.py', '7 类强弱关键词加权'],
            ['④ 张力打分', 'score_lines2.py', '每句一个张力分，thresh 1.0'],
            ['⑤ 剪辑出片', 'cut_ep2.py / render_plan.py', '单集线 + 精品混剪线'],
          ].map(([t, s, d], i) => `
            <div class="step ${i === 0 ? 'run' : 'wait'}">
              <div class="step-num">${i + 1}</div>
              <div class="step-body">
                <div class="step-title">${t}</div>
                <div class="step-desc"><code style="font-family:var(--mono);font-size:10px">${s}</code> · ${d}</div>
              </div>
            </div>`).join('')}
        </div>

        <div class="card" style="margin-bottom:13px">
          <div class="card-head"><div class="card-title">工具检查</div></div>
          <div class="card-body" id="pl-tools">
            <div style="font-size:11.5px;color:var(--tx-3)">检查中…</div>
          </div>
        </div>

        <div class="card" style="margin-bottom:13px">
          <div class="card-head"><div class="card-title">启动处理</div></div>
          <div class="card-body">
            <div class="row-2">
              <div class="field"><label>剧名</label>
                <input class="input" id="pl-drama" placeholder="How_to_tame_a_bad_boy" /></div>
              <div class="field"><label>目标时长（秒）</label>
                <input class="input" id="pl-target" type="number" value="45" /></div>
            </div>
            <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px">
              <label class="switch"><input type="checkbox" id="pl-single" checked />
                <span class="track"></span><span class="lbl">单集线（40–55s，段边界对齐台词）</span></label>
              <label class="switch"><input type="checkbox" id="pl-premium" checked />
                <span class="track"></span><span class="lbl">精品混剪线（120–150s，5 阶段结构）</span></label>
            </div>
            <button class="btn primary" id="pl-run">
              <span data-icon="bolt"></span>开始处理
            </button>
            <div id="pl-result" style="margin-top:11px"></div>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><div class="card-title">历史任务</div></div>
          <div class="card-body tight" id="pl-history">
            <div style="padding:18px;text-align:center;color:var(--tx-3);font-size:11px">加载中…</div>
          </div>
        </div>
      </div>`;

    checkTools(root);
    loadPipelineHistory(root);
    const runBtn = $('#pl-run', inner);
    if (runBtn) {
      runBtn.onclick = async () => {
        const drama = ($('#pl-drama', inner).value || '').trim();
        if (!drama) return toast('请输入剧名', '', 'err');
        runBtn.disabled = true;
        const old = runBtn.innerHTML;
        runBtn.innerHTML = '<span class="spin" data-icon="bolt"></span>处理中…';
        try {
          const r = await api.runPipeline({
            drama,
            single: $('#pl-single', inner).checked,
            premium: $('#pl-premium', inner).checked,
            targetSec: parseInt($('#pl-target', inner).value, 10) || 45,
          });
          toast('已入队', `${r.steps.join(' → ')}`, 'info', 6000);
          const t0 = Date.now();
          while (Date.now() - t0 < 7200000) {
            await new Promise((res) => setTimeout(res, 4000));
            const j = await api.job(r.jobId);
            runBtn.innerHTML = `<span class="spin" data-icon="bolt"></span>${j.progress || 0}%`;
            $('#pl-result', inner).innerHTML = renderSteps(j.steps);
            if (['done', 'failed', 'blocked'].includes(j.status)) {
              const res = j.result || {};
              toast(j.status === 'done' ? '处理完成' : '处理中断',
                j.status === 'done' ? `出片 ${(res.made || []).length} 条` : (j.error || ''),
                j.status === 'done' ? 'ok' : 'err', 7000);
              await load(root);
              break;
            }
          }
        } catch (e) {
          toast('处理失败', e.message, 'err', 6000);
        } finally {
          runBtn.disabled = false;
          runBtn.innerHTML = old;
        }
      };
    }
    return;
  }

  tools.innerHTML = `
    <div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap">
      <input class="input" id="lb-q" placeholder="搜文件 / 剧名" value="${filter.q}"
             style="width:150px;padding:4px 8px;font-size:11.5px" />
      <select class="select" id="lb-drama" style="width:160px;padding:4px 8px;font-size:11.5px">
        <option value="*" ${filter.drama === '*' ? 'selected' : ''}>全部剧（${items.length} 条）</option>
        ${(store.libGroups || []).map((g) =>
          `<option value="${esc(g.drama)}" ${filter.drama === g.drama ? 'selected' : ''}>${esc(g.drama)}（${g.count}）</option>`).join('')}
      </select>
      <select class="select" id="lb-cop" style="width:120px;padding:4px 8px;font-size:11.5px">
        <option value="all" ${filter.copyright === 'all' ? 'selected' : ''}>版权全部</option>
        <option value="ok" ${filter.copyright === 'ok' ? 'selected' : ''}>版权通过</option>
        <option value="fail" ${filter.copyright === 'fail' ? 'selected' : ''}>版权不过</option>
        <option value="unchecked" ${filter.copyright === 'unchecked' ? 'selected' : ''}>未检</option>
      </select>
      <div class="seg" data-seg="line">
        <button class="${filter.line === 'all' ? 'on' : ''}" data-v="all">全部</button>
        <button class="${filter.line === 'single' ? 'on' : ''}" data-v="single">单集</button>
        <button class="${filter.line === 'premium' ? 'on' : ''}" data-v="premium">混剪</button>
      </div>
      <button class="btn xs ghost" data-act="selall">全选当前</button>
      <button class="btn xs ghost" data-act="selnone">清空</button>
    </div>`;

  if (!items.length) {
    const root = store.libraryRoot || '（读取中）';
    inner.innerHTML = `
      <div style="padding:40px 20px;text-align:center">
        <div style="font-size:13px;color:var(--tx-1);margin-bottom:6px">素材库还是空的</div>
        <div style="font-size:11.5px;color:var(--tx-3);line-height:1.9">
          把视频放到 <code style="font-family:var(--mono);color:var(--ac)">${esc(root)}</code><br/>
          按 <b>剧名 / 文件.mp4</b> 的结构放（也可以直接点下面按钮导入）<br/>
          然后点右上「扫描目录」
        </div>
        <div style="margin-top:14px;display:flex;gap:8px;justify-content:center">
          <button class="btn sm" data-act="import">导入素材</button>
          <button class="btn sm ghost" data-act="setroot">修改素材库路径</button>
        </div>
      </div>`;
  } else if (!list.length) {
    inner.innerHTML = emptyState('没有匹配的素材', '换个筛选条件');
  } else {
    // ── 只显示剧名卡片 ──
    //
    // 用户要求（2026-11-12）：
    //   "如果只是少量素材那还行，但是要是多了我也看不完啊，
    //    所有改成只有剧名，然后点击剧名打开弹窗里面是文件"
    //
    // 原来每个剧把全部文件摊成一张宽表，43 条素材要滚好几屏，
    // 找一部剧得翻半天。现在列表只显示剧名 + 统计，
    // 点一行才弹出该剧的文件清单（弹窗里可以做全选/单项操作）。
    inner.innerHTML = `
      <div class="lib-drama-list">
        ${Object.entries(groups).map(([drama, rows]) => {
          const dt = types[rows[0].dtype] || null;
          const mb = rows.reduce((a, x) => a + (+x.size_mb || 0), 0).toFixed(0);
          const rdy = rows.filter((x) => x.state === 'ready').length;
          const usd = rows.filter((x) => x.state === 'used').length;
          const bad = rows.filter((x) => x.state === 'blocked').length;
          const unorg = rows.filter((x) => !x.organized).length;
          const selN = rows.filter((x) => selected.has(x.id)).length;
          return `
            <div class="lib-drama ${selN ? 'has' : ''}" data-open-drama="${esc(drama)}">
              <div class="lib-drama-av">${esc((drama[0] || '?').toUpperCase())}</div>
              <div class="lib-drama-main">
                <div class="lib-drama-name">${esc(drama)}</div>
                <div class="lib-drama-meta">
                  ${rows.length} 条 · ${mb} MB
                  <span class="dot-sep">·</span>
                  待用 <b>${rdy}</b>
                  ${usd ? `<span class="dot-sep">·</span>已用 ${usd}` : ''}
                  ${bad ? `<span class="dot-sep">·</span><span style="color:var(--danger)">拦截 ${bad}</span>` : ''}
                </div>
              </div>
              ${dt ? `<span class="lib-drama-type">${esc(dt.name)}</span>` : ''}
              ${unorg ? `<span class="lib-drama-warn" title="还有 ${unorg} 条没整理，不能发布">未整理 ${unorg}</span>` : ''}
              ${selN ? `<span class="lib-drama-sel">已选 ${selN}</span>` : ''}
              <span class="lib-drama-open">查看 ${icon('arrowR', 10)}</span>
            </div>`;
        }).join('')}
      </div>`;
  }

  // 交互
  const q = $('#lb-q', root);
  if (q) q.oninput = (e) => { filter.q = e.target.value; paint(root); };
  const ds = $('#lb-drama', root);
  if (ds) ds.onchange = (e) => { filter.drama = e.target.value; paint(root); };
  const cs = $('#lb-cop', root);
  if (cs) cs.onchange = (e) => { filter.copyright = e.target.value; paint(root); };
  $$('[data-seg="line"] button', root).forEach((b) => {
    b.onclick = () => { filter.line = b.dataset.v; paint(root); };
  });
  $$('[data-act="selall"]', root).forEach((b) => (b.onclick = () => {
    list.filter((x) => x.state === 'ready').forEach((x) => selected.add(x.id));
    toast('已全选', `${selected.size} 条`, 'ok');
    paint(root);
  }));
  $$('[data-act="selnone"]', root).forEach((b) => (b.onclick = () => {
    selected.clear();
    paint(root);
  }));
  $$('[data-sel]', root).forEach((cb) => {
    cb.onchange = () => {
      if (cb.checked) selected.add(cb.dataset.sel);
      else selected.delete(cb.dataset.sel);
    };
  });
  $$('[data-pickall]', root).forEach((b) => {
    b.onclick = () => {
      const d = b.dataset.pickall;
      items.filter((x) => (x.drama || '未分类') === d && x.state === 'ready')
        .forEach((x) => selected.add(x.id));
      toast('已选中', `${d} 全部可发布素材`, 'ok');
      paint(root);
    };
  });
  $$('[data-x="detail"]', root).forEach((b) => {
    b.onclick = () => openDetail(b.dataset.id);
  });
  $$('[data-cop]', root).forEach((b) => {
    b.onclick = async (e) => {
      e.stopPropagation();
      const x = items.find((v) => v.id === b.dataset.cop);
      if (!x) return;
      const next = x.copyright_ok === 1 ? 0 : 1;
      try {
        await api.setCopyright(x.id, next === 1,
          next === 1 ? '人工确认通过' : '人工标记不过');
        toast(next === 1 ? '版权通过' : '版权不过', x.file, next === 1 ? 'ok' : 'warn');
        await load(document.getElementById('view'));
      } catch (err) { toast('失败', err.message, 'err'); }
    };
  });

  // 点剧名 → 弹出该剧的文件弹窗
  $$('[data-open-drama]', root).forEach((el) => {
    el.onclick = () => openDramaFiles(el.dataset.openDrama, items, (newIds) => {
      paint(root);
    });
  });
}

/* ---------------- 剧名 → 文件弹窗 ---------------- */
// 用户要求：列表只显示剧名，点开才看文件。
// 弹窗里保留全部操作（选中/版权/详情），不损失功能。
function openDramaFiles(drama, items, onChanged) {
  const rows = items.filter((x) => (x.drama || '未分类') === drama);
  if (!rows.length) return;

  const body = document.createElement('div');
  const rdyN = rows.filter((x) => x.state === 'ready').length;
  const unorgN = rows.filter((x) => !x.organized).length;

  body.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
      <span style="font-size:12.5px;font-weight:600">${esc(drama)}</span>
      <span style="font-size:10.5px;color:var(--tx-3)">
        ${rows.length} 条 · 待用 ${rdyN}
        ${unorgN ? ` · <span style="color:var(--warn)">${unorgN} 条未整理</span>` : ''}
      </span>
      <span style="flex:1"></span>
      <button class="btn xs ghost" data-all>全选可发</button>
      <button class="btn xs ghost" data-none>清空</button>
    </div>
    <div class="tbl-wrap" style="max-height:min(58vh,540px);overflow-y:auto">
      <table class="tbl">
        <thead><tr>
          <th style="width:26px"></th><th>文件</th><th>线</th><th>集</th>
          <th class="num">时长</th><th class="num">大小</th>
          <th>整理</th><th>版权</th><th>状态</th><th></th>
        </tr></thead>
        <tbody>
          ${rows.map((x) => `
            <tr data-lib="${x.id}">
              <td><input type="checkbox" data-sel="${x.id}"
                  style="width:13px;height:13px;accent-color:var(--ac)"
                  ${selected.has(x.id) ? 'checked' : ''} /></td>
              <td style="font-family:var(--mono);font-size:10.5px;max-width:250px;
                         overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
                  title="${esc(x.file)}">${esc(x.file)}</td>
              <td>${x.line === 'premium' ? badge('混剪', 'purple') : badge('单集', 'info')}</td>
              <td class="mono" style="font-size:10px">${x.ep || '—'}</td>
              <td class="num">${x.dur || '—'}s</td>
              <td class="num">${x.size_mb || '—'} MB</td>
              <td>${x.organized
                ? badge('已整理', 'ok')
                : `<span title="还没整理，不能发布" style="color:var(--warn);font-size:10px">未整理</span>`}</td>
              <td>
                <button class="btn xs ${x.copyright_ok === 1 ? 'ok' : x.copyright_ok === 0 ? 'danger' : 'ghost'}"
                        data-cop="${x.id}" title="${esc(x.copyright_note || '')}">
                  ${x.copyright_ok === 1 ? '通过' : x.copyright_ok === 0 ? '不过' : '未检'}
                </button>
              </td>
              <td>${x.state === 'ready' ? badge('待用', 'ok', true)
                : x.state === 'used' ? badge('已用', 'mute', true)
                : badge('需处理', 'danger', true)}</td>
              <td class="row-actions">
                <button class="btn xs ghost" data-x="detail" data-id="${x.id}">详情</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;

  const m = modal({
    title: `${drama} · 文件清单`,
    width: 'wide',
    body,
    footer: [Object.assign(document.createElement('button'), {
      className: 'btn', textContent: '关闭', onclick: () => m.close(),
    })],
  });

  // 选中
  body.querySelectorAll('[data-sel]').forEach((cb) => {
    cb.onchange = () => {
      if (cb.checked) selected.add(cb.dataset.sel);
      else selected.delete(cb.dataset.sel);
      onChanged && onChanged();
    };
  });
  body.querySelector('[data-all]').onclick = () => {
    rows.filter((x) => x.state === 'ready').forEach((x) => selected.add(x.id));
    body.querySelectorAll('[data-sel]').forEach((cb) => { cb.checked = true; });
    toast('已全选', `${drama} 可发布素材`, 'ok');
    onChanged && onChanged();
  };
  body.querySelector('[data-none]').onclick = () => {
    rows.forEach((x) => selected.delete(x.id));
    body.querySelectorAll('[data-sel]').forEach((cb) => { cb.checked = false; });
    onChanged && onChanged();
  };

  // 版权
  body.querySelectorAll('[data-cop]').forEach((b) => {
    b.onclick = async (e) => {
      e.stopPropagation();
      const x = rows.find((v) => v.id === b.dataset.cop);
      if (!x) return;
      const next = x.copyright_ok === 1 ? 0 : 1;
      try {
        await api.setCopyright(x.id, next === 1,
          next === 1 ? '人工确认通过' : '人工标记不过');
        x.copyright_ok = next;
        b.className = `btn xs ${next === 1 ? 'ok' : 'danger'}`;
        b.textContent = next === 1 ? '通过' : '不过';
        toast(next === 1 ? '版权通过' : '版权不过', x.file,
          next === 1 ? 'ok' : 'warn');
        onChanged && onChanged();
      } catch (err) { toast('失败', err.message, 'err'); }
    };
  });

  // 详情
  body.querySelectorAll('[data-x="detail"]').forEach((b) => {
    b.onclick = () => openDetail(b.dataset.id);
  });
}

/* ---------------- 整理素材 ---------------- */
//
// 用户需求（2026-11-12）：
//   "增加一下整理素材的按钮，并且要求入库后的视频必须整理素材，
//    不然不算正式入库。整理素材要求按剧名/文件，把整理素材加上
//    素材名字转换什么语言"
//
// 流程：选语言 → 预览（看从哪搬到哪、名字怎么变）→ 确认执行。
// 执行后 library.organized=1，发布页才认这些素材。
async function openOrganize(root) {
  const sel = Array.from(selected || []);
  const items = store.library || [];

  let rootPath = store.libraryRoot || '';
  try {
    const p = await api.organizePath();
    if (p && p.root) rootPath = p.root;
  } catch (e) { /* 用本地值兜底 */ }

  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:13px;border-color:var(--ac-line)">
      <div class="card-body" style="font-size:11.5px;color:var(--tx-2);line-height:1.8">
        整理会把文件按 <b>剧名/文件名</b> 归档到：
        <div style="font-family:var(--mono);font-size:10.5px;color:var(--ac);
                    margin:6px 0;word-break:break-all">${esc(rootPath)}</div>
        <span style="color:var(--warn)">未整理（organized=0）的素材不会出现在发布页。</span>
      </div>
    </div>

    <div class="row-2" style="margin-bottom:12px">
      <div class="field">
        <label>剧名语言</label>
        <select class="select" id="og-lang">
          <option value="keep">保持原样（只清洗非法字符）</option>
          <option value="en">转英文（美区发布用，查已验证映射）</option>
          <option value="zh">转中文（有反向映射才换）</option>
        </select>
      </div>
      <div class="field">
        <label>范围</label>
        <select class="select" id="og-scope">
          <option value="selected" ${sel.length ? '' : 'disabled'}>
            选中的 ${sel.length} 条</option>
          <option value="unorganized" selected>所有未整理的素材</option>
          <option value="all">全部素材（重排目录）</option>
        </select>
      </div>
    </div>

    <div style="display:flex;gap:8px;margin-bottom:12px">
      <button class="btn sm" id="og-preview"><span data-icon="eye"></span>预览计划</button>
      <label class="switch" style="margin-left:auto">
        <input type="checkbox" id="og-move" checked />
        <span class="track"></span><span class="lbl">同时移动文件（关掉只改记录）</span>
      </label>
    </div>

    <div id="og-result" style="font-size:11.5px;color:var(--tx-3)">
      点「预览计划」看会怎么整理，确认后再执行。
    </div>`;

  const m = modal({
    title: '整理素材',
    width: 'wide',
    body,
    footer: [
      Object.assign(document.createElement('button'), {
        className: 'btn', textContent: '取消', onclick: () => m.close(),
      }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', id: 'og-run', textContent: '开始整理',
      }),
    ],
  });

  const res = body.querySelector('#og-result');
  let lastPlan = null;

  const buildReq = () => {
    const scope = body.querySelector('#og-scope').value;
    let ids = [];
    if (scope === 'selected') ids = sel;
    else if (scope === 'unorganized') {
      ids = items.filter((x) => !x.organized).map((x) => x.id);
    } else {
      ids = items.map((x) => x.id);
    }
    return {
      ids,
      lang: body.querySelector('#og-lang').value,
      moveFiles: body.querySelector('#og-move').checked,
    };
  };

  body.querySelector('#og-preview').onclick = async () => {
    const req = buildReq();
    if (!req.ids.length && body.querySelector('#og-scope').value === 'selected') {
      return toast('没有选中素材', '先在列表里勾选', 'err');
    }
    res.innerHTML = '<span class="spin"></span> 计算中…';
    try {
      const p = await api.organizePreview(req);
      lastPlan = p;
      if (!p.total) {
        res.innerHTML = '<span style="color:var(--tx-3)">没有需要整理的素材</span>';
        return;
      }
      res.innerHTML = `
        <div style="margin-bottom:8px;color:var(--tx-1)">
          共 <b>${p.total}</b> 条 · 改名 <b>${p.renameCount}</b>
          ${p.skipped ? ` · <span style="color:var(--warn)">跳过 ${p.skipped}</span>` : ''}
          ${p.conflicts ? ` · <span style="color:var(--danger)">同名冲突 ${p.conflicts}</span>` : ''}
        </div>
        <div class="tbl-wrap" style="max-height:300px;overflow-y:auto">
          <table class="tbl">
            <thead><tr><th>原文件</th><th>新文件</th><th>剧名</th><th></th></tr></thead>
            <tbody>
              ${p.items.slice(0, 100).map((x) => `
                <tr>
                  <td style="font-family:var(--mono);font-size:10px;max-width:180px;
                             overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
                      title="${esc(x.src)}">${esc(x.fileOld)}</td>
                  <td style="font-family:var(--mono);font-size:10px;color:var(--ac-2)">${esc(x.fileNew)}</td>
                  <td style="font-size:10.5px">${esc(x.dramaNew)}</td>
                  <td>${x.skip ? badge('跳过', 'warn')
                    : x.conflict ? badge('冲突', 'danger')
                    : x.dramaOld !== x.dramaNew ? badge('改名', 'info')
                    : badge('原样', 'mute')}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
    } catch (e) {
      res.innerHTML = `<span style="color:var(--danger)">预览失败: ${esc(e.message)}</span>`;
    }
  };

  const runBtn = document.querySelector('#og-run');
  if (runBtn) runBtn.onclick = async () => {
    const req = buildReq();
    if (!req.ids.length && body.querySelector('#og-scope').value === 'selected') {
      return toast('没有选中素材', '先在列表里勾选', 'err');
    }
    runBtn.disabled = true;
    runBtn.innerHTML = '<span class="spin"></span> 整理中…';
    try {
      const r = await api.organizeRun(req);
      toast(r.ok ? '整理完成' : '部分失败',
        `移动 ${r.moved} · 改名 ${r.renamed}${r.failed ? ` · 失败 ${r.failed}` : ''}`,
        r.ok ? 'ok' : 'warn', 6000);
      if (r.failed) {
        res.innerHTML = r.details.filter((d) => d.result === 'fail')
          .map((d) => `<div style="color:var(--danger)">${esc(d.file)}: ${esc(d.reason)}</div>`)
          .join('');
      } else {
        m.close();
      }
      if (typeof load === 'function') await load(root);
    } catch (e) {
      toast('整理失败', e.message, 'err', 6000);
    } finally {
      runBtn.disabled = false;
      runBtn.textContent = '开始整理';
    }
  };
}

/* ---------------- 扫描 ---------------- */
async function doScan(btn) {
  btn.disabled = true;
  const old = btn.innerHTML;
  btn.innerHTML = '<span class="spin" data-icon="refresh"></span>扫描中…';
  try {
    const r = await api.scanLibrary();
    // 轮询
    const t0 = Date.now();
    while (Date.now() - t0 < 600000) {
      await new Promise((res) => setTimeout(res, 2000));
      const j = await api.job(r.jobId);
      btn.innerHTML = `<span class="spin" data-icon="refresh"></span>${j.progress || 0}%`;
      if (['done', 'failed', 'blocked'].includes(j.status)) {
        const res = j.result || {};
        toast(j.status === 'done' ? '扫描完成' : '扫描失败',
          `新增 ${res.added || 0} · 跳过 ${res.skipped || 0} · 失败 ${res.failed || 0}`,
          j.status === 'done' ? 'ok' : 'err', 5000);
        break;
      }
    }
    await load(document.getElementById('view'));
  } catch (e) {
    toast('扫描失败', e.message, 'err');
  } finally {
    btn.disabled = false;
    btn.innerHTML = old;
  }
}

/* ---------------- 批量质检 ---------------- */
async function doQcBatch(btn) {
  const ids = [...selected];
  if (!ids.length) return toast('先选素材', '勾选左侧复选框', 'warn');
  btn.disabled = true;
  const old = btn.innerHTML;
  btn.innerHTML = '<span class="spin" data-icon="check"></span>质检中…';
  try {
    const r = await api.qcBatch(ids);
    toast('质检完成', `通过 ${r.passed} · 不过 ${r.failed}`, r.failed ? 'warn' : 'ok');
    await load(document.getElementById('view'));
  } catch (e) {
    toast('质检失败', e.message, 'err');
  } finally {
    btn.disabled = false;
    btn.innerHTML = old;
  }
}

/* ---------------- 原始素材 tab（2026-11-13） ----------------
 * 下载的未处理视频展示。paint 非 async，这里单独抽成 async 函数。
 */
async function renderSourceTab(inner) {
  let html = '';
  try {
    const resp = await api.sourceFiles();
    const groups = resp.items || [];
    html = groups.length ? groups.map((g) => `
      <div class="card" style="margin-bottom:12px">
        <div class="card-head"><div class="card-title">${esc(g.name)}
          <span class="cnt">${g.count}</span></div></div>
        <div class="card-body tight">
          ${g.files.slice(0, 8).map((f) => `
            <div class="litem">
              <div class="litem-main">
                <div class="litem-title">${esc(f.name)}</div>
                <div class="litem-sub">${f.sizeMb} MB ${f.relDir ? '· ' + esc(f.relDir) : ''}</div>
              </div>
            </div>`).join('')}
          ${g.files.length > 8 ? `<div class="litem" style="justify-content:center;color:var(--tx-3)">… 共 ${g.files.length} 个文件</div>` : ''}
        </div>
      </div>`).join('')
    : `<div style="padding:18px;text-align:center;color:var(--tx-3)">
         原始素材目录为空（${esc(resp.root)}）</div>`;
  } catch (e) {
    html = `<div style="padding:18px;color:var(--danger)">加载失败：${esc(e.message)}</div>`;
  }
  inner.innerHTML = `
    <div class="card" style="margin-bottom:13px;border-color:rgba(79,70,229,.28)">
      <div class="card-body" style="display:flex;gap:10px;align-items:flex-start">
        <span style="color:var(--ac);flex:0 0 auto">${icon('info', 15)}</span>
        <div style="font-size:11.5px;color:var(--tx-2);line-height:1.75">
          这里是<b>下载的原始素材</b>（未处理）。要出片请走
          <b>「短剧切片」</b>页：转录 → 张力打分 → 切片出片；
          切好的成片进「成品库」，整理后才能发布。
        </div>
      </div>
    </div>
    ${html}`;
}

/* ---------------- 管线辅助 ---------------- */
async function checkTools(root) {
  const box = document.getElementById('pl-tools');
  if (!box) return;
  try {
    const t = await api.pipelineTools();
    const missing = Object.entries(t.scripts || {}).filter(([, v]) => !v).map(([k]) => k);
    box.innerHTML = `
      <div class="kv"><span class="k">tools 目录</span>
        <span class="v" style="font-family:var(--mono);font-size:10.5px;color:${t.exists ? 'var(--ok)' : 'var(--danger)'}">
          ${esc(t.toolsDir)} ${t.exists ? '✓' : '✗'}</span></div>
      <div class="kv"><span class="k">状态目录</span>
        <span class="v" style="font-family:var(--mono);font-size:10.5px;color:${t.stateExists ? 'var(--ok)' : 'var(--warn)'}">
          ${esc(t.stateDir)} ${t.stateExists ? '✓' : '（不存在，首次运行会创建）'}</span></div>
      <div class="kv"><span class="k">脚本</span>
        <span class="v" style="font-size:10.5px">
          ${missing.length
            ? `<span style="color:var(--danger)">缺 ${missing.length} 个：${missing.join(', ')}</span>`
            : `<span style="color:var(--ok)">全部就绪（${Object.keys(t.scripts || {}).length} 个）</span>`}
        </span></div>`;
  } catch (e) {
    box.innerHTML = `<div style="color:var(--danger);font-size:11px">${esc(e.message)}</div>`;
  }
}

function renderSteps(steps) {
  if (!steps || !steps.length) return '';
  return `<div style="display:flex;flex-direction:column;gap:4px">
    ${steps.map((s) => `
      <div style="display:flex;gap:8px;font-size:11px;align-items:center">
        <span style="width:14px;color:${s.state === 'done' ? 'var(--ok)' : s.state === 'err' ? 'var(--danger)' : s.state === 'run' ? 'var(--ac)' : 'var(--tx-3)'}">
          ${s.state === 'done' ? '✓' : s.state === 'err' ? '✕' : s.state === 'run' ? '…' : '·'}
        </span>
        <span style="flex:1;color:var(--tx-2)">${esc(s.name)}</span>
        <span style="font-family:var(--mono);font-size:9.5px;color:var(--tx-3)">${esc(s.note || '')}</span>
      </div>`).join('')}
  </div>`;
}

async function loadPipelineHistory(root) {
  const box = document.getElementById('pl-history');
  if (!box) return;
  try {
    const d = await api.pipeline();
    const items = d.items || [];
    box.innerHTML = items.length ? items.slice(0, 10).map((j) => {
      const st = j.status === 'running' ? ['执行中', 'info']
        : j.status === 'done' ? ['完成', 'ok']
        : j.status === 'failed' ? ['失败', 'danger']
        : j.status === 'blocked' ? ['受阻', 'warn'] : ['排队', 'mute'];
      return `
        <div class="litem" style="flex-direction:column;align-items:stretch;gap:6px">
          <div style="display:flex;gap:8px;align-items:center">
            <div class="litem-title" style="flex:1">${esc(j.title)} ${badge(st[0], st[1])}</div>
            <span style="font-family:var(--mono);font-size:10px;color:var(--tx-3)">${j.progress || 0}%</span>
          </div>
          ${renderSteps(j.steps)}
          ${j.error ? `<div style="font-size:10px;color:var(--danger)">${esc(j.error)}</div>` : ''}
        </div>`;
    }).join('') : '<div style="padding:18px;text-align:center;color:var(--tx-3);font-size:11px">还没有处理任务</div>';
  } catch {
    box.innerHTML = '<div style="padding:18px;text-align:center;color:var(--tx-3);font-size:11px">加载失败</div>';
  }
}

/* ---------------- 清理版权不过 ---------------- */
async function doPurgeCopyright(root) {
  const fail = (store.library || []).filter((x) => x.copyright_ok === 0);
  if (!fail.length) return toast('没有版权不过的素材', '先用表格里的版权按钮标记', 'info');
  const mb = fail.reduce((a, x) => a + (+x.size_mb || 0), 0);

  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="border-color:rgba(248,113,113,.45);background:rgba(248,113,113,.05)">
      <div class="card-body" style="padding:12px 14px">
        <div style="font-size:13px;font-weight:620;color:var(--danger);margin-bottom:6px">
          将删除 ${fail.length} 个版权不过的素材（${mb.toFixed(0)} MB）
        </div>
        <div style="font-size:11.5px;color:var(--tx-2);line-height:1.7">
          磁盘文件会被真实删除。这是不可恢复操作。
        </div>
      </div>
    </div>
    <div class="field" style="margin-top:13px">
      <label>待删列表</label>
      <div class="card"><div class="card-body tight" style="max-height:200px;overflow-y:auto">
        ${fail.map((x) => `
          <div class="litem">
            <div class="litem-main">
              <div class="litem-title" style="font-size:11px">${esc(x.file)}</div>
              <div class="litem-sub">${esc(x.copyright_note || '版权不过')} · ${x.size_mb}MB</div>
            </div>
          </div>`).join('')}
      </div></div>
    </div>
    <div class="field">
      <label>输入 <b style="color:var(--danger)">DELETE</b> 确认</label>
      <input class="input" id="pc-confirm" placeholder="DELETE" style="font-family:var(--mono)" />
    </div>`;

  const m = modal({
    title: '清理版权不过素材', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn danger', textContent: '确认清理',
        onclick: async () => {
          if ((body.querySelector('#pc-confirm').value || '').trim().toUpperCase() !== 'DELETE') {
            return toast('输入不匹配', '请输入 DELETE', 'err');
          }
          try {
            const r = await api.purgeCopyrightFail(true);
            toast('已清理', `${r.deleted} 个，释放 ${r.freedMb} MB`, 'warn', 5000);
            m.close();
            await load(root);
          } catch (e) { toast('清理失败', e.message, 'err', 6000); }
        },
      }),
    ],
  });
}

/* ---------------- 删除（真删文件） ---------------- */
async function doDelete(root) {
  const ids = [...selected];
  if (!ids.length) return toast('先选素材', '勾选要删除的条目', 'warn');
  const rows = (store.library || []).filter((x) => ids.includes(x.id));
  const mb = rows.reduce((a, x) => a + (+x.size_mb || 0), 0);

  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="border-color:rgba(248,113,113,.45);background:rgba(248,113,113,.05)">
      <div class="card-body" style="padding:12px 14px">
        <div style="font-size:13px;font-weight:620;color:var(--danger);margin-bottom:6px">
          将永久删除 ${rows.length} 个文件（${mb.toFixed(0)} MB）
        </div>
        <div style="font-size:11.5px;color:var(--tx-2);line-height:1.7">
          磁盘上的 mp4 文件会被真实删除，不可恢复。数据库记录与队列引用一并清除。
        </div>
      </div>
    </div>
    <div class="field" style="margin-top:13px">
      <label>待删列表</label>
      <div class="card"><div class="card-body tight" style="max-height:200px;overflow-y:auto">
        ${rows.map((x) => `
          <div class="litem">
            <div class="litem-main">
              <div class="litem-title" style="font-size:11px">${esc(x.file)}</div>
              <div class="litem-sub">${esc(x.drama || '—')} · ${x.size_mb}MB · ${esc(x.path)}</div>
            </div>
          </div>`).join('')}
      </div></div>
    </div>
    <div class="field">
      <label>确认方式</label>
      <div style="display:flex;flex-direction:column;gap:8px;margin-top:4px">
        <label class="switch"><input type="checkbox" id="dl-file" checked />
          <span class="track"></span><span class="lbl">同时删除磁盘文件（真删）</span></label>
      </div>
      <div class="hint">取消勾选只移除记录，文件保留在磁盘上。</div>
    </div>
    <div class="field">
      <label>输入 <b style="color:var(--danger)">DELETE</b> 确认</label>
      <input class="input" id="dl-confirm" placeholder="DELETE" style="font-family:var(--mono)" />
    </div>`;

  const m = modal({
    title: '删除素材', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn danger', textContent: '确认删除',
        onclick: async () => {
          const v = (body.querySelector('#dl-confirm').value || '').trim().toUpperCase();
          if (v !== 'DELETE') return toast('输入不匹配', '请输入 DELETE', 'err');
          const delFile = body.querySelector('#dl-file').checked;
          try {
            const r = await api.deleteLibBatch(ids, delFile);
            toast('已删除',
              `${r.deleted} 个${delFile ? `，释放 ${r.freedMb} MB` : '（文件保留）'}`,
              'warn', 5000);
            selected.clear();
            m.close();
            await load(document.getElementById('view'));
          } catch (e) { toast('删除失败', e.message, 'err', 6000); }
        },
      }),
    ],
  });
}

/* ---------------- 推队列 ---------------- */
function openPush() {
  const ids = [...selected];
  if (!ids.length) return toast('先选素材', '勾选要发布的视频', 'warn');
  const ready = (store.library || []).filter((x) => ids.includes(x.id) && x.state === 'ready');
  if (!ready.length) return toast('没有可发布的', '选中的都已入队或质检未过', 'warn');

  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:13px">
      <div class="card-body" style="padding:11px 13px;font-size:11.5px;color:var(--tx-2);line-height:1.7">
        将推送 <b>${ready.length}</b> 条素材到待发队列。剧名会作为标签带进发布文案。
      </div>
    </div>
    <div class="field">
      <label>目标主页（可选）</label>
      <select class="select" id="ps-page">
        <option value="">— 不指定，排期时再选 —</option>
        ${(store.pages || []).filter((p) => p.health === 'ok').map((p) =>
          `<option value="${p.name}">${p.name} · ${p.assetId ? 'OK' : '缺 asset'}</option>`).join('')}
      </select>
    </div>
    <div class="field">
      <label>推送明细</label>
      <div class="card"><div class="card-body tight" style="max-height:220px;overflow-y:auto">
        ${ready.map((x) => `
          <div class="litem">
            <div class="litem-main">
              <div class="litem-title">${esc(x.drama)} ${x.ep || ''}
                ${x.line === 'premium' ? badge('混剪', 'purple') : badge('单集', 'info')}</div>
              <div class="litem-sub">${esc(x.file)} · ${x.dur}s · ${x.size_mb}MB</div>
            </div>
          </div>`).join('')}
      </div></div>
    </div>`;

  const m = modal({
    title: '推入排期队列', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '确认推送',
        onclick: async () => {
          try {
            const r = await api.pushLibrary({
              ids: ready.map((x) => x.id),
              page: body.querySelector('#ps-page').value,
              autoSchedule: true,
            });
            toast('已推送', `${r.pushed} 条进入队列`, 'ok');
            selected.clear();
            m.close();
            await load(document.getElementById('view'));
          } catch (e) { toast('推送失败', e.message, 'err'); }
        },
      }),
    ],
  });
}

/* ---------------- 详情 ---------------- */
async function openDetail(id) {
  const x = (store.library || []).find((i) => i.id === id);
  if (!x) return;
  const body = document.createElement('div');
  body.innerHTML = `
    <div style="font-family:var(--mono);font-size:11px;margin-bottom:10px;word-break:break-all;
                color:var(--tx-2)">${esc(x.path)}</div>
    <div class="grid g2" style="margin-bottom:14px">
      <div>
        <div class="kv"><span class="k">剧名</span><span class="v">${esc(x.drama || '—')}</span></div>
        <div class="kv"><span class="k">集号</span><span class="v">${x.ep || '—'}</span></div>
        <div class="kv"><span class="k">线</span><span class="v">${x.line === 'premium' ? '精品混剪' : '单集'}</span></div>
        <div class="kv"><span class="k">日期夹</span><span class="v">${x.day_dir || '—'}</span></div>
      </div>
      <div>
        <div class="kv"><span class="k">时长</span><span class="v">${x.dur || '—'}s</span></div>
        <div class="kv"><span class="k">大小</span><span class="v">${x.size_mb || '—'} MB</span></div>
        <div class="kv"><span class="k">分辨率</span><span class="v">${x.width && x.height ? x.width + '×' + x.height : '—'}</span></div>
        <div class="kv"><span class="k">状态</span><span class="v">${x.state}</span></div>
      </div>
    </div>
    <div class="section-title">标签（含剧名）</div>
    <div class="field">
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px" id="tg-list">
        ${(x.tagList || []).map((t) => `<span class="badge info">${esc(t)}</span>`).join('')
          || '<span style="font-size:11px;color:var(--tx-3)">无标签</span>'}
      </div>
      <div style="display:flex;gap:6px">
        <input class="input" id="tg-in" placeholder="加标签，回车确认" />
        <button class="btn sm" id="tg-add">添加</button>
      </div>
      <div class="hint">第一个标签会作为剧名（发布文案用）。</div>
    </div>
    <div class="section-title">操作</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn sm" data-x="qc">重新质检</button>
      <button class="btn sm ghost" data-x="open">路径</button>
      <button class="btn sm danger" data-x="del">删除（含文件）</button>
    </div>`;

  const m = modal({
    title: `${x.drama || '未分类'} · ${x.file}`, width: 'wide', body,
    footer: [Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: () => m.close() })],
  });

  const addTag = async () => {
    const inp = body.querySelector('#tg-in');
    const t = (inp.value || '').trim();
    if (!t) return;
    const tags = [...(x.tagList || []), t];
    try {
      await api.setLibraryTags(x.id, tags);
      x.tagList = tags;
      body.querySelector('#tg-list').innerHTML = tags.map((v) => `<span class="badge info">${esc(v)}</span>`).join('');
      inp.value = '';
      toast('已添加', t, 'ok');
    } catch (e) { toast('失败', e.message, 'err'); }
  };
  body.querySelector('#tg-add').onclick = addTag;
  body.querySelector('#tg-in').onkeydown = (e) => { if (e.key === 'Enter') addTag(); };

  body.querySelectorAll('[data-x]').forEach((b) => {
    b.onclick = async () => {
      const a = b.dataset.x;
      if (a === 'qc') {
        try {
          const r = await api.qcLibrary(x.id);
          toast(r.ok ? '质检通过' : '质检不过', (r.problems || []).join('；') || '全部项通过',
            r.ok ? 'ok' : 'warn');
          m.close();
          await load(document.getElementById('view'));
        } catch (e) { toast('失败', e.message, 'err'); }
      } else if (a === 'open') {
        copyText(x.path);
      } else {
        if (!confirm(`彻底删除「${x.file}」？\n\n磁盘文件会被真实删除，不可恢复。`)) return;
        try {
          await api.deleteLib(x.id, true);
          toast('已删除', `${x.file}（含文件）`, 'warn');
          selected.delete(x.id);
          m.close();
          await load(document.getElementById('view'));
        } catch (e) { toast('删除失败', e.message, 'err', 6000); }
      }
    };
  });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/* ---------------- 导出 / 导入素材（2026-11-13） ----------------
 * ⚠ 这是搬运**视频文件**，不是备份素材库。
 *   导出 → 把 mp4 复制到你选的目录（按剧名分文件夹）
 *   导入 → 把某个目录里的 mp4 复制进素材库，可选自动入库
 *   不生成索引文件、不覆盖同名文件。
 */
function openExport() {
  const sel = Array.from(selected);
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.28)">
      <div class="card-body" style="padding:10px 12px;font-size:11px;color:var(--tx-2);line-height:1.7">
        <b>导出素材</b>：把视频文件复制到指定目录，按「剧名/文件名」分好。
        <b>只复制文件</b>，不带数据库。可以拷给别人、拷到U盘。
      </div>
    </div>
    <div class="field"><label>导出哪些</label>
      <select id="ex-scope">
        ${sel.length ? `<option value="sel">已选中的 ${sel.length} 条</option>` : ''}
        <option value="all">全部素材</option>
      </select>
    </div>
    <div class="field"><label>导出到哪个目录</label>
      <input id="ex-dir" placeholder="留空 = 软件目录\\data\\export_files" />
      <div class="hint">填个你方便找的位置，比如 D:\\导出素材</div>
    </div>
    <div class="field"><label>目录结构</label>
      <select id="ex-flat">
        <option value="0">按剧名分文件夹（推荐）</option>
        <option value="1">全部平铺在一起</option>
      </select>
    </div>
    <div id="ex-result"></div>`;
  const m = modal({
    title: '导出素材文件', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn ghost', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '开始导出', onclick: async (e) => {
        const btn = e.target;
        btn.disabled = true;
        btn.textContent = '复制中…';
        const scope = body.querySelector('#ex-scope').value;
        try {
          const r = await api.exportFiles({
            ids: scope === 'sel' ? sel : [],
            outDir: body.querySelector('#ex-dir').value.trim(),
            flat: body.querySelector('#ex-flat').value === '1',
          });
          if (!r.ok && !r.copied) throw new Error(r.error || '没有可导出的文件');
          body.querySelector('#ex-result').innerHTML = `
            <div class="card" style="border-color:rgba(16,185,129,.35)"><div class="card-body">
              <div style="font-size:12px;font-weight:600;color:var(--ok);margin-bottom:6px">
                导出完成 · ${r.copied} 个文件 · ${r.totalMb}MB</div>
              <div style="font-size:11px;color:var(--tx-2);word-break:break-all">
                目录：${esc(r.outDir)}</div>
              ${r.skipped ? `<div style="font-size:11px;color:var(--warn);margin-top:4px">跳过 ${r.skipped}（源文件不存在）</div>` : ''}
            </div></div>`;
          toast('导出完成', `${r.copied} 个文件 · ${r.totalMb}MB`, 'ok');
          btn.textContent = '再次导出';
          btn.disabled = false;
        } catch (err) {
          toast('导出失败', err.message, 'err');
          btn.disabled = false;
          btn.textContent = '开始导出';
        }
      } }),
    ],
  });
}

function openImport(root) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.28)">
      <div class="card-body" style="padding:10px 12px;font-size:11px;color:var(--tx-2);line-height:1.7">
        <b>导入素材</b>：把某个目录里的视频<b>复制进素材库</b>（或原始素材目录）。
        同名同大小会自动跳过，不会覆盖你已有的文件。
      </div>
    </div>
    <div class="field"><label>方式</label>
      <div class="pub-seg">
        <button class="on" data-im="dir">从电脑目录复制</button>
        <button data-im="up">上传文件</button>
      </div>
    </div>
    <div id="im-dir-box" class="field"><label>源目录</label>
      <input id="im-src" placeholder="比如 D:\\要导入的素材" />
      <div class="hint">会递归找这个目录下所有 mp4/mov/mkv/webm</div>
    </div>
    <div id="im-up-box" class="field" style="display:none"><label>选择视频文件</label>
      <input type="file" id="im-files" multiple accept="video/*" />
    </div>
    <div class="field"><label>放进哪里</label>
      <select id="im-target">
        <option value="素材库">素材库（成品库，可直接发布）</option>
        <option value="视频素材">视频素材（原始素材，待处理）</option>
      </select>
    </div>
    <div class="field"><label>指定剧名（可选）</label>
      <input id="im-drama" placeholder="留空 = 按源目录名自动判断" />
    </div>
    <div id="im-result"></div>`;
  const m = modal({
    title: '导入素材文件', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn ghost', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '开始导入', id: 'im-go' }),
    ],
  });

  let mode = 'dir';
  body.querySelectorAll('[data-im]').forEach((b) => {
    b.onclick = () => {
      mode = b.dataset.im;
      body.querySelectorAll('[data-im]').forEach((x) => x.classList.toggle('on', x === b));
      body.querySelector('#im-dir-box').style.display = mode === 'dir' ? '' : 'none';
      body.querySelector('#im-up-box').style.display = mode === 'up' ? '' : 'none';
    };
  });

  body.querySelector('#im-go').onclick = async (e) => {
    const btn = e.target;
    btn.disabled = true;
    btn.textContent = '复制中…';
    const target = body.querySelector('#im-target').value;
    const asDrama = body.querySelector('#im-drama').value.trim();
    const out = body.querySelector('#im-result');
    try {
      let srcDir = body.querySelector('#im-src').value.trim();
      if (mode === 'up') {
        const fl = body.querySelector('#im-files').files;
        if (!fl || !fl.length) throw new Error('先选视频文件');
        out.innerHTML = '<div style="padding:10px;color:var(--tx-3);font-size:11.5px">上传中…</div>';
        const up = await api.importFilesUpload(Array.from(fl));
        srcDir = up.dir;
      }
      if (!srcDir) throw new Error('填源目录，或切成上传模式');
      const r = await api.importFiles({
        srcDir, target, asDrama, autoScan: target === '素材库',
      });
      if (!r.ok && !r.copied) throw new Error(r.error || '没有可导入的文件');
      out.innerHTML = `
        <div class="card" style="border-color:rgba(16,185,129,.35)"><div class="card-body">
          <div style="font-size:12px;font-weight:600;color:var(--ok);margin-bottom:6px">
            导入完成 · 复制 ${r.copied} 个文件 · ${r.totalMb}MB</div>
          <div style="font-size:11px;color:var(--tx-2);word-break:break-all">
            目标：${esc(r.destDir)}</div>
          ${r.skipped ? `<div style="font-size:11px;color:var(--tx-3);margin-top:4px">跳过 ${r.skipped}（同名已存在）</div>` : ''}
          ${r.failed ? `<div style="font-size:11px;color:var(--warn);margin-top:4px">失败 ${r.failed}</div>` : ''}
        </div></div>`;
      toast('导入完成', `复制 ${r.copied} 个文件`, 'ok');
      await load(root);
      btn.textContent = '完成';
    } catch (err) {
      toast('导入失败', err.message, 'err');
      btn.disabled = false;
      btn.textContent = '开始导入';
    }
  };
}
/* ---------------- 成品 / 原始素材分离（2026-11-17） ----------------
 * 用户复盘："把所有素材混一起了，同一个文件夹里面不能出现同名的
 *            所以就没有剧名了"
 *
 * 根因：原始素材和切片产出都叫 EP03.mp4 → Windows 加 _2 后缀 →
 *       分不清哪个是成品哪个是原片（实测完全随机）
 *
 * 解决：按码率分开
 *   成品（码率 ≥3Mbps，1080x1920，34-49s）→ 素材库/<剧名>/成品/
 *   原始（码率 <3Mbps，多 576x1024）        → 视频素材/<剧名>/原始/
 */
async function openMaterialSplit(root) {
  let st = null;
  try { st = await api.materialSplit(); }
  catch (e) { return toast('读取失败', e.message, 'err'); }

  const body = document.createElement('div');
  const paint = (s) => {
    body.innerHTML = `
      <div class="card" style="margin-bottom:12px;border-color:${
        s.separated ? 'rgba(34,197,94,.35)' : 'rgba(251,191,36,.45)'}">
        <div class="card-body" style="font-size:11px;line-height:1.85">
          <b>${s.separated ? '✓ 已经分开' : '⚠ 还没分开'}</b>
          <div style="margin-top:6px;color:var(--tx-2)">
            素材库（成品）：<b>${s.libFinished}</b> 个 · 顶层未分类：<b>${s.libTopLevel}</b> 个<br/>
            视频素材（原始）：<b>${s.srcRaw}</b> 个
          </div>
          <div class="hint" style="margin-top:6px;color:${
            s.separated ? 'var(--tx-3)' : 'var(--warn)'}">${esc(s.advice || '')}</div>
        </div>
      </div>

      <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.25)">
        <div class="card-body" style="font-size:10.5px;line-height:1.9;color:var(--tx-2)">
          <b>为什么会有这个问题</b><br/>
          原始素材和切片产出<b>同名</b>（都叫 <span class="mono">EP03.mp4</span>），
          放在同一个文件夹必然冲突，Windows 就自动加 <span class="mono">_2</span> 后缀。<br/>
          结果同一个剧里 <span class="mono">EP03</span> 可能是成品、
          <span class="mono">EP03_2</span> 反而可能是原始片 —— 完全随机，没法靠名字判断。<br/><br/>
          <b>怎么分</b>：逐个读取视频真实参数<br/>
          · 成品 → 码率 <b>≥3 Mbps</b>、1080×1920、时长 34-49 秒<br/>
          · 原始 → 码率 <b>&lt;3 Mbps</b>、多为 576×1024、时长 33-218 秒
        </div>
      </div>

      <div id="ms-out"></div>
    `;
  };
  paint(st);

  const out = () => document.getElementById('ms-out');
  const show = (h) => { const o = out(); if (o) o.innerHTML = h; };
  const busy = (b, on, txt) => { if (b) { b.disabled = on; if (txt) b.textContent = txt; } };

  const btnClose = Object.assign(document.createElement('button'), {
    className: 'btn', textContent: '关闭', onclick: () => m.close(),
  });
  const btnScan = Object.assign(document.createElement('button'), {
    className: 'btn', textContent: '先扫描预览',
    onclick: async () => {
      busy(btnScan, true, '扫描中…');
      show('<div style="font-size:11px;color:var(--tx-3)">正在逐个读取视频参数，文件多时要几分钟…</div>');
      try {
        const r = await api.materialSplitScan();
        const rows = (r.plan || []).slice(0, 40);
        show(`
          <div class="card" style="border-color:rgba(79,70,229,.3)">
            <div class="card-body" style="font-size:11px;line-height:1.85">
              <b>扫描完成：共 ${r.total} 个</b><br/>
              成品 <b style="color:var(--ok)">${r.finished}</b> 个 ·
              原始 <b style="color:var(--warn)">${r.raw}</b> 个
              ${r.unknown ? ` · 判不出 ${r.unknown} 个（不处理）` : ''}
              <div style="margin-top:8px;max-height:220px;overflow:auto;
                          font-size:10px;color:var(--tx-2)">
                ${rows.map((x) => `<div style="padding:1px 0">
                  <span style="color:${x.type === 'fin' ? 'var(--ok)' : 'var(--warn)'}">
                    [${x.type === 'fin' ? '成品' : '原始'}]</span>
                  ${esc(x.file)}
                </div>`).join('')}
                ${r.plan.length > 40 ? `<div style="color:var(--tx-3)">
                  …还有 ${r.plan.length - 40} 条</div>` : ''}
              </div>
              <div style="margin-top:8px;color:var(--tx-3);font-size:10px">
                ${esc(r.note || '')}</div>
            </div>
          </div>`);
      } catch (e) {
        show(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
      } finally { busy(btnScan, false, '先扫描预览'); }
    },
  });
  const btnApply = Object.assign(document.createElement('button'), {
    className: 'btn primary', textContent: '执行分离',
    onclick: async () => {
      if (!confirm('执行分离？\n\n成品留在素材库，原始素材移到视频素材。\n只移动不删除，同名自动加序号。')) return;
      busy(btnApply, true, '处理中…');
      show('<div style="font-size:11px;color:var(--tx-3)">正在移动文件…</div>');
      try {
        const r = await api.materialSplitApply();
        show(`<div class="card" style="border-color:rgba(34,197,94,.35)">
          <div class="card-body" style="font-size:11px;line-height:1.85">
            <b style="color:var(--ok)">✓ 分离完成</b><br/>
            移动文件：<b>${r.moved || 0}</b> 个<br/>
            更新记录：<b>${r.updated || 0}</b> 条<br/>
            ${r.kindFixed ? `修正混剪标记：${r.kindFixed} 条<br/>` : ''}
            ${(r.emptyDirsRemoved || []).length
              ? `清理空文件夹：${r.emptyDirsRemoved.length} 个<br/>` : ''}
            ${(r.errors || []).length
              ? `<span style="color:var(--warn)">失败 ${r.errors.length} 个</span>` : ''}
          </div>
        </div>`);
        toast('分离完成', `移动 ${r.moved || 0} 个文件`, 'ok', 7000);
        if (r.layout) paint(r.layout);
        setTimeout(() => {
          try { load(root); } catch (e) {}
        }, 900);
      } catch (e) {
        show(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
      } finally { busy(btnApply, false, '执行分离'); }
    },
  });

  const m = modal({
    title: '成品 / 原始素材分离',
    body,
    footer: [btnClose, btnScan, btnApply],
    width: '620px',
  });
}

/* ---------------- 素材库路径设置（2026-11-13） ----------------
 * 用户问"这个素材库的路径能改吗" → 能改。
 * 写进 data/config.json，重启生效。只改配置，不搬文件。
 */
async function openSetRoot() {
  let cfg = {};
  try { cfg = await api.pathConfig(); } catch (e) { return toast('读取失败', e.message, 'err'); }

  const body = document.createElement('div');
  const row = (key, label, hint) => {
    const it = cfg[key] || {};
    return `
      <div class="field"><label>${label}</label>
        <input id="pc-${key}" value="${esc(it.path || '')}" />
        <div class="hint">${hint}
          ${it.exists ? '' : '<span style="color:var(--warn)">· 目录不存在（保存时会自动创建）</span>'}
          ${it.writable === false ? '<span style="color:var(--danger)">· 不可写</span>' : ''}
        </div>
      </div>`;
  };
  body.innerHTML = `
    <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.28)">
      <div class="card-body" style="padding:10px 12px;font-size:11px;color:var(--tx-2);line-height:1.7">
        <b>改路径只写配置，不会自动搬文件。</b>
        换目录后建议：① 把旧素材库的文件挪到新目录 → ② 点「扫描目录」重建记录。
        留空 = 不改这一项。
      </div>
    </div>
    ${row('libraryRoot', '素材库（成品库）', '整理后的成片，可直接发布')}
    ${row('videoRoot', '视频素材（原始素材）', '下载的未处理视频')}
    ${row('outputRoot', '处理好素材', '切片/管线产出的成片')}
    <div id="pc-result"></div>`;
  const m = modal({
    title: '素材目录设置', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn ghost', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '保存', onclick: async (e) => {
        const btn = e.target;
        btn.disabled = true;
        btn.textContent = '保存中…';
        try {
          const payload = {
            libraryRoot: (body.querySelector('#pc-libraryRoot').value || '').trim(),
            videoRoot: (body.querySelector('#pc-videoRoot').value || '').trim(),
            outputRoot: (body.querySelector('#pc-outputRoot').value || '').trim(),
          };
          const r = await api.setPathConfig(payload);
          body.querySelector('#pc-result').innerHTML = `
            <div class="card" style="border-color:rgba(16,185,129,.35)"><div class="card-body">
              <div style="font-size:12px;font-weight:600;color:var(--ok);margin-bottom:6px">已保存</div>
              <div style="font-size:11px;color:var(--tx-2);line-height:1.8">
                ${(r.changed || []).map((x) => esc(x)).join('<br/>')}
              </div>
              <div style="font-size:11px;color:var(--warn);margin-top:8px">
                ${esc(r.note || '重启软件后生效')}</div>
            </div></div>`;
          toast('已保存', '重启软件后生效', 'ok', 6000);
          btn.textContent = '已保存';
        } catch (err) {
          toast('保存失败', err.message, 'err');
          btn.disabled = false;
          btn.textContent = '保存';
        }
      } }),
    ],
  });
}
/* ---------------- 素材体检 / 清理（2026-11-13） ----------------
 * 用户问："那些明显不是处理好的素材怎么也在里面能不能清理了"
 *          "越扫越多"
 * 这个弹窗列出所有问题素材，分类勾选清理。
 */
async function openAudit(root) {
  const body = document.createElement('div');
  body.innerHTML = '<div style="padding:20px;text-align:center;color:var(--tx-3)">体检中…</div>';
  const m = modal({ title: '素材体检 / 清理', width: 'wide', body,
    footer: [Object.assign(document.createElement('button'),
      { className: 'btn ghost', textContent: '关闭', onclick: () => m.close() })] });

  let a = null;
  try { a = await api.libraryAudit(); }
  catch (e) { body.innerHTML = `<div style="padding:20px;color:var(--danger)">${esc(e.message)}</div>`; return; }

  const KINDS = [
    ['missing', '文件不存在', '记录还在但文件没了（移动/删除/改名）'],
    ['duplicate', '同名重复', '同一部剧同一个文件名有多条记录'],
    ['noDrama', '没有剧名', '无法生成标题，发布时会被过滤'],
    ['tooShort', '时长过短', '少于 15 秒，Reels 不合格'],
    ['badName', '文件名不规范', '如 01.mp4、MAIN.mp4，建议用「整理素材」改名'],
  ];

  const rows = KINDS.map(([k, title, desc]) => {
    const it = (a.issues || {})[k] || { count: 0, suggest: '' };
    const cln = k === 'badName';   // 不规范文件名不删，只提示改名
    return `
      <div class="litem">
        <label style="display:flex;align-items:center;gap:9px;flex:1;cursor:pointer">
          <input type="checkbox" data-k="${k}" ${it.count && !cln ? '' : 'disabled'}
                 ${it.count && !cln ? 'checked' : ''} />
          <div class="litem-main">
            <div class="litem-title">${title}
              <span style="color:${it.count ? 'var(--warn)' : 'var(--tx-3)'}">${it.count}</span></div>
            <div class="litem-sub">${desc}</div>
          </div>
        </label>
        ${cln && it.count ? `<span style="font-size:10.5px;color:var(--tx-3)">用「整理素材」改名</span>` : ''}
      </div>`;
  }).join('');

  body.innerHTML = `
    <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.28)">
      <div class="card-body" style="display:flex;gap:14px;align-items:center">
        <div><div style="font-size:11px;color:var(--tx-3)">总素材</div>
          <div style="font-size:19px;font-weight:700">${a.total}</div></div>
        <div><div style="font-size:11px;color:var(--tx-3)">健康</div>
          <div style="font-size:19px;font-weight:700;color:var(--ok)">${a.healthy}</div></div>
      </div>
    </div>
    <div class="card" style="margin-bottom:12px"><div class="card-body tight">${rows}</div></div>
    <label class="switch" style="display:flex;align-items:center;gap:8px;font-size:11.5px">
      <input type="checkbox" id="au-files" />
      <span>同时删除磁盘上的视频文件</span>
    </label>
    <div style="font-size:10.5px;color:var(--warn);margin-top:6px">
      不勾只删记录，视频文件保留在磁盘上（推荐先这样）
    </div>
    <div id="au-result"></div>`;

  const btn = Object.assign(document.createElement('button'), {
    className: 'btn danger', textContent: '清理选中项',
  });
  btn.onclick = async () => {
    const what = $$('input[data-k]:checked', body).map((x) => x.dataset.k);
    if (!what.length) return toast('没选要清理的项', '', 'warn');
    const delFiles = body.querySelector('#au-files').checked;
    btn.disabled = true; btn.textContent = '清理中…';
    try {
      const r = await api.libraryClean({ what, dryRun: false, deleteFiles: delFiles });
      body.querySelector('#au-result').innerHTML = `
        <div class="card" style="border-color:rgba(16,185,129,.35)"><div class="card-body">
          <div style="font-size:12px;font-weight:600;color:var(--ok)">
            已清理 ${r.deleted} 条记录${r.filesDeleted ? ` · 删除 ${r.filesDeleted} 个文件` : ''}</div>
        </div></div>`;
      toast('清理完成', `${r.deleted} 条记录`, 'ok');
      await load(root);
      setTimeout(() => { m.close(); openAudit(root); }, 900);
    } catch (e) {
      toast('清理失败', e.message, 'err');
      btn.disabled = false; btn.textContent = '清理选中项';
    }
  };
  m.footer.appendChild(btn);
}
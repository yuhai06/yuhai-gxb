"""统一路径解析 —— 换机器/换目录不用改代码。

优先级（高 → 低）：
    ① 环境变量（YUHAI_WORKSPACE / YUHAI_TOOLS / YUHAI_LIBRARY /
       YUHAI_OUTPUT / YUHAI_SOURCE_ROOTS / YUHAI_FONTS / YUHAI_AUDIO / PD_PROXY）
    ② 数据目录下的 config.json（用户可在「设置」里改，界面写入）
    ③ 自动发现（从可执行文件/代码位置向上找工作区标志）
    ④ 平台默认（Windows 用 %USERPROFILE% 下的固定名，其它系统用 ~ 下同名目录）

设计原则：任何路径都返回 Path，且**不保证存在**；调用方需要时自己 mkdir。
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from functools import lru_cache
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------- 基础

IS_WIN = os.name == "nt"
IS_FROZEN = bool(getattr(sys, "frozen", False))


def _app_root() -> Path:
    """软件文件夹（三个素材目录的统一父目录）。

    2026-11-13 目录迁移：素材库 / 视频素材 / 处理好素材
    统一放在软件文件夹下，不再散在工作区或盘根。
    打包后 = exe 所在目录（如 E:\雨海工作台）；
    开发时优先取 config.json 的 workspace（与 exe 行为一致），
    兜底用仓库根。
    """
    v = _env_or_cfg("YUHAI_APP_ROOT", "workspace")
    if v:
        return Path(v)
    if IS_FROZEN:
        return Path(sys.executable).resolve().parent
    # 开发模式：与 exe 一致，优先数据目录配置的 workspace
    try:
        cfg = _data_dir() / "config.json"
        if cfg.exists():
            d = json.loads(cfg.read_text(encoding="utf-8"))
            w = d.get("workspace")
            if w:
                return Path(w)
    except Exception:
        pass
    return Path(__file__).resolve().parent.parent


def _exe_dir() -> Path:
    """打包后：exe 所在目录；开发时：仓库根（backend 的上级）。"""
    if IS_FROZEN:
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _data_dir() -> Path:
    """数据目录。

    优先级：
      ① YUHAI_DATA_DIR 环境变量
      ② 打包后：%LOCALAPPDATA%\\YuhaiWorkbench
      ③ 开发时：仓库根的 data\\（backend 的**上级**，那里才有真实数据）
      ④ 兜底：backend\\data
    """
    env = os.environ.get("YUHAI_DATA_DIR")
    if env:
        return Path(env)
    if IS_FROZEN:
        base = os.environ.get("LOCALAPPDATA") or str(Path.home())
        return Path(base) / "YuhaiWorkbench"
    # 开发：仓库根 = backend 的上级
    repo_root = Path(__file__).resolve().parent.parent.parent
    for cand in (repo_root / "data", _exe_dir() / "data"):
        # 有 workbench.db 且非空 → 就是它
        db = cand / "workbench.db"
        try:
            if db.exists() and db.stat().st_size > 20 * 1024:
                return cand
        except OSError:
            pass
    return repo_root / "data"


DATA_DIR = _data_dir()

# 工作区标志文件：有这些之一就认为是工作区根
_WORKSPACE_MARKS = ("tools", "素材库", "yuhai-workbench", "短剧切片完整流程.md")

# 盘根、系统目录不能当工作区
_BAD_WORKSPACE = {
    "c:\\", "d:\\", "e:\\", "f:\\", "g:\\",
    "c:\\windows", "c:\\program files", "c:\\program files (x86)",
    "c:\\users", "c:\\programdata",
}


def _is_bad_ws(p: Path) -> bool:
    s = str(p).lower().rstrip("\\") + "\\"
    if s in _BAD_WORKSPACE:
        return True
    # 盘根：D:\ 这种只有 3 个字符
    try:
        if p.parent == p:
            return True
        if len(str(p).rstrip("\\")) <= 3 and str(p)[1:3] == ":\\":
            return True
    except Exception:
        pass
    return False


def _user_cfg() -> dict[str, Any]:
    p = DATA_DIR / "config.json"
    if not p.exists():
        return {}
    try:
        raw = json.loads(p.read_text(encoding="utf-8-sig"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


_CFG = _user_cfg()


def _cfg_get(*keys: str) -> str:
    """从 config.json 取第一个命中的键（大小写不敏感）。"""
    lower = {k.lower(): v for k, v in _CFG.items()}
    for k in keys:
        v = lower.get(k.lower())
        if isinstance(v, str) and v.strip():
            return v.strip()
        if isinstance(v, list) and v:
            return ";".join(str(x) for x in v)
    return ""


def _env_or_cfg(env_key: str, *cfg_keys: str) -> str:
    v = os.environ.get(env_key, "").strip()
    if v:
        return v
    return _cfg_get(*cfg_keys)


# ---------------------------------------------------------------- 工作区

def _workspace_is_shared(p: Path) -> bool:
    """这个目录是不是「很多程序共用的公共目录」（桌面/文档/下载等）。

    这类目录不能当工作区，否则素材库会散落一地。
    """
    low = str(p).lower().replace("/", "\\").rstrip("\\")
    for bad in ("\\desktop", "\\documents", "\\downloads", "\\pictures",
                "\\videos", "\\music", "\\onedrive", "\\appdata",
                "\\local", "\\roaming", "\\temp", "\\tmp"):
        if low.endswith(bad):
            return True
    return False


def workspace() -> Path:
    """工作区根（放 tools / 素材 / 素材库 / 处理好素材 的那一层）。

    优先找**已有素材类目录**的位置，其次看标志文件；
    盘根、系统目录、桌面/文档这类公共目录一律排除。
    """
    v = _env_or_cfg("YUHAI_WORKSPACE", "workspace", "workspace_root", "工作区")
    if v:
        return Path(v)

    start = _exe_dir()

    # ① 从 exe 目录向上找「已经有素材类目录」的位置（最可靠）
    for base in [start, *start.parents][:6]:
        if _is_bad_ws(base) or _workspace_is_shared(base):
            continue
        for name in ("素材库", "素材", "处理好素材"):
            try:
                if (base / name).is_dir():
                    return base
            except OSError:
                continue

    # ② 找标志文件
    for base in [start, *start.parents][:6]:
        if _is_bad_ws(base) or _workspace_is_shared(base):
            continue
        for mark in _WORKSPACE_MARKS:
            try:
                if (base / mark).exists():
                    return base
            except OSError:
                continue

    # ③ 兜底：exe 所在目录（打包后是 <root>\雨海工作台\）
    #    不用父目录，因为父目录可能是盘根或桌面这类"共享大目录"。
    return start


WORKSPACE = workspace()


def _first_existing(cands: list[Path], fallback: Path) -> Path:
    for c in cands:
        try:
            if c.exists():
                return c
        except OSError:
            continue
    return fallback


# ---------------------------------------------------------------- 工具脚本

def tools_dir() -> Path:
    """切片/抓取脚本目录（pipeline2.py 所在）。

    优先级：**包内目录最优先**（换电脑拷贝整个文件夹即可用），
    其次环境变量/配置，最后才是工作区。
    """
    # ① 随包分发（打包后可移植）
    for c in (_exe_dir() / "_internal" / "tools",
              _exe_dir() / "tools",
              _exe_dir().parent / "tools"):
        if (c / "pipeline2.py").exists() or (c / "pd_drama.py").exists():
            return c
    # ② 用户显式配置
    v = _env_or_cfg("YUHAI_TOOLS", "tools", "tools_dir", "工具目录")
    if v:
        return Path(v)
    # ③ 工作区 / 数据目录
    cands = [
        WORKSPACE / "tools",
        DATA_DIR / "tools",
    ]
    for c in cands:
        if (c / "pipeline2.py").exists() or (c / "pd_drama.py").exists():
            return c
    return _first_existing(cands, cands[0])


def models_dir() -> Path:
    """ASR 模型目录（打包后可移植）。

    优先包内 models\\，其次 tools/models（开发机把模型放脚本旁边最方便），
    再次数据目录。每个模型一个子目录，含 config.json / model.bin /
    tokenizer.json / vocabulary.txt（faster-whisper 标准结构）。
    """
    v = _env_or_cfg("YUHAI_MODELS", "models", "models_dir", "模型目录")
    if v:
        return Path(v)
    for c in (_exe_dir() / "models",
              _exe_dir() / "_internal" / "models",
              tools_dir() / "models",
              DATA_DIR / "models",
              WORKSPACE / "models"):
        try:
            if c.exists() and any(c.glob("faster-whisper-*")):
                return c
        except OSError:
            continue
    # 都不存在 → 默认放包内（新机器首次下载会建）
    return _exe_dir() / "models"



def state_dir() -> Path:
    return tools_dir() / "_state"


# ---------------------------------------------------------------- 素材

def library_root() -> Path:
    """素材库根：按 剧名/文件 两层（整理后的正式入库结构）。

    2026-11-13 目录迁移：统一放在软件文件夹下（exe 所在目录）。
    """
    v = _env_or_cfg("YUHAI_LIBRARY", "library", "library_root", "素材库")
    if v:
        return Path(v)
    return _app_root() / "素材库"


def output_root() -> Path:
    """成片根目录（单集_日期 / 精品混剪_日期）。

    2026-11-13 目录迁移：三个素材目录统一放进软件文件夹
    （<exe目录>/素材库、视频素材、处理好素材），不再散在外面。
    优先选**已经有成片**的目录，避免换环境后突然找不到历史产出。
    """
    v = _env_or_cfg("YUHAI_OUTPUT", "output", "output_root", "成片目录")
    if v:
        return Path(v)
    cands = [_app_root() / "处理好素材", WORKSPACE / "处理好素材",
             WORKSPACE / "成片"]
    cands.append(DATA_DIR / "output")

    # 有 mp4 的优先
    for c in cands:
        try:
            if c.is_dir():
                for sub in c.iterdir():
                    if sub.is_dir() and any(sub.rglob("*.mp4")):
                        return c
        except OSError:
            continue
    # 其次存在的
    for c in cands:
        if c.exists():
            return c
    return cands[0]


def source_roots() -> list[Path]:
    """源素材可能存在的所有位置（按优先级）。

    ⚠ 2026-11-17 纠错（用户："原始素材和处理好的素材为什么放一起"）：
        原来这里把 `library_root()/"原始素材"` 排在候选**第二位**，
        于是原始素材被塞进素材库内部，跟成片混在一棵树里。
        现在**只认独立目录** `视频素材/`，素材库内部不再作为素材来源。
        历史遗留的 `素材库/原始素材` 由 fix_layout() 一次性挪出去。
    """
    v = _env_or_cfg("YUHAI_SOURCE_ROOTS", "source_roots", "源素材目录")
    if v:
        out: list[Path] = []
        for p in v.split(";"):
            s = p.strip()
            if not s:
                continue
            # 过滤掉混放写法（素材库内部的东西不该当素材来源）
            if "素材库" in s and "原始素材" in s:
                continue
            out.append(Path(s))
        if out:
            return out
    cands = [
        source_root(),                 # <软件>\视频素材\  ← 唯一权威位置
        WORKSPACE / "素材",
    ]
    # 同级历史位置（工作区不是盘根时才算）
    if not _is_bad_ws(WORKSPACE.parent):
        cands.append(WORKSPACE.parent / "视频素材")
    out2: list[Path] = []
    for c in cands:
        if c not in out2:
            out2.append(c)
    return out2


def asset_roots() -> list[Path]:
    """素材库页面要扫的根（素材库 + 成片 + 原始素材）。

    ⚠ 2026-11-13 用户反馈"扫描目录不行"：
        之前只扫 [素材库, 成片]，下载功能存的原始素材目录
        （视频素材/）不在范围内，扫出来永远是 0。
        现在把原始素材目录也加进来。
    """
    v = _env_or_cfg("YUHAI_ASSET_ROOTS", "asset_roots")
    if v:
        return [Path(p) for p in v.split(";") if p.strip()]
    return [library_root(), output_root(), source_root()]


def source_root() -> Path:
    """原始素材根（下载的未处理视频）。

    ⚠ 2026-11-17 用户反馈纠正：
        「为什么原始素材和处理好的素材是放一起的，怎么不分开文件夹放」

    之前 source_roots() 里把 library_root()/"原始素材" 排在候选前面，
    而且 config.json 的 source_roots 又显式写成了
        E:\雨海工作台\素材库\原始素材;E:\雨海工作台\视频素材
    结果**原始素材被塞进了素材库内部**，跟成片混在一棵树上。

    现在的硬性约定（四个目录互不嵌套）：
        <软件目录>/视频素材/      ← 只放下载的原始素材（未处理）
        <软件目录>/处理好素材/    ← 只放切片/管线产出（待整理）
        <软件目录>/素材库/        ← 只放整理好的成片（可直接发布）
        <软件目录>/素材库/<剧名>/ ← 每部剧一个文件夹

    三者是**平级兄弟目录**，任何一方都不在另一方内部。
    """
    v = _env_or_cfg("YUHAI_SOURCE_ROOT", "source_root", "source_root_dir")
    if v:
        return Path(v)
    return _app_root() / "视频素材"


# ---------------- 目录结构自检与迁移（2026-11-17） ----------------

DECLARED_DIRS = ("视频素材", "处理好素材", "素材库")


def layout_check() -> dict:
    """检查四个目录是否互相嵌套（嵌套就是用户说的「放一起」）。"""
    app = _app_root()
    paths = {
        "原始素材": source_root(),
        "处理好素材": output_root(),
        "素材库": library_root(),
    }
    problems: list[dict] = []
    for ia, (na, pa) in enumerate(paths.items()):
        for ib, (nb, pb) in enumerate(paths.items()):
            if ia >= ib:
                continue
            try:
                ra = pa.resolve()
                rb = pb.resolve()
            except OSError:
                continue
            # A 在 B 里面，或 B 在 A 里面 —— 都算混放
            def _inside(x: Path, y: Path) -> bool:
                try:
                    x.relative_to(y)
                    return True
                except ValueError:
                    return False
            if _inside(ra, rb):
                problems.append({"bad": na, "inside": nb,
                                 "path": str(pa), "parent": str(pb)})
            elif _inside(rb, ra):
                problems.append({"bad": nb, "inside": na,
                                 "path": str(pb), "parent": str(pa)})

    return {
        "appRoot": str(app),
        "dirs": {k: str(v) for k, v in paths.items()},
        "separated": not problems,
        "problems": problems,
        "nestedSource": any(
            p for p in problems
            if p["bad"] == "原始素材" or p["inside"] == "原始素材"),
        "advice": ("目录结构正常：原始素材 / 处理好素材 / 素材库 三者平级"
                   if not problems else
                   "有目录被套在另一个里面，点「修正目录结构」自动挪出来"),
    }


def fix_layout() -> dict:
    """把「素材库\\原始素材」这类嵌套目录挪出来，变成平级兄弟目录。

    安全原则：
      · **只移动，不删除**
      · 目标已存在且非空 → 不覆盖，改成合并子目录
      · 移动失败（占用中）→ 记录错误，不影响其它
      · 移动完把 config.json 里的 source_roots 一并纠正
    """
    moved: list[dict] = []
    errors: list[dict] = []
    app = _app_root()
    want_src = app / "视频素材"
    lib = library_root()

    # ① 处理素材库内部的「原始素材」
    nested = lib / "原始素材"
    if nested.exists() and nested.is_dir():
        try:
            files = [p for p in nested.rglob("*") if p.is_file()]
            if files:
                want_src.mkdir(parents=True, exist_ok=True)
                n = 0
                for f in files:
                    rel = f.relative_to(nested)
                    dst = want_src / rel
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    if dst.exists():
                        # 同名不覆盖，加后缀
                        stem, suf = dst.stem, dst.suffix
                        i = 2
                        while dst.exists():
                            dst = dst.parent / f"{stem}_{i}{suf}"
                            i += 1
                    shutil.move(str(f), str(dst))
                    n += 1
                moved.append({"from": str(nested), "to": str(want_src),
                              "files": n})
                # 清掉空壳（含空子目录）
                for d in sorted(nested.rglob("*"), key=lambda x: -len(str(x))):
                    if d.is_dir():
                        try:
                            d.rmdir()
                        except OSError:
                            pass
                try:
                    nested.rmdir()
                except OSError:
                    pass
            else:
                # 空的直接删壳
                try:
                    nested.rmdir()
                    moved.append({"from": str(nested), "to": "", "files": 0,
                                  "note": "空目录已移除"})
                except OSError as e:
                    errors.append({"path": str(nested), "error": str(e)[:100]})
        except Exception as e:
            errors.append({"path": str(nested), "error": str(e)[:150]})

    # ② 纠正 config.json 里的 source_roots（去掉素材库里面的那种写法）
    try:
        cfgp = DATA_DIR / "config.json"
        if cfgp.exists():
            raw = json.loads(cfgp.read_text(encoding="utf-8-sig"))
            changed = False
            for key in ("source_roots", "sourceRoots", "源素材目录"):
                v = raw.get(key)
                if not v:
                    continue
                if isinstance(v, str):
                    items = [x for x in v.split(";") if x.strip()]
                elif isinstance(v, list):
                    items = [str(x) for x in v]
                else:
                    continue
                keep = []
                for it in items:
                    # 「素材库\原始素材」这种属于混放，丢掉
                    if "素材库" in it and "原始素材" in it:
                        changed = True
                        continue
                    keep.append(it)
                if str(want_src) not in keep:
                    keep.insert(0, str(want_src))
                    changed = True
                raw[key] = ";".join(keep) if isinstance(v, str) else keep
            if changed:
                cfgp.write_text(json.dumps(raw, ensure_ascii=False, indent=2),
                                encoding="utf-8")
                moved.append({"from": "config.json", "to": str(want_src),
                              "files": 0, "note": "已修正 source_roots"})
    except Exception as e:
        errors.append({"path": "config.json", "error": str(e)[:150]})

    # ③ 建齐四个目录
    for d in (want_src, output_root(), lib):
        try:
            d.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            errors.append({"path": str(d), "error": str(e)[:100]})

    return {"ok": not errors, "moved": moved, "errors": errors,
            "layout": layout_check()}


# ---------------------------------------------------------------- 字体 / 音频

def _dsh_home() -> Path:
    return Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))


def fonts_dir() -> Path:
    """字幕/CTA 用的字体目录。**包内优先**（可移植）。"""
    # ① 随包分发
    for c in (_exe_dir() / "assets" / "fonts",
              _exe_dir() / "_internal" / "assets" / "fonts"):
        if c.exists() and any(c.glob("*.ttf")):
            return c
    v = _env_or_cfg("YUHAI_FONTS", "fonts", "fonts_dir", "字体目录")
    if v:
        return Path(v)
    cands = [
        DATA_DIR / "assets" / "fonts",
        WORKSPACE / "assets" / "fonts",
        _dsh_home() / "fonts",
        Path("C:/Windows/Fonts") if IS_WIN else Path("/usr/share/fonts"),
    ]
    return _first_existing(cands, cands[0])


def audio_dir() -> Path:
    """BGM / 音效目录。**包内优先**（可移植）。"""
    for c in (_exe_dir() / "assets" / "audio",
              _exe_dir() / "_internal" / "assets" / "audio"):
        if c.exists() and any(c.glob("*.wav")):
            return c
    v = _env_or_cfg("YUHAI_AUDIO", "audio", "audio_dir", "音频目录")
    if v:
        return Path(v)
    cands = [
        DATA_DIR / "assets" / "audio",
        WORKSPACE / "assets" / "audio",
        _dsh_home() / "audio",
    ]
    return _first_existing(cands, cands[0])


# ---------------------------------------------------------------- 二进制

def ffmpeg() -> tuple[Path | None, Path | None]:
    """返回 (ffmpeg, ffprobe)。优先内置，其次 PATH。"""
    names = ("ffmpeg.exe", "ffprobe.exe") if IS_WIN else ("ffmpeg", "ffprobe")
    dirs = [
        _exe_dir() / "bin",
        _exe_dir() / "_internal" / "bin",
        Path(__file__).resolve().parent.parent / "bin",
        tools_dir() / "bin",
    ]
    ff = fp = None
    for d in dirs:
        a, b = d / names[0], d / names[1]
        if a.exists() and ff is None:
            ff = a
        if b.exists() and fp is None:
            fp = b
    if ff is None:
        w = shutil.which("ffmpeg")
        ff = Path(w) if w else None
    if fp is None:
        w = shutil.which("ffprobe")
        fp = Path(w) if w else None
    return ff, fp


def curl() -> Path | None:
    w = shutil.which("curl") or shutil.which("curl.exe")
    if w:
        return Path(w)
    for p in (Path("C:/Windows/System32/curl.exe"), Path("/usr/bin/curl")):
        if p.exists():
            return p
    return None


# ---------------------------------------------------------------- 网络

def proxy() -> str:
    """抓取用代理。没有代理也不报错，返回空串表示直连。"""
    v = _env_or_cfg("PD_PROXY", "proxy", "grab_proxy", "代理")
    if v:
        return v
    # 常见本地代理端口，探到哪个用哪个
    import socket
    for port in (7897, 7890, 10809, 1080, 8889):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.35):
                return f"http://127.0.0.1:{port}"
        except OSError:
            continue
    return ""


# ---------------------------------------------------------------- 汇总

@lru_cache(maxsize=1)
def snapshot() -> dict[str, Any]:
    """当前所有关键路径 + 存在性，供环境自检和设置页用。"""
    ff, fp = ffmpeg()
    return {
        "platform": {
            "os": sys.platform,
            "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "frozen": IS_FROZEN,
            "exeDir": str(_exe_dir()),
        },
        "dataDir": str(DATA_DIR),
        "workspace": str(WORKSPACE),
        "tools": str(tools_dir()),
        "state": str(state_dir()),
        "models": str(models_dir()),
        "library": str(library_root()),
        "output": str(output_root()),
        "sourceRoots": [str(p) for p in source_roots()],
        "assetRoots": [str(p) for p in asset_roots()],
        "fonts": str(fonts_dir()),
        "audio": str(audio_dir()),
        "ffmpeg": str(ff) if ff else "",
        "ffprobe": str(fp) if fp else "",
        "curl": str(curl()) if curl() else "",
        "proxy": proxy(),
        "configFile": str(DATA_DIR / "config.json"),
        "exists": {
            "tools": tools_dir().exists(),
            "models": models_dir().exists(),
            "library": library_root().exists(),
            "output": output_root().exists(),
            "fonts": fonts_dir().exists(),
            "audio": audio_dir().exists(),
            "ffmpeg": bool(ff),
        },
    }


def ensure_dirs() -> list[str]:
    """创建所有该存在的目录，返回创建了哪些。"""
    made = []
    for p in (DATA_DIR, library_root(), output_root(), source_roots()[0],
              DATA_DIR / "logs", DATA_DIR / "cache"):
        try:
            if not p.exists():
                p.mkdir(parents=True, exist_ok=True)
                made.append(str(p))
        except OSError:
            continue
    return made

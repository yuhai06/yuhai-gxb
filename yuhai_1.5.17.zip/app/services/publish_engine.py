"""发布编排层：内部数据直连的批量发布。

设计目标（与旧实现的区别）
--------------------------
旧链路的问题：
  · 素材/主页/分配全在前端算（publish.js 700+ 行），后端只做白名单校验
  · 文案三套并存（reel_caption / caption / caption_tpl），占位符三种方言
  · 文案"轮转"依赖 units.title_id，而发布链路从不写这一列 → 永远失效
  · worker 的 ok=true 只代表"命令跑完"，被当成"发布成功"
  · 一次 order 的信息散在 jobs / publish_locks / worker state.json 三处

本模块的做法：
  · 素材从 library / queue 读（drama / ep 是切片阶段算好的准确值）
  · 主页从 pages + accounts + envs 读（health / skip_publish / asset_id 全查）
  · 文案唯一入口 build_caption()，占位符 {{X}} 只在这里替换一次
  · 一条订单 = publish_orders 一行 + publish_items N 行，逐条固化文案
  · 每个主页单独调一次 worker（clipsPerPage=K, pages=[一个]），
    这样"哪个素材发到了哪个主页"是可验证的事实，不是推测
  · 执行结果写回 units / pages / library / queue / promo_links / title_pool

worker 交互的一个硬约束
----------------------
ReelsPublisher 的 worker 只接受 `directory`，不接受精确文件列表
（`selectedFiles` 在 v19.7 里根本没有实现）。

所以这里给每个主页建一个 staging 目录，用硬链接（同盘）或复制（跨盘）
把该主页要发的 K 条放进去，再把这个目录交给 worker。
好处：
  · 精确控制"哪条发给哪个主页"
  · worker 的"发布后删源"只会删 staging 里的链接，库里母片不动
  · material_roots 天然收敛在 staging 目录内
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import random
import re
import secrets
import shutil
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.publish.engine")

# ─────────────────────────────────────────────────────────────
# 常量
# ─────────────────────────────────────────────────────────────

MIN_CLIPS = 1
MAX_CLIPS = 20
DEFAULT_CLIPS = 1

CAPTION_STYLES = ("simple", "template")
MATERIAL_SOURCES = ("library", "queue", "path")
ALLOC_MODES = ("merge", "per_drama")

# 订单主状态
ORDER_STATES = (
    "CREATED", "PREPARING", "RUNNING", "COMPLETED",
    "ATTENTION", "BLOCKED", "FAILED", "CANCELLED",
)

# 明细状态
ITEM_STATES = (
    "PENDING", "RUNNING", "COMMITTED", "REJECTED",
    "FAILED", "BLOCKED", "SKIPPED", "ATTENTION",
)

# worker 回执里视为"这个主页成功"的页面状态
OK_PAGE_STATES = {"published", "done", "success", "completed", "ok"}


# ─────────────────────────────────────────────────────────────
# 数据结构
# ─────────────────────────────────────────────────────────────

@dataclass
class Material:
    key: str                  # lib:<id> / q:<id> / path:<abs>
    path: str
    file: str
    drama: str
    ep: str
    kind: str                 # single | mix
    source: str               # library | queue | path
    lib_id: str = ""
    queue_id: str = ""
    bytes: int = 0
    sha256: str = ""
    # 内容类型（library.dtype：revenge/romance/...）
    # 主页绑定可以按类型而不仅按剧名（2026-11-13）
    dtype: str = ""


@dataclass
class PageTarget:
    page_id: str
    asset_id: str
    name: str
    env_code: str
    account_id: str = ""
    c_user: str = ""
    cdp_port: int = 0
    health: str = "ok"
    skip_publish: int = 0


@dataclass
class CaptionPlan:
    body: str
    title: str
    link: str
    title_id: str = ""
    link_id: str = ""
    source: str = ""


@dataclass
class ItemPlan:
    page: PageTarget
    material: Material
    slot: int
    caption: CaptionPlan | None = None


@dataclass
class AllocationResult:
    items: list[ItemPlan] = field(default_factory=list)
    shortage: int = 0
    available: int = 0
    required: int = 0
    note: str = ""


class PublishError(ValueError):
    """业务校验失败（可直接展示给用户）。"""
    def __init__(self, msg: str, code: str = "PUBLISH_INVALID"):
        super().__init__(msg)
        self.code = code


# ─────────────────────────────────────────────────────────────
# 路径自愈：DB 里的 path 可能因为目录改名/搬移而失效
# ─────────────────────────────────────────────────────────────

_PATH_INDEX: dict[str, str] | None = None


def _path_index() -> dict[str, str]:
    """按文件名建索引：{文件名小写: 绝对路径}，懒加载 + 缓存。

    实机情况：库里存的是 E:\处理好素材\单集_2026-11-06\剧名\文件.mp4，
    但磁盘上已经改成 E:\处理好素材\剧名\文件.mp4（少了一层日期目录）。
    130 个 mp4 都在，只是 DB 里的路径过期了。

    如果因为没有回退，发布页会显示"可发素材 0 条"，
    而实际有 130 条 —— 这是线上真实遇到的情况。
    """
    global _PATH_INDEX
    if _PATH_INDEX is not None:
        return _PATH_INDEX
    idx: dict[str, str] = {}
    roots: list[Path] = []
    try:
        from app import paths as _paths
        for p in (_paths.output_root(), _paths.library_root()):
            if p and str(p) not in [str(x) for x in roots]:
                roots.append(Path(p))
    except Exception:
        pass
    # 再加一层：DB 里出现过的父目录的父目录（覆盖用户手工换过目录的情况）
    try:
        for r in db.q("SELECT DISTINCT path FROM library WHERE path IS NOT NULL LIMIT 500"):
            p = Path(r["path"] or "")
            for up in (p.parent.parent.parent, p.parent.parent):
                if str(up) and up.exists() and str(up) not in [str(x) for x in roots]:
                    roots.append(up)
    except Exception:
        pass

    for root in roots:
        try:
            for f in root.rglob("*.mp4"):
                idx.setdefault(f.name.lower(), str(f))
        except Exception:
            continue
    _PATH_INDEX = idx
    log.info("path index built: %d files from %d roots", len(idx), len(roots))
    return idx


def reset_path_index() -> None:
    """素材目录变了 / 重新扫描后调用，强制下次重建索引。"""
    global _PATH_INDEX
    _PATH_INDEX = None


def resolve_path(raw: str) -> str | None:
    """把 DB 里的路径还原成一个真实存在的文件路径。

    ⚠ 2026-11-13 改造（用户要求"不要管是哪个盘，是软件里面目录就行"）：
        优先走 materialpath.to_absolute() —— 支持相对形式（lib:素材库/...）
        以及旧绝对路径的自动重定位。换机器/换盘都能用。
        最后才按文件名索引兜底（处理彻底改名的情况）。

    ① 相对形式 / 旧绝对路径重定位 → 命中即用
    ② 原名在索引里 → 用索引里的新路径
    ③ 都不行 → None
    """
    if not raw:
        return None

    # ① 可移植解析
    try:
        from app.services import materialpath as mp
        hit = mp.to_absolute(raw)
        if hit:
            return hit
    except Exception as e:
        log.debug("materialpath 解析失败: %s", e)

    # ② 直接当绝对路径试（兜底）
    p = Path(raw)
    if p.is_file():
        return str(p)

    # ③ 文件名索引兜底
    hit = _path_index().get(p.name.lower())
    if hit and Path(hit).is_file():
        return hit
    return None


# ─────────────────────────────────────────────────────────────
# 1. 素材来源
# ─────────────────────────────────────────────────────────────

def resolve_materials(
    *,
    source: str = "library",
    materials: list[str] | None = None,
    directory: str = "",
    include_used: bool = False,
    kinds: tuple[str, ...] = ("single",),
) -> list[Material]:
    """返回候选素材。全部从内部数据派生，不猜目录名。

    source = "library" : library 表 state=ready（含版权过滤）
    source = "queue"   : queue 表 state=ready
    source = "path"    : materials 里显式给的绝对路径（剧名从路径反推）

    路径全部经 resolve_path() 自愈：DB 路径失效时按文件名回退。
    """
    source = (source or "library").strip().lower()
    if source not in MATERIAL_SOURCES:
        raise PublishError(f"未知素材来源 {source}")

    if source == "library":
        return _materials_from_library(include_used=include_used, kinds=kinds)
    if source == "queue":
        return _materials_from_queue(kinds=kinds)
    return _materials_from_paths(materials or [], directory)


def _materials_from_library(*, include_used: bool, kinds: tuple[str, ...],
                            require_organized: bool = True) -> list[Material]:
    """从素材库取可发素材。

    ⚠ require_organized=True（默认）：只发**整理过**的素材。
    用户要求："入库后的视频必须整理素材，不然不算正式入库"。
    整理 = 按 剧名/文件 归档到素材库根目录（见 api/organize.py）。
    没整理的素材剧名混乱、文件名不规范，发出去标题和内容对不上。
    """
    states = ("ready", "used") if include_used else ("ready",)
    ph = ",".join("?" * len(states))
    kp = ",".join("?" * len(kinds))
    org_clause = "AND organized=1" if require_organized else ""
    rows = db.q(
        f"""SELECT id, path, file, drama, ep, kind, size_mb, copyright_ok, dtype
              FROM library
             WHERE state IN ({ph})
               AND kind IN ({kp})
               AND path IS NOT NULL AND path <> ''
               AND (copyright_ok IS NULL OR copyright_ok = 1)
               {org_clause}
             ORDER BY created_at ASC""",
        (*states, *kinds),
    )
    out: list[Material] = []
    for r in rows:
        real = resolve_path(r["path"])
        if not real:
            continue
        out.append(Material(
            key=f"lib:{r['id']}",
            path=real,
            file=r["file"] or Path(real).name,
            drama=(r["drama"] or "").strip(),
            ep=(r["ep"] or "").strip(),
            kind=r["kind"] or "single",
            source="library",
            lib_id=r["id"],
            bytes=int(float(r["size_mb"] or 0) * 1048576),
            dtype=(r["dtype"] or "").strip(),
        ))
    return out


def _materials_from_queue(*, kinds: tuple[str, ...]) -> list[Material]:
    kp = ",".join("?" * len(kinds))
    rows = db.q(
        f"""SELECT id, path, file, drama, ep, kind, size_mb
              FROM queue
             WHERE state = 'ready' AND kind IN ({kp})
             ORDER BY added_at ASC""",
        kinds,
    )
    out: list[Material] = []
    for r in rows:
        real = resolve_path(r["path"])
        if not real:
            continue
        out.append(Material(
            key=f"q:{r['id']}",
            path=real,
            file=r["file"] or Path(real).name,
            drama=(r["drama"] or "").strip(),
            ep=(r["ep"] or "").strip(),
            kind=r["kind"] or "single",
            source="queue",
            queue_id=r["id"],
            bytes=int(float(r["size_mb"] or 0) * 1048576),
        ))
    return out


def _materials_from_paths(paths: list[str], directory: str = "") -> list[Material]:
    """手工指定的文件。剧名从 DB 反查（路径能对上 library/queue 就用库里的值）。"""
    root = Path(directory) if directory else None
    out: list[Material] = []
    for raw in paths:
        p = Path(raw)
        if not p.is_absolute() and root:
            p = root / raw
        try:
            p = p.resolve(strict=True)
        except Exception:
            raise PublishError(f"素材不存在: {raw}")
        if not p.is_file():
            raise PublishError(f"素材不是文件: {raw}")

        row = db.q1("SELECT id, drama, ep, kind FROM library WHERE path=?", (str(p),))
        src, lib_id, queue_id = "path", "", ""
        drama = ep = ""
        kind = "single"
        if row:
            lib_id = row["id"]
            drama = row["drama"] or ""
            ep = row["ep"] or ""
            kind = row["kind"] or "single"
            src = "library"
        else:
            qrow = db.q1("SELECT id, drama, ep, kind FROM queue WHERE path=?", (str(p),))
            if qrow:
                queue_id = qrow["id"]
                drama = qrow["drama"] or ""
                ep = qrow["ep"] or ""
                kind = qrow["kind"] or "single"
                src = "queue"
            else:
                # 都没有 → 从路径推（父目录名当剧名，去尾部数字/下划线）
                drama = _drama_from_path(p)

        out.append(Material(
            key=f"path:{p}",
            path=str(p),
            file=p.name,
            drama=drama.strip(),
            ep=ep.strip(),
            kind=kind,
            source=src,
            lib_id=lib_id,
            queue_id=queue_id,
        ))
    return out


def _drama_from_path(p: Path) -> str:
    name = p.parent.name or p.stem
    import re
    s = re.sub(r"^\d+[_.\-\s]+", "", name)
    s = re.sub(r"[_\-][0-9]{15,}$", "", s)
    s = s.replace("_", " ").strip()
    return re.sub(r"\s{2,}", " ", s)


# ─────────────────────────────────────────────────────────────
# 2. 主页来源
# ─────────────────────────────────────────────────────────────

def resolve_pages(
    page_ids: list[str],
    *,
    require_publishable: bool = True,
) -> list[PageTarget]:
    """显式主页列表 → 可发布主页。空列表直接拒绝（不再有"全部"隐式语义）。

    入参可以是两种 ID 之一（前端从 sources 拿到的主页可能是任一种）：
        · pages.page_id   = profile id（61595086030150）
        · pages.asset_id  = asset id  （1381470255051396）
        · 内核 plan 里的 pageId 其实就是 asset id，且这些主页
          可能还没同步进 pages 表（discoverPages 抓到了但没入库）

    所以这里做三级查找：profile id → asset id → 内核 plan 兜底。
    以前只查 page_id，导致从内核补出来的主页（Yu04 / Z01 / Z03Shop / Z05Shop）
    一律报「主页不存在」。
    """
    ids = [str(x).strip() for x in (page_ids or []) if str(x).strip()]
    if not ids:
        raise PublishError("必须显式指定要发布的主页")

    seen: set[str] = set()
    uniq: list[str] = []
    for pid in ids:
        if pid not in seen:
            seen.add(pid)
            uniq.append(pid)

    ph = ",".join("?" * len(uniq))
    rows = db.q(
        f"""SELECT p.page_id, p.asset_id, p.name, p.health, p.skip_publish,
                   p.env_code,
                   a.id AS account_id, a.c_user,
                   e.cdp_port, e.status AS env_status
              FROM pages p
              LEFT JOIN accounts a
                     ON a.env_code = p.env_code AND a.enabled = 1
              LEFT JOIN envs e
                     ON e.container_code = p.env_code
             WHERE p.page_id IN ({ph}) OR p.asset_id IN ({ph})""",
        (*uniq, *uniq),
    )
    by_profile = {str(r["page_id"]): r for r in rows}
    by_asset = {str(r["asset_id"]): r for r in rows if r["asset_id"]}

    # 内核 plan 兜底：库里没有但内核抓到了的主页
    plan_by_asset: dict[str, dict] = {}
    try:
        from app.services import reels as _rl
        for a in _rl.plan_pages():
            aid = str(a.get("pageId") or "")
            if aid:
                plan_by_asset[aid] = a
    except Exception:
        pass

    out: list[PageTarget] = []
    problems: list[str] = []
    for pid in uniq:
        r = by_profile.get(pid) or by_asset.get(pid)
        if r:
            name = r["name"] or pid
            asset_id = str(r["asset_id"] or "")
            env_code = str(r["env_code"] or "")
            cdp_port = int(r["cdp_port"] or 0)
            env_status = r["env_status"] or ""
            account_id = str(r["account_id"] or "")
            c_user = str(r["c_user"] or "")
            health = r["health"] or "ok"
            skip = int(r["skip_publish"] or 0)
            from_plan = False
        else:
            plan_row = plan_by_asset.get(pid)
            if not plan_row:
                problems.append(f"主页不存在: {pid}")
                continue
            # 只在核心里有：用 plan 里的信息，环境从 plan 拿
            name = str(plan_row.get("pageName") or pid)
            asset_id = pid
            env_code = str(plan_row.get("environmentId") or "")
            cdp_port = 0
            env_status = "running"
            account_id = ""
            c_user = ""
            health = "ok"
            skip = 0
            from_plan = True

            # 补一次 cdp_port（plan 里没有）
            try:
                row = db.q1("SELECT cdp_port, status FROM envs WHERE container_code=?",
                            (env_code,))
                if row:
                    cdp_port = int(row["cdp_port"] or 0)
                    env_status = row["status"] or env_status
            except Exception:
                pass

        if require_publishable:
            if not asset_id:
                problems.append(f"{name} 缺 asset_id（先到「主页与授权」同步）")
                continue
            if health != "ok":
                problems.append(f"{name} 状态 {health}，不能发布")
                continue
            if skip:
                problems.append(f"{name} 已标记「手动发，自动别碰」")
                continue
            if not env_code:
                problems.append(f"{name} 没绑定指纹环境")
                continue
            if env_status != "running":
                problems.append(f"{name} 的环境未启动")
                continue

        out.append(PageTarget(
            page_id=str(r["page_id"]) if r else pid,
            asset_id=asset_id,
            name=name,
            env_code=env_code,
            account_id=account_id,
            c_user=c_user,
            cdp_port=cdp_port,
            health=health,
            skip_publish=skip,
        ))

    if problems:
        raise PublishError("；".join(problems[:6]))
    return out


# ─────────────────────────────────────────────────────────────
# 3. 文案（唯一入口）
# ─────────────────────────────────────────────────────────────

MAX_CAPTION_LEN = 2200


def build_caption(
    *,
    page_id: str,
    drama: str = "",
    ep: str = "",
    style: str = "simple",
    fixed_title: str = "",
    fixed_link: str = "",
    reference_title: str = "",
    template_body: str = "",
    language: str = "",
    pick_only: bool = False,
    preset_title: str = "",
) -> CaptionPlan:
    """唯一文案入口。所有来源从 DB 派生，占位符 {{X}} 在这里替换一次。

    优先级（从高到低）：
        ① preset_title                批次预先分配的标题（正常路径）
        ② fixed_title / fixed_link    本次显式指定，原样用
        ③ template_body               整段模板（4 行结构）
        ④ reference_title             多行模板或单行标题（用户手填）
        ⑤ 剧名兜底

    reference_title 支持整段粘贴：
        用户经常直接把这一整段贴进「文案模板」：
            🎬NEXT EPISODE👉🏻<链接>
            🌟Watch all episodes for FREE
            🔍Title: "{{DRAMA}}".
            Click the link in the title to search the show name...
        这时不能当成单行标题处理，必须：
          · 保留换行
          · 把里面自带的链接抠出来当 link
          · {{DRAMA}} 换成剧名
          · 如果没写链接，就在末尾补一条
    """
    style = (style or "simple").strip().lower()
    if style not in CAPTION_STYLES:
        raise PublishError(f"未知文案风格 {style}")

    # ⚠ 2026-11-16（用户："我发美区所以得用英文，素材库都没有把文件名改英文"）：
    #   language 指定了目标语言时，剧名换成该语言的版本（走 drama_names 表）。
    #   这样正文里的 🔍Title: "{{DRAMA}}" 也是英文，
    #   观众按剧名去搜能搜到。
    #   图片/视频文件名不动（改了会找不到文件），只换文案里的显示名。
    drama_orig = drama
    if language and drama:
        try:
            from app.services import caption as _cap
            _localized = _cap.drama_title(drama, language)
            if _localized and _localized != drama:
                drama = _localized
                log.debug("剧名 %s → %s（%s）", drama_orig, drama, language)
        except Exception as e:
            log.warning("剧名语言转换失败 %s: %s", drama, e)

    ref = (reference_title or "").strip()
    fixed_t = (fixed_title or "").strip()

    # ③ 多行模板优先（用户手填的整段）
    if not fixed_t and not preset_title.strip() and _looks_like_template(ref):
        return _build_from_paragraph(
            text=ref, page_id=page_id, drama=drama, ep=ep,
            fixed_link=fixed_link, pick_only=pick_only)

    # ① 批次分配的标题 / ② 显式标题
    title, title_id, title_src = _pick_title(
        page_id, fixed_t, ref, drama, pick_only=pick_only,
        preset_title=preset_title)
    link, link_id, link_src = _pick_link(page_id, fixed_link, pick_only=pick_only)

    if style == "template":
        from app.services import reel_caption as rc
        body = rc.build_auto(
            drama_name=drama or title,
            variant=_variant(drama, page_id, ep),
            lang=language,
            link=link,
        )
        body = _fill(body, {"DRAMA": drama, "EP": ep, "TITLE": title, "LINK": link})
    else:
        from app.services import platform_cfg as pc
        # 2026-11-17：必须把剧名传进去，否则标题里不会有剧名
        body = _compose_simple(title, link, drama=drama)
        body = _fill(body, {"DRAMA": drama, "EP": ep, "TITLE": title, "LINK": link})

    if template_body.strip():
        tpl = _fill(template_body.strip(), {
            "DRAMA": drama or title, "EP": ep, "TITLE": title, "LINK": link,
        })
        if link and link not in tpl:
            tpl = f"{tpl}\n\n{link}"
        body = tpl + _platform_tags(style)

    problems = validate_caption(body, style=style, link=link, drama=drama)
    if problems:
        raise PublishError("文案不合规：" + "；".join(problems), "PUBLISH_CAPTION_INVALID")

    return CaptionPlan(body=body, title=title, link=link,
                       title_id=title_id or "", link_id=link_id or "",
                       source=f"{title_src}+{link_src}")


def _looks_like_template(text: str) -> bool:
    """判断用户填的是"整段文案"还是"一行标题"。

    只要不是"单行短标题"就当模板处理。判据（命中任意一条即认为整段）：
        · 含换行
        · 含 {{...}} 占位符
        · 含 http(s) 链接
        · 长度 > 120 字符

    之前要求命中两条才算，导致「标题 + 换行 + 链接」这种两行写法
    被当成单行标题处理，链接被当成标题正文的一部分。
    """
    if not text:
        return False
    if "\n" in text:
        return True
    if "{{" in text and "}}" in text:
        return True
    if "http://" in text or "https://" in text:
        return True
    if len(text) > 120:
        return True
    return False


def _build_from_paragraph(*, text: str, page_id: str, drama: str, ep: str,
                          fixed_link: str, pick_only: bool) -> CaptionPlan:
    """把用户整段粘贴的模板渲染成最终文案。

    步骤：
        ① 从正文里抠出第一条 URL 当 link（若用户另填了 fixed_link 则用它）
        ② 把 {{DRAMA}} / {{EP}} / {DRAMA} / {EP} 换成实际值
        ③ 把正文里的旧链接替换成选定的链接（若正文没有链接则补在末尾）
        ④ 校验

    这样用户贴的那段「🎬NEXT EPISODE👉🏻…」会原样保留结构，
    链接换成链接池/指定链接里的那条，剧名按主页替换。
    """
    body = text.strip()

    # ① 正文自带链接？
    in_text = URL_IN_TEXT.findall(body)
    if fixed_link.strip():
        link, link_id, link_src = fixed_link.strip(), "", "fixed"
    elif in_text:
        link, link_id, link_src = in_text[0], "", "template"
    else:
        link, link_id, link_src = _pick_link(page_id, "", pick_only=pick_only)

    # ② 占位符替换
    name = drama.strip() or "Untitled"
    body = _fill(body, {"DRAMA": name, "EP": ep, "TITLE": name, "LINK": link})

    # ③ 正文里的旧链接统一换成选定的那条
    if link:
        for old in in_text:
            if old.rstrip("/") != link.rstrip("/"):
                body = body.replace(old, link)
        if link not in body:
            body = f"{body}\n\n{link}"

    # ④ 缺剧名就补在最前（不报错、不阻塞，保证「剧名 + 链接」这条底线）
    #
    # 用户明确要求：文案必须「剧名 + 链接」，模板也一样。
    # 但很多存量模板里没写 {{DRAMA}}，直接报错会把发布卡死。
    # 这里的选择是：**自动把剧名补到第一行前面**，而不是拒绝发布。
    if name and name != "Untitled":
        _d = _ensure_drama_in_title(body, name)
        if _d != body:
            body = _d

    # ⑤ 校验：按"这段文本自身像不像 4 行模板"选判据，不要硬套模板规则。
    #
    # 以前不管内容如何都按 style="template" 校验，导致用户贴
    #     AAA-TITLE
    #     https://xxx
    # 这种"标题 + 链接"被判成"模板缺少 🔍Title 行 / FREE 行"，
    # 预览直接 400，前端显示"(无预览)"。
    has_title_line = ('Title: "' in body) or ("剧名：「" in body)
    has_free_line = ("FREE" in body) or ("免费" in body)
    eff_style = "template" if (has_title_line and has_free_line) else "simple"

    problems = validate_caption(body, style=eff_style, link=link,
                                drama="" if name == "Untitled" else name)
    if problems:
        raise PublishError("文案不合规：" + "；".join(problems), "PUBLISH_CAPTION_INVALID")

    # 标题行：取第一行做摘要（给前端列表显示）
    first_line = next((ln.strip() for ln in body.splitlines() if ln.strip()), "")
    return CaptionPlan(body=body, title=first_line[:200], link=link,
                       title_id="", link_id=link_id or "",
                       source=f"template+{link_src}")


def _platform_tags(style: str) -> str:
    from app.services import platform_cfg as pc
    return pc.hashtags()


# 引导点击链接的文案变体。
#
# 用户要求（2026-11-12）："加上引导点击链接的文案"。
# 原来 simple 风格只有「标题 + 空行 + 链接」，链接孤零零挂着，
# 观看者不知道点了干嘛。现在在链接前插一句引导语。
#
# 中英按剧名自动判断；同一批里按剧名 hash 轮换，避免 18 条一模一样。
CTA_EN = [
    "👉 Watch the full series for free — tap the link below",
    "🔥 All episodes are free. Click to keep watching",
    "✨ Don't stop here — the rest is free. Tap below",
    "👀 Curious how it ends? Watch every episode free",
    "🎬 Full series, no cost. Tap the link to continue",
]
CTA_CN = [
    "👉 全集免费看，点下面链接继续",
    "🔥 后面更精彩，点链接一集不落",
    "✨ 全集免费，点链接接着看",
    "👀 想知道结局？点链接看完全集",
    "🎬 完整剧集免费，点下面继续观看",
]


def _cta_for(drama: str) -> str:
    import hashlib as _h
    import re as _re
    cn = len(_re.findall(r"[\u4e00-\u9fff]", drama or ""))
    pool = CTA_CN if cn >= 2 else CTA_EN
    idx = int(_h.md5((drama or "").encode("utf-8")).hexdigest()[:8], 16) % len(pool)
    return pool[idx]


def _compose_simple(title: str, link: str, drama: str = "") -> str:
    """simple 风格正文：**剧名 + 链接** 必须是主体，其他文案只是附加。

    ⚠ 2026-11-17 用户纠正（关键）：
        「怎么发的标题没有剧名，一定要包含剧名加链接，
         其他文案只是附加，一定是这两个的配合，
         比如点击链接免费观看该剧等都可以，
         文案是附带的，但是这两个才是收益到账的关键」

    旧实现在做的事（错误）：
        [英文钩子标题]
        [引导语]
        [链接]
      → 标题里**没有剧名**。观众不知道推的是什么剧，也没法按剧名搜索，
        投出去的钱和曝光全部浪费，转化只能靠链接本身撞运气。

    现在的结构（正确）：
        第 1 行：剧名 + 钩子（剧名一定在最前，Reels 首屏就能看到）
        第 2 行：链接（紧跟在剧名后面，这是收益落点，不能埋在末尾）
        第 3 行起：引导语 / 话题标签等**附加**内容

    为什么链接放第 2 行而不是最后：
        Reels 文案默认折叠，用户点「更多」的比例很低。
        链接放在引导语之后，很多人根本看不到。
        剧名 → 链接 相邻，是唯一能保证「看到剧名就顺手点」的顺序。
    """
    from app.services import platform_cfg as pc

    t = (title or "").strip()
    d = (drama or "").strip()
    ln = (link or "").strip()

    # ── 第 1 行：保证剧名在前 ──
    first = _ensure_drama_in_title(t, d)

    parts: list[str] = [first]

    # ── 第 2 行：链接紧跟剧名（收益落点）──
    if ln:
        parts.extend(["", ln])

        # ── 第 3 行起：附加文案（引导语）──
        parts.append(_cta_for(d or t))

    return "\n".join(parts) + pc.hashtags()


def _ensure_drama_in_title(title: str, drama: str) -> str:
    """确保标题里**一定出现剧名**。

    规则（按优先级）：
      ① 标题已经包含剧名（忽略大小写）→ 原样返回
      ② 有剧名但标题里没有 → 把剧名放到最前面：「剧名 - 原标题」
      ③ 没有剧名 → 用标题本身（但调用方应视为异常并告警）
      ④ 都没有 → 空串（上层会兜底）

    为什么剧名必须放最前：
        优化师看后台、观众看首屏，第一眼决定要不要点。
        剧名放后面等于没有。
    """
    import re as _re

    t = (title or "").strip()
    d = (drama or "").strip()
    if not d:
        return t
    if not t:
        return d

    # 归一化比较：忽略大小写、下划线、多余空格、常见包装符号
    def _norm(x: str) -> str:
        x = x.lower().replace("_", " ")
        x = _re.sub(r"[^\w\s\u4e00-\u9fff]", " ", x)
        return _re.sub(r"\s+", " ", x).strip()

    if _norm(d) and _norm(d) in _norm(t):
        return t                     # ① 已包含

    # ② 剧名放最前
    #    中文剧名用「《》」包裹更醒目；英文不加符号，用 " | " 分隔
    cn = len(_re.findall(r"[\u4e00-\u9fff]", d))
    if cn >= 2:
        return f"《{d}》{t}"
    return f"{d} | {t}"


URL_IN_TEXT = __import__("re").compile(r"https?://[^\s<>\"'）)】\]]+")
# 各种占位符形态：{{LINK}} / {LINK} / {{链接}} / {链接}
TITLE_PLACEHOLDER = __import__("re").compile(
    r"\{\{\s*(?:LINK|链接|URL)\s*\}\}|\{\s*(?:LINK|链接|URL)\s*\}")
# 占位符被替换后剩下的乱码/假链接残留（历史数据里的 onelink.me/xxx）
FAKE_LINK = __import__("re").compile(r"https?://[^\s]*\bxxx\b[^\s]*", __import__("re").I)
# 连在一起的问号/替换字符（emoji 编码损坏后的产物，如 ??WATCH NOW????）
BROKEN_GLYPH = __import__("re").compile(r"[?？\ufffd]{2,}")


def _strip_urls(text: str) -> str:
    """清洗标题里的杂质。

    标题池里有几类历史脏数据（都是早期模板复制/编码损坏留下的）：
        · 自带真实链接：https://pinedrama.onelink.me/...
        · 占位符残留：{{LINK}} / {LINK} / {{链接}}
        · 假链接：https://onelink.me/xxx
        · emoji 变成问号串：??WATCH NOW????

    这些原样发出去会很难看，且占位符残留还会导致
    validate_caption 报"存在未替换的占位符"。
    链接统一由链接池提供，标题里不该有任何 URL。
    """
    s = text or ""
    s = FAKE_LINK.sub("", s)
    s = URL_IN_TEXT.sub("", s)
    s = TITLE_PLACEHOLDER.sub("", s)
    s = BROKEN_GLYPH.sub("", s)
    s = __import__("re").sub(r"[ \t]{2,}", " ", s)
    # 清理首尾残留的标点/箭头（占位符删掉后常留下 👉🏻 或冒号）
    s = s.strip(" \t\n\r-—·|:：、,，")
    s = __import__("re").sub(r"[👉🏻\s]+$", "", s)
    return s.strip()


def _pick_title(page_id: str, fixed: str, reference: str, drama: str,
                *, pick_only: bool = False,
                preset_title: str = "") -> tuple[str, str, str]:
    """决定这条视频用哪个标题。

    优先级（2026-11-12 重构后）：
        ① preset_title  批次里预先分配好的（来自 assign_batch_titles）
                        —— 这是正常路径，保证同批内每条不重复
        ② fixed          用户显式指定的固定标题
        ③ reference      用户填的参考标题
        ④ drama          剧名兜底
        ⑤ REFERENCE_TITLE 最后兜底

    ⚠ 原来的实现从标题池里 random.choice，同批 6 条可能抽到同一条，
      而且池子里是别的剧的标题。现在标题由上层按剧预先分配，这里只做兜底。
    """
    if preset_title.strip():
        t = _strip_urls(preset_title)
        if t:
            return t, "", "batch"

    if fixed.strip():
        return _strip_urls(fixed), "", "fixed"

    if reference.strip():
        t = _strip_urls(reference)
        if t:
            return t, "", "reference"
    if drama.strip():
        return _strip_urls(drama) or drama.strip(), "", "drama"
    if pick_only:
        return "", "", "none"
    from app.services import caption as cap2
    return cap2.REFERENCE_TITLE, "", "default"


def _pick_link(page_id: str, fixed: str, *, pick_only: bool = False) -> tuple[str, str, str]:
    if fixed.strip():
        return fixed.strip(), "", "fixed"
    from app.services import caption as cap
    lk = cap.pick_link(page_id)
    if lk:
        return lk["url"], lk["id"], "promo"
    return "", "", "none"


def _recent_title_ids(page_id: str, n: int) -> set[str]:
    """最近用过的标题 id（用于轮转避让）。

    page_id 传空表示跨主页统计 —— 标题是全局共用的，
    只看单个主页的最近记录会让不同主页反复撞同一条。
    """
    try:
        if page_id:
            rows = db.q(
                "SELECT title_id FROM units WHERE page_id=? AND title_id IS NOT NULL "
                "AND title_id<>'' ORDER BY created_at DESC LIMIT ?", (page_id, n))
        else:
            rows = db.q(
                "SELECT title_id FROM units WHERE title_id IS NOT NULL "
                "AND title_id<>'' ORDER BY created_at DESC LIMIT ?", (n,))
        return {r["title_id"] for r in rows if r["title_id"]}
    except Exception:
        return set()


def _variant(drama: str, page_id: str, ep: str) -> int:
    """变体选择必须含主页与集数，不能只按剧名。

    只按剧名 → 同一部剧的 6 条视频拿到完全相同的文案（旧实现的真实问题）。
    """
    key = f"{drama}|{page_id}|{ep}".encode("utf-8")
    return int(hashlib.md5(key).hexdigest()[:8], 16)


def _fill(body: str, vars: dict[str, str]) -> str:
    """占位符替换。{{X}} 与 {X} 两种方言都支持（历史模板两种都有）。

    链接类占位符在 simple 风格下已被 _strip_urls 清掉；这里只处理标题/剧名/集数。
    """
    out = body
    for k, v in vars.items():
        for form in (f"{{{{{k}}}}}", f"{{{k}}}", f"{{{{ {k} }}}}"):
            out = out.replace(form, v or "")
    return out


def validate_caption(body: str, *, style: str, link: str,
                     drama: str = "") -> list[str]:
    """文案合规校验。

    注意：不复用 reel_caption.validate() 的整段逻辑 —— 那个函数把链接写死成
    FIXED_LINK 或链接池里的某条，用户用自定义链接时会被误判为"缺少链接"。
    这里只借它的**结构判据**（Title 行 / FREE 行），链接用实参判。

    ⚠ 2026-11-17 新增 drama 参数与两条硬判据（用户明确要求）：
        「一定要包含剧名加链接，其他文案只是附加，
         一定是这两个的配合，这两个才是收益到账的关键」

    所以现在把「有剧名」和「有链接」当成**发布阻塞项**，
    不是建议、不是警告，是必须满足才能发。
    """
    import re as _re
    problems: list[str] = []
    text = (body or "").strip()
    if not text:
        problems.append("文案为空")
        return problems
    if "{{" in text or "}}" in text:
        problems.append("存在未替换的占位符")
    if len(text) > MAX_CAPTION_LEN:
        problems.append(f"超长（{len(text)}/{MAX_CAPTION_LEN}）")
    if len(text) < 12:
        problems.append("文案过短（至少 12 字）")

    # 归一化比较：忽略大小写/下划线/标点，用于判「剧名在不在文案里」
    # 注意：必须定义在函数顶层 —— 下面两处判据都要用，
    # 之前写在 `if d:` 里，剧名为空时会 NameError。
    def _norm(x: str) -> str:
        x = (x or "").lower().replace("_", " ")
        x = _re.sub(r"[^\w\s\u4e00-\u9fff]", " ", x)
        return _re.sub(r"\s+", " ", x).strip()

    d = (drama or "").strip()
    drama_ok = bool(d) and _norm(d) in _norm(text)

    # ── 硬判据 ①：必须含剧名 ──
    if d and not drama_ok:
        problems.append(f"文案里没有剧名「{d}」（剧名是转化的唯一抓手）")

    # ── 硬判据 ②：必须有链接 ──
    found = URL_IN_TEXT.findall(text)
    if link:
        if link not in text:
            problems.append("链接未出现在文案里")
        extra = [u for u in found if u.rstrip("/") != link.rstrip("/")]
        if extra:
            problems.append(f"文案里有 {len(extra)} 条额外链接（只允许一条推广链接）")
        # 链接必须排在剧名之后的前部（不能埋在最末）
        if link in text and drama_ok:
            try:
                pos_link = text.index(link)
                head = text[:pos_link]
                # 链接之前的内容不该超过约 3 行
                if head.count("\n") > 4:
                    problems.append("链接位置太靠后（应紧跟剧名，前 3 行内）")
            except ValueError:
                pass
    elif not found:
        problems.append("缺少链接")

    if style == "template":
        # 4 行模板的结构判据（中英两套）
        has_title_line = ('Title: "' in text) or ("剧名：「" in text)
        has_free_line = ("FREE" in text) or ("免费" in text)
        if not has_title_line:
            problems.append("模板缺少 🔍Title / 🔍剧名 行")
        if not has_free_line:
            problems.append("模板缺少 FREE / 免费 行")

    return problems


# ─────────────────────────────────────────────────────────────
# 4. 素材分配
# ─────────────────────────────────────────────────────────────

def allocate(
    pages: list[PageTarget],
    materials: list[Material],
    clips_per_page: int,
    *,
    already_used_hashes: set[str] | None = None,
    mode: str = "merge",
    hash_cache: dict[str, str] | None = None,
    drama_picks: dict[str, int] | None = None,
) -> AllocationResult:
    """唯一分配入口：主页数 × 条数，sha256 去重，安全洗牌。

    drama_picks（2026-11-13 新增）：
        {"剧名": 条数} 非空时**只用这些剧的素材**，且每部剧最多取指定条数。
        此时 clips_per_page 会被忽略（条数由 drama_picks 汇总决定）。
        这样用户勾选哪部剧、每部几集，发出去的就是那些，不再全库乱混。
    """
    clips = normalize_clips(clips_per_page)
    used = set(already_used_hashes or set())
    cache = hash_cache if hash_cache is not None else {}

    # 跨轮次已发过的素材（按 lib_id 判断，避免为去重而全文哈希）
    used_keys: set[str] = set()
    try:
        rows = db.q("""SELECT DISTINCT library_id FROM publish_items
                        WHERE library_id IS NOT NULL AND library_id <> ''
                          AND state IN ('ok','sent','done')""")
        used_keys = {str(r["library_id"]) for r in rows}
    except Exception:
        used_keys = set()

    # ⚠ 2026-11-16 修（用户："Y03 要发百合类型"）：
    #   指纹去重会把「同一文件的不同命名」合并：
    #     冰后總裁_EP01.mp4 和 冰后總裁-01.mp4 内容相同 → 只留 1 条
    #   这本来是对的（避免重发同一内容），但会导致
    #   「专属素材绑定 6 条 → 去重后只剩 1 条」→ 跨剧分配失败。
    #
    #   现在：先收集被专属绑定的 lib_id，去重时**优先保留绑定素材**，
    #   保证绑定条数不被普通素材挤掉。
    _bound_ids: set[str] = set()
    try:
        for _pid, _ids in _load_page_materials().items():
            _bound_ids |= set(_ids)
    except Exception:
        pass

    pool: list[Material] = []
    seen: set[str] = set()
    seen_fp_of_bound: dict[str, str] = {}

    # 先处理绑定素材（占住指纹），再处理其余
    ordered_mats = sorted(materials, key=lambda x: 0 if (x.lib_id in _bound_ids)
                          else 1)

    for m in ordered_mats:
        try:
            fp = _quick_fingerprint(m.path)
        except Exception as e:
            raise PublishError(f"无法读取素材 {m.file}: {e}")

        # 跨轮次：这个库条目已经发过 → 跳过
        if m.lib_id and m.lib_id in used_keys:
            continue
        # 批内：同一文件不要两次
        if fp in seen:
            continue
        seen.add(fp)
        if m.lib_id:
            seen_fp_of_bound[fp] = m.lib_id
        m.sha256 = m.sha256 or fp      # 占位；需要真哈希时另算
        pool.append(m)

    # ⚠ 2026-11-13 重大修正（用户："锁定素材怎么还是跟没锁一样用混合素材"）：
    #
    #   旧的分支顺序：
    #     if drama_picks:  → _alloc_picked(...)   ← 完全绕过了专属素材！
    #     else:            → _alloc_mixed(...)    ← 只有这里才查 page_materials
    #
    #   结果：只要用户勾了剧（很常见的操作），专属素材绑定就被整个忽略，
    #   发布时又回到"混发"，用户看到的就是"锁定没生效"。
    #
    #   正确顺序（越具体越优先）：
    #     ① 主页绑了**具体素材**（page_materials）→ 最高优先级，任何人不能覆盖
    #     ② 主页绑了**剧/标签**（page_fit）
    #     ③ 批次勾选了**剧**（drama_picks）
    #     ④ 全库混合随机
    #
    #   所以先检查有没有素材级绑定；有就走 _alloc_mixed（它内部按页处理
    #   专属素材 + 剧绑定 + 剩余混发），不受 drama_picks 影响。
    mat_binds = _load_page_materials()
    has_mat_bind = bool(mat_binds)

    if has_mat_bind:
        # 有主页绑定了具体素材 → 必须走 mixed 路径，让绑定生效
        required = len(pages) * clips
        result = AllocationResult(available=len(pool), required=required)
        return _alloc_mixed(pages, pool, clips, result)

    # ── 指定剧模式（批次级：本次发布只用这些剧）──
    if drama_picks:
        return _alloc_picked(pages, pool, drama_picks, clips,
                             result_required=None)

    required = len(pages) * clips
    result = AllocationResult(available=len(pool), required=required)

    # ⚠ 素材数量校验（2026-11-13 调整）：
    #   有主页绑定时不能在总数上先卡死 —— 绑定的主页吃指定素材，
    #   其余混发，两者需求要分开算。交给分配函数自己判断。
    binds = _load_page_binds()
    has_bind = any(str(p.page_id) in binds for p in pages)
    if not has_bind and len(pool) < required:
        result.shortage = required - len(pool)
        result.note = (f"{len(pages)} 个主页 × {clips} 条 = 需要 {required} 条，"
                       f"去重后只有 {len(pool)} 条")
        return result
    result.available = len(pool)

    if mode == "per_drama":
        return _alloc_per_drama(pages, pool, clips, result)

    # 默认 merge：混合随机，但**尊重每个主页的手动绑定**
    #   绑定了的主页只发绑定的剧/类型，没绑定的照常混合随机。
    #   两种主页可以混在同一批里（2026-11-13 用户要求）。
    return _alloc_mixed(pages, pool, clips, result)


def _load_page_binds() -> dict[str, dict]:
    """读主页手动绑定（page_fit.manual=1）。

    返回 {page_id: {"dramas": set(剧名小写), "dramasRaw": {原名},
                    "dramaType": 内容类型, "tags": set(标签)}}
    没有手动绑定的主页不出现在结果里 → 走混合随机。

    2026-11-13：新增 tags 支持。绑定里的 drama_type 现在可以是
    **自由标签**（AI 给剧打的标签），不是固定分类。
    """
    binds: dict[str, dict] = {}
    try:
        rows = db.q("""SELECT page_id, keywords, drama_type, avoid, manual
                         FROM page_fit WHERE IFNULL(manual,0)=1""")
    except Exception:
        return binds
    for r in rows or []:
        pid = str(r["page_id"])
        try:
            kws = json.loads(r["keywords"] or "[]")
        except Exception:
            kws = []
        dramas = [str(k).strip() for k in kws if str(k).strip()]
        dtype = str(r["drama_type"] or "").strip()
        # drama_type 里可能存多个标签（逗号分隔）
        tags = [t.strip() for t in re.split(r"[,，、;；]", dtype) if t.strip()]
        if not dramas and not tags:
            continue      # 空绑定 = 未绑定，走混合
        binds[pid] = {
            "dramasRaw": set(dramas),
            "dramas": {d.lower() for d in dramas},
            "dramaType": dtype,
            "tags": set(tags),
        }
    return binds


# 标签 → 剧名 的反查缓存（一次分配内复用，避免反复查库）
_TAG_DRAMA_CACHE: dict[str, set[str]] = {}


def _dramas_for_tags(tags: set[str]) -> set[str]:
    """有这些标签的剧名集合（缓存）。"""
    if not tags:
        return set()
    key = ",".join(sorted(tags))
    if key in _TAG_DRAMA_CACHE:
        return _TAG_DRAMA_CACHE[key]
    try:
        from app.services import drama_tags as dt
        out = dt.dramas_with_tags(sorted(tags))
    except Exception as e:
        log.debug("查标签失败: %s", e)
        out = set()
    _TAG_DRAMA_CACHE[key] = out
    return out


def _match_bind(m: Material, bind: dict) -> bool:
    """素材是否匹配主页绑定。

    匹配优先级（2026-11-13 用户口径："指定内容类型**或者**具体的剧"）：
      · 绑定里有剧名 → **只按剧名**匹配（忽略残留的 drama_type）
      · 绑了标签（drama_type 存自由标签）→ 剧有这些标签就命中
      · 剧名和标签都绑了 → 任一命中即算（用户显式要的是并集）
    """
    d = (m.drama or "").strip()
    has_dramas = bool(bind.get("dramas"))
    tags = bind.get("tags") or set()
    has_tags = bool(tags)

    if has_dramas and d.lower() in bind["dramas"]:
        return True

    if has_tags:
        # 这部剧有任一绑定的标签 → 命中
        tagged = _dramas_for_tags(tags)
        if d in tagged:
            return True
        # 兼容老数据：剧名/kind 直接等于类型值
        if d.lower() in {t.lower() for t in tags}:
            return True
        if (getattr(m, "dtype", "") or "").strip() in tags:
            return True
        if (m.kind or "").strip() in tags:
            return True

    return False


def _load_page_materials() -> dict[str, set[str]]:
    """主页专属素材：{page_id: {lib_id, ...}}

    2026-11-13 用户要求"单独给主页安排素材"。
    优先级最高：绑了具体素材的主页只用那些素材。
    """
    out: dict[str, set[str]] = {}
    try:
        rows = db.q("SELECT page_id, lib_id FROM page_materials")
    except Exception:
        return out
    for r in rows or []:
        out.setdefault(str(r["page_id"]), set()).add(str(r["lib_id"]))
    return out


def _alloc_mixed(pages: list[PageTarget], pool: list[Material],
                 clips: int, result: AllocationResult) -> AllocationResult:
    """混合随机 + 尊重主页绑定（2026-11-13）。

    优先级（用户明确要求）：
      ① 主页绑了**具体素材**（page_materials）→ 只发那几条，别的不要
      ② 主页绑了**剧/标签**（page_fit）→ 只发这些剧的
      ③ 都没绑 → 全库混合随机

    三种主页可以同时存在（一批里既有绑定的也有自由混发的）。

    ⚠ 绑定了但素材不够 → 报短缺，**不偷偷退回全库**
    """
    binds = _load_page_binds()
    mat_binds = _load_page_materials()
    remaining = list(pool)
    picked: dict[str, list[Material]] = {}

    # ── 第一轮：先满足有绑定的主页（避免素材被自由主页抢走）──
    for page in pages:
        pid = str(page.page_id)

        # ① 素材级绑定（最精确）
        lib_ids = mat_binds.get(pid)
        if lib_ids:
            cands = [m for m in remaining if m.lib_id in lib_ids]
            if len(cands) < clips:
                # ⚠ 2026-11-13 修（用户："锁定素材怎么跟没锁一样"）：
                #   绑定 11 条但实际凑不够，原因有两层：
                #     ① 部分素材已经发过（used_keys 过滤）
                #     ② 同一部剧存在大小写两种剧名 + 同一文件多份副本
                #        （实测 MAIN.mp4 / MAIN_2.mp4 / _主线.mp4 指纹完全相同，
                #          去重后只剩 1 条）
                #
                #   补齐策略（保持"只发这部绑定剧"的约束）：
                #     ① 先用同一部剧的其他集（跨大小写变体）
                #     ② 还不够就把绑定的文件全部拿出来（等价文件也允许——
                #        它们内容相同，发给同一主页的不同 slot 是合理的）
                bound_dramas: set[str] = set()
                try:
                    ph = ",".join("?" * len(lib_ids))
                    for r in db.q(
                            f"SELECT DISTINCT LOWER(TRIM(drama)) AS d "
                            f"FROM library WHERE id IN ({ph}) "
                            f"AND drama IS NOT NULL AND TRIM(drama) <> ''",
                            tuple(lib_ids)):
                        if r["d"]:
                            bound_dramas.add(r["d"])
                except Exception:
                    pass
                extra = [m for m in remaining
                         if m.lib_id not in lib_ids
                         and (m.drama or "").strip().lower() in bound_dramas]
                cands = _secure_shuffle(cands) + _secure_shuffle(extra)

                if len(cands) < clips:
                    # 仍不够：把绑定文件全部解出来（含被去重掉的等价副本），
                    # 它们内容相同但库条目不同，可以当独立 slot 用
                    for lid in lib_ids:
                        if len(cands) >= clips:
                            break
                        row = db.q1(
                            "SELECT id, path, file, drama, ep, kind "
                            "FROM library WHERE id=?", (lid,))
                        if not row:
                            continue
                        if any(c.lib_id == row["id"] for c in cands):
                            continue
                        real = resolve_path(row["path"])
                        if not real:
                            continue
                        cands.append(Material(
                            key=f"lib:{row['id']}", path=real,
                            file=row["file"] or Path(real).name,
                            drama=(row["drama"] or "").strip(),
                            ep=(row["ep"] or "").strip(),
                            kind=row["kind"] or "single",
                            source="library", lib_id=row["id"],
                        ))

            if len(cands) < clips:
                result.shortage = clips - len(cands)
                result.note = (f"{page.name} 专属绑定 {len(lib_ids)} 条素材，"
                               f"扣除已发过的之后只能凑到 {len(cands)} 条，"
                               f"需要 {clips} 条（专属绑定不混发别的剧）")
                return result

            # ⚠ 2026-11-16 修（用户："Y03 要发百合类型"）：
            #   专属素材原来直接切片，6 条可能全来自同一部剧。
            #   用户要的是"发百合类型"= 多部百合剧混着发。
            #
            #   现在按剧轮转：第 1 轮每部剧各取 1 条，第 2 轮再各取第 2 条，
            #   直到凑够 clips 条。绑定 6 部剧 + clips=6 → 正好 6 部各 1 条。
            #
            #   ⚠ 注意：剧的顺序和剧内顺序都只洗牌**一次**，
            #     不能在 while 循环里重复洗，否则 depth 与列表下标错位。
            by_drama_pool: dict[str, list[Material]] = {}
            for m in cands:
                by_drama_pool.setdefault((m.drama or "").strip(), []).append(m)

            dramas_order = _secure_shuffle(list(by_drama_pool.keys()))
            for d in dramas_order:
                by_drama_pool[d] = _secure_shuffle(by_drama_pool[d])

            ordered: list[Material] = []
            depth = 0
            while len(ordered) < clips:
                added = False
                for d in dramas_order:
                    lst = by_drama_pool[d]
                    if depth < len(lst):
                        ordered.append(lst[depth])
                        added = True
                        if len(ordered) >= clips:
                            break
                if not added:
                    break
                depth += 1

            take = ordered[:clips]
            for m in take:
                # 补齐时可能构造了不在 remaining 里的对象，安全删除
                try:
                    remaining.remove(m)
                except ValueError:
                    pass
            picked[pid] = take
            continue

        # ② 剧/标签级绑定
        bind = binds.get(pid)
        if not bind:
            continue
        cands = [m for m in remaining if _match_bind(m, bind)]
        if len(cands) < clips:
            want = "、".join(sorted(bind["dramasRaw"])) or bind.get("dramaType") or "（空）"
            result.shortage = clips - len(cands)
            result.note = (f"{page.name} 绑定了「{want}」，但只有 {len(cands)} 条，"
                           f"需要 {clips} 条（绑定的主页不混发别的剧）")
            return result
        take = _secure_shuffle(cands)[:clips]
        for m in take:
            remaining.remove(m)
        picked[pid] = take

    # ── 第二轮：没绑定的主页从剩余池混发 ──
    bound_pids = set(mat_binds) | set(binds)
    free_pages = [p for p in pages if str(p.page_id) not in bound_pids]
    need_free = len(free_pages) * clips
    if len(remaining) < need_free:
        result.shortage = need_free - len(remaining)
        result.note = (f"未绑定主页需要 {need_free} 条，剩余可发 {len(remaining)} 条"
                       f"（绑定的主页已先分走）。差 {result.shortage} 条")
        return result

    # ⚠ 2026-11-13 关键修正（用户："每一个主页都发不同的剧"）：
    #   旧实现「洗牌后按顺序平铺」→ 同一部剧的连续几条会被切给同一个主页，
    #   出现"某个主页 5 条全是同一部剧"（实测 Y01 就是），而别的主页又很杂。
    #
    #   新做法：**逐条轮转分配**，每个主页每次只拿一条，且优先给它还没拿过的剧
    #     · 建一个"每页已用剧"集合
    #     · 每轮从"该页还没用过的剧"里挑一条给它
    #     · 所有页都没得挑时，才允许重复剧
    #   这样只要剧够多，每个主页内部一定是不同剧。
    quota: dict[str, int] = {str(p.page_id): clips for p in free_pages}
    page_order = list(free_pages)
    used_drama: dict[str, set[str]] = {str(p.page_id): set() for p in free_pages}
    picked_list: dict[str, list[Material]] = {str(p.page_id): [] for p in free_pages}

    # 每部剧一个待取队列（剧内洗牌）
    pools: dict[str, list[Material]] = {}
    for m in remaining:
        pools.setdefault((m.drama or "").strip() or "未分类", []).append(m)
    for d in pools:
        pools[d] = _secure_shuffle(pools[d])

    rounds = max(1, clips)
    for _round in range(rounds):
        # 每轮打乱主页顺序，避免"总是前几个主页优先挑到好剧"
        round_pages = _secure_shuffle(list(page_order))
        for page in round_pages:
            pid = str(page.page_id)
            if len(picked_list[pid]) >= clips:
                continue
            # 优先挑"这个主页没用过的剧"
            cand_dramas = [d for d, lst in pools.items()
                           if lst and d not in used_drama[pid]]
            if not cand_dramas:
                cand_dramas = [d for d, lst in pools.items() if lst]
            if not cand_dramas:
                break
            # ⚠ 挑"剩余素材最多"的剧，让各剧消耗均衡 ——
            #   否则素材多的剧会被前面的主页吃光，后面的主页只能重复
            cand_dramas.sort(key=lambda d: -len(pools[d]))
            d = cand_dramas[0]
            picked_list[pid].append(pools[d].pop())
            used_drama[pid].add(d)

    for page in free_pages:
        picked[str(page.page_id)] = picked_list[str(page.page_id)]

    # 按 pages 原顺序输出
    for page in pages:
        for slot, m in enumerate(picked.get(str(page.page_id)) or [], 1):
            result.items.append(ItemPlan(page=page, material=m, slot=slot))
    return result


def _alloc_picked(pages: list[PageTarget],
                  pool: list[Material],
                  drama_picks: dict[str, int],
                  clips: int = 1,
                  result_required=None) -> AllocationResult:
    """指定剧分配：**只用用户勾选的剧**，但条数仍按 主页数 × 每页条数。

    ⚠ 2026-11-13 修正语义（之前理解错了）：
        dramaPicks 的作用是「限定素材范围」——只用这些剧，
        **不是**「总共只发这么多条」。

        正确行为：
          勾了 6 部剧，每页 5 条，22 个主页
          → 需要 110 条，全部来自这 6 部剧（按剧内集数循环取用）
          → 每部剧被取用的次数大致 = 110 / 剧总数

        错误行为（旧实现）：
          把 picks 的条数当成总量，只发 sum(picks) 条（30 条），
          然后平铺给 22 个主页 —— 每页不到 2 条，和 UI 显示的
          「每主页 5 条」完全不符。

        所以这里：picks 的 value 只表示「这部剧至少要凑够几条」的下限提示，
        实际取用按 clips × 页数 的总需求来分摊。
    """
    picks = {str(k).strip(): int(v) for k, v in (drama_picks or {}).items()
             if str(k).strip() and int(v or 0) > 0}
    if not picks:
        return AllocationResult()

    # 剧名大小写归一（同剧不同大小写合并）
    picks_lower = {k.lower(): (k, v) for k, v in picks.items()}

    buckets: dict[str, list[Material]] = {}
    for m in pool:
        d = (m.drama or "").strip()
        hit = picks_lower.get(d.lower())
        if hit:
            buckets.setdefault(hit[0], []).append(m)

    # 只保留有素材的剧
    avail = {k: v for k, v in buckets.items() if v}
    if not avail:
        r = AllocationResult(available=0, required=len(pages) * clips)
        r.shortage = r.required
        r.note = "指定的剧没有可用素材"
        return r

    total_avail = sum(len(v) for v in avail.values())
    required = len(pages) * clips

    result = AllocationResult(available=total_avail, required=required)
    if total_avail < required:
        result.shortage = required - total_avail
        result.note = (f"指定剧共 {total_avail} 条（{len(avail)} 部），"
                       f"需要 {required} 条（{len(pages)} 主页 × {clips}），"
                       f"还差 {result.shortage} 条")

    # 从各剧轮流取，直到凑够 required（或取完）
    # 每部剧内部洗牌，剧之间轮转，保证均衡
    shuffled = {k: _secure_shuffle(list(v)) for k, v in avail.items()}
    order = list(shuffled.keys())
    idx = {k: 0 for k in order}
    chosen: list[Material] = []

    while len(chosen) < required:
        progressed = False
        for d in order:
            if len(chosen) >= required:
                break
            i = idx[d]
            if i < len(shuffled[d]):
                chosen.append(shuffled[d][i])
                idx[d] = i + 1
                progressed = True
        if not progressed:
            break      # 所有剧都取完了

    result.available = len(chosen)

    # 按主页顺序平铺（每页 clips 条）
    cursor = 0
    for page in pages:
        for slot in range(1, clips + 1):
            if cursor >= len(chosen):
                break
            result.items.append(
                ItemPlan(page=page, material=chosen[cursor], slot=slot))
            cursor += 1
    return result


def _alloc_per_drama(pages, pool, clips, result: AllocationResult) -> AllocationResult:
    """按剧分组：同一部剧的视频优先发给偏好这部剧的主页（page_fit）。"""
    fits: dict[str, dict] = {}
    try:
        for r in db.q("SELECT page_id, keywords, avoid FROM page_fit"):
            fits[str(r["page_id"])] = r
    except Exception:
        pass

    remaining = list(pool)
    for page in pages:
        fit = fits.get(page.page_id) or {}
        try:
            avoid = set(json.loads(fit.get("avoid") or "[]"))
        except Exception:
            avoid = set()
        try:
            prefer = set(json.loads(fit.get("keywords") or "[]"))
        except Exception:
            prefer = set()

        cands = [m for m in remaining if m.drama not in avoid]
        if prefer:
            hit = [m for m in cands if m.drama in prefer]
            cands = hit or cands
        if len(cands) < clips:
            cands = remaining
        if len(cands) < clips:
            result.shortage = clips - len(cands)
            result.note = f"{page.name} 可用素材不足 {clips} 条"
            return result

        picked = _secure_shuffle(cands)[:clips]
        for i, m in enumerate(picked, 1):
            remaining.remove(m)
            result.items.append(ItemPlan(page=page, material=m, slot=i))
    return result


def normalize_clips(v: Any) -> int:
    """空值走默认；给了非数字就报错，不静默吃成默认（否则用户以为改了 60）。"""
    if v is None or (isinstance(v, str) and not v.strip()):
        return DEFAULT_CLIPS
    try:
        n = int(v)
    except (TypeError, ValueError):
        raise PublishError(f"每主页条数必须是 {MIN_CLIPS}–{MAX_CLIPS} 之间的整数，收到 {v!r}")
    if n < MIN_CLIPS or n > MAX_CLIPS:
        raise PublishError(f"每主页条数必须是 {MIN_CLIPS}–{MAX_CLIPS} 之间的整数，收到 {n}")
    return n


def _secure_shuffle(items: list) -> list:
    out = list(items)
    for i in range(len(out) - 1, 0, -1):
        j = secrets.randbelow(i + 1)
        out[i], out[j] = out[j], out[i]
    return out


_FP_CACHE: dict[str, str] = {}       # {path: "size:mtime"} 快速指纹缓存


def _quick_fingerprint(path: str) -> str:
    """文件快速指纹（大小 + 修改时间），不做全文哈希。

    ⚠ 2026-11-13 性能修复：
        分配前要对所有素材算 sha256（136 个文件 × 平均 30MB = 4GB），
        实测耗时 12.8 秒，前端预览直接卡住/超时。
        去重只需要判断"是不是同一个文件"，用 size+mtime 足够，
        只有真正冲突（size+mtime 完全相同但可能是不同文件）时才回退全文哈希。
    """
    st = os.stat(path)
    return f"{st.st_size}:{int(st.st_mtime)}"


def _sha256(path: str, cache: dict[str, str] | None = None) -> str:
    """文件内容哈希（完整读一遍）——只在需要最终确认时调用。"""
    if cache is not None and path in cache:
        return cache[path]
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    digest = h.hexdigest()
    if cache is not None:
        cache[path] = digest
    return digest


def used_hashes() -> set[str]:
    """跨轮次去重：已成功发过的素材不再重复用。

    ⚠ 必须把内核的 usedHashes 也算进来。
    yuhai 自己的 units / publish_items 只记录"通过 yuhai 发的"，
    而内核（ReelsPublisher）有一份独立的 usedHashes（state.json），
    里面既有 yuhai 发过的，也有以前用 ReelsPublisher 界面发过的。

    实机教训：yuhai 选出 4 条，其中 2 条在内核 usedHashes 里 →
    worker 自己再去重，staging 目录里的文件被全部过滤 →
      MATERIAL_SHORTAGE: 所选 1 个主页需要 2 个视频，当前只有 0 个
    前端显示"素材充足"，发布却报素材不足，极难排查。
    """
    out: set[str] = set()
    try:
        for r in db.q("SELECT video_hash FROM units WHERE video_hash IS NOT NULL "
                      "AND video_hash<>''"):
            out.add(r["video_hash"])
    except Exception:
        pass
    try:
        for r in db.q("SELECT file_sha256 FROM publish_items WHERE file_sha256<>'' "
                      "AND state IN ('COMMITTED','RUNNING','PENDING')"):
            out.add(r["file_sha256"])
    except Exception:
        pass
    # 内核的 usedHashes（state.json）
    try:
        from app.services import reels as _rl
        snap = _rl.state_snapshot()
        for h in (snap.get("usedHashes") or []):
            if isinstance(h, str) and h:
                out.add(h)
        # 内核历史里的 assignments 也算
        for run in (snap.get("history") or []):
            for a in (run.get("assignments") or []):
                h = a.get("sha256")
                if isinstance(h, str) and h:
                    out.add(h)
        # 当前未归档运行
        cur = snap.get("currentRun") or {}
        for a in (cur.get("assignments") or []):
            h = a.get("sha256")
            if isinstance(h, str) and h:
                out.add(h)
    except Exception:
        pass
    return out


def count_available(*, source: str = "library", include_used: bool = False) -> dict:
    """真实可发素材数（与 resolve_materials + allocate 完全一致的判据）。

    为什么要单独提供：
        库里 state=ready 的行数 ≠ 能发的条数。库里的行可能
          · 文件已被删（state 没来得及改）
          · 是混剪（kind=mix，不参与单集发布）
          · 版权未通过
          · 已在内核 usedHashes 里（worker 会自己再过滤一次）
        界面若显示库里的 ready 数，用户会看到"充足"却报素材不足。
    """
    mats = resolve_materials(source=source, include_used=include_used)
    # 再排除内核已用的
    used = used_hashes() if not include_used else set()
    fresh: list[Material] = []
    seen: set[str] = set()
    cache: dict[str, str] = {}
    for m in mats:
        try:
            h = m.sha256 or _sha256(m.path, cache)
        except Exception:
            continue
        if h in used or h in seen:
            continue
        seen.add(h)
        m.sha256 = h
        fresh.append(m)

    by_drama: dict[str, int] = {}
    for m in fresh:
        key = m.drama or ""
        by_drama[key] = by_drama.get(key, 0) + 1
    dramas = [{"drama": k, "n": v}
              for k, v in sorted(by_drama.items(), key=lambda kv: -kv[1])]
    return {"count": len(fresh), "dramas": dramas}


# ─────────────────────────────────────────────────────────────
# 5. staging 目录（worker 只吃目录，不吃文件列表）
# ─────────────────────────────────────────────────────────────

def _stage_root() -> Path:
    root = Path(settings.data_dir) / "publish_stage"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe(name: str) -> str:
    """把主页名 / 环境名转成安全的目录名。"""
    keep = "".join(ch if (ch.isalnum() or ch in "-_.") else "_" for ch in (name or ""))
    return keep[:40] or "page"


def stage_items(order_id: str, items: list[ItemPlan]) -> dict[str, str]:
    """给每个主页建一个 staging 目录，返回 {page_id: 目录}。

    同盘用硬链接（零拷贝，worker 删源只删链接）；
    跨盘退回复制（并在返回值里可通过 total_bytes 判断开销）。
    """
    root = _stage_root() / order_id
    if root.exists():
        shutil.rmtree(root, ignore_errors=True)
    out: dict[str, str] = {}
    by_page: dict[str, list[ItemPlan]] = {}
    for it in items:
        by_page.setdefault(it.page.page_id, []).append(it)

    for page_id, plans in by_page.items():
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in page_id)[:40]
        folder = root / f"{safe}_{_sanitize(plans[0].page.name)}"
        folder.mkdir(parents=True, exist_ok=True)
        for p in plans:
            src = Path(p.material.path)
            dst = folder / src.name
            if dst.exists():
                dst = folder / f"{p.slot:02d}_{src.name}"
            _link_or_copy(src, dst)
        out[page_id] = str(folder)
    return out


def _sanitize(name: str) -> str:
    keep = "".join(ch if (ch.isalnum() or ch in "-_.") else "_" for ch in (name or ""))
    return keep[:40] or "page"


def _link_or_copy(src: Path, dst: Path) -> None:
    try:
        os.link(src, dst)
        return
    except OSError:
        pass
    shutil.copy2(src, dst)


def cleanup_stage(order_id: str) -> None:
    root = _stage_root() / order_id
    shutil.rmtree(root, ignore_errors=True)


# ─────────────────────────────────────────────────────────────
# 6. 订单持久化
# ─────────────────────────────────────────────────────────────

def new_order_id() -> str:
    return "po-" + uuid.uuid4().hex[:12]


def order_idem_key(page_ids: list[str], hashes: list[str], clips: int) -> str:
    raw = json.dumps({
        "pages": sorted(page_ids),
        "hashes": sorted(hashes),
        "clips": clips,
    }, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def create_order(
    *,
    order_id: str,
    pages: list[PageTarget],
    items: list[ItemPlan],
    clips_per_page: int,
    caption_style: str,
    material_source: str,
    alloc_mode: str,
    payload: dict,
    title: str = "",
) -> None:
    """一个事务写入 order + items。"""
    idem = order_idem_key([p.page_id for p in pages],
                          [i.material.sha256 for i in items], clips_per_page)
    ts = now_iso()
    with db.tx() as cur:
        cur.execute(
            """INSERT INTO publish_orders
               (id, idem_key, title, env_code, account_id, state,
                clips_per_page, caption_style, material_source, alloc_mode,
                item_count, progress, stage, payload, created_at)
               VALUES (?,?,?,?,?,'CREATED',?,?,?,?,?,0,?,?,?)""",
            (order_id, idem, title or f"发布 {len(pages)} 个主页 × {clips_per_page} 条",
             pages[0].env_code if pages else "",
             pages[0].account_id if pages else "",
             clips_per_page, caption_style, material_source, alloc_mode,
             len(items), "已创建", json.dumps(payload, ensure_ascii=False, default=str),
             ts),
        )
        for it in items:
            cap = it.caption
            cur.execute(
                """INSERT INTO publish_items
                   (id, order_id, page_id, page_name, asset_id, lib_id, queue_id,
                    file, file_name, file_sha256, drama, ep, slot,
                    title, link, caption, title_id, link_id, state, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'PENDING',?)""",
                (
                    "pi-" + uuid.uuid4().hex[:12], order_id,
                    it.page.page_id, it.page.name, it.page.asset_id,
                    it.material.lib_id, it.material.queue_id,
                    it.material.path, it.material.file, it.material.sha256,
                    it.material.drama, it.material.ep, it.slot,
                    (cap.title if cap else ""), (cap.link if cap else ""),
                    (cap.body if cap else ""),
                    (cap.title_id if cap else ""), (cap.link_id if cap else ""),
                    ts,
                ),
            )


def set_order(order_id: str, **fields) -> None:
    if not fields:
        return
    # 白名单，避免把任意列名拼进 SQL
    allowed = {"state", "job_id", "progress", "stage", "ok_count", "fail_count",
               "error", "started_at", "ended_at", "result", "title", "env_code"}
    sets, params = [], []
    for k, v in fields.items():
        if k not in allowed:
            continue
        sets.append(f"{k}=?")
        params.append(json.dumps(v, ensure_ascii=False, default=str)
                      if isinstance(v, (dict, list)) else v)
    if not sets:
        return
    params.append(order_id)
    db.exec(f"UPDATE publish_orders SET {', '.join(sets)} WHERE id=?", tuple(params))


def set_item(item_id: str, **fields) -> None:
    allowed = {"state", "acceptance", "error", "ended_at"}
    sets, params = [], []
    for k, v in fields.items():
        if k not in allowed:
            continue
        sets.append(f"{k}=?")
        params.append(v)
    if not sets:
        return
    params.append(item_id)
    db.exec(f"UPDATE publish_items SET {', '.join(sets)} WHERE id=?", tuple(params))


def get_order(order_id: str) -> dict | None:
    o = db.q1("SELECT * FROM publish_orders WHERE id=?", (order_id,))
    if not o:
        return None
    items = db.q(
        "SELECT * FROM publish_items WHERE order_id=? ORDER BY page_name, slot",
        (order_id,))
    o["items"] = items
    return o


def list_orders(limit: int = 40) -> list[dict]:
    rows = db.q(
        "SELECT * FROM publish_orders ORDER BY created_at DESC LIMIT ?",
        (min(max(1, limit), 200),))
    for r in rows:
        r["items"] = db.q(
            "SELECT id, page_id, page_name, file_name, slot, state, acceptance, error "
            "FROM publish_items WHERE order_id=? ORDER BY page_name, slot", (r["id"],))
    return rows


def progress_of(order_id: str) -> dict:
    """按明细状态算进度（不依赖外部进程回报）。"""
    rows = db.q("SELECT state, COUNT(*) n FROM publish_items WHERE order_id=? "
                "GROUP BY state", (order_id,))
    counts = {r["state"]: r["n"] for r in rows}
    total = sum(counts.values()) or 1
    done = (counts.get("COMMITTED", 0) + counts.get("REJECTED", 0)
            + counts.get("FAILED", 0) + counts.get("SKIPPED", 0)
            + counts.get("BLOCKED", 0))
    return {
        "counts": counts,
        "total": total,
        "done": done,
        "progress": int(done / total * 100),
    }


# ─────────────────────────────────────────────────────────────
# 7. 结果回写（闭环：让内部数据真的动起来）
# ─────────────────────────────────────────────────────────────

def commit_item(order_id: str, item: dict, *, success: bool,
                acceptance: str = "", error: str = "") -> None:
    """单条明细到终态时的六处回写。全部在一个事务里。"""
    state = "COMMITTED" if success else "FAILED"
    ts = now_iso()
    with db.tx() as cur:
        cur.execute(
            "UPDATE publish_items SET state=?, acceptance=?, error=?, ended_at=? "
            "WHERE id=?", (state, acceptance or "", error or None, ts, item["id"]))

        if not success:
            return

        # ① units：指标体系的锚点
        try:
            cur.execute(
                """INSERT INTO units
                   (id, page_id, asset_id, video_hash, file, title, caption, tags,
                    published_at, published_date, post_id, tracker, state, created_at,
                    link_id, title_id, permalink)
                   VALUES (?,?,?,?,?,?,?,'',?,?,NULL,'','published',?,?,?,NULL)""",
                ("u-" + uuid.uuid4().hex[:12], item["page_id"], item["asset_id"],
                 item["file_sha256"], item["file_name"], item["title"],
                 item["caption"], ts, ts[:10], ts,
                 item["link_id"] or None, item["title_id"] or None))
        except Exception as e:
            log.warning("write units failed: %s", e)

        # ② 主页已发计数
        cur.execute("UPDATE pages SET published = COALESCE(published,0) + 1 "
                    "WHERE page_id=?", (item["page_id"],))

        # ③ 素材出库
        if item.get("lib_id"):
            cur.execute("UPDATE library SET state='used', used_by=? WHERE id=?",
                        (order_id, item["lib_id"]))
        if item.get("queue_id"):
            cur.execute("UPDATE queue SET state='done' WHERE id=?",
                        (item["queue_id"],))

        # ④ 标题轮转
        if item.get("title_id"):
            for tbl in ("caption_variants", "title_pool"):
                try:
                    cur.execute(f"UPDATE {tbl} SET used_count=COALESCE(used_count,0)+1, "
                                f"last_used=? WHERE id=?", (ts, item["title_id"]))
                except Exception:
                    pass

        # ⑤ 链接权重轮转
        if item.get("link_id"):
            cur.execute("UPDATE promo_links SET used_count=COALESCE(used_count,0)+1, "
                        "last_used=? WHERE id=?", (ts, item["link_id"]))


def mark_items(order_id: str, state: str, *, only=(("PENDING", "RUNNING"),),
               error: str = "") -> None:
    ph = ",".join("?" * len(only[0]))
    db.exec(f"UPDATE publish_items SET state=?, error=COALESCE(?, error), ended_at=? "
            f"WHERE order_id=? AND state IN ({ph})",
            (state, error or None, now_iso(), order_id, *only[0]))


def judge_worker_result(value: dict) -> dict:
    """把 worker 的 ok=true 翻译成真实结论。

    沿用 services/reels.py:_judge_publish_result 的判据 ——
    那是这套系统里最有价值的一段逻辑（区分"命令跑完"和"真的发出去了"）。
    """
    from app.services.reels import _judge_publish_result
    return _judge_publish_result(value or {})

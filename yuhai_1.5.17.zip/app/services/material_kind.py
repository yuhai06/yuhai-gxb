# -*- coding: utf-8 -*-
"""素材分类：区分「切片成品」和「原始素材」，并支持自动分离。

═══ 为什么需要这个模块（2026-11-17） ═══

用户复盘：
    「把所有素材混一起了，同一个文件夹里面不能出现同名的所以就没有剧名了」

根因链：
    ① 原始素材从下载区落到了 `素材库/<剧名>/`
    ② 切片产出也写到 `素材库/<剧名>/`
    ③ 两边文件名都叫 `EP03.mp4` → 冲突
    ④ Windows 自动改名 `EP03_2.mp4`
    ⑤ 结果：`EP03` 可能是成品、`EP03_2` 可能是原始片，完全随机
       （实测 `A cativa` 的 EP03_2 是原始、EP04_2 是成品）

实测规律（470 个文件全量 ffprobe 验证）：
    成品  码率 ≥ 3 Mbps，全部 1080x1920，时长 34~49s
    原始  码率 < 3 Mbps，多为 576x1024/540x960，时长 33~218s

    88 个成品里 1080x1920 占 100%，阈值附近没有模糊样本，
    所以「码率 3 Mbps」是可靠判据，不需要再按分辨率二次判断。

新结构（同名冲突彻底消除）：
    素材库/<剧名>/成品/*.mp4      ← 可直接发布
    视频素材/<剧名>/原始/*.mp4    ← 未处理原片

═══ 这个模块做什么 ═══
    classify_video()   单个文件判成品/原始
    scan_library()     扫描整个素材库，给出分类报告
    plan_split()       计算移动计划（不执行）
    apply_split()      执行移动 + 更新数据库
"""
from __future__ import annotations

import json
import logging
import re
import shutil
import sqlite3
import subprocess
from pathlib import Path

log = logging.getLogger("yuhai.material_kind")

# 码率分界：≥ 3 Mbps 判成品（实测 88/88 命中，无模糊样本）
FIN_BITRATE = 3_000_000

# 精品混剪的命名特征（用户确认：剧名_主线 就是精品混剪）
MIX_RE = re.compile(r"主线|主線|混剪|主线版|精品混剪|_MAIN|MAIN_", re.I)

SUBDIR_FIN = "成品"
SUBDIR_RAW = "原始"


def is_mix(filename: str) -> bool:
    """文件名是否表示精品混剪。"""
    return bool(MIX_RE.search(filename or ""))


def kind_of(filename: str) -> str:
    """single | mix"""
    return "mix" if is_mix(filename) else "single"


def _ffprobe_bin() -> Path | None:
    """找 ffprobe：优先包内，其次 PATH。"""
    for p in (Path(__file__).resolve().parents[2] / "_internal" / "bin" / "ffprobe.exe",
              Path(__file__).resolve().parents[1].parent / "_internal" / "bin" / "ffprobe.exe",
              Path(__file__).resolve().parent.parent.parent / "bin" / "ffprobe.exe"):
        if p.is_file():
            return p
    w = shutil.which("ffprobe")
    return Path(w) if w else None


def probe(path: Path, timeout: int = 45) -> dict:
    """用 ffprobe 取时长/码率/分辨率。失败返回 {}。"""
    fp = _ffprobe_bin()
    if fp is None:
        return {}
    try:
        r = subprocess.run(
            [str(fp), "-v", "quiet", "-print_format", "json",
             "-show_format", "-show_streams", str(path)],
            capture_output=True, timeout=timeout)
        d = json.loads(r.stdout.decode("utf-8", "replace") or "{}")
        fmt = d.get("format") or {}
        w = h = 0
        for s in d.get("streams") or []:
            if s.get("codec_type") == "video":
                w = int(s.get("width") or 0)
                h = int(s.get("height") or 0)
                break
        return {"dur": float(fmt.get("duration") or 0),
                "br": int(fmt.get("bit_rate") or 0),
                "w": w, "h": h,
                "size": path.stat().st_size}
    except Exception as e:
        log.debug("probe %s: %s", path.name, e)
        return {}


def classify_video(path: Path) -> str:
    """判成品还是原始：'fin' | 'raw' | 'unknown'。

    没有 ffprobe 或探测失败时返回 unknown，调用方保守处理（不移动）。
    """
    info = probe(path)
    if not info:
        return "unknown"
    return "fin" if info["br"] >= FIN_BITRATE else "raw"


def scan_library(lib_root: Path, on_progress=None) -> list[dict]:
    """扫描素材库全部 mp4，逐个判定类型。

    只扫 <lib_root>/<剧名>/*.mp4 这一层（不含已有的 成品/ 子目录），
    因为分好之后就不需要再反复判定。
    """
    out: list[dict] = []
    if not lib_root.is_dir():
        return out
    files: list[Path] = []
    for d in lib_root.iterdir():
        if not d.is_dir():
            continue
        for f in d.glob("*.mp4"):
            files.append(f)

    total = len(files)
    for i, f in enumerate(files, 1):
        info = probe(f)
        rec = {"path": str(f), "dir": f.parent.name, "file": f.name,
               "kind_name": kind_of(f.name)}
        if info:
            rec.update(info)
            rec["type"] = "fin" if info["br"] >= FIN_BITRATE else "raw"
        else:
            rec["type"] = "unknown"
        out.append(rec)
        if on_progress:
            try:
                on_progress(i, total)
            except Exception:
                pass
    return out


def plan_split(lib_root: Path, src_root: Path, scanned: list[dict]) -> list[dict]:
    """计算移动计划，不执行任何文件操作。

    成品 → <lib_root>/<剧名>/成品/
    原始 → <src_root>/<剧名>/原始/

    返回 [{src, dst, drama, type, file}]
    """
    plan: list[dict] = []
    for r in scanned:
        if r["type"] == "unknown":
            continue                      # 判不出的不动，避免误伤
        drama = r["dir"]
        name = r["file"]
        src = Path(r["path"])
        if r["type"] == "fin":
            dst = lib_root / drama / SUBDIR_FIN / name
        else:
            dst = src_root / drama / SUBDIR_RAW / name
        plan.append({"src": src, "dst": dst, "drama": drama,
                     "type": r["type"], "file": name})
    return plan


def apply_split(db_path: Path, lib_root: Path, src_root: Path,
                plan: list[dict]) -> dict:
    """执行移动并同步更新 library 表里的 path。

    安全原则：
      · 只移动，不删除任何文件
      · 目标已存在时自动加序号，绝不覆盖
      · 单条失败不影响其它，全部记入 errors
      · 移动成功后把库里 lib: 路径改成新位置
    """
    moved = 0
    errors: list[dict] = []
    pathmap: dict[str, str] = {}

    for item in plan:
        src: Path = item["src"]
        dst: Path = item["dst"]
        if not src.is_file():
            continue
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            final = dst
            i = 2
            while final.exists():
                final = dst.parent / f"{dst.stem}_{i}{dst.suffix}"
                i += 1
            shutil.move(str(src), str(final))
            moved += 1
            old_rel = f"lib:{item['drama']}/{item['file']}"
            if item["type"] == "fin":
                new_rel = f"lib:{item['drama']}/{SUBDIR_FIN}/{final.name}"
            else:
                new_rel = f"src:{item['drama']}/{SUBDIR_RAW}/{final.name}"
            pathmap[old_rel] = new_rel
        except Exception as e:
            errors.append({"file": item["file"], "error": str(e)[:120]})

    # 同步数据库（先拷副本，避免 WAL 锁）
    upd = 0
    tmp = None
    try:
        import tempfile
        tmp = Path(tempfile.gettempdir()) / "yh_split_apply.db"
        shutil.copy2(db_path, tmp)
        con = sqlite3.connect(str(tmp))
        con.row_factory = sqlite3.Row
        for row in list(con.execute("SELECT id,path FROM library")):
            old = row["path"] or ""
            if old in pathmap:
                con.execute("UPDATE library SET path=? WHERE id=?",
                            (pathmap[old], row["id"]))
                upd += 1
        con.commit()
        con.close()
        shutil.copy2(tmp, db_path)
    except Exception as e:
        errors.append({"file": "(db)", "error": f"写库失败 {str(e)[:100]}"})
    finally:
        if tmp is not None:
            try:
                tmp.unlink()
            except Exception:
                pass

    return {"moved": moved, "updated": upd, "errors": errors}


def fix_kind_marks(db_path: Path) -> dict:
    """修正 library / queue 表里 mix 标记（_主线 应标 mix）。"""
    fixed = 0
    tmp = None
    try:
        import tempfile
        tmp = Path(tempfile.gettempdir()) / "yh_kind_fix.db"
        shutil.copy2(db_path, tmp)
        con = sqlite3.connect(str(tmp))
        con.row_factory = sqlite3.Row
        for table in ("library", "queue"):
            try:
                rows = list(con.execute(f"SELECT id,file,kind FROM {table}"))
            except sqlite3.OperationalError:
                continue
            for r in rows:
                should = kind_of(r["file"] or "")
                if (r["kind"] or "single") != should:
                    con.execute(f"UPDATE {table} SET kind=? WHERE id=?",
                                (should, r["id"]))
                    fixed += 1
        con.commit()
        con.close()
        shutil.copy2(tmp, db_path)
    except Exception as e:
        return {"fixed": fixed, "error": str(e)[:150]}
    finally:
        if tmp is not None:
            try:
                tmp.unlink()
            except Exception:
                pass
    return {"fixed": fixed}


def cleanup_empty_dirs(lib_root: Path) -> list[str]:
    """删掉素材库里完全空的剧目录（已被搬空的壳）。"""
    removed: list[str] = []
    if not lib_root.is_dir():
        return removed
    for d in list(lib_root.iterdir()):
        if not d.is_dir():
            continue
        try:
            files = [p for p in d.rglob("*") if p.is_file()]
            if not files:
                d.rmdir()
                removed.append(d.name)
        except OSError:
            continue
    return removed


def layout_report(lib_root: Path, src_root: Path) -> dict:
    """当前分离状态报告（给前端/自检用）。"""
    def count(root: Path, sub: str | None = None) -> int:
        base = root / sub if sub else root
        if not base.is_dir():
            return 0
        try:
            return len(list(base.glob("*.mp4")))
        except OSError:
            return 0

    lib_top = count(lib_root)
    lib_fin = sum(count(d, SUBDIR_FIN) for d in lib_root.iterdir()
                  if d.is_dir()) if lib_root.is_dir() else 0
    src_raw = sum(count(d, SUBDIR_RAW) for d in src_root.iterdir()
                  if d.is_dir()) if src_root.is_dir() else 0

    return {
        "libRoot": str(lib_root),
        "srcRoot": str(src_root),
        "libTopLevel": lib_top,
        "libFinished": lib_fin,
        "srcRaw": src_raw,
        "separated": lib_top == 0,
        "advice": ("已完成分离：素材库只剩成品" if lib_top == 0
                   else f"素材库顶层还有 {lib_top} 个未分类 mp4，建议执行分离"),
    }

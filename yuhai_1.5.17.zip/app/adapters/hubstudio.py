"""Hubstudio 指纹浏览器适配层。

接口实测校准（2026-11，Hubstudio 3.61.2 桌面版，本地 API 127.0.0.1:6873）
─────────────────────────────────────────────────────────────────────
本文件已按真实抓包结果重写，修正了旧版的若干错误假设。要点：

1. env 系列走的是「本地 API 路径 → 云端路径」的映射白名单。
   本地路径用 /api/v1/xxx，云端实际是 /base/api/v2/container/xxx。
   白名单在 dist/service/service.js 的 Fb 常量里，不在白名单的路径
   一律返回 {"code":"E010006","msg":"请检查请求路径是否正确"}。

2. 改环境和改代理是两个不同接口，字段名也不一样：
     /api/v1/env/update        改名称/备注。代理字段传了无效。
     /api/v1/env/proxy/update  改代理。必须带 asDynamicType，
                               主机字段叫 proxyHost（不是 proxyServer）。
     /api/v1/env/create        创建。主机字段叫 proxyServer。
   三个接口的代理字段名不统一，这是 Hubstudio 侧的历史遗留，必须分别处理。

3. 启动环境可以用 serialNumber（序号）或 containerCode（编码）。
   两者都行，containerCode 数字/字符串均可。serialNumber 更稳
   （containerCode 云端校验容易因类型问题报「参数校验失败」）。

4. env/list 不返回 containerId / envId。
   env/list 只有 containerCode 和 serialNumber。那个 19 位的
   envId（如 2109350234355572736）只能从 browser/start 的
   open-detail 响应里拿，或用 all-browser-status 的运行态反查。
   profile 目录是 chromium_<envId>，所以 envId 只能运行后才知道。

5. all-browser-status 的 pid 是真实进程 PID，可直接用于 psutil 反查。

保持不变的旧逻辑：PID → CDP 端口靠逐个 probe，不猜端口范围。
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import sqlite3
import tempfile
import shutil
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

import httpx
import psutil

from app.config import settings

log = logging.getLogger("yuhai.hubstudio")


# ────────────────────────────── 错误码 ──────────────────────────────
# 本地 API 网关自己产生的错误码（与云端错误码不重叠）
LOCAL_ERR_PATH = "E010006"      # 路径不在白名单
LOCAL_ERR_PARAM = "E010008"     # 参数校验失败
LOCAL_ERR_NOENV = "E110321"     # 该环境不存在
LOCAL_ERR_PROXYHOST = "E110076"  # 代理主机不能为空
LOCAL_ERR_PROXYPORT = "E110077"  # 代理端口不能为空

# Facebook 的 username_value 有时存的是 profile URL 而不是邮箱，
# 用这个把两类分开（实测 2109350234355572736 存的就是 URL）
_EMAIL_RE = re.compile(r"^[\w.\-+]+@[\w\-]+\.[\w.\-]+$")


@dataclass
class EnvInfo:
    container_code: str
    serial_number: int = 0
    container_id: str = ""       # 注意：env/list 不返回，通常为空
    name: str = ""
    role: str = "spare"
    account: str = ""
    c_user: str = ""
    display_name: str = ""
    profile_dir: str = ""
    proxy_type: str = ""
    proxy_host: str = ""
    proxy_port: int = 0
    proxy_account: str = ""
    proxy_password: str = ""
    proxy_dynamic: int = 0
    proxy_kind: str = ""
    status: str = "closed"
    pid: int = 0
    cdp_port: int = 0
    egress_ip: str = ""
    egress_country: str = ""
    kernel: str = ""
    core_version: int = 0
    login_valid: int | None = None
    last_checked: str = ""
    raw: dict = field(default_factory=dict)


class HubstudioError(RuntimeError):
    """Hubstudio 调用失败。

    code 保留原始错误码，便于上层区分「路径不存在」和「业务失败」。
    """
    def __init__(self, msg: str, code: str = "") -> None:
        super().__init__(msg)
        self.code = code


def _as_dict(data: dict) -> dict:
    """把云端返回的 data 字段统一成 dict。

    云端有的接口回对象（env/list、env/create），有的只回 true
    （env/update、env/del、env/proxy/update）。直接 dict() 会炸，
    所以这里统一兜底。
    """
    d = data.get("data") if isinstance(data, dict) else None
    return d if isinstance(d, dict) else {"ok": bool(d), "raw": d}


class Hubstudio:
    def __init__(self, base: str | None = None) -> None:
        self.base = (base or settings.hubstudio_api).rstrip("/")

    # ───────────────────────── 低层 ─────────────────────────
    async def _post(self, path: str, body: dict | None = None,
                    timeout: float = 20.0) -> dict:
        """POST 并返回解析后的 JSON。

        与旧版的差异：
          - 错误码放进异常对象，调用方可判断是不是路径不存在
          - 空 body 也发 {}，本地网关要求 body 必须是合法 JSON
        """
        url = f"{self.base}{path}"
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.post(url, json=body if body is not None else {})
        except httpx.ConnectError as e:
            raise HubstudioError(
                f"Hubstudio 未启动或端口不通: {url}（确认客户端在运行，"
                f"且设置里已开启本地 API）") from e
        except httpx.TimeoutException as e:
            raise HubstudioError(f"Hubstudio 接口超时: {path}") from e

        if r.status_code != 200:
            raise HubstudioError(f"Hubstudio {path} HTTP {r.status_code}",
                                 code=str(r.status_code))
        try:
            data = r.json()
        except Exception as e:
            raise HubstudioError(f"Hubstudio {path} 返回非 JSON") from e

        code = str(data.get("code"))
        # 本地网关用字符串 "0"，云端透传用数字 0，两种都算成功
        if code not in ("0", "200", "None", ""):
            msg = data.get("msg") or data.get("errMessage") or "未知错误"
            raise HubstudioError(f"Hubstudio {path} 失败: {msg} ({code})", code=code)
        return data

    async def _try_post(self, path: str, body: dict | None = None,
                        timeout: float = 20.0) -> dict | None:
        """探测用：路径不存在返回 None，其它错误照抛。"""
        try:
            return await self._post(path, body, timeout)
        except HubstudioError as e:
            if e.code == LOCAL_ERR_PATH:
                return None
            raise

    # ───────────────────────── 状态 ─────────────────────────
    async def status(self) -> dict[str, dict]:
        """返回 {containerCode: {status, pid, raw_status}}。

        status 语义（来自 Hubstudio 的 Gf 映射）：
            0 → 运行中    1 → 已连接
            2 → 启动中    3 → 未运行
        """
        data = await self._post("/api/v1/browser/all-browser-status")
        out: dict[str, dict] = {}
        for c in (data.get("data") or {}).get("containers") or []:
            code = str(c.get("containerCode") or "")
            if not code:
                continue
            raw = int(c.get("status") if c.get("status") is not None else 3)
            pid = int(c.get("pid") or 0)
            # 只有真的跑起来才有 pid；raw 0/1 视为运行中
            running = pid > 0 or raw in (0, 1)
            out[code] = {
                "status": "running" if running else "closed",
                "pid": pid,
                "raw_status": raw,
            }
        return out

    async def env_list(self) -> list[dict]:
        """环境清单。

        返回字段（实测）：containerCode / serialNumber / containerName /
        tagName / labels / remark / proxyTypeName / proxyHost / proxyPort /
        proxyAccount / proxyPassword / asDynamicType / lastUsedIp /
        lastCountry / openTime / createTime / coreVersion / ua

        注意：没有 containerId、没有 envId。
        """
        data = await self._post("/api/v1/env/list")
        return list((data.get("data") or {}).get("list") or [])

    async def open_count(self) -> dict:
        """配额。返回 {maxDailyOpenCount, todayOpenCount}。"""
        data = await self._post("/api/v1/team/open-count")
        return _as_dict(data)

    # ───────────────────────── 生命周期 ─────────────────────────
    async def start(self, container_code: str = "", serial_number: int = 0,
                    **opts) -> dict:
        """启动环境。

        两种寻址方式，二选一：
            start(container_code="1887976888")
            start(serial_number=5)

        可选参数（都能省略，省略就用环境里存的那份）：
            isHeadless              无头模式
            isWebDriverReadOnlyMode webdriver 只读
            args                    额外启动参数 list
            containerTabs           打开时加载的 URL list
            shouldCloseTabsOnOpen   打开时关掉旧标签
            cdpHide                 隐藏 CDP 痕迹
            pageZoom                缩放
            skipSystemResourceCheck 跳过 CPU/内存/磁盘检查
            ipCheckOpen             打开时校验出口 IP

        返回 data：
            debuggingPort   CDP 端口（关键）
            containerId     Hubstudio 内部 container id（不是 PID）
            containerCode   环境编码
            browserPath / webdriver / downloadPath / proxyType / ip
        """
        if not container_code and not serial_number:
            raise HubstudioError("必须指定 containerCode 或 serialNumber")

        body: dict[str, Any] = {}
        if serial_number:
            body["serialNumber"] = int(serial_number)
        else:
            body["containerCode"] = container_code
        body.update(opts)

        data = await self._post("/api/v1/browser/start", body, timeout=120)
        d = _as_dict(data)
        log.info("start %s -> port=%s containerId=%s ip=%s",
                 container_code or f"serial:{serial_number}",
                 d.get("debuggingPort"), d.get("containerId"), d.get("ip"))
        return d

    async def stop(self, container_code: str) -> dict:
        data = await self._post("/api/v1/browser/stop",
                                {"containerCode": str(container_code)})
        return _as_dict(data)

    async def stop_all(self) -> dict:
        data = await self._post("/api/v1/browser/stop-all")
        return _as_dict(data)

    async def foreground(self, container_code: str) -> dict:
        data = await self._post("/api/v1/browser/foreground",
                                {"containerCode": str(container_code)})
        return _as_dict(data)

    async def clear_cache(self, container_codes: list[str | int],
                          localStorage: bool = True, indexedDB: bool = True,
                          cookie: bool = True, extension: bool = True) -> dict:
        """清环境缓存。container_codes 传 containerCode。"""
        if not container_codes:
            raise HubstudioError("container_codes 为空")
        body = {
            "browserOauths": [str(c) for c in container_codes],
            "localStorage": localStorage,
            "indexedDB": indexedDB,
            "cookie": cookie,
            "extension": extension,
        }
        data = await self._post("/api/v1/cache/clear", body, timeout=120)
        return _as_dict(data)

    # ───────────────────────── 环境增删改 ─────────────────────────
    async def create_env(self, name: str, proxy_type: str = "Socks5",
                         proxy_server: str = "", proxy_port: int = 0,
                         proxy_account: str = "", proxy_password: str = "",
                         remark: str = "") -> dict:
        """创建环境。

        必填（云端逐级校验，缺一个报一个）：
            containerName   环境名
            proxyTypeName   代理类型（实测不传就报「代理类型不能为空」）
            proxyServer     代理主机 ← 注意这里叫 proxyServer
            proxyPort       代理端口

        返回 data: {containerCode, coreVersion}
        """
        if not name.strip():
            raise HubstudioError("环境名不能为空")
        if not (proxy_type or "").strip():
            raise HubstudioError("代理类型不能为空（proxyTypeName）")
        if not proxy_server.strip():
            raise HubstudioError("代理主机不能为空（proxyServer）")
        if not proxy_port:
            raise HubstudioError("代理端口不能为空（proxyPort）")

        body: dict[str, Any] = {
            "containerName": name.strip(),
            "proxyTypeName": proxy_type.strip(),
            "proxyServer": proxy_server.strip(),
            "proxyPort": int(proxy_port),
        }
        if proxy_account:
            body["proxyAccount"] = proxy_account
        if proxy_password:
            body["proxyPassword"] = proxy_password
        if remark:
            body["remark"] = remark

        data = await self._post("/api/v1/env/create", body, timeout=60)
        return _as_dict(data)

    async def delete_env(self, container_codes: list[str | int]) -> dict:
        """删除环境，一次可传多个。不可恢复。"""
        if not container_codes:
            raise HubstudioError("containerCodes 为空")
        codes = [int(c) if str(c).isdigit() else c for c in container_codes]
        data = await self._post("/api/v1/env/del", {"containerCodes": codes},
                                timeout=60)
        return _as_dict(data)

    async def rename_env(self, container_code: str, name: str,
                         remark: str | None = None) -> dict:
        """改环境名 / 备注。

        对应本地路径 /api/v1/env/update。

        注意这个接口的两个坑：
          1) containerName 是必填的，即使你只想改备注也得把名字回传。
          2) 它对代理字段无效 —— 传 proxyHost / proxyServer 都会被忽略，
             改代理必须用 set_proxy()。这是实测结论，不是猜测。
        """
        if not name.strip():
            raise HubstudioError("containerName 是必填项（env/update 不接受空名字）")
        body: dict[str, Any] = {
            "containerCode": str(container_code),
            "containerName": name.strip(),
        }
        if remark is not None:
            body["remark"] = remark
        data = await self._post("/api/v1/env/update", body, timeout=30)
        # 云端对 update 只回 true，不是对象
        return {"updated": True, "raw": data.get("data")}

    async def set_proxy(self, container_code: str, proxy_host: str,
                        proxy_port: int, proxy_type: str = "Socks5",
                        proxy_account: str = "", proxy_password: str = "",
                        as_dynamic_type: int = 0) -> dict:
        """改环境代理。

        对应本地路径 /api/v1/env/proxy/update（不是 env/update！）。

        必填：
            containerCode
            asDynamicType      0=静态  1=动态。缺这个直接报 E010008
            proxyHost          主机 ← 注意这里叫 proxyHost，与 create 的
                               proxyServer 不一致
            proxyPort
        """
        if not str(container_code).strip():
            raise HubstudioError("containerCode 不能为空")
        if not proxy_host.strip():
            raise HubstudioError("代理主机不能为空（proxyHost）")
        if not proxy_port:
            raise HubstudioError("代理端口不能为空（proxyPort）")

        body: dict[str, Any] = {
            "containerCode": str(container_code),
            "asDynamicType": int(as_dynamic_type),
            "proxyTypeName": (proxy_type or "Socks5").strip(),
            "proxyHost": proxy_host.strip(),
            "proxyPort": int(proxy_port),
            "proxyAccount": proxy_account or "",
            "proxyPassword": proxy_password or "",
        }
        data = await self._post("/api/v1/env/proxy/update", body, timeout=30)
        return _as_dict(data)

    async def set_remark(self, container_codes: list[str | int], remark: str,
                         op_type: int = 1) -> dict:
        """批量改备注（不碰名字，比 env/update 省事）。

        对应 /api/v1/container/batch-update-remark
        必填：containerCodes, type（1=覆盖）, remark
        """
        if not container_codes:
            raise HubstudioError("containerCodes 为空")
        body = {
            "containerCodes": [str(c) for c in container_codes],
            "type": int(op_type),
            "remark": remark,
        }
        data = await self._post("/api/v1/container/batch-update-remark",
                                body, timeout=30)
        return _as_dict(data)

    # ───────────────────────── 兼容性自检 ─────────────────────────
    async def version(self) -> dict:
        """探测 Hubstudio 本地 API 是否可用、接口路径有没有变。

        用于「客户端升级后还能不能连上」的体检。
        判定依据：能不能拿到环境清单 + 各关键路径是否还在白名单里。
        """
        out: dict[str, Any] = {
            "apiOk": False,
            "envListOk": False,
            "statusOk": False,
            "envCount": 0,
            "quota": None,
            "endpoint": self.base,
            "endpoints": {},          # 各路径可用性
            "error": None,
            "warnings": [],
        }

        try:
            envs = await self.env_list()
            out["apiOk"] = True
            out["envListOk"] = True
            out["envCount"] = len(envs)
        except Exception as e:
            out["error"] = f"env/list 失败: {e}"
            return out

        try:
            await self.status()
            out["statusOk"] = True
        except Exception as e:
            out["warnings"].append(f"all-browser-status 失败: {e}")

        try:
            out["quota"] = await self.open_count()
        except Exception as e:
            out["warnings"].append(f"team/open-count 失败: {e}")

        # 探测写接口是否还在（用空 body 触发参数校验，能返回 E010008 就说明路径存在）
        probes = [
            ("/api/v1/env/create", "create"),
            ("/api/v1/env/update", "update"),
            ("/api/v1/env/proxy/update", "proxyUpdate"),
            ("/api/v1/env/del", "delete"),
            ("/api/v1/container/batch-update-remark", "batchRemark"),
        ]
        for path, key in probes:
            try:
                d = await self._post(path, {}, timeout=15)
                out["endpoints"][key] = "ok"
            except HubstudioError as e:
                if e.code == LOCAL_ERR_PATH:
                    out["endpoints"][key] = "missing"
                    out["warnings"].append(f"{path} 路径不存在（客户端可能改了接口）")
                elif e.code in (LOCAL_ERR_PARAM, LOCAL_ERR_PROXYHOST,
                                LOCAL_ERR_PROXYPORT, LOCAL_ERR_NOENV):
                    # 参数错误 = 路径存在且在工作
                    out["endpoints"][key] = "ok"
                else:
                    out["endpoints"][key] = f"err:{e.code}"

        return out

    # ───────────────────────── PID → CDP ─────────────────────────
    @staticmethod
    def listening_ports(pid: int) -> list[int]:
        """列出进程（含子进程）的监听端口。

        不能猜端口范围 —— 环境重启后端口会变，只能实测。
        """
        ports: list[int] = []

        def _collect(p: psutil.Process) -> None:
            try:
                for c in p.net_connections(kind="inet"):
                    if c.status == psutil.CONN_LISTEN and c.laddr:
                        ports.append(int(c.laddr.port))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        try:
            proc = psutil.Process(pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return []

        _collect(proc)
        try:
            for child in proc.children(recursive=True):
                _collect(child)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        return sorted(set(ports))

    @staticmethod
    async def probe_cdp(port: int, timeout: float = 3.0) -> dict | None:
        """GET /json/version，Browser 里含 Chrom 才算命中。"""
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.get(f"http://127.0.0.1:{port}/json/version")
            if r.status_code != 200:
                return None
            d = r.json()
            if "Chrom" in (d.get("Browser") or ""):
                return {"port": port, **d}
        except Exception:
            return None
        return None

    async def resolve_cdp(self, pid: int, hint_port: int = 0) -> dict | None:
        """PID → {port, Browser, webSocketDebuggerUrl}

        hint_port 先试（browser/start 的返回值里直接有 debuggingPort，
        比反查快得多）。
        """
        if hint_port:
            hit = await self.probe_cdp(hint_port)
            if hit:
                return hit
        for p in self.listening_ports(pid):
            hit = await self.probe_cdp(p)
            if hit:
                return hit
        return None

    async def find_env_by_pid(self, pid: int) -> dict | None:
        st = await self.status()
        for code, info in st.items():
            if info.get("pid") == pid:
                return {"container_code": code, **info}
        return None

    # ───────────────────── 本地 profile 读取 ─────────────────────
    @staticmethod
    def profile_dir_by_cdp_port(cdp_port: int) -> str:
        """按 CDP 端口反查 profile 目录名（chromium_<envId>）。

        原理：Chromium 每个环境都带 --remote-debugging-port=N 和
        --user-data-dir=<cache>/chromium_<envId> 两个启动参数。
        扫一遍进程命令行就能把 port ↔ profile 目录对上。

        为什么不用 CDP 的 Browser.getBrowserCommandLine：
        Chrome 152 加了 origin 校验，裸 websocket 连不上（403 Forbidden），
        除非启动时显式给了 --remote-allow-origins。所以我们不去碰它。

        为什么不用 env/list：
        env/list 根本不返回 envId，只有 containerCode 和 serialNumber。
        """
        if not cdp_port:
            return ""
        marker_port = f"--remote-debugging-port={cdp_port}"
        marker_dir = "--user-data-dir="
        try:
            for p in psutil.process_iter(["pid", "cmdline"]):
                cl = p.info.get("cmdline") or []
                if not cl:
                    continue
                hit_port = False
                udd = ""
                for a in cl:
                    if a == marker_port:
                        hit_port = True
                    elif a.startswith(marker_dir):
                        udd = a[len(marker_dir):]
                if hit_port and udd:
                    return Path(udd).name
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        return ""

    @staticmethod
    def hubstudio_cache_root() -> Path:
        appdata = os.environ.get("APPDATA") or str(Path.home() / "AppData/Roaming")
        return Path(appdata) / "hubstudio-client" / "sdk" / "cache"

    def read_login_emails(self, profile_dir: str) -> list[str]:
        """从 Login Data 读已保存的登录邮箱（username_value 是明文）。

        实测坑：Facebook 的 username_value 有时不是邮箱，而是 profile URL
        （https://www.facebook.com/profile.php?id=61596...）。
        所以这里按「像邮箱」过滤，URL 一律丢掉，避免污染 account 字段。

        只读邮箱，不碰密码（密码是 Chromium 用 DPAPI 加密的）。
        """
        root = self.hubstudio_cache_root()
        p = root / profile_dir / "Default" / "Login Data"
        if not p.exists():
            return []
        tmp = Path(tempfile.gettempdir()) / f"ld_{abs(hash(profile_dir))}.db"
        try:
            shutil.copy2(p, tmp)
            con = sqlite3.connect(str(tmp))
            rows = con.execute(
                "SELECT origin_url, username_value FROM logins "
                "WHERE origin_url LIKE '%facebook%'"
            ).fetchall()
            con.close()
            out: list[str] = []
            seen: set[str] = set()
            for _, u in rows:
                if not u:
                    continue
                u = u.strip()
                # 只要邮箱形态的；URL / 纯数字 id 都不是账号
                if not _EMAIL_RE.match(u):
                    continue
                if u.lower() in seen:
                    continue
                seen.add(u.lower())
                out.append(u)
            return out
        except Exception as e:
            log.debug("read login data failed: %s", e)
            return []
        finally:
            try:
                tmp.unlink()
            except Exception:
                pass

    def read_login_identities(self, profile_dir: str) -> list[dict]:
        """读 profile 里的 FB 身份线索：邮箱 + profile URL。

        返回 [{email, profileUrl}]。account 字段用 email，
        没有邮箱时用 profile 链接（那是 FB 的 c_user 型身份）。
        """
        root = self.hubstudio_cache_root()
        p = root / profile_dir / "Default" / "Login Data"
        if not p.exists():
            return []
        tmp = Path(tempfile.gettempdir()) / f"ld2_{abs(hash(profile_dir))}.db"
        try:
            shutil.copy2(p, tmp)
            con = sqlite3.connect(str(tmp))
            rows = con.execute(
                "SELECT origin_url, username_value FROM logins "
                "WHERE origin_url LIKE '%facebook%'"
            ).fetchall()
            con.close()
        except Exception as e:
            log.debug("read login identities failed: %s", e)
            return []
        finally:
            try:
                tmp.unlink()
            except Exception:
                pass

        emails: list[str] = []
        urls: list[str] = []
        for _, u in rows:
            if not u:
                continue
            u = u.strip()
            if _EMAIL_RE.match(u):
                if u.lower() not in {x.lower() for x in emails}:
                    emails.append(u)
            elif u.startswith("http"):
                if u not in urls:
                    urls.append(u)
        if emails:
            return [{"email": e, "profileUrl": urls[0] if urls else ""} for e in emails]
        # 没邮箱但有 profile 链接 → 用链接当身份，email 留空
        return [{"email": "", "profileUrl": u} for u in urls]

    def find_profile_by_account(self, account: str) -> str:
        """按登录邮箱反查 profile 目录名（chromium_<envId>）。

        因为 env/list 不返回 envId，只能靠遍历 profile 里的 Login Data 反查。
        """
        root = self.hubstudio_cache_root()
        if not root.exists() or not account:
            return ""
        for d in root.iterdir():
            if not (d.is_dir() and d.name.startswith("chromium_")):
                continue
            emails = self.read_login_emails(d.name)
            if emails and account in emails:
                return d.name
        return ""

    # ───────────────────────── 汇总 ─────────────────────────
    async def collect(self) -> list[EnvInfo]:
        """合并 env/list + all-browser-status，产出完整环境列表。"""
        envs_raw = await self.env_list()
        try:
            st = await self.status()
        except HubstudioError:
            st = {}

        out: list[EnvInfo] = []
        for e in envs_raw:
            code = str(e.get("containerCode") or "")
            if not code:
                continue
            info = EnvInfo(
                container_code=code,
                serial_number=int(e.get("serialNumber") or 0),
                # env/list 没有 containerId，这里留空；运行后可补
                container_id=str(e.get("containerId") or ""),
                name=e.get("containerName") or code,
                proxy_type=(e.get("proxyTypeName") or "").upper(),
                proxy_host=e.get("proxyHost") or "",
                proxy_port=int(e.get("proxyPort") or 0),
                proxy_account=e.get("proxyAccount") or "",
                proxy_password=e.get("proxyPassword") or "",
                proxy_dynamic=int(e.get("asDynamicType") or 0),
                egress_ip=e.get("lastUsedIp") or "",
                egress_country=e.get("lastCountry") or "",
                core_version=int(e.get("coreVersion") or 0),
                raw=e,
            )
            s = st.get(code)
            if s:
                info.status = s["status"]
                info.pid = s["pid"]
            out.append(info)
        return out


hub = Hubstudio()


# ───────────────────────── 环境信息补全 ─────────────────────────
_PUB = settings.fb_publisher_cuser
_BAK = settings.fb_backup_cuser


def classify_role(email: str, name: str) -> str:
    if email and email.startswith("m19897410232"):
        return "publisher"
    if email and email.startswith("haiyu325355"):
        return "backup"
    if "网易" in name:
        return "publisher"
    if "谷歌" in name:
        return "backup"
    return "spare"


async def enrich(info: EnvInfo) -> EnvInfo:
    """用本地 profile 把账号、登录态、CDP 端口、内核补上。

    顺序有讲究：
      1) 运行中 → 先拿 CDP 和内核版本
      2) profile 目录 → env/list 不返回 envId，只有运行后才可能对上
      3) 账号 → 从 profile 的 Login Data 读；URL 型身份存到 c_user 字段

    重要：env/list 不返回 envId / containerId，所以「没有 profile_dir 且
    没在运行」的环境，本函数无法自动定位 profile —— 这是 Hubstudio 的
    设计限制，不是 bug。那种情况只能靠名字归类角色。
    """
    root = hub.hubstudio_cache_root()

    # 1) 运行中 → CDP + 内核
    if info.status == "running" and info.pid:
        cdp = await hub.resolve_cdp(info.pid, info.cdp_port)
        if cdp:
            info.cdp_port = cdp["port"]
            info.kernel = cdp.get("Browser") or ""

    # 2) 运行中且已拿到 CDP 端口 → 直接按端口反查 profile 目录（最可靠）
    if not info.profile_dir and info.cdp_port:
        info.profile_dir = hub.profile_dir_by_cdp_port(info.cdp_port)
        if info.profile_dir:
            # chromium_<envId> → 补 container_id，下次不用再扫进程
            tail = info.profile_dir.split("_", 1)[-1]
            if tail.isdigit() and not info.container_id:
                info.container_id = tail

    # 3) 有 container_id 就能直接对目录名
    if not info.profile_dir and info.container_id and root.exists():
        cand = root / f"chromium_{info.container_id}"
        if cand.exists():
            info.profile_dir = cand.name

    # 4) 按已知识别反查 profile
    if not info.profile_dir and root.exists():
        key = info.account or info.c_user
        if key:
            info.profile_dir = hub.find_profile_by_account(key)

    # 5) 从 profile 读身份（邮箱优先，URL 当 c_user 型身份）
    if info.profile_dir:
        idents = hub.read_login_identities(info.profile_dir)
        if idents:
            first = idents[0]
            if first.get("email") and not info.account:
                info.account = first["email"]
            if first.get("profileUrl"):
                info.c_user = first["profileUrl"]

    info.role = classify_role(info.account, info.name)

    # 6) 登录态判定：跑起来且有 CDP 就认为可控
    if info.status == "running" and info.cdp_port:
        info.login_valid = 1

    return info


async def dump_to_db(infos: list[EnvInfo]) -> int:
    """把环境信息写库。

    字段更新策略分两类，别混：

    1) 「本次采到就是事实」的字段 → 无条件覆盖：
       name / status / pid / cdp_port / 代理 / 出口IP / 内核 / role
       这些每次都能从 Hubstudio 拿到最新值，留着旧值只会骗人。

    2) 「本次可能采不到」的字段 → 空则保留旧值：
       container_id / profile_dir / account / c_user
       这几个只有环境在跑、或者之前跑过才拿得到。没采到就保留，
       否则一同步就全清空了。

    注意 profile_dir 有个陷阱：它必须跟着 container_id 走。
    env/list 不返回 envId，如果环境一直没启动过，我们根本无法确定
    它的 profile 目录。这种环境下 profile_dir 留空才是对的 ——
    绝不能让它继承别的环境的值（旧代码的 COALESCE 就是这么出错的）。
    所以这里加了个约束：profile_dir 只在 container_id 对得上时才写。
    """
    from app.db import db, now_iso
    ts = now_iso()
    n = 0
    for i in infos:
        # profile_dir 必须与 container_id 一致，否则视为无效
        pdir = i.profile_dir or ""
        if pdir and i.container_id:
            tail = pdir.split("_", 1)[-1]
            if tail.isdigit() and tail != i.container_id:
                log.debug("profile_dir %s 与 container_id %s 不匹配，丢弃",
                          pdir, i.container_id)
                pdir = ""
        elif pdir and not i.container_id:
            # 没有 container_id 就没法验证这个目录是不是自己的，不写
            pdir = ""

        db.exec(
            """INSERT INTO envs(container_code,container_id,name,role,account,c_user,
                    display_name,profile_dir,proxy_type,proxy_host,proxy_port,proxy_kind,
                    status,pid,cdp_port,egress_ip,egress_country,kernel,login_valid,
                    last_checked,raw,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(container_code) DO UPDATE SET
                    container_id=COALESCE(NULLIF(excluded.container_id,''),
                                          envs.container_id),
                    name=excluded.name,
                    role=excluded.role,
                    account=COALESCE(NULLIF(excluded.account,''), envs.account),
                    c_user=COALESCE(NULLIF(excluded.c_user,''), envs.c_user),
                    display_name=CASE WHEN excluded.display_name<>''
                                      THEN excluded.display_name
                                      ELSE envs.display_name END,
                    -- profile_dir 直接覆盖（含清空）：它是 container_id 的函数，
                    -- 不一致的旧值必须被清掉，不能靠 COALESCE 保活
                    profile_dir=excluded.profile_dir,
                    proxy_type=excluded.proxy_type, proxy_host=excluded.proxy_host,
                    proxy_port=excluded.proxy_port, proxy_kind=excluded.proxy_kind,
                    status=excluded.status, pid=excluded.pid, cdp_port=excluded.cdp_port,
                    egress_ip=CASE WHEN excluded.egress_ip<>''
                                   THEN excluded.egress_ip ELSE envs.egress_ip END,
                    egress_country=CASE WHEN excluded.egress_country<>''
                                        THEN excluded.egress_country
                                        ELSE envs.egress_country END,
                    kernel=CASE WHEN excluded.kernel<>'' THEN excluded.kernel
                                ELSE envs.kernel END,
                    login_valid=excluded.login_valid,
                    last_checked=excluded.last_checked, raw=excluded.raw,
                    updated_at=excluded.updated_at""",
            (i.container_code, i.container_id, i.name, i.role, i.account, i.c_user,
             i.display_name, pdir, i.proxy_type, i.proxy_host, i.proxy_port,
             i.proxy_kind, i.status, i.pid or None, i.cdp_port or None,
             i.egress_ip, i.egress_country, i.kernel,
             i.login_valid if i.login_valid is not None else None,
             i.last_checked, json.dumps(i.raw, ensure_ascii=False), ts),
        )
        n += 1
    return n

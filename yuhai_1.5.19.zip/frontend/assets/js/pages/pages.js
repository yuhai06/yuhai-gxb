/* 公共主页（真实数据版） */
import { icon } from '../icons.js?v=e2c064c209';
import { api } from '../api.js?v=57de7f9574';
import { store, raiseGuard } from '../store.js?v=dd9f0e78d7';
import {
  nfmt, badge, pageHead, sparkline, statCard, $, $$, toast, modal, bar, ts, ago, emptyState,
} from '../ui.js?v=0770c29dda';

let viewMode = 'grid';
let filter = { q: '', health: 'all', sort: 'views' };
const opened = new Set();   // 展开了哪些账号分组

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '公共主页',
      desc: '主页是发布通道，数据看「视频数据」页',
      actions: [
        `<button class="btn sm" data-act="pid"><span data-icon="route"></span>按 PID 提取</button>`,
        `<button class="btn sm primary" data-act="create"><span data-icon="plus"></span>创建主页</button>`,
      ],
    })}
    <div id="pg-body"></div>
  `;
  $$('[data-act="create"]', root).forEach((b) => (b.onclick = openCreate));
  $$('[data-act="pid"]', root).forEach((b) => (b.onclick = openPid));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    await store.loadCore();
  } catch (e) {
    toast('加载失败', e.message, 'err');
  }
  paint(root);
}

function paint(root) {
  const body = $('#pg-body', root);
  if (!body) return;
  const all = store.pages || [];

  // ── 按账号分组折叠（2026-11-17 重做）──
  // 用户：「这个页面看着好乱整理一下全部主页都摆出来太难看了」
  // 旧版 23 张卡片全平铺，找主页要滚好几屏。
  // 现在：一个账号一行，点开才展开该号的主页表格。
  const accs = (store.accountsData && store.accountsData.items) || [];
  const envToAcc = {};
  accs.forEach((a) => { if (a.envCode) envToAcc[String(a.envCode)] = a; });

  const ORPHAN = '__orphan__';
  const groups = new Map();
  groups.set(ORPHAN, { label: '未归属主页', role: '', cUser: '',
                       pages: [], isOrphan: true });
  accs.forEach((a) => {
    groups.set(a.id, { label: a.label, role: a.role, cUser: a.cUser || '',
                       pages: [], isOrphan: false });
  });
  all.forEach((p) => {
    const acc = envToAcc[String(p.envCode || '')];
    const k = acc ? acc.id : ORPHAN;
    groups.get(k).pages.push(p);
  });

  const q = (filter.q || '').trim().toLowerCase();
  const hit = (p) => (!q
    || String(p.name || '').toLowerCase().includes(q)
    || String(p.profileId || '').includes(q)
    || String(p.assetId || '').includes(q));

  const rows = [];
  groups.forEach((g, k) => {
    if (!g.pages.length) return;
    const ps = g.pages.filter(hit);
    if (!ps.length) return;
    rows.push({
      key: k, label: g.label, role: g.role, cUser: g.cUser,
      isOrphan: g.isOrphan, pages: ps,
      plays: g.pages.reduce((a, p) => a + (p.views30d || 0), 0),
      total: g.pages.length,
    });
  });
  rows.sort((a, b) => b.plays - a.plays);

  const totalPlays = all.reduce((a, p) => a + (p.views30d || 0), 0);
  const noAsset = all.filter((p) => !p.assetId).length;
  const noOwner = all.filter((p) => !p.envCode).length;
  // 接口失败时不能显示"0 个主页"——那是把故障说成空数据。
  const loadErr = store.failed('pages', 'accounts');

  body.innerHTML = `
    ${loadErr ? `<div class="card" style="margin-bottom:13px;border-color:rgba(248,113,113,.45)">
      <div class="card-body" style="display:flex;gap:10px;align-items:center">
        <span style="color:var(--danger);font-size:12px">主页数据加载失败，下面的 0 不是真实结果。</span>
        <button class="btn sm" id="pg-retry" style="margin-left:auto">重试</button>
      </div></div>` : ''}
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '主页总数', value: loadErr ? '—' : all.length, unit: '个', iconName: 'flag' })}
      ${statCard({ label: '总播放', value: loadErr ? '—' : nfmt(totalPlays), unit: '次', iconName: 'eye',
                   foot: loadErr ? '数据未加载' : `${all.length} 个主页合计` })}
      ${statCard({ label: '未归属', value: loadErr ? '—' : noOwner, unit: '个', iconName: 'warn',
                   foot: loadErr ? '数据未加载' : (noOwner ? '没有挂在任何账号下' : '全部已归属') })}
      ${statCard({ label: '缺 asset_id', value: loadErr ? '—' : noAsset, unit: '个', iconName: 'warn',
                   foot: loadErr ? '数据未加载' : (noAsset ? '无法发布' : '全部齐备') })}
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-body" style="display:flex;gap:9px;align-items:center;padding:10px 13px">
        <input class="input" id="pf-q" placeholder="搜索主页名 / page_id / asset_id"
               value="${esc(filter.q)}" style="flex:1;min-width:200px;font-size:11px" />
        <button class="btn sm ghost" id="pf-clear">清空</button>
        <span style="color:var(--tx-3);font-size:10px;margin-left:auto;white-space:nowrap">
          ${all.length} 个主页 · ${rows.length} 个分组
        </span>
      </div>
    </div>

    <div id="pg-groups"></div>
  `;

  const host = $('#pg-groups', body);
  if (!rows.length) {
    host.innerHTML = `<div class="card"><div class="card-body">${
      emptyState('没有匹配的主页', '清空搜索条件试试')}</div></div>`;
  } else {
    host.innerHTML = rows.map((g) => {
      const open = opened.has(g.key) || !!q;
      const rb = g.isOrphan ? badge('无归属', 'mute')
        : g.role === 'publisher' ? badge('发布号', 'info')
        : g.role === 'backup' ? badge('备份号', 'purple')
        : badge(g.role || '—', 'mute');
      return `
      <div class="card" style="margin-bottom:8px">
        <div class="card-head" style="cursor:pointer" data-gtoggle="${esc(g.key)}">
          <div class="card-title" style="display:flex;align-items:center;gap:8px">
            <span style="color:var(--tx-3);font-size:11px">${open ? '\u25be' : '\u25b8'}</span>
            <b>${esc(g.label)}</b>
            ${rb}
            <span class="sub">${g.total} 个主页 · ${nfmt(g.plays)} 播放</span>
          </div>
          ${g.cUser ? `<span class="mono" style="font-size:10px;color:var(--tx-3)">${esc(g.cUser)}</span>` : ''}
        </div>
        ${open ? `<div class="card-body tight" style="padding-top:0">${pagesTable(g.pages)}</div>` : ''}
      </div>`;
    }).join('');
  }

  const qi = $('#pf-q', body);
  if (qi) {
    qi.oninput = () => {
      filter.q = qi.value;
      const pos = qi.selectionStart;
      paint(root);
      const n = $('#pf-q', body);
      if (n) { n.focus(); n.setSelectionRange(pos, pos); }
    };
  }
  const cb = $('#pf-clear', body);
  if (cb) cb.onclick = () => { filter.q = ''; paint(root); };
  const rt = $('#pg-retry', body);
  if (rt) rt.onclick = () => load(root);

  $$('[data-gtoggle]', body).forEach((el) => {
    el.onclick = () => {
      const k = el.dataset.gtoggle;
      if (opened.has(k)) opened.delete(k); else opened.add(k);
      paint(root);
    };
  });
  $$('[data-pg]', body).forEach((el) => {
    el.onclick = (ev) => {
      if (ev.target.tagName === 'BUTTON') return;
      openDetail(el.dataset.pg);
    };
  });
}

/* 一个账号下的主页清单：紧凑表格，一屏看完 */
function pagesTable(list) {
  const sorted = list.slice().sort((a, b) => (b.views30d || 0) - (a.views30d || 0));
  return `<div class="tbl-wrap">
    <table class="tbl" style="font-size:10.5px">
      <thead><tr>
        <th>主页</th><th class="num">30天播放</th><th class="num">粉丝</th>
        <th class="num">已发</th><th>状态</th><th></th>
      </tr></thead>
      <tbody>
        ${sorted.map((p) => `
          <tr>
            <td>
              <b>${esc(p.name)}</b>
              <div class="mono" style="font-size:9px;color:var(--tx-3)">
                ${esc(p.assetId || p.profileId)}${
                  !p.assetId ? ' <span style="color:var(--danger)">缺 asset_id</span>' : ''}
              </div>
            </td>
            <td class="num" style="font-weight:600">${nfmt(p.views30d)}</td>
            <td class="num">${nfmt(p.followers)}</td>
            <td class="num">${p.published || 0}</td>
            <td>${healthBadge(p.health)}</td>
            <td class="row-actions">
              <button class="btn xs ghost" data-pg="${esc(p.profileId)}">查看</button>
            </td>
          </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

function repaint(root) {
  const all = store.pages || [];
  let list = all.slice();
  if (filter.q) {
    const k = filter.q.toLowerCase();
    list = list.filter((p) => (p.name || '').toLowerCase().includes(k)
      || (p.profileId || '').includes(k) || (p.assetId || '').includes(k));
  }
  if (filter.health !== 'all') list = list.filter((p) => p.health === filter.health);
  const sorters = {
    views: (a, b) => (b.views30d || 0) - (a.views30d || 0),
    followers: (a, b) => (b.followers || 0) - (a.followers || 0),
    name: (a, b) => String(a.name).localeCompare(String(b.name)),
    published: (a, b) => (b.published || 0) - (a.published || 0),
  };
  list.sort(sorters[filter.sort] || sorters.views);
  const wrap = $('#pg-list', root);
  wrap.innerHTML = viewMode === 'grid' ? gridHtml(list) : tableHtml(list);
  bind(root);
}

function healthBadge(h) {
  if (h === 'ok') return badge('正常', 'ok', true);
  if (h === 'restricted') return badge('受限', 'danger', true);
  if (h === 'pending') return badge('待授权', 'warn', true);
  return badge('未知', 'mute');
}

function gridHtml(list) {
  if (!list.length) {
    return `<div class="card"><div class="card-body">${emptyState('没有主页', '点「按 PID 提取」从账号拉取')}</div></div>`;
  }
  return `<div class="grid g3">${list.map((p) => `
    <div class="page-card" data-page="${p.profileId}">
      <div class="pc-top">
        <div class="pc-avatar">${esc(p.name)}</div>
        <div class="pc-name">
          <strong>${esc(p.name)}</strong>
          <span>${p.assetId || '⚠ 缺 asset_id'}</span>
        </div>
        ${healthBadge(p.health)}
      </div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--tx-3);margin-bottom:4px">
        ${p.profileId}
      </div>
      <div class="pc-metrics">
        <div class="pc-m"><b>${nfmt(p.views30d)}</b><span>30天播放</span></div>
        <div class="pc-m"><b>${nfmt(p.followers)}</b><span>粉丝</span></div>
        <div class="pc-m"><b>${p.published || 0}</b><span>已发</span></div>
      </div>
      <div class="pc-foot">
        <span style="font-family:var(--mono);font-size:9.5px;color:var(--tx-3)">${p.envCode || '—'}</span>
        <span style="display:flex;gap:4px">
          ${p.authz && p.authz.publisher && p.authz.publisher.present
            ? badge('发布号', 'info') : badge('发布号缺失', 'danger')}
          ${p.authz && p.authz.backup && p.authz.backup.present
            ? badge('备份号', 'purple') : badge('待授权', 'warn')}
        </span>
      </div>
    </div>`).join('')}</div>`;
}

function tableHtml(list) {
  return `<div class="card"><div class="card-body tight"><div class="tbl-wrap">
    <table class="tbl"><thead><tr>
      <th>主页</th><th>page_id</th><th>asset_id</th>
      <th class="num">30天播放</th><th class="num">粉丝</th><th class="num">已发</th>
      <th>授权</th><th>状态</th><th></th>
    </tr></thead><tbody>
      ${list.map((p) => `
        <tr data-page="${p.profileId}">
          <td><b>${esc(p.name)}</b></td>
          <td class="mono">${p.profileId}</td>
          <td class="mono">${p.assetId || '<span style="color:var(--danger)">缺失</span>'}</td>
          <td class="num">${nfmt(p.views30d)}</td>
          <td class="num">${nfmt(p.followers)}</td>
          <td class="num">${p.published || 0}</td>
          <td>
            <div style="display:flex;gap:3px">
              ${p.authz && p.authz.publisher && p.authz.publisher.present ? badge('发', 'info') : badge('—', 'mute')}
              ${p.authz && p.authz.backup && p.authz.backup.present ? badge('备', 'purple') : badge('—', 'mute')}
            </div>
          </td>
          <td>${healthBadge(p.health)}</td>
          <td class="row-actions"><button class="btn xs ghost" data-detail="${p.profileId}">展开</button></td>
        </tr>`).join('')}
    </tbody></table>
  </div></div></div>`;
}

function bind(root) {
  $$('[data-page]', root).forEach((el) => {
    el.onclick = (e) => {
      if (e.target.closest('[data-detail]')) return;
      openDetail(el.dataset.page);
    };
  });
  $$('[data-detail]', root).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); openDetail(b.dataset.detail); };
  });
}

async function openDetail(pid) {
  let d;
  try { d = await api.pageDetail(pid); } catch (e) { return toast('失败', e.message, 'err'); }
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="grid g2" style="margin-bottom:14px">
      <div>
        <div class="kv"><span class="k">page_id</span><span class="v">${d.profileId}</span></div>
        <div class="kv"><span class="k">asset_id</span><span class="v" style="color:${d.assetId ? '' : 'var(--danger)'}">${d.assetId || '缺失'}</span></div>
        <div class="kv"><span class="k">环境</span><span class="v">${d.envCode || '—'}</span></div>
      </div>
      <div>
        <div class="kv"><span class="k">30天播放</span><span class="v">${nfmt(d.views30d)}</span></div>
        <div class="kv"><span class="k">粉丝</span><span class="v">${nfmt(d.followers)}</span></div>
        <div class="kv"><span class="k">已发布</span><span class="v">${d.published || 0}</span></div>
      </div>
    </div>
    <div class="section-title">授权</div>
    <div class="card" style="margin-bottom:14px"><div class="card-body tight">
      ${(d.roles || []).length ? (d.roles || []).map((r) => `
        <div class="litem">
          <span class="dot ${r.state === 'active' ? 'ok' : 'warn'}"></span>
          <div class="litem-main">
            <div class="litem-title">c_user ${r.c_user} ${badge(r.state, r.state === 'active' ? 'ok' : 'warn')}</div>
            <div class="litem-sub">${r.role} · ${r.granted_at || '—'}</div>
          </div>
        </div>`).join('')
        : '<div class="litem" style="justify-content:center;color:var(--tx-3)">无授权记录</div>'}
    </div></div>
    <div class="section-title">操作</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn sm" data-x="verify">核对权限</button>
      <button class="btn sm ghost" data-x="open">在浏览器打开</button>
    </div>`;
  const m = modal({
    title: `${d.name} 详情`, width: 'wide', body,
    footer: [Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: () => m.close() })],
  });
  body.querySelectorAll('[data-x]').forEach((b) => {
    b.onclick = async () => {
      if (b.dataset.x === 'verify') {
        try {
          const r = await api.verifyAuthz(d.profileId);
          toast('核对完成', `发布号 ${r.publisherPresent ? '在' : '不在'} · 备份号 ${r.backupPresent ? '在' : '不在'}`, 'ok');
          load(document.getElementById('view'));
        } catch (e) { toast('核对失败', e.message, 'err'); }
      } else {
        toast('打开', `facebook.com/profile.php?id=${d.profileId}`, 'info');
      }
    };
  });
}

/* ---------------- 按 PID 提取 ---------------- */
function openPid() {
  const running = (store.envs || []).filter((e) => e.status === 'running');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>PID 或 CDP 端口</label>
      <input class="input" id="px-pid" placeholder="PID（如 12584）或端口（如 60005）"
             value="${running[0] ? (running[0].pid || running[0].cdpPort || '') : ''}"
             style="font-family:var(--mono)" />
      <div class="hint">
        注意：Hubstudio 的 containerId 不是进程 PID。不知道 PID 就填 CDP 端口，
        或直接从下面的已开环境里选。
      </div>
    </div>
    <div class="field">
      <label>已开环境</label>
      <select class="select" id="px-env">
        <option value="">— 手动输入 —</option>
        ${running.map((e) => `<option value="${e.containerCode}">${e.name} · PID ${e.pid || '—'} · 端口 ${e.cdpPort || '—'}</option>`).join('')}
      </select>
    </div>
    <div class="hint" style="margin-top:8px">
      提取会用当前登录身份读取该账号名下的全部主页（page_id + asset_id），
      与本地台账做差集后入库。全程拟人化操作，命中风控立即熔断。
    </div>`;
  const m = modal({
    title: '按 PID 提取主页', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), { className: 'btn primary', textContent: '开始提取', id: 'px-run' }),
    ],
  });
  const pg = body.querySelector('#px-pid');
  body.querySelector('#px-env').onchange = (e) => {
    const env = running.find((x) => x.containerCode === e.target.value);
    if (env) pg.value = env.pid || env.cdpPort || '';
  };
  m.el.querySelector('#px-run').onclick = async () => {
    const v = (pg.value || '').trim();
    if (!v) return toast('请输入 PID 或端口', '', 'err');
    const btn = m.el.querySelector('#px-run');
    btn.disabled = true; btn.textContent = '提取中…';
    try {
      const isPort = +v > 40000;
      const r = isPort ? await api.extractPages(0, +v) : await api.extractPages(+v, 0);
      if (!r.ok) {
        toast('提取失败', r.error || '未知原因', 'err', 6000);
      } else {
        toast('提取完成', `c_user ${r.cUser} · ${r.count} 个主页`, 'ok');
        m.close();
        await load(document.getElementById('view'));
      }
    } catch (e) {
      toast('提取失败', e.message, 'err');
    } finally {
      btn.disabled = false; btn.textContent = '开始提取';
    }
  };
}

/* ---------------- 创建主页 ---------------- */
function openCreate() {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="row-2">
      <div class="field"><label>主页名称</label><input class="input" id="cr-name" placeholder="Y16" /></div>
      <div class="field"><label>类别</label>
        <select class="select" id="cr-cat">
          <option>家居用品</option><option>电子产品店</option><option>宠物店</option>
          <option>餐饮服务</option><option>健身房/健身中心</option>
          <option>美容、美妆与个人护理</option><option>汽车服务</option>
          <option>本地服务</option><option>零售购物</option>
        </select>
      </div>
    </div>
    <div class="field"><label>简介</label><textarea class="textarea" id="cr-bio"></textarea></div>
    <div class="row-2">
      <div class="field"><label>数量</label><input class="input" id="cr-count" type="number" value="1" min="1" max="2" /></div>
      <div class="field"><label>今日上限</label><input class="input" id="cr-limit" type="number" value="2" min="1" max="5" readonly /></div>
    </div>
    <div class="card" style="border-color:rgba(251,191,36,.3)">
      <div class="card-body" style="padding:11px 13px;font-size:10.5px;color:var(--tx-2);line-height:1.7">
        实测：单号一天建 5–6 个就会触发静默限制。这里默认 2 个，
        服务端拒绝时立即停手不重试。创建前会自动切回个人身份。
      </div>
    </div>`;
  const m = modal({
    title: '创建公共主页', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), { className: 'btn primary', textContent: '开始创建', id: 'cr-run' }),
    ],
  });
  m.el.querySelector('#cr-run').onclick = async () => {
    const name = (body.querySelector('#cr-name').value || '').trim();
    if (!name) return toast('请输入名称', '', 'err');
    const btn = m.el.querySelector('#cr-run');
    btn.disabled = true; btn.textContent = '提交中…';
    try {
      const r = await api.createPages({
        name, category: body.querySelector('#cr-cat').value,
        bio: body.querySelector('#cr-bio').value,
        count: parseInt(body.querySelector('#cr-count').value, 10) || 1,
        dailyLimit: 2,
      });
      toast('已入队', `任务 ${r.jobId}`, 'ok');
      m.close();
    } catch (e) {
      toast('创建失败', e.message, 'err', 5000);
    } finally {
      btn.disabled = false; btn.textContent = '开始创建';
    }
  };
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

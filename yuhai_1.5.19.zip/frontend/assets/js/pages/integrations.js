/* 第三方对接 + 模型 / 技能 / 插件（真实数据） */
import { icon } from '../icons.js?v=e2c064c209';
import { api } from '../api.js?v=57de7f9574';
import { store } from '../store.js?v=dd9f0e78d7';
import { badge, pageHead, statCard, $, $$, toast, modal, ts, ago, emptyState, nfmt } from '../ui.js?v=0770c29dda';

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '第三方对接',
      desc: '外部依赖的连通性、模型来源、技能与插件',
      actions: [
        `<button class="btn sm" data-act="retest"><span data-icon="refresh"></span>全部重测</button>`,
      ],
    })}
    <div id="it-body"></div>
  `;
  $$('[data-act="retest"]', root).forEach((b) => (b.onclick = () => retestAll(b)));
  paint(root);
  load(root);
}

async function load(root) {
  await store.loadIntegrations();
  try {
    store.dsh = await api.dshStatus();
    store.dshPlugins = await api.dshPlugins();
  } catch (e) {
    store.dsh = null;
    store.dshPlugins = null;
  }
  // Graph 采集通道状态（读不到不影响页面其它部分，置 null 即可）
  try {
    store.graphSt = await api.graphStatus();
  } catch (e) {
    store.graphSt = null;
  }
  // 未完成的 App 切换（点了「设主用」但还没用新 App 重新同步）
  try {
    store.pendingSwitch = await api.graphPendingSwitch();
  } catch (e) {
    store.pendingSwitch = null;
  }
  // 取令牌标准步骤（全站唯一来源）
  try {
    const prim = (store.graphSt && store.graphSt.apps || [])
      .find((a) => a.role === 'primary');
    store.tokenSteps = await api.graphTokenSteps(prim ? prim.appId : '');
  } catch (e) {
    store.tokenSteps = null;
  }
  paint(root);
}

function paint(root) {
  const body = $('#it-body', root);
  if (!body) return;
  const integ = store.integrations || [];
  const models = store.models || [];
  const skills = store.skills || [];
  const plugins = store.plugins || [];
  const graphSt = store.graphSt || null;
  const pend = (store.pendingSwitch && store.pendingSwitch.pending)
    ? store.pendingSwitch : null;
  /* 取令牌步骤：全站唯一来源（后端 token_steps），三处都读这一份 */
  const tSteps = (store.tokenSteps && store.tokenSteps.steps) || [];
  const steps = tSteps;
  const explorer = (store.tokenSteps && store.tokenSteps.explorer) || '';

  const connected = integ.filter((i) => i.state === 'connected').length;
  const modelCount = models.reduce((a, m) => a + (m.models || []).length, 0);
  const visionCount = models.reduce(
    (a, m) => a + (m.models || []).filter((x) => x.vision).length, 0);

  body.innerHTML = `
    ${store.dsh && store.dsh.modelCount > 0 ? `
    <div class="card" style="margin-bottom:13px;border-color:rgba(79,70,229,.3)">
      <div class="card-head">
        <div class="card-title">插件模型接入
          <span class="sub">${store.dsh.channelCount} 个渠道 · ${store.dsh.modelCount} 个模型</span>
        </div>
        <span class="chip ok">只含账号接入</span>
      </div>
      <div class="card-body">
        <div class="card" style="margin-bottom:11px;border-color:rgba(251,191,36,.3)">
          <div class="card-body" style="padding:9px 11px;font-size:10.5px;
                      color:var(--tx-2);line-height:1.7">
            已排除：<b>our-free-model</b>（插件匿名免费池）、
            <b>eac / magpie</b>（付费转售）。只保留你自己登录的账号渠道。
          </div>
        </div>

        <div class="field">
          <label>默认模型（按渠道分组）</label>
          <select class="select" id="dsh-model" style="font-size:11px">
            ${(store.dsh.channels || []).map((g) => `
              <optgroup label="${esc(g.label)}（${g.models.length} 个${g.freeCount ? ` · ${g.freeCount} 免费` : ''}）">
                ${g.models.map((m) =>
                  `<option value="${esc(m.id)}" ${store.dsh.selected === m.id ? 'selected' : ''}>
                    ${esc(m.name)}${m.free ? ' · 免费' : ''}${m.vision ? ' 👁' : ''}
                  </option>`).join('')}
              </optgroup>`).join('')}
          </select>
          <div class="hint">端点：${esc(store.dsh.endpoint?.base || '')} · 选完点保存</div>
        </div>
        <div style="display:flex;gap:7px;flex-wrap:wrap">
          <button class="btn sm primary" id="dsh-save">保存默认模型</button>
          <button class="btn sm ghost" id="dsh-test">测试连通</button>
        </div>
        <div id="dsh-out" style="margin-top:9px"></div>

        <div class="section-title" style="margin-top:14px">插件接入</div>
        <div class="tbl-wrap">
          <table class="tbl" style="font-size:10.5px">
            <thead><tr>
              <th>插件</th><th>版本</th><th>可接入渠道</th><th>状态</th>
            </tr></thead>
            <tbody>
              ${(store.dshPlugins?.items || []).map((p) => `
                <tr>
                  <td class="mono" style="font-size:10px">${esc(p.name)}</td>
                  <td style="font-size:10px">v${esc(p.version || '?')}</td>
                  <td>
                    ${(p.channels || []).length
                      ? (p.channels || []).map((c) =>
                          `<span class="badge info" style="font-size:9px;margin-right:3px">
                            ${esc(c.label)} ${c.models}${c.freeCount ? ` /${c.freeCount}免费` : ''}
                          </span>`).join('')
                      : (p.excludedChannels || []).length
                        ? (p.excludedChannels || []).map((c) =>
                            `<span class="badge mute" style="font-size:9px;margin-right:3px">
                              ${esc(c.label)}（已排除）</span>`).join('')
                        : '<span style="font-size:10px;color:var(--tx-3)">不经网关</span>'}
                  </td>
                  <td>${p.usable ? badge('可接入', 'ok') : badge('不接入', 'mute')}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>

        <div class="section-title" style="margin-top:14px">渠道明细</div>
        <div class="tbl-wrap">
          <table class="tbl" style="font-size:10.5px">
            <thead><tr>
              <th>渠道</th><th>名称</th><th class="num">模型</th>
              <th class="num">免费</th><th>类型</th><th></th>
            </tr></thead>
            <tbody>
              ${(store.dsh.channels || []).map((g) => `
                <tr>
                  <td class="mono">${esc(g.channel)}</td>
                  <td><b>${esc(g.label)}</b></td>
                  <td class="num">${g.models.length}</td>
                  <td class="num" style="color:${g.freeCount ? 'var(--ok)' : 'var(--tx-3)'}">${g.freeCount}</td>
                  <td>${g.isAccount ? badge('账号接入', 'info') : badge('其他', 'mute')}</td>
                  <td class="row-actions">
                    <button class="btn xs ghost" data-cht="${esc(g.channel)}">测</button>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
      <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
        模型来自本机 DSH 网关（8326），读取你已登录的账号池。
        点某个渠道的「测」会用该渠道第一个免费模型试一次。
      </div>
    </div>` : `
    <div class="card" style="margin-bottom:13px;border-color:rgba(251,191,36,.35)">
      <div class="card-body" style="font-size:11.5px;color:var(--warn);line-height:1.75">
        <b>DSH 网关未检测到</b> —— 确认 DSH 在运行且已登录账号。
        没有模型时 AI 分析会自动退回规则统计（不编造结论）。
      </div>
    </div>`}

    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '对接项', value: integ.length, unit: '个', iconName: 'plug',
                   foot: `${connected} 个已连通` })}
      ${statCard({ label: '可用模型', value: modelCount, unit: '个', iconName: 'layers',
                   foot: `${visionCount} 个支持视觉` })}
      ${statCard({ label: '技能', value: skills.length, unit: '个', iconName: 'bolt' })}
      ${statCard({ label: '插件', value: plugins.length, unit: '个', iconName: 'plug' })}
    </div>

    <div class="section-title">对接状态</div>
    <div class="grid g3" style="margin-bottom:18px">
      ${integ.map((it) => {
        const st = it.state === 'connected' ? ['已连通', 'ok', 'ok']
          : it.state === 'error' ? ['异常', 'danger', 'bad']
          : it.state === 'configured' ? ['已配置', 'warn', 'warn']
          : ['未配置', 'mute', ''];
        return `
          <div class="integ" data-integ="${it.id}">
            <div class="integ-top">
              <div class="integ-ico">${esc((it.label || '?').slice(0, 1))}</div>
              <div class="integ-name">
                <strong>${esc(it.label)}</strong>
                <span>${esc(it.kind || '')}</span>
              </div>
              <span class="dot ${st[2]}"></span>
            </div>
            <div class="integ-desc">${esc(it.desc || '')}</div>
            <div class="integ-foot">
              <span class="mono" style="font-size:10px;color:var(--tx-3)">${esc(it.endpoint || '—')}</span>
              <span class="badge ${st[1]}">${st[0]}</span>
            </div>
          </div>`;
      }).join('')}
    </div>

    <div class="section-title">模型来源</div>
    <div class="grid g2" style="margin-bottom:18px">
      ${models.map((src) => `
        <div class="integ" data-src="${src.id}">
          <div class="integ-top">
            <div class="integ-ico">${src.kind === 'plugin' ? icon('plug', 14) : icon('key', 14)}</div>
            <div class="integ-name">
              <strong>${esc(src.name)}</strong>
              <span>${src.plugin ? esc(src.plugin) + ' v' + esc(src.version || '') : 'API 端点'}</span>
            </div>
            <span class="dot ${src.on ? 'ok' : ''}"></span>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:4px;padding-top:8px;
                      border-top:1px dashed rgba(0,0,0,.06)">
            ${(src.models || []).length
              ? (src.models || []).slice(0, 10).map((mm) => `
                  <span class="chip" style="font-size:9.5px;padding:2px 7px"
                        title="${esc(mm.id || '')} · ctx ${mm.ctx || '—'}">
                    ${esc(mm.name || mm.id)}${mm.vision ? ' 👁' : ''}
                  </span>`).join('')
              : `<span style="font-size:10px;color:var(--tx-3)">无模型信息</span>`}
          </div>
        </div>`).join('') || '<div class="integ">无模型来源</div>'}
    </div>

    <div class="section-title">技能（skill）</div>
    <div class="card" style="margin-bottom:18px">
      <div class="card-body tight">
        ${skills.length ? skills.map((s) => `
          <div class="litem">
            <span class="dot ok"></span>
            <div class="litem-main">
              <div class="litem-title">${esc(s.name)}</div>
              <div class="litem-sub" style="font-family:var(--sans)">${esc((s.desc || '').slice(0, 140))}</div>
              <div class="litem-sub" style="color:var(--tx-3)">${esc(s.path || '')}</div>
            </div>
            <span style="font-family:var(--mono);font-size:10px;color:var(--tx-3)">
              ${s.size ? (s.size / 1024).toFixed(1) + ' KB' : ''}
            </span>
          </div>`).join('')
          : '<div class="litem" style="justify-content:center;color:var(--tx-3)">未发现技能</div>'}
      </div>
    </div>

    <div class="section-title">插件</div>
    <div class="grid g3">
      ${plugins.length ? plugins.map((p) => `
        <div class="integ">
          <div class="integ-top">
            <div class="integ-ico">${icon('plug', 13)}</div>
            <div class="integ-name">
              <strong>${esc(p.name)}</strong>
              <span>v${esc(p.ver || '—')}</span>
            </div>
            <span class="dot ok"></span>
          </div>
          <div class="integ-desc" style="min-height:auto">${esc((p.desc || '').slice(0, 120))}</div>
        </div>`).join('')
        : '<div class="integ">未发现插件</div>'}
    </div>
    <div class="section-title">Meta Graph API（数据采集通道）</div>
    <div class="card" style="margin-bottom:18px">
      <div class="card-head">
        <div class="card-title">采集不走浏览器
          <span class="sub">${graphSt ? `${graphSt.pages} 个主页令牌 · ${esc(graphSt.version || '')}` : '未读取'}</span>
        </div>
        <span class="chip ${graphSt && graphSt.configured && graphSt.pages ? 'ok' : 'warn'}">
          ${graphSt && graphSt.configured && graphSt.pages ? '已就绪' : '待配置'}
        </span>
      </div>
      <div class="card-body">
        ${pend ? `
        <div class="card" style="margin-bottom:11px;border-color:var(--warn);
             background:rgba(251,191,36,.06)">
          <div class="card-body" style="padding:10px 12px;font-size:10.5px;line-height:1.85">
            <b style="color:var(--warn)">⚠ 切换未完成</b>
            —— 已把「${esc(pend.label)}」设为主用，但还没用它的令牌重新同步。
            现在采集仍在用旧应用签发的令牌，<b>旧应用一挂照样全停</b>。<br/>
            <span style="color:var(--tx-3)">点于 ${esc((pend.at || '').slice(0, 16))}</span>
            <div style="margin-top:8px;display:flex;gap:7px;flex-wrap:wrap">
              <a class="btn sm primary" href="${esc((pend.guide && pend.guide.links || {}).explorer || '#')}"
                 target="_blank" rel="noopener">去探索器生成令牌 ↗</a>
              ${(pend.guide && pend.guide.links || {}).appSettings ? `
              <a class="btn sm ghost" href="${esc(pend.guide.links.appSettings)}"
                 target="_blank" rel="noopener">App 设置（取 Secret）↗</a>` : ''}
              <button class="btn sm ghost" id="g-cancel-pend">取消切换</button>
            </div>
            ${(pend.guide && pend.guide.steps || []).length ? `
            <ol style="margin:8px 0 0 16px;padding:0;color:var(--tx-2);font-size:10px;line-height:1.9">
              ${pend.guide.steps.map((s) => `<li>${esc(s.text)}${
                s.detail ? ` <span style="color:var(--tx-3)">（${esc(s.detail)}）</span>` : ''}</li>`).join('')}
            </ol>` : ''}
          </div>
        </div>` : ''}
        <div class="card" style="margin-bottom:11px;border-color:rgba(79,70,229,.3)">
          <div class="card-body" style="padding:9px 11px;font-size:10.5px;
                      color:var(--tx-2);line-height:1.85">
            <b>取令牌步骤（共 ${steps.length} 步）</b>
            <span style="color:var(--tx-3);font-size:10px">
              —— 和切换引导用的是同一份，不会对不上</span>
            <div class="hint" style="margin-top:6px;color:var(--warn)">
              第 5 步最容易漏：加完权限不重新生成，令牌还是旧权限。
            </div>
            <div style="margin-top:7px">
              <button class="btn xs" id="g-show-steps">展开全部 ${steps.length} 步 ▾</button>
              <a class="btn xs ghost" href="${esc(explorer)}"
                 target="_blank" rel="noopener">直接打开探索器 ↗</a>
            </div>
          </div>
        </div>

        <div id="g-steps-box" style="display:none;margin-bottom:11px"></div>

        <details style="margin-bottom:11px">
          <summary style="cursor:pointer;font-size:11px;font-weight:600;
                          color:var(--ac);padding:5px 0">
            其它说明（多账号 / 备用应用 / 手机号，点开）
          </summary>
          <div class="card" style="margin-top:7px;border-color:rgba(79,70,229,.25)">
            <div class="card-body" style="font-size:10.5px;line-height:1.95;color:var(--tx-2)">

              <div><b style="color:var(--tx-1)">■ 多个发布号怎么办</b></div>
              你有几个发布号在管主页，就要生成几个令牌，<b>一个号一个令牌</b>。<br/>
              · 开发者账号和应用只要 <b>1 个</b><br/>
              · 其他号加成应用里的「<b>测试者</b>」（应用后台 → 应用角色 → 角色 →
                添加人员 → 测试者），<b>不碰手机号</b><br/>
              · 每个号登录探索器各生成一次 → 各点一次「保存并同步主页」<br/>
              · 同步只增不减，后填的不会覆盖前一个号的主页

              <div style="margin-top:11px"><b style="color:var(--tx-1)">■ 为什么要多个应用（备用）</b></div>
              令牌由应用签发。<b>应用一旦被限制，它签发的所有令牌当场一起失效。</b><br/>
              主页多了就按组分到 2 个应用（如 Y 组一个、Z 组一个），
              挂一个只损失一半，不至于全停。<br/>
              建第二个应用 → 在下方「多 App 与爆炸半径」点「＋ 加一个备用 App」→
              出问题点「设主用」切过去。

              <div style="margin-top:11px"><b style="color:var(--tx-1)">■ 关于手机号（重要）</b></div>
              手机号是 Meta 认定「同一实体」最强的证据，<b>复用会留下无法撤销的关联记录</b>。<br/>
              · 只用在<b>注册开发者</b>这一步，一次<br/>
              · 绝不和任何发布号共用<br/>
              · 需要隔离就用一个专门的小号注册开发者，发布号只当测试者

              <div style="margin-top:11px"><b style="color:var(--tx-1)">■ 令牌为什么只有 1~2 小时</b></div>
              探索器生成的是短期令牌。想长期跑，在第 9 步填「应用编号 + 应用密钥」，
              点「换成 60 天长效」。应用密钥在应用后台 → 设置 → 基本，最上面两栏。

            </div>
          </div>
        </details>

        <div class="field">
          <label>用户访问令牌（User Access Token）</label>
          <input class="input" id="g-token" type="password" placeholder="EAAG… " autocomplete="off" />
          <div class="hint">${graphSt && graphSt.tokenHint
            ? `当前已保存：${esc(graphSt.tokenHint)}（重新填会覆盖）`
            : '还没有保存过'}</div>
        </div>
        <div style="display:flex;gap:7px;flex-wrap:wrap">
          <button class="btn sm primary" id="g-save">保存并同步主页</button>
          <button class="btn sm ghost" id="g-test">测试连通</button>
          <button class="btn sm ghost" id="g-sync">只同步主页令牌</button>
          <button class="btn sm ghost" id="g-diag">看令牌还能用多久</button>
        </div>
        <div id="g-out" style="margin-top:9px"></div>

        <div class="section-title" style="margin-top:14px">
          令牌有效期与永久化
          <span class="sub">探索器只给 1~2 小时，永久要自己换</span>
        </div>
        <div class="card" style="margin-bottom:10px;border-color:rgba(79,70,229,.25)">
          <div class="card-body" style="padding:9px 11px;font-size:10.5px;
                      line-height:1.85;color:var(--tx-2)">
            <b>三种令牌，有效期差 1000 倍</b>
            <table class="tbl" style="font-size:10px;margin-top:6px">
              <thead><tr><th>令牌</th><th>有效期</th><th>怎么拿</th></tr></thead>
              <tbody>
                <tr><td>探索器生成的用户令牌</td>
                  <td style="color:var(--danger)">1~2 小时</td>
                  <td>点「生成访问令牌」直接给</td></tr>
                <tr><td>长期用户令牌</td>
                  <td style="color:var(--warn)">60 天</td>
                  <td>用上面那个换（需应用密钥）</td></tr>
                <tr><td><b>主页令牌（长期令牌派生）</b></td>
                  <td style="color:var(--ok)"><b>永不过期</b></td>
                  <td>先换长期，再同步主页</td></tr>
                <tr><td>系统用户令牌</td>
                  <td style="color:var(--ok)"><b>永不过期</b></td>
                  <td>Business Manager 里建系统用户</td></tr>
              </tbody>
            </table>
            <div style="margin-top:7px;padding:6px 8px;border-radius:4px;
                        background:rgba(251,191,36,.08);color:var(--tx-2)">
              <b>关键因果</b>：主页令牌的有效期<b>跟着签发它的用户令牌走</b>。
              用短效令牌同步 → 主页令牌也 1~2 小时就死；
              用长期令牌同步 → 主页令牌永久。
            </div>
          </div>
        </div>
        <div class="row-2">
          <div class="field">
            <label>应用编号（App ID）</label>
            <input class="input" id="g-appid" placeholder="123456789012345"
                   value="${esc((graphSt && graphSt.appId) || '')}" autocomplete="off" />
          </div>
          <div class="field">
            <label>应用密钥（App Secret）</label>
            <input class="input" id="g-appsecret" type="password"
                   placeholder="只存在本机数据库" autocomplete="off" />
          </div>
        </div>
        <div class="hint" style="margin-bottom:7px">
          取法：<a href="https://developers.facebook.com/apps/" target="_blank"
          rel="noopener">应用列表 ↗</a> → 点你的应用 → 左侧「设置」→「基本」，
          页面最上面两栏就是编号和密钥（密钥要点「显示」）。
        </div>
        <div style="display:flex;gap:7px;flex-wrap:wrap">
          <button class="btn sm" id="g-saveapp">保存应用凭据</button>
          <button class="btn sm" id="g-long">第一步：换成 60 天</button>
          <button class="btn sm primary" id="g-permanent">第二步：一键拿永久令牌</button>
          <button class="btn sm ghost" id="g-probe-bm">查有没有 Business Manager</button>
        </div>
        <div class="hint" style="margin-top:6px">
          顺序不能反：先「换 60 天」，再「拿永久」。<br/>
          已是系统用户令牌或长期令牌时，直接点第二步即可。
        </div>

        ${(() => {
          const b = (graphSt && graphSt.blast) || null;
          const apps = (graphSt && graphSt.apps) || (b && b.apps) || [];
          const lvColor = b ? (b.level === 'high' ? 'var(--danger)'
            : b.level === 'medium' ? 'var(--warn)'
            : b.level === 'low' ? 'var(--ok)' : 'var(--tx-3)') : 'var(--tx-3)';
          const lvText = !b ? '未就绪' : b.level === 'high' ? '高危'
            : b.level === 'medium' ? '中等'
            : b.level === 'low' ? '已分散' : '未就绪';
          return `
          <div class="section-title" style="margin-top:16px">
            多 App 与爆炸半径
            <span class="sub">应用挂了它签发的令牌会一起失效</span>
          </div>
          <div class="card" style="border-color:${lvColor}40;margin-bottom:10px">
            <div class="card-body" style="font-size:11px;line-height:1.8">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
                <span class="badge" style="background:${lvColor}20;color:${lvColor};
                      font-size:10px;padding:2px 8px">风险：${lvText}</span>
                <span style="color:var(--tx-3);font-size:10px">
                  ${b ? `已跟踪 ${b.trackedTokens}/${b.totalPages} 个主页·
                  最大单点 ${b.maxShare}%` : '暂无数据'}</span>
              </div>
              <div style="color:var(--tx-2)">${esc((b && b.advice) || '')}</div>
              <div style="color:var(--tx-3);font-size:10px;margin-top:5px">
                ${esc((b && b.note) || '')}</div>
            </div>
          </div>
          ${apps.length ? `
          <div class="tbl-wrap" style="max-height:180px;overflow:auto;margin-bottom:9px">
            <table class="tbl" style="font-size:10px">
              <thead><tr>
                <th>App</th><th>角色</th><th class="num">撑主页</th>
                <th class="num">占比</th><th>状态</th><th></th>
              </tr></thead>
              <tbody>
                ${apps.map((a) => `
                  <tr>
                    <td><b>${esc(a.label || a.appId)}</b>
                      <div class="mono" style="font-size:9px;color:var(--tx-3)">
                        ${esc(a.appId)}</div></td>
                    <td>${a.role === 'primary'
                      ? badge('主用', 'ok') : badge('备用', 'mute')}</td>
                    <td class="num">${a.pages}</td>
                    <td class="num" style="color:${a.share >= 60 ? 'var(--danger)' : 'var(--tx-2)'}">
                      ${a.share}%</td>
                    <td>${a.state === 'ok' ? badge('正常', 'ok')
                         : a.state === 'invalid' ? badge('失效', 'danger')
                         : a.state === 'limited' ? badge('受限', 'warn')
                         : badge('未验证', 'mute')}</td>
                    <td class="row-actions">
                      <button class="btn xs ghost" data-app-check="${esc(a.appId)}">验</button>
                      ${a.role !== 'primary'
                        ? `<button class="btn xs ghost" data-app-switch="${esc(a.appId)}">设主用</button>`
                        : ''}
                      <button class="btn xs ghost" data-app-del="${esc(a.appId)}">删</button>
                    </td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>` : `
          <div class="hint" style="margin-bottom:9px;color:var(--warn)">
            还没有登记任何应用。<b>填上面的应用编号/密钥点「保存应用凭据」</b>，
            它会自动登记到这里；或点下面「自动识别当前令牌的应用」。
          </div>`}
          <div style="display:flex;gap:7px;flex-wrap:wrap">
            <button class="btn sm" id="g-detect-app">自动识别当前令牌的应用</button>
            <button class="btn sm ghost" id="g-verify-app">核对当前令牌属于哪个应用</button>
            <button class="btn sm ghost" id="g-add-standby">＋ 加一个备用 App</button>
          </div>
          <div id="g-standby-form" style="display:none;margin-top:9px;
               padding:9px 11px;border:1px dashed var(--line);border-radius:6px">
            <div style="font-size:10.5px;color:var(--tx-2);margin-bottom:7px;line-height:1.75">
              再建一个 Meta 应用，把部分主页迁过去，主应用挂了不至于全停。
              在这里登记成<b>备用</b>，需要时点「设主用」切过去。
            </div>
            <div class="row-2">
              <div class="field">
                <label>备用应用编号</label>
                <input class="input" id="g-sb-id" placeholder="纯数字" autocomplete="off" />
              </div>
              <div class="field">
                <label>备注名</label>
                <input class="input" id="g-sb-label" placeholder="如 备用App-B" autocomplete="off" />
              </div>
            </div>
            <div class="field">
              <label>应用密钥（可选，用于换长期令牌与核对）</label>
              <input class="input" id="g-sb-secret" type="password"
                     placeholder="只存本机数据库" autocomplete="off" />
            </div>
            <div style="display:flex;gap:7px">
              <button class="btn sm primary" id="g-sb-save">登记为备用</button>
              <button class="btn sm ghost" id="g-sb-cancel">取消</button>
            </div>
          </div>
          <div id="g-app-out" style="margin-top:8px"></div>
          `;
        })()}

        <div class="section-title" style="margin-top:16px">
          主页令牌状态
          <span class="sub">${(graphSt && graphSt.items || []).length} 个${graphSt && graphSt.permanent ? ` · ${graphSt.permanent} 个永久` : ''}${graphSt && graphSt.expiringSoon ? ` · ${graphSt.expiringSoon} 个快过期` : ''}</span>
        </div>
        ${graphSt && graphSt.expiringSoon ? `
        <div class="hint" style="margin-bottom:7px;color:var(--danger)">
          ⚠ 有 ${graphSt.expiringSoon} 个主页令牌将在 3 天内过期。
          点上方「第二步：一键拿永久令牌」把它们换成永久的。
        </div>` : ''}
        ${graphSt && (graphSt.items || []).length ? `
        <div class="tbl-wrap" style="max-height:240px;overflow:auto">
          <table class="tbl" style="font-size:10px">
            <thead><tr>
              <th>主页</th><th>page_id</th><th>签发应用</th>
              <th>类型</th><th>剩余</th><th>状态</th>
            </tr></thead>
            <tbody>
              ${(graphSt.items || []).slice(0, 100).map((p) => `
                <tr>
                  <td>${esc(p.page_name || '')}</td>
                  <td class="mono" style="font-size:9.5px">${esc(p.page_id)}</td>
                  <td style="font-size:9.5px;color:${p.app_id ? 'var(--tx-2)' : 'var(--tx-3)'}">
                    ${esc(p.app_label || p.app_id || '未记录')}</td>
                  <td style="font-size:9.5px">${p.neverExpires
                    ? '<span style="color:var(--ok)">永久</span>'
                    : `<span style="color:var(--tx-2)">${esc(p.tokenKindText || '')}</span>`}</td>
                  <td class="num" style="font-size:9.5px;color:${p.urgent ? 'var(--danger)' : 'var(--tx-2)'}">
                    ${esc(p.leftText || '')}</td>
                  <td>${p.state === 'ok' ? badge('可用', 'ok')
                       : p.state === 'expired' ? badge('失效', 'danger')
                       : p.state === 'no_perm' ? badge('无权限', 'warn')
                       : badge(p.state || '?', 'mute')}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>` : `
        <div class="hint" style="color:var(--tx-3)">
          还没有主页令牌。填好令牌后点「保存并同步主页」。
        </div>`}
      </div>
      <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
        视频指标走 <code>/{video-id}/video_insights?period=lifetime</code>，
        返回服务端原始整数，不用再从「1.2万」这种文本反解析。
        累计值按天存快照，「当天新增」用两次快照相减。
      </div>
    </div>
  `;

  $$('[data-integ]', root).forEach((el) => {
    el.onclick = () => testOne(el.dataset.integ);
  });
  $$('[data-src]', root).forEach((el) => {
    el.onclick = () => openSource((store.models || []).find((x) => x.id === el.dataset.src));
  });

  /* ---- Graph API 通道 ---- */
  const gOut = () => document.getElementById('g-out');
  const gShow = (html) => { const o = gOut(); if (o) o.innerHTML = html; };
  const gBusy = (b, on, txt) => {
    if (!b) return;
    b.disabled = on;
    if (txt) b.textContent = txt;
  };

  const gSave = document.getElementById('g-save');
  if (gSave) gSave.onclick = async () => {
    const el = document.getElementById('g-token');
    const tok = (el?.value || '').trim();
    if (!tok) return toast('先填令牌', '需要用户访问令牌', 'warn');
    gBusy(gSave, true, '保存中…');
    gShow('<div style="font-size:11px;color:var(--tx-3)">正在验证令牌并同步主页…</div>');
    try {
      const r = await api.graphSetToken(tok, true);
      const t = r.test || {};
      const s = r.sync || {};
      /* 切换核对结果：期望 App vs 实际 App */
      const sc = s.switchCheck || null;
      const sApp = s.appId ? `<br/>本次令牌签发应用：<b>${esc(s.appLabel || s.appId)}</b>
        <span class="mono" style="color:var(--tx-3)">(${esc(s.appId)})</span>` : '';
      const sWarn = (sc && !sc.matched) ? `
        <div style="margin-top:7px;padding:7px 9px;border-radius:5px;
                    background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);
                    color:var(--danger);font-size:10.5px;line-height:1.75">
          ⚠ <b>切换没有生效</b><br/>
          你点的是「${esc(sc.pendingLabel)}」设主用，
          但这次同步用的令牌其实属于 <b>应用 ${esc(sc.actualApp)}</b>。<br/>
          多半是探索器右上角没切应用，或者生成后没重新复制。
        </div>` : (sc && sc.matched ? `
        <div style="margin-top:7px;padding:7px 9px;border-radius:5px;
                    background:rgba(34,197,94,.08);color:var(--ok);font-size:10.5px">
          ✓ 切换核对通过 —— 令牌已由「${esc(sc.pendingLabel)}」签发
        </div>` : '');
      gShow(`<div style="font-size:11px;line-height:1.75;color:${t.ok ? 'var(--ok)' : 'var(--danger)'}">
        ${t.ok ? '✓ 令牌有效' : '✗ ' + esc(t.error || '验证失败')}
        ${t.me ? ` · 身份 ${esc(t.me.name || t.me.id || '')}` : ''}
        ${t.pages != null ? ` · ${t.pages} 个主页（${t.withToken || 0} 个带令牌）` : ''}
        ${t.sampleVideos != null ? ` · 样本视频 ${t.sampleVideos} 条` : ''}
        ${s.ok ? `<br/>已同步 ${s.pages || 0} 个主页令牌` : ''}
        ${sApp}
        ${t.hint ? `<br/><span style="color:var(--warn)">${esc(t.hint)}</span>` : ''}
        ${sWarn}
      </div>`);
      if (t.ok) {
        toast(sWarn && sc && !sc.matched ? '同步完成但切换未生效'
          : '已接入', `同步 ${s.pages || 0} 个主页`,
          (sc && !sc.matched) ? 'warn' : 'ok', (sc && !sc.matched) ? 9000 : 4000);
      }
      if (el) el.value = '';
      setTimeout(() => load(root), 1100);
    } catch (e) {
      gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gBusy(gSave, false, '保存并同步主页'); }
  };

  const gTest = document.getElementById('g-test');
  if (gTest) gTest.onclick = async () => {
    gBusy(gTest, true, '测试中…');
    gShow('<div style="font-size:11px;color:var(--tx-3)">正在请求 Graph…</div>');
    try {
      const t = await api.graphTest();
      gShow(`<div style="font-size:11px;line-height:1.75;color:${t.ok ? 'var(--ok)' : 'var(--danger)'}">
        ${t.ok ? '✓ 通道可用' : '✗ ' + esc(t.error || '失败')}
        ${t.pages != null ? ` · ${t.pages} 个主页` : ''}
        ${(t.sampleMetrics || []).length ? `<br/>样本指标：${esc((t.sampleMetrics || []).join(', '))}` : ''}
        ${(t.metricErrors || []).length ? `<br/><span style="color:var(--warn)">指标告警：${esc((t.metricErrors || []).join(' | ').slice(0, 200))}</span>` : ''}
        ${t.hint ? `<br/><span style="color:var(--warn)">${esc(t.hint)}</span>` : ''}
      </div>`);
    } catch (e) {
      gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gBusy(gTest, false, '测试连通'); }
  };

  const gSync = document.getElementById('g-sync');
  if (gSync) gSync.onclick = async () => {
    gBusy(gSync, true, '同步中…');
    try {
      const r = await api.graphSyncPages();
      if (r.ok) {
        gShow(`<div style="font-size:11px;color:var(--ok)">
          ✓ 已同步 ${r.pages || 0} 个主页（${r.withToken || 0} 个带令牌）</div>`);
        toast('已同步', `${r.pages || 0} 个主页`, 'ok');
        setTimeout(() => load(root), 800);
      } else {
        gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(r.error || '失败')}
          ${r.hint ? `<br/><span style="color:var(--warn)">${esc(r.hint)}</span>` : ''}</div>`);
      }
    } catch (e) {
      gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gBusy(gSync, false, '只同步主页令牌'); }
  };

  /* 看令牌还能用多久 —— 短效 token 是「昨天还好今天全空」的头号原因 */
  const gDiag = document.getElementById('g-diag');
  if (gDiag) gDiag.onclick = async () => {
    gBusy(gDiag, true, '查询中…');
    gShow('<div style="font-size:11px;color:var(--tx-3)">正在查令牌有效期…</div>');
    try {
      const d = await api.graphDiag();
      if (!d.ok) {
        gShow(`<div style="font-size:11px;line-height:1.75;color:var(--danger)">
          ✗ ${esc(d.error || '查询失败')}
          ${d.hint ? `<br/><span style="color:var(--warn)">${esc(d.hint)}</span>` : ''}
        </div>`);
      } else {
        const exp = d.neverExpires
          ? '<span style="color:var(--ok)">永不过期</span>'
          : (d.expiresInSec > 0
            ? `<span style="color:${d.expiresInSec < 7200 ? 'var(--warn)' : 'var(--tx-2)'}">
                 还剩 ${esc(d.expiresInText || '')}</span>`
            : '<span style="color:var(--danger)">已过期</span>');
        const scopes = d.scopes || [];
        const need = ['pages_show_list', 'pages_read_engagement',
                      'pages_read_user_content', 'read_insights'];
        const miss = need.filter((x) => !scopes.includes(x));
        gShow(`<div style="font-size:11px;line-height:1.85">
          <b>${esc((d.me || {}).name || '')}</b>
          <span style="color:var(--tx-3)"> · id ${esc((d.me || {}).id || '')}</span><br/>
          有效期：${exp}<br/>
          类型：<span class="mono">${esc(d.type || '?')}</span>
          ${d.appName ? ` · 应用 ${esc(d.appName)}` : ''}<br/>
          权限 ${scopes.length} 个${miss.length
            ? `<br/><span style="color:var(--warn)">缺：${esc(miss.join(', '))}</span>`
            : ' <span style="color:var(--ok)">（4 个必需权限都齐）</span>'}
          ${d.debugError ? `<br/><span style="color:var(--tx-3)">debug 不可用：${esc(String(d.debugError).slice(0, 100))}</span>` : ''}
        </div>`);
      }
    } catch (e) {
      gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gBusy(gDiag, false, '看令牌还能用多久'); }
  };

  /* 保存应用凭据 —— 必须立刻刷新，否则多 App 区看不到刚登记的 App */
  const gSaveApp = document.getElementById('g-saveapp');
  if (gSaveApp) gSaveApp.onclick = async () => {
    const aid = (document.getElementById('g-appid')?.value || '').trim();
    const sec = (document.getElementById('g-appsecret')?.value || '').trim();
    if (!aid && !sec) return toast('没有内容', '填应用编号或应用密钥', 'warn');
    gBusy(gSaveApp, true, '保存中…');
    try {
      const r = await api.graphSetApp(aid, sec);
      gShow(`<div style="font-size:11px;line-height:1.8;color:var(--ok)">
        ✓ 应用凭据已保存（编号 ${r.hasAppId ? '有' : '无'} ·
        密钥 ${r.hasSecret ? '有' : '无'}）
        ${r.appId ? `<br/>App <span class="mono">${esc(r.appId)}</span>
          ${r.registered ? `已登记为「${r.role === 'primary' ? '主用' : '备用'}」` : ''}` : ''}
        ${r.next ? `<br/><span style="color:var(--tx-2)">${esc(r.next)}</span>` : ''}
      </div>`);
      const el = document.getElementById('g-appsecret');
      if (el) el.value = '';
      toast('已保存', r.registered ? '已登记到多 App 列表' : 'App 凭据只存本机',
        'ok');
      // 关键：刷新，让多 App 表格立刻出现刚登记的 App
      setTimeout(() => load(root), 500);
    } catch (e) {
      gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gBusy(gSaveApp, false, '保存应用凭据'); }
  };

  /* 一键拿永久令牌 */
  const gPerm = document.getElementById('g-permanent');
  if (gPerm) gPerm.onclick = async () => {
    gBusy(gPerm, true, '处理中…');
    gShow('<div style="font-size:11px;color:var(--tx-3)">正在换取永久主页令牌…</div>');
    try {
      const r = await api.graphPermanent();
      const st = (r.steps || []).map((s) => `
        <div style="padding:3px 0;color:${s.ok ? 'var(--ok)' : 'var(--danger)'}">
          ${s.ok ? '✓' : '✗'} ${esc(s.name || '')}</div>`).join('');
      if (r.ok) {
        gShow(`<div style="font-size:11px;line-height:1.85">
          <b style="color:var(--ok)">✓ ${esc(r.message || '完成')}</b>
          ${r.permanentPages != null
            ? `<br/>永久主页令牌：<b>${r.permanentPages}/${r.totalPages}</b>` : ''}
          <div style="margin-top:7px;padding:7px 9px;border-radius:5px;
                      background:var(--bg-0)">${st}</div>
        </div>`);
        toast('永久令牌就绪',
          `${r.permanentPages || 0} 个主页已永久`,
          r.permanentPages ? 'ok' : 'warn', 8000);
        setTimeout(() => load(root), 1200);
      } else {
        gShow(`<div style="font-size:11px;line-height:1.85;color:var(--danger)">
          ✗ ${esc(r.error || '失败')}
          ${r.hint ? `<br/><span style="color:var(--warn)">${esc(r.hint)}</span>` : ''}
          ${st ? `<div style="margin-top:7px;background:var(--bg-0);
            padding:7px 9px;border-radius:5px">${st}</div>` : ''}
        </div>`);
      }
    } catch (e) {
      gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gBusy(gPerm, false, '第二步：一键拿永久令牌'); }
  };

  /* 探测 Business Manager */
  const gProbe = document.getElementById('g-probe-bm');
  if (gProbe) gProbe.onclick = async () => {
    gBusy(gProbe, true, '查询中…');
    gShow('<div style="font-size:11px;color:var(--tx-3)">正在查 Business Manager…</div>');
    try {
      const r = await api.graphProbeBusiness();
      if (!r.ok) {
        gShow(`<div style="font-size:11px;color:var(--danger)">
          ✗ ${esc(r.error || '查询失败')}</div>`);
      } else if ((r.businesses || []).length) {
        gShow(`<div style="font-size:11px;line-height:1.85">
          <b style="color:var(--ok)">✓ 找到 ${r.businesses.length} 个 Business Manager</b>
          <div style="margin-top:5px">
            ${r.businesses.map((b) => `<div>· ${esc(b.name || '')}
              <span class="mono" style="color:var(--tx-3)">(${esc(b.id)})</span></div>`).join('')}
          </div>
          ${r.businessPages != null
            ? `<div style="margin-top:5px;color:var(--tx-2)">
                名下主页：${r.businessPages} 个</div>` : ''}
          <div style="margin-top:7px;padding:6px 8px;border-radius:4px;
                      background:rgba(34,197,94,.08);color:var(--tx-2)">
            可以走系统用户路线拿永久令牌 →
            <a href="https://business.facebook.com/settings/system-users"
               target="_blank" rel="noopener">打开系统用户设置 ↗</a>
          </div>
        </div>`);
      } else {
        gShow(`<div style="font-size:11px;line-height:1.85;color:var(--warn)">
          没有 Business Manager
          <div style="color:var(--tx-2);margin-top:3px">
            ${esc(r.hint || '')}</div>
          <div style="margin-top:6px;color:var(--tx-2)">
            改用上面的「两步走」：换 60 天 → 一键拿永久。
          </div>
        </div>`);
      }
    } catch (e) {
      gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gBusy(gProbe, false, '查有没有 Business Manager'); }
  };

  const gLong = document.getElementById('g-long');
  if (gLong) gLong.onclick = async () => {
    gBusy(gLong, true, '换取中…');
    gShow('<div style="font-size:11px;color:var(--tx-3)">正在向 Meta 换长期令牌…</div>');
    try {
      const r = await api.graphLongLived();
      if (r.ok) {
        const s = r.sync || {};
        gShow(`<div style="font-size:11px;line-height:1.8;color:var(--ok)">
          ✓ 已换成长期令牌
          ${r.expiresInDays ? `· 有效期约 ${r.expiresInDays} 天` : ''}
          · ${esc(r.preview || '')}
          ${s.ok ? `<br/>已同步 ${s.pages || 0} 个主页令牌` : ''}
        </div>`);
        toast('已换成长期令牌',
          r.expiresInDays ? `${r.expiresInDays} 天内不用管` : '完成', 'ok', 8000);
        setTimeout(() => load(root), 900);
      } else {
        gShow(`<div style="font-size:11px;line-height:1.8;color:var(--danger)">
          ✗ ${esc(r.error || '换取失败')}
          ${r.hint ? `<br/><span style="color:var(--warn)">${esc(r.hint)}</span>` : ''}
        </div>`);
      }
    } catch (e) {
      gShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gBusy(gLong, false, '换成 60 天长效'); }
  };

  const saveM = document.getElementById('dsh-save');
  if (saveM) saveM.onclick = async () => {
    const m = document.getElementById('dsh-model').value;
    try {
      await api.dshSelectModel(m);
      toast('已保存', m, 'ok');
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
  };
  /* ---- 多 App：验证 / 设主用 / 删除 / 自动识别 ---- */
  const appOut = () => document.getElementById('g-app-out');
  const appShow = (html) => { const o = appOut(); if (o) o.innerHTML = html; };

  $$('[data-app-check]', root).forEach((b) => {
    b.onclick = async () => {
      const id = b.dataset.appCheck;
      b.disabled = true; b.textContent = '…';
      try {
        const r = await api.graphCheckApp(id);
        if (r.ok) {
          appShow(`<div style="font-size:11px;color:var(--ok)">
            ✓ ${esc(r.note || 'App 可用')} · ${esc(r.preview || '')}</div>`);
          toast('App 正常', `${id} · Secret 正确`, 'ok');
          setTimeout(() => load(root), 700);
        } else {
          appShow(`<div style="font-size:11px;line-height:1.7;color:var(--danger)">
            ✗ ${esc(r.error || '验证失败')}
            ${r.hint ? `<br/><span style="color:var(--warn)">${esc(r.hint)}</span>` : ''}</div>`);
        }
      } catch (e) {
        appShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
      } finally { b.disabled = false; b.textContent = '验'; }
    };
  });

  $$('[data-app-switch]', root).forEach((b) => {
    b.onclick = async () => {
      const id = b.dataset.appSwitch;
      b.disabled = true;
      try {
        const r = await api.graphSwitchApp(id);
        if (r.ok) {
          const g = r.guide || {};
          const links = g.links || {};
          /* 用与顶部「展开全部步骤」完全相同的渲染，保证一字不差 */
          appShow(`<div class="card" style="border-color:var(--ac);
                   background:rgba(79,70,229,.05)">
            <div class="card-body" style="font-size:11px;line-height:1.85">
              <b style="color:var(--ok)">✓ 已把「${esc(r.label || id)}」设为主用</b>
              ${r.prevPrimary ? `<span style="color:var(--tx-3)">
                （原主用「${esc(r.prevPrimary)}」降为备用）</span>` : ''}
              <div style="margin:9px 0 7px;color:var(--warn);font-size:10.5px">
                还差最后一步：用这个应用重新生成令牌。否则采集仍走旧令牌。
              </div>
              <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:9px">
                <a class="btn sm primary" href="${esc(links.explorer || '#')}"
                   target="_blank" rel="noopener">① 打开探索器 ↗</a>
                ${links.appSettings ? `<a class="btn sm ghost"
                  href="${esc(links.appSettings)}" target="_blank"
                  rel="noopener">应用设置（取密钥）↗</a>` : ''}
                ${links.appRoles ? `<a class="btn sm ghost"
                  href="${esc(links.appRoles)}" target="_blank"
                  rel="noopener">应用角色（加测试者）↗</a>` : ''}
              </div>
              ${renderSteps(g.steps && g.steps.length ? g.steps : steps)}
              <div style="margin-top:9px;padding-top:8px;border-top:1px dashed var(--line);
                          color:var(--tx-3);font-size:10px;line-height:1.75">
                ${esc(g.why || '')}
              </div>
              <div style="margin-top:8px;color:var(--tx-2);font-size:10.5px">
                粘好令牌后点上面的「<b>保存并同步主页</b>」，系统会自动核对
                令牌是否真的属于「${esc(r.label || id)}」并告诉你结果。
              </div>
            </div>
          </div>`);
          toast('已切换主用', `下一步：用 ${r.label || id} 重新生成令牌`, 'warn', 9000);
          setTimeout(() => load(root), 1200);
        } else {
          appShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(r.error || '失败')}</div>`);
          b.disabled = false;
        }
      } catch (e) {
        appShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
        b.disabled = false;
      }
    };
  });

  $$('[data-app-del]', root).forEach((b) => {
    b.onclick = async () => {
      const id = b.dataset.appDel;
      if (!confirm(`移除应用 ${id} 的登记？\n\n已存的主页令牌不会被删除，只是不再归它管。`)) return;
      b.disabled = true;
      try {
        await api.graphDelApp(id);
        toast('已移除', id, 'ok');
        setTimeout(() => load(root), 500);
      } catch (e) {
        toast('失败', e.message, 'err');
        b.disabled = false;
      }
    };
  });

  /* 加备用 App */
  const gAddSb = document.getElementById('g-add-standby');
  const sbForm = document.getElementById('g-standby-form');
  if (gAddSb && sbForm) {
    gAddSb.onclick = () => {
      sbForm.style.display = sbForm.style.display === 'none' ? '' : 'none';
      if (sbForm.style.display !== 'none') {
        document.getElementById('g-sb-id')?.focus();
      }
    };
    const sbCancel = document.getElementById('g-sb-cancel');
    if (sbCancel) sbCancel.onclick = () => { sbForm.style.display = 'none'; };
    const sbSave = document.getElementById('g-sb-save');
    if (sbSave) sbSave.onclick = async () => {
      const id = (document.getElementById('g-sb-id')?.value || '').trim();
      const label = (document.getElementById('g-sb-label')?.value || '').trim();
      const secret = (document.getElementById('g-sb-secret')?.value || '').trim();
      if (!id) return toast('先填应用编号', '在应用后台 → 设置 → 基本 最上方', 'warn');
      gBusy(sbSave, true, '登记中…');
      try {
        const r = await api.graphSaveApp({
          appId: id, label: label || id, appSecret: secret,
          role: 'standby', note: '界面手动加为备用',
        });
        if (r.ok) {
          appShow(`<div style="font-size:11px;color:var(--ok)">
            ✓ 已登记备用 App「${esc(label || id)}」
            <div style="color:var(--tx-2);margin-top:5px">
              需要切换时在表格里点「设主用」，会给出下一步引导。</div></div>`);
          toast('已登记', label || id, 'ok');
          setTimeout(() => load(root), 500);
        } else {
          appShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(r.error || '失败')}</div>`);
        }
      } catch (e) {
        appShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
      } finally { gBusy(sbSave, false, '登记为备用'); }
    };
  }

  const gDetect = document.getElementById('g-detect-app');
  if (gDetect) gDetect.onclick = async () => {
    gDetect.disabled = true; gDetect.textContent = '识别中…';
    appShow('<div style="font-size:11px;color:var(--tx-3)">正在反查令牌属于哪个应用…</div>');
    try {
      const r = await api.graphDetectApp();
      if (r.ok) {
        appShow(`<div style="font-size:11px;line-height:1.75;color:var(--ok)">
          ✓ 当前令牌属于 <b>${esc(r.appName || r.appId)}</b>
          <span class="mono" style="color:var(--tx-3)">(${esc(r.appId)})</span>
          ${r.registered ? '<br/>已自动登记' : '<br/>之前已登记过'}</div>`);
        toast('已识别', r.appName || r.appId, 'ok');
        setTimeout(() => load(root), 700);
      } else {
        appShow(`<div style="font-size:11px;line-height:1.7;color:var(--danger)">
          ✗ ${esc(r.error || '识别失败')}
          ${r.note ? `<br/><span style="color:var(--tx-3)">${esc(r.note)}</span>` : ''}</div>`);
      }
    } catch (e) {
      appShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gDetect.disabled = false; gDetect.textContent = '自动识别当前令牌的应用'; }
  };

  /* 用 app token 核对当前令牌属于哪个应用（最可靠） */
  const gVerify = document.getElementById('g-verify-app');
  if (gVerify) gVerify.onclick = async () => {
    gVerify.disabled = true; gVerify.textContent = '核对中…';
    appShow('<div style="font-size:11px;color:var(--tx-3)">用应用密钥组成应用令牌核对…</div>');
    try {
      const r = await api.graphVerifyTokenApp();
      if (r.ok) {
        const apps = (graphSt && graphSt.apps) || [];
        const match = apps.find((a) => a.appId === r.appId);
        const isPrimary = match && match.role === 'primary';
        const exp = r.neverExpires ? '永不过期'
          : (r.expiresInSec > 0
            ? `还剩 ${Math.floor(r.expiresInSec / 3600)} 小时 ${Math.floor((r.expiresInSec % 3600) / 60)} 分`
            : '已过期');
        appShow(`<div style="font-size:11px;line-height:1.9">
          <b style="color:var(--ok)">✓ 核对成功</b><br/>
          令牌属于：<b>${esc(r.appName || r.appId)}</b>
          <span class="mono" style="color:var(--tx-3)">(${esc(r.appId)})</span>
          ${isPrimary ? ' <span class="badge ok" style="font-size:9px">正是当前主用</span>'
            : match ? ' <span class="badge warn" style="font-size:9px">不是主用</span>'
            : ' <span class="badge mute" style="font-size:9px">未登记</span>'}<br/>
          有效期：${esc(exp)}<br/>
          权限 ${(r.scopes || []).length} 个
          ${(r.scopes || []).includes('read_insights') ? '' :
            '<span style="color:var(--warn)"> · 缺 read_insights</span>'}
        </div>`);
      } else {
        appShow(`<div style="font-size:11px;line-height:1.8;color:var(--danger)">
          ✗ ${esc(r.error || '核对失败')}
          ${r.hint ? `<br/><span style="color:var(--warn)">${esc(r.hint)}</span>` : ''}</div>`);
      }
    } catch (e) {
      appShow(`<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`);
    } finally { gVerify.disabled = false; gVerify.textContent = '核对当前令牌属于哪个应用'; }
  };

  /* 取消未完成的切换 */
  const gCancelPend = document.getElementById('g-cancel-pend');
  if (gCancelPend) gCancelPend.onclick = async () => {
    gCancelPend.disabled = true;
    try {
      await api.graphCancelPending();
      toast('已取消', '切换标记已清除', 'ok');
      await load(root);
    } catch (e) {
      toast('失败', e.message, 'err');
      gCancelPend.disabled = false;
    }
  };

  /* ---- 取令牌步骤：展开/收起（数据来自后端 token_steps） ---- */
  const gShowSteps = document.getElementById('g-show-steps');
  const gStepsBox = document.getElementById('g-steps-box');
  if (gShowSteps && gStepsBox) {
    gShowSteps.onclick = () => {
      const open = gStepsBox.style.display !== 'none';
      if (open) {
        gStepsBox.style.display = 'none';
        gShowSteps.textContent = `展开全部 ${steps.length} 步 ▾`;
        return;
      }
      gStepsBox.innerHTML = renderSteps(steps);
      gStepsBox.style.display = '';
      gShowSteps.textContent = '收起 ▴';
    };
  }

  const testM = document.getElementById('dsh-test');
  if (testM) testM.onclick = async () => {
    const out = document.getElementById('dsh-out');
    const m = document.getElementById('dsh-model').value;
    out.innerHTML = '<div style="font-size:11px;color:var(--tx-3)">测试中…（模型响应可能 20–60 秒）</div>';
    try {
      const t = await api.dshTest(m);
      out.innerHTML = `<div style="font-size:11px;color:${t.ok ? 'var(--ok)' : 'var(--danger)'}">
        ${t.ok ? '✓ 连通' : '✗ 失败'} · ${esc(t.model || m)}
        ${t.reply ? ` · 回复「${esc(t.reply)}」` : ''}
        ${t.error ? ` · ${esc(t.error)}` : ''}
      </div>`;
    } catch (e) {
      out.innerHTML = `<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`;
    }
  };
  $$('[data-cht]', root).forEach((b) => {
    b.onclick = async () => {
      const ch = b.dataset.cht;
      const g = (store.dsh.channels || []).find((x) => x.channel === ch);
      if (!g) return;
      // 优先免费模型
      const m = (g.models.find((x) => x.free) || g.models[0]).id;
      b.disabled = true; b.textContent = '…';
      try {
        const t = await api.dshTest(m);
        toast(t.ok ? '渠道可用' : '渠道不可用',
          `${ch} · ${m}${t.error ? ' · ' + t.error.slice(0, 60) : ''}`,
          t.ok ? 'ok' : 'warn', 7000);
      } catch (e) { toast('失败', e.message, 'err'); }
      finally { b.disabled = false; b.textContent = '测'; }
    };
  });
}

/* ---------------- 步骤渲染（全站唯一实现） ----------------
   数据来自后端 token_steps()，前端不再自己写步骤文案。
   切换引导和顶部「展开全部步骤」都调这一个函数，保证完全一致。 */
function renderSteps(steps) {
  if (!Array.isArray(steps) || !steps.length) {
    return '<div class="hint" style="color:var(--warn)">步骤数据没加载到，点「测试连通」重试</div>';
  }
  return `
    <div class="card" style="border-color:rgba(79,70,229,.25)">
      <div class="card-body" style="padding:10px 12px">
        <ol style="margin:0;padding-left:0;list-style:none;
                   font-size:10.5px;line-height:1.85;color:var(--tx-2)">
          ${steps.map((s) => `
            <li style="display:flex;gap:8px;padding:7px 0;
                       border-bottom:1px dashed rgba(0,0,0,.06)">
              <span style="flex:0 0 20px;height:20px;border-radius:50%;
                    background:${s.optional ? 'var(--bg-0)' : 'var(--ac)'};
                    color:${s.optional ? 'var(--tx-3)' : '#fff'};
                    font-size:10px;display:flex;align-items:center;
                    justify-content:center;font-weight:600">${s.n}</span>
              <div style="flex:1;min-width:0">
                <div style="font-weight:600;color:var(--tx-1)">
                  ${esc(s.title || '')}
                  ${s.optional ? `<span style="font-weight:400;color:var(--tx-3);
                    font-size:9.5px"> · 可选</span>` : ''}
                </div>
                <div style="color:var(--tx-2);margin-top:2px">${esc(s.body || '')}</div>
                ${(s.permissions || []).length ? `
                <div style="margin-top:5px">
                  ${s.permissions.map((p) => `
                    <div style="display:flex;gap:6px;align-items:baseline;
                                padding:2px 0 2px 7px;border-left:2px solid var(--line)">
                      <span class="mono" style="font-size:9.5px;
                            color:var(--ac)">${esc(p.key)}</span>
                      <span style="font-size:9.5px;color:var(--tx-2)">
                        ${esc(p.zh)}</span>
                      <span style="font-size:9px;color:var(--tx-3)">
                        （${esc(p.why)}）</span>
                    </div>`).join('')}
                </div>` : ''}
                ${s.query ? `
                <div style="margin-top:5px;padding:5px 8px;border-radius:4px;
                            background:var(--bg-0);font-family:var(--mono);
                            font-size:9.5px;color:var(--tx-1);
                            user-select:all">${esc(s.query)}</div>
                ${s.expect ? `<div style="margin-top:3px;font-size:9.5px;
                  color:var(--ok)">✓ ${esc(s.expect)}</div>` : ''}` : ''}
                ${s.link && s.link.url ? `
                <a class="btn xs ghost" style="margin-top:5px"
                   href="${esc(s.link.url)}" target="_blank"
                   rel="noopener">${esc(s.link.text || '打开')} ↗</a>` : ''}
              </div>
            </li>`).join('')}
        </ol>
      </div>
    </div>`;
}

async function testOne(id) {
  try {
    const r = await api.testIntegration(id);
    toast(r.ok ? '连通' : '失败', r.error || (r.version || r.containers || r.proxies || '').toString(),
      r.ok ? 'ok' : 'err');
    await load(document.getElementById('view'));
  } catch (e) {
    toast('测试失败', e.message, 'err');
  }
}

async function retestAll(btn) {
  btn.disabled = true;
  const old = btn.innerHTML;
  btn.innerHTML = '<span class="spin" data-icon="refresh"></span>重测中…';
  const ids = ['hubstudio', 'clash', 'ffmpeg'];
  let ok = 0;
  for (const id of ids) {
    try {
      const r = await api.testIntegration(id);
      if (r.ok) ok++;
    } catch { /* ignore */ }
  }
  toast('重测完成', `${ok}/${ids.length} 连通`, ok === ids.length ? 'ok' : 'warn');
  btn.disabled = false;
  btn.innerHTML = old;
  await load(document.getElementById('view'));
}

function openSource(src) {
  if (!src) return;
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:13px"><div class="card-body" style="padding:11px 13px">
      <div class="kv"><span class="k">来源</span><span class="v">${esc(src.plugin || '自定义 API')} ${src.version ? 'v' + esc(src.version) : ''}</span></div>
      <div class="kv"><span class="k">模型数</span><span class="v">${(src.models || []).length}</span></div>
      <div class="kv"><span class="k">状态</span><span class="v" style="color:${src.on ? 'var(--ok)' : 'var(--tx-3)'}">${src.on ? '已启用' : '已停用'}</span></div>
    </div></div>
    <div class="section-title">可用模型</div>
    <div class="card"><div class="card-body tight">
      ${(src.models || []).map((m) => `
        <div class="litem">
          <div class="litem-main">
            <div class="litem-title">${esc(m.name || m.id)}
              ${m.vision ? badge('视觉', 'purple') : badge('纯文本', 'mute')}</div>
            <div class="litem-sub">${esc(m.id || '')}${m.ctx ? ' · 上下文 ' + nfmt(m.ctx) : ''}</div>
          </div>
        </div>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">无</div>'}
    </div></div>`;
  modal({ title: esc(src.name), body, footer: [Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: function () { this.closest('.modal-root').classList.remove('on'); } })] });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

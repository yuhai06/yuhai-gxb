/* 入口：路由、侧边栏、命令面板 */
import { hydrateIcons, icon } from './icons.js?v=e2c064c209';
import { $, $$, toast, closeAllModals } from './ui.js?v=0770c29dda';
import { store, paintGuardBadge } from './store.js?v=dd9f0e78d7';

import * as dashboard from './pages/dashboard.js?v=241c607de3';
import * as agent from './pages/agent.js?v=3866beaeb8';
import * as pages from './pages/pages.js?v=6136585b9b';
import * as authz from './pages/authz.js?v=5e8e7af54e';
import * as analytics from './pages/analytics.js?v=311707b065';
import * as guard from './pages/guard.js?v=f6780d0f6b';
import * as comments from './pages/comments.js?v=0d4b3cd911';
import * as video from './pages/video.js?v=119e05d698';
import * as dl from './pages/dl.js?v=4214ffa93f';
import * as slice from './pages/slice.js?v=fe6a352e6b';
import * as publish from './pages/publish.js?v=444fecb57c';
import * as schedule from './pages/schedule.js?v=f5bdb50fc7';
import * as library from './pages/library.js?v=4a10e8ac23';
import * as mail from './pages/mail.js?v=99159025ba';
import * as integrations from './pages/integrations.js?v=18731ee20b';
import * as mcp from './pages/mcp.js?v=d787fb7afb';
import * as envs from './pages/envs.js?v=db12c4e978';
import * as logs from './pages/logs.js?v=366ead74f5';
import * as settings from './pages/settings.js?v=f173d6b4aa';

// title 必须和侧边栏文字一致（以前「主页与授权」点进去叫「授权管理」，
// 「手动微调」点进去叫「视频制作」，用户找不到自己在哪）。
// sec = 所属侧边栏分组，用于自动展开折叠的分组。
const ROUTES = {
  dashboard: { mod: dashboard, title: '今日概览', sec: '' },
  agent: { mod: agent, title: '雨海 Agent', sec: '' },
  dl: { mod: dl, title: '短剧下载', sec: 'produce' },
  slice: { mod: slice, title: '短剧切片', sec: 'produce' },
  video: { mod: video, title: '手动微调', sec: 'produce' },
  library: { mod: library, title: '素材库', sec: 'produce' },
  publish: { mod: publish, title: '发布中心', sec: 'publish' },
  schedule: { mod: schedule, title: '排期与队列', sec: 'publish' },
  envs: { mod: envs, title: '指纹浏览器', sec: 'account' },
  authz: { mod: authz, title: '主页与授权', sec: 'account' },
  guard: { mod: guard, title: '风控中心', sec: 'account' },
  analytics: { mod: analytics, title: '视频数据', sec: 'data' },
  comments: { mod: comments, title: '评论区维护', sec: 'data' },
  mail: { mod: mail, title: '邮箱与验证码', sec: 'tools' },
  integrations: { mod: integrations, title: '第三方对接', sec: 'tools' },
  mcp: { mod: mcp, title: 'MCP 接入', sec: 'tools' },
  logs: { mod: logs, title: '运行日志', sec: 'tools' },
  settings: { mod: settings, title: '设置', sec: 'tools' },
};

// 默认页：没带 hash（直接打开站点）或 hash 无效时落到「工作台概览」。
// 以前这里写的是 'agent'，于是双击打开软件停在 Agent 页——
// 没接本机 Agent 时那页几乎空白（只有一句提示），用户会以为软件坏了。
const DEFAULT_ROUTE = 'dashboard';

function currentRoute() {
  const h = location.hash.replace(/^#\/?/, '');
  if (!h) return DEFAULT_ROUTE;
  return ROUTES[h] ? h : DEFAULT_ROUTE;
}

function navigate(name) {
  if (location.hash === `#/${name}`) renderRoute();
  else location.hash = `#/${name}`;
}

function renderRoute() {
  const name = currentRoute();
  const r = ROUTES[name];
  closeAllModals();
  $$('#nav .nav-item').forEach((el) => el.classList.toggle('active', el.dataset.route === name));
  if (r.sec) setSecOpen(r.sec, true, false);   // 当前页所在分组必须展开
  $('#crumb-cur').textContent = r.title;
  document.title = `${r.title} · 雨海工作台`;
  const view = $('#view');
  view.scrollTop = 0;
  view.innerHTML = '';
  r.mod.render(view);
  hydrateIcons(view);
  syncBadges();
}

/* ---------- 侧边栏分组折叠 ---------- */
const SEC_KEY = 'yuhai.navSecClosed';
function closedSecs() {
  try { return new Set(JSON.parse(localStorage.getItem(SEC_KEY) || '[]')); } catch { return new Set(); }
}
function setSecOpen(sec, open, persist = true) {
  const el = document.querySelector(`.nav-sec[data-sec="${sec}"]`);
  if (!el) return;
  el.classList.toggle('closed', !open);
  if (!persist) return;
  const s = closedSecs();
  if (open) s.delete(sec); else s.add(sec);
  try { localStorage.setItem(SEC_KEY, JSON.stringify([...s])); } catch { /* ignore */ }
}
closedSecs().forEach((sec) => setSecOpen(sec, false, false));
$$('#nav [data-toggle]').forEach((g) => {
  g.addEventListener('click', () => {
    const sec = g.dataset.toggle;
    const el = document.querySelector(`.nav-sec[data-sec="${sec}"]`);
    setSecOpen(sec, el.classList.contains('closed'));
  });
});

function syncBadges() {
  const s = store.loaded || store.summary ? (store.summary || {}) : {};
  // 数值为 0 时隐藏角标，只在有意义的时候出现，避免满屏灰色 0
  const setB = (id, v, kind, hideZero = true) => {
    const el = document.getElementById(id);
    if (!el) return;
    const n = typeof v === 'number' ? v : parseInt(v, 10) || 0;
    el.textContent = v;
    el.style.display = (hideZero && !n) ? 'none' : '';
    el.className = 'nav-badge' + (kind ? ' ' + kind : '');
  };
  setB('nav-badge-library', s.libReady ?? 0, s.libReady ? 'ok' : 'warn', false);
  setB('nav-badge-schedule', s.queueReady ?? 0, 'ok');
  const envEl = document.getElementById('nav-badge-envs');
  if (envEl) {
    const total = (store.envs && store.envs.length) ? store.envs.length : (s.envsTotal ?? 0);
    const run = (store.envs && store.envs.length)
      ? store.envs.filter((e) => e.status === 'running').length
      : (s.envsRunning ?? 0);
    envEl.textContent = `${run}/${total}`;
    envEl.className = 'nav-badge' + (run ? ' ok' : ' warn');
  }
  setB('nav-badge-authz', s.authzPending ?? 0, 'warn');
  setB('nav-badge-mail', store.mails.filter((m) => m.code).length, 'ok');

  const gb = document.getElementById('nav-badge-guard');
  if (gb) {
    const n = (store.guard && store.guard.count) || 0;
    gb.style.display = n ? '' : 'none';
    gb.textContent = n;
  }

  const ct = document.getElementById('chip-tasks');
  if (ct) {
    const n = s.runningJobs ?? 0;
    ct.innerHTML = `任务 <b>${n}</b>`;
    ct.className = 'chip link' + (n ? ' busy' : '');
  }
  const ca = document.getElementById('chip-alerts');
  if (ca) {
    ca.innerHTML = `告警 <b>${s.alerts ?? 0}</b>`;
    ca.className = 'chip link' + ((s.alerts || 0) ? ' alarm' : '');
  }
  paintGuardBadge();
  paintEnv();
}

/* ---------- 启动时拉真实数据 ---------- */
async function boot() {
  try {
    await store.loadCore();
    await store.loadMail({ limit: 30 });
  } catch (e) {
    console.warn('boot load failed', e.message);
    toast('后端未连接', '请确认后端服务在 127.0.0.1:8710 运行', 'err', 6000);
  }
  syncBadges();
  // 风控轮询（30s）
  setInterval(async () => {
    try {
      const before = store.guard.count || 0;
      await store.loadGuard();
      if ((store.guard.count || 0) > before) {
        const v = store.guard.latest || {};
        if (v.tripped) raiseGuardFront(v);
      }
      syncBadges();
    } catch (e) { /* ignore */ }
  }, 30000);
}

function raiseGuardFront(v) {
  import('./store.js').then((m) => m.raiseGuard(v)).catch(() => {});
}

/* ---------- 侧边栏 ---------- */
$$('#nav .nav-item').forEach((el) => {
  el.addEventListener('click', () => navigate(el.dataset.route));
});

/* ---------- 顶栏 ---------- */
// 刷新 = 真的重新拉后端数据再渲染（以前只是重绘，数据还是旧的）
$('#btn-refresh').addEventListener('click', async () => {
  const b = $('#btn-refresh');
  b.disabled = true;
  try {
    await store.loadCore();
    renderRoute();
    toast('已刷新', '已重新拉取后端数据', 'ok', 1600);
  } catch (e) {
    toast('刷新失败', e.message || '后端无响应', 'err', 4000);
  } finally { b.disabled = false; }
});
$('#btn-quick').addEventListener('click', () => openCmdk());
$('#chip-tasks')?.addEventListener('click', () => navigate('logs'));
$('#chip-alerts')?.addEventListener('click', () => navigate('logs'));
$('#chip-guard')?.addEventListener('click', () => navigate('guard'));
$('#env-card')?.addEventListener('click', () => navigate('envs'));

/* ---------- 时钟 ---------- */
function tickClock() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const el = document.getElementById('chip-clock');
  if (el) el.textContent = `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
setInterval(tickClock, 1000);
tickClock();

/* ---------- 侧边栏底部：真实状态 ----------
   以前这里写死 "在线 / DE · 13.141 / 机房 IP"，Hubstudio 挂了也显示在线。
   现在：Hubstudio 用 /health 真实探测；环境数、发布号从 store.envs 读。 */
let hubOk = null;
let appVer = '';
function paintEnv() {
  const set = (dotId, valId, cls, txt) => {
    const d = document.getElementById(dotId);
    if (d) d.className = 'dot ' + cls;
    const b = document.getElementById(valId);
    if (b && txt != null) b.textContent = txt;
  };
  set('dot-hub', 'env-hub', hubOk == null ? '' : hubOk ? 'ok' : 'bad',
    hubOk == null ? '检测中' : hubOk ? '在线' : '未连接');
  const envs = store.envs || [];
  const run = envs.filter((e) => e.status === 'running').length;
  set('dot-envs', 'env-envs', run ? 'ok' : 'warn', envs.length ? `${run} / ${envs.length} 运行` : '—');
  const pub = envs.find((e) => e.role === 'publisher');
  if (pub) {
    const on = pub.status === 'running';
    set('dot-publisher', 'env-publisher', on ? 'ok' : 'warn', on ? '已打开' : '未打开');
    const b = document.getElementById('env-publisher');
    if (b) b.title = `${pub.name || ''} · ${pub.containerCode || ''}`;
  } else {
    set('dot-publisher', 'env-publisher', 'warn', '未设置');
  }
  const v = document.getElementById('ver-line');
  if (v) v.textContent = appVer ? `雨海工作台 v${appVer}` : '雨海工作台';
  const bv = document.getElementById('brand-ver');
  if (bv) bv.textContent = appVer ? `WORKBENCH · v${appVer}` : 'YUHAI WORKBENCH';
}
async function probeHealth() {
  try {
    const base = window.__YHAI_API__ || (location.protocol === 'file:' ? 'http://127.0.0.1:8710' : '');
    const [root, sys] = await Promise.all([
      fetch(base + '/health').then((r) => r.json()).catch(() => null),
      fetch(base + '/api/system/health').then((r) => r.json()).catch(() => null),
    ]);
    if (root && root.version) appVer = root.version;
    hubOk = !!(sys && sys.hubstudio && sys.hubstudio.ok);
  } catch { hubOk = false; }
  paintEnv();
}
paintEnv();
probeHealth();
setInterval(probeHealth, 60000);

/* ---------- 命令面板 ----------
   只保留「真的会做事」的条目。以前有几条只弹一个假 toast
   （如「启动发布号环境」其实什么都没启动），容易误以为操作成功。 */
const CMDS = [
  ...[...Object.entries(ROUTES)].map(([k, v]) => ({ label: `打开：${v.title}`, run: () => navigate(k), key: k })),
  { label: '去发布：新建发布单', run: () => navigate('publish') },
  { label: '去切片：查看切片进度', run: () => navigate('slice') },
  { label: '去素材库：扫描 / 入库素材', run: () => navigate('library') },
  { label: '去排期：查看队列与日历', run: () => navigate('schedule') },
  { label: '去指纹浏览器：启动 / 关闭环境', run: () => navigate('envs') },
  { label: '去主页与授权：提取 / 建主页', run: () => navigate('authz') },
  { label: '去邮箱：查看验证码', run: () => navigate('mail') },
  { label: '风格：切换浅色 / 夜间', run: () => document.getElementById('btn-theme')?.click() },
];

let cmdkOn = false;
let cmdSel = 0;

function openCmdk() {
  const box = document.getElementById('cmdk');
  box.hidden = false;
  cmdkOn = true;
  cmdSel = 0;
  const inp = document.getElementById('cmdk-input');
  inp.value = '';
  paintCmdk('');
  setTimeout(() => inp.focus(), 20);
}
function closeCmdk() {
  document.getElementById('cmdk').hidden = true;
  cmdkOn = false;
}
function paintCmdk(q) {
  const list = CMDS.filter((c) => !q || c.label.toLowerCase().includes(q.toLowerCase()));
  const el = document.getElementById('cmdk-list');
  if (!list.length) {
    el.innerHTML = `<div class="cmdk-empty">没有匹配项</div>`;
    return;
  }
  el.innerHTML = list.map((c, i) => `
    <div class="cmdk-item ${i === cmdSel ? 'on' : ''}" data-i="${i}" data-cmd="${escAttr(c.label)}">
      <span>${c.label}</span>
      <span class="k">${c.key || '↵'}</span>
    </div>`).join('');
  // 用 data 属性 + 闭包下标绑定，避免 HTML 注入与选择器转义问题
  el.querySelectorAll('[data-i]').forEach((it) => {
    it.onclick = () => { list[+it.dataset.i].run(); closeCmdk(); };
  });
  el._list = list;
}

function escAttr(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    cmdkOn ? closeCmdk() : openCmdk();
    return;
  }
  if (!cmdkOn) return;
  const inp = document.getElementById('cmdk-input');
  const el = document.getElementById('cmdk-list');
  const list = el._list || [];
  if (e.key === 'Escape') return closeCmdk();
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    cmdSel = Math.min(cmdSel + 1, Math.max(0, list.length - 1));
    paintCmdk(inp.value);
  }
  if (e.key === 'ArrowUp') {
    e.preventDefault();
    cmdSel = Math.max(cmdSel - 1, 0);
    paintCmdk(inp.value);
  }
  if (e.key === 'Enter') {
    e.preventDefault();
    const c = list[cmdSel];
    if (c) { c.run(); closeCmdk(); }
  }
});

$('#cmdk-input')?.addEventListener('input', (e) => {
  cmdSel = 0;
  paintCmdk(e.target.value);
});
$('#cmdk')?.addEventListener('click', (e) => {
  if (e.target.id === 'cmdk') closeCmdk();
});

/* ---------- 主题切换（B 浅色为默认，深色保留为夜间模式） ---------- */
const THEME_KEY = 'yuhai.theme';
const THEMES = [
  { id: 'light', label: '浅色', icon: 'sun' },
  { id: 'dark', label: '夜间', icon: 'moon' },
];

function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  const def = THEMES.find((x) => x.id === t) || THEMES[0];
  const lbl = document.getElementById('theme-label');
  const ico = document.querySelector('#btn-theme [data-icon]');
  if (lbl) lbl.textContent = def.label;
  if (ico) {
    ico.dataset.icon = def.icon;
    ico.innerHTML = icon(def.icon, 13);
  }
  const meta = document.querySelector('meta[name="color-scheme"]');
  if (meta) meta.setAttribute('content', t === 'dark' ? 'dark' : 'light');
  try { localStorage.setItem(THEME_KEY, t); } catch (e) { /* file:// */ }
}

function initTheme() {
  let t = 'light';
  try { t = localStorage.getItem(THEME_KEY) || 'light'; } catch (e) { /* ignore */ }
  if (!THEMES.some((x) => x.id === t)) t = 'light';
  applyTheme(t);
}

document.getElementById('btn-theme')?.addEventListener('click', () => {
  const cur = document.documentElement.dataset.theme || 'light';
  const i = THEMES.findIndex((x) => x.id === cur);
  const next = THEMES[(i + 1) % THEMES.length];
  applyTheme(next.id);
  // 图表颜色在渲染时确定，切主题后需要重绘当前页
  if (typeof renderRoute === 'function') renderRoute();
  toast(next.id === 'dark' ? '夜间模式' : '浅色模式', 'Ctrl+J 切换', 'info', 1500);
});

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'j') {
    e.preventDefault();
    document.getElementById('btn-theme')?.click();
  }
});

/* ---------- 启动 ---------- */
initTheme();
window.addEventListener('hashchange', renderRoute);
hydrateIcons(document);
renderRoute();
boot();

/* 预热：把图标塞进静态顶栏按钮 */
$$('.btn [data-icon], .nav-ico[data-icon], .ev [data-icon]').forEach((el) => {
  if (!el.innerHTML.trim()) el.innerHTML = icon(el.dataset.icon, 14);
});





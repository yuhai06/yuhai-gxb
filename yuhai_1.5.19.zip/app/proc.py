"""子进程静默启动工具——避免打包后每次调用都弹黑框。

Windows 上 `subprocess.run/Popen` 默认会给控制台程序新建窗口；
打包成 windowed exe 后，这些窗口会一个个闪出来，很难看。
统一走这个模块拿 kwargs，保证所有外部命令都在后台跑。

编码保护
--------
子进程的 stdout/stderr 和它写出的路径，在中文 Windows 上很容易踩编码坑：
控制台默认代码页是 936(GBK)，而 Python 内部是 Unicode。
一旦某个环节用错了编码，「账号运营」这种中文目录名会被写成
「璐﹀彿杩愯惀」这样的畸形目录（UTF-8 字节被当作 GBK 解读后再存回去），
而且这种目录会悄悄堆积、很难发现。

所以这里统一给子进程补两份保护：
  · 环境变量 PYTHONIOENCODING=utf-8 / PYTHONUTF8=1（Python 子进程）
  · 文本模式下显式 encoding（避免用 locale 默认值）
调用方仍可覆盖。
"""
from __future__ import annotations

import os
import subprocess
import sys
from typing import Any


def kw() -> dict:
    """给 subprocess.run / Popen 用的静默参数。"""
    if os.name == "nt":
        return {"creationflags": subprocess.CREATE_NO_WINDOW}
    return {}


def env_with_utf8(env: dict[str, str] | None = None) -> dict[str, str]:
    """返回一份已开启 Python UTF-8 模式的子进程环境。

    不会改调用方传进来的字典，也不会覆盖调用方显式设置的值。
    """
    base = dict(os.environ if env is None else env)
    base.setdefault("PYTHONIOENCODING", "utf-8")
    base.setdefault("PYTHONUTF8", "1")
    return base


def _apply_defaults(command: list[Any] | Any, kwargs: dict) -> None:
    """按需补环境变量与文本编码。仅作用于 Python 子进程/文本模式。"""
    # 1. 文本模式：没显式给 encoding 就用 utf-8，别用 locale 默认
    text_mode = bool(kwargs.get("text") or kwargs.get("universal_newlines")
                     or kwargs.get("encoding"))
    if text_mode and "encoding" not in kwargs:
        kwargs["encoding"] = "utf-8"
        kwargs.setdefault("errors", "replace")

    # 2. Python 子进程：开启 UTF-8 模式，防止中文路径被错误编码
    is_python = False
    if isinstance(command, (list, tuple)) and command:
        first = str(command[0]).lower()
        is_python = os.path.basename(first) in {
            "python", "python.exe", "pythonw", "pythonw.exe",
        } or first.endswith("python.exe")
    elif isinstance(command, str):
        is_python = "python" in command.lower()

    if is_python:
        kwargs["env"] = env_with_utf8(kwargs.get("env"))


def run(cmd, **kwargs):
    """subprocess.run 的静默版（默认带 capture_output）。"""
    kw_ = kw()
    kw_.update(kwargs)
    if "capture_output" not in kw_ and "stdout" not in kw_:
        kw_["capture_output"] = True
    _apply_defaults(cmd, kw_)
    return subprocess.run(cmd, **kw_)


def popen(cmd, **kwargs):
    """subprocess.Popen 的静默版。"""
    kw_ = kw()
    kw_.update(kwargs)
    _apply_defaults(cmd, kw_)
    return subprocess.Popen(cmd, **kw_)


def no_window_flags() -> int:
    """直接拿 creationflags 给别处用。"""
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def python_exe() -> str:
    """当前解释器路径（打包后是 exe，开发时是 python）。

    子进程调 Python 脚本时统一用它，避免依赖 PATH 里的 python 版本。
    """
    return sys.executable

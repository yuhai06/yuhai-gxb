"""短剧切片 API：严格对齐《短剧切片完整流程.md》。"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import slicing as sl
from app import proc

log = logging.getLogger("yuhai.api.slice")
router = APIRouter(tags=["slice"])


@router.get("/slice/env")
async def env():
    """检查流程环境：脚本 / 模型 / ffmpeg / GPU。"""
    import shutil
    from app.services import video_maker as vm

    t = sl.tools_dir()
    scripts = ["pipeline2.py", "transcribe_audio.py", "voice_check3.py",
               "classify.py", "score_lines2.py", "cut_ep2.py",
               "plan_from_tension.py", "render_plan.py", "mark_done.py"]
    have = {s: (t / s).exists() for s in scripts}

    # faster-whisper
    fw = False
    try:
        import faster_whisper  # noqa: F401
        fw = True
    except Exception:
        pass

    # GPU
    gpu = ""
    try:
        r = proc.run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                           capture_output=True, text=True, timeout=10,
                           encoding="utf-8", errors="replace")
        if r.returncode == 0:
            gpu = (r.stdout or "").strip().split("\n")[0][:60]
    except Exception:
        pass

    # NVENC
    nvenc = False
    try:
        r = proc.run([vm.ffmpeg_path(), "-hide_banner", "-encoders"],
                           capture_output=True, text=True, timeout=20,
                           encoding="utf-8", errors="replace")
        nvenc = "h264_nvenc" in (r.stdout or "")
    except Exception:
        pass

    return {
        "toolsDir": str(t),
        "stateDir": str(sl.state_dir()),
        "sourceDir": str(sl.source_dir()),
        "outRoot": str(sl.out_root()),
        "scripts": have,
        "allScripts": all(have.values()),
        "fasterWhisper": fw,
        "ffmpeg": vm.env_check(),
        "gpu": gpu,
        "nvenc": nvenc,
        "ok": all(have.values()) and fw,
    }


@router.get("/slice/dramas")
async def dramas():
    """列出所有可处理的剧 + 每部进行到哪步。"""
    return {"items": sl.list_dramas(), "count": len(sl.list_dramas())}


@router.get("/slice/status")
async def status(drama: str):
    """单部剧的详细状态（含中间产物）。"""
    st = sl.drama_status(drama)
    # 附带张力分布（前 30 句）
    tn = sl.read_tension(drama)
    lines = tn.get("lines") or tn.get("scored") or []
    st["tensionTop"] = sorted(
        [{"ep": x.get("ep"), "text": (x.get("text") or "")[:80],
          "score": x.get("score") or x.get("tension") or 0}
         for x in lines], key=lambda x: -(x["score"] or 0))[:30]
    # 计划阶段
    pl = sl.read_plan(drama)
    st["planStages"] = pl.get("stages") or []
    return st


class RunReq(BaseModel):
    drama: str
    single: bool = True
    premium: bool = True
    model: str = "small"
    target: float = 45
    maxEp: int = 0
    episodes: list[str] = []


@router.post("/slice/run")
async def run(req: RunReq):
    """跑完整流程（转录→检测→分类→打分→单集→精品）。"""
    if not req.drama.strip():
        raise HTTPException(400, "剧名不能为空")
    src = sl.find_drama_dir(req.drama)
    if not src:
        from app import paths as _p
        main_src = _p.source_roots()[0]
        raise HTTPException(400,
            f"源素材不存在：{req.drama}\n"
            f"已查找：{', '.join(str(r) for r in sl.source_roots())}\n"
            f"可用「素材抓取」先抓片，或手动放到 {main_src}\\{req.drama}\\EP01.mp4")

    job_id = "job-" + uuid.uuid4().hex[:12]
    names = ["① 台词转录", "② 语音检测", "③ 类型判定",
             "④ 张力打分", "⑤ 单集出片", "⑥ 精品混剪"]
    steps = [{"name": n, "state": "wait", "note": ""} for n in names]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "slice", f"切片 {req.drama}", "queued", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso()))
    asyncio.create_task(sl.run_pipeline(job_id, req.drama, req.model_dump()))
    return {"ok": True, "jobId": job_id,
            "note": "转录最慢（20集约 43 秒 GPU 加速）"}


class StepReq(BaseModel):
    drama: str
    ep: str = ""
    target: float = 45
    model: str = "small"


@router.post("/slice/step/{name}")
async def run_step(name: str, req: StepReq):
    """单独跑某一步（调试用）。"""
    steps = {
        "transcribe": lambda: sl.step_transcribe("", req.drama, req.model),
        "voice": lambda: sl.step_voice("", req.drama),
        "classify": lambda: sl.step_classify("", req.drama),
        "tension": lambda: sl.step_tension("", req.drama),
        "single": lambda: sl.step_single("", req.drama,
                                         [req.ep] if req.ep else None,
                                         req.target),
        "premium": lambda: sl.step_premium("", req.drama),
    }
    if name not in steps:
        raise HTTPException(400, f"未知步骤 {name}")
    r = await asyncio.to_thread(steps[name])
    return r


@router.get("/slice/verify")
async def verify(path: str):
    """校验成片：规格 + 静音段。"""
    if not Path(path).exists():
        raise HTTPException(404, "文件不存在")
    out = await asyncio.to_thread(sl.verify_output, path)
    sil = await asyncio.to_thread(sl.check_audio_guard, path)
    out["silence"] = sil
    return out


@router.get("/slice/check-dialogue")
async def check_dialogue(drama: str, ep: str = "", plan: str = ""):
    """台词完整性 + 无重叠校验（通用版 chk_full2.py）。"""
    return await asyncio.to_thread(sl.check_dialogue_complete, drama, ep, plan)


@router.get("/slice/audio-guard")
async def audio_guard(path: str, minSilence: float = 2.0):
    """静音段检查（通用版 audio_guard.py）。"""
    if not Path(path).exists():
        raise HTTPException(404, "文件不存在")
    return await asyncio.to_thread(sl.check_audio_guard, path, minSilence)


# ---------------- 环境自检 / 自动安装 ----------------
@router.get("/env/full")
async def env_full():
    """全环境自检（换电脑时先跑这个）。"""
    from app.services import envcheck
    return await asyncio.to_thread(envcheck.full_check)


@router.post("/env/install")
async def env_install(what: str = "all", target: str = ""):
    """自动安装/更新缺失项。

    what:
      all            全部（python → ffmpeg → whisper → tools）
      python         Python 包
      ffmpeg         FFmpeg / ffprobe
      whisper        ASR 模型（默认 small）
      whisper-medium 下载 medium（中文/日语更准）
      whisper-tiny   下载 tiny（测试用）
      tools          切片脚本（从包内/工作区复制最新版）
      cuda           CUDA 运行库（GPU 加速）

    target: whisper 模型名 / tools 源目录（可选）
    """
    from app.services import envcheck
    w = (what or "all").lower()

    if w == "python":
        return await asyncio.to_thread(envcheck.install_python)
    if w == "ffmpeg":
        return await asyncio.to_thread(envcheck.install_ffmpeg)
    if w.startswith("whisper"):
        size = target or w.replace("whisper-", "").replace("whisper", "small")
        if size in ("", "whisper"):
            size = "small"
        return await asyncio.to_thread(envcheck.install_whisper_model, size)
    if w == "tools":
        return await asyncio.to_thread(envcheck.install_tools, target)
    if w == "cuda":
        return await asyncio.to_thread(envcheck.install_cuda)
    return await asyncio.to_thread(envcheck.install_all)


@router.get("/env/model")
async def env_model(name: str = "small"):
    """只查 ASR 模型状态（前端点更新前先问一下多大）。"""
    from app.services import envcheck
    return await asyncio.to_thread(envcheck.check_whisper_model, name)


# ---------------- 路径配置（跨环境适配） ----------------
PATH_KEYS = {
    "workspace": ("YUHAI_WORKSPACE", "工作区根目录", "workspace"),
    "tools": ("YUHAI_TOOLS", "切片/抓取脚本目录", "tools"),
    "models": ("YUHAI_MODELS", "ASR 模型目录", "models"),
    "library": ("YUHAI_LIBRARY", "素材库目录", "library"),
    "output": ("YUHAI_OUTPUT", "成片输出目录", "output"),
    "source_roots": ("YUHAI_SOURCE_ROOTS", "源素材目录（多个用 ; 分隔）", "sourceRoots"),
    "fonts": ("YUHAI_FONTS", "字体目录", "fonts"),
    "audio": ("YUHAI_AUDIO", "BGM/音效目录", "audio"),
    "proxy": ("PD_PROXY", "抓取代理", "proxy"),
}


@router.get("/slice/sources")
async def slice_sources():
    """切片用源素材目录（可自定义，跨机器可指向别处的素材）。

    返回当前生效的目录 + 候选目录（带每部剧数量和是否可切片）。
    """
    from app import paths as _p
    import os
    cur_env = os.environ.get("YUHAI_SOURCE_ROOTS", "")
    cfg_val = ""
    try:
        cfg_val = str(_p._CFG.get("source_roots") or "")
    except Exception:
        pass
    roots = [str(x) for x in _p.source_roots()]
    items = []
    for r in roots:
        from pathlib import Path as _P
        p = _P(r)
        n = 0
        ok = False
        try:
            if p.is_dir():
                ok = True
                n = sum(1 for d in p.iterdir()
                        if d.is_dir() and list(d.glob("*.mp4")))
        except OSError:
            pass
        items.append({"path": r, "exists": ok, "dramaCount": n})
    return {
        "roots": roots,
        "items": items,
        "source": "环境变量" if cur_env else ("配置文件" if cfg_val else "自动发现"),
        "configFile": str(_p.DATA_DIR / "config.json"),
    }


class SourceReq(BaseModel):
    roots: list[str] = []


@router.post("/slice/sources")
async def slice_sources_save(req: SourceReq):
    """保存切片源素材目录（写 config.json，重启生效）。"""
    from app import paths as _p
    from app.config import settings
    from pathlib import Path as _P
    cleaned = []
    for r in (req.roots or []):
        s = str(r or "").strip()
        if not s:
            continue
        p = _P(s)
        try:
            p.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return {"ok": False, "error": f"目录不可用：{s} — {e}"}
        if s not in cleaned:
            cleaned.append(s)
    if cleaned:
        settings.save_user_config({"source_roots": cleaned})
        try:
            _p._CFG["source_roots"] = cleaned
            _p.snapshot.cache_clear()
        except Exception:
            pass
    else:
        settings.save_user_config({"source_roots": ""})
        try:
            _p._CFG.pop("source_roots", None)
            _p.snapshot.cache_clear()
        except Exception:
            pass
    db.log_event("info", "slice", f"切片源素材目录改为 {cleaned or '默认'}")
    return {"ok": True, "roots": cleaned,
            "note": "已保存；重启程序后所有模块生效"}


@router.get("/env/paths")
async def env_paths():
    """当前生效的全部路径（含来源：env / config / auto）。"""
    from app import paths
    snap = paths.snapshot()
    cfg = paths._CFG
    cfg_lower = {k.lower() for k in cfg}
    items = []
    for key, (env_key, label, snap_key) in PATH_KEYS.items():
        env_val = os.environ.get(env_key, "")
        cfg_val = ""
        for ck in (key, f"{key}_root", label):
            if ck.lower() in cfg_lower:
                real = [k for k in cfg if k.lower() == ck.lower()][0]
                v = cfg[real]
                cfg_val = ";".join(map(str, v)) if isinstance(v, list) else str(v)
                break
        eff = snap.get(snap_key, "")
        if isinstance(eff, list):
            eff = ";".join(eff)
        items.append({
            "key": key, "label": label, "envKey": env_key,
            "envValue": env_val, "configValue": cfg_val,
            "value": eff,
            "source": "环境变量" if env_val else ("配置文件" if cfg_val else "自动发现"),
        })
    return {"items": items, "configFile": snap["configFile"],
            "snapshot": snap}


@router.post("/env/paths")
async def env_paths_save(patch: dict):
    """保存路径覆盖到 config.json（重启后生效）。"""
    from app import paths
    from app.config import settings
    clean = {}
    for k, v in (patch or {}).items():
        if k not in PATH_KEYS:
            continue
        if isinstance(v, list):
            v = ";".join(str(x).strip() for x in v if str(x).strip())
        v = str(v or "").strip()
        if v:
            clean[k] = v
        else:
            clean[k] = ""      # 空 = 清除该覆盖
    settings.save_user_config(clean)
    # 同步更新已加载的模块级常量（不重启也能看到效果）
    try:
        paths._CFG.update({k: v for k, v in clean.items() if v})
        for k, v in clean.items():
            if not v:
                paths._CFG.pop(k, None)
        paths.snapshot.cache_clear()
    except Exception:
        pass
    return {"ok": True, "saved": clean,
            "note": "已写入 config.json；重启程序后所有模块生效",
            "configFile": str(paths.DATA_DIR / "config.json")}


@router.post("/env/ensure-dirs")
async def env_ensure_dirs():
    """按当前路径创建缺失目录。"""
    from app import paths
    return {"ok": True, "created": paths.ensure_dirs(),
            "snapshot": paths.snapshot()}


@router.get("/slice/types")
async def types():
    """7 种剧型定义（含 BGM / 节奏 / 强特征）。"""
    return {"items": [
        {"id": k, **v} for k, v in sl.DRAMA_TYPES.items()
    ]}


@router.get("/slice/constraints")
async def constraints():
    """硬性约束清单。"""
    return {
        "constraints": sl.CONSTRAINTS,
        "stages": sl.STAGES,
        "rules": [
            "① 台词完整不截断（冲突丢低分段）",
            "② 段间零重叠（三道防线）",
            "③ pad 0.15s",
            "④ 不用字幕 OCR 对齐，用 whisper 时间戳",
            "⑤ 过滤 <1.5s 的段",
            "⑥ 单段 > target×1.4 拆单句",
            "⑦ 时长容差 ±6s",
            "⑧ 段数不足放宽到 max_lines=5",
            "⑨ 成片 <30s 直接不生成",
        ],
    }


@router.get("/slice/jobs")
async def jobs(limit: int = 50):
    rows = db.q("SELECT * FROM jobs WHERE kind='slice' ORDER BY created_at DESC"
                " LIMIT ?", (min(limit, 200),))
    for r in rows:
        for k in ("steps", "payload", "result"):
            if r.get(k):
                try:
                    r[k] = json.loads(r[k])
                except Exception:
                    pass
    return {"items": rows}


@router.post("/slice/mark-done")
async def mark_done(drama: str, deleteSource: bool = False):
    """标记完成 + 可选删原始素材（一部剧 3-4.5GB）。"""
    r = await asyncio.to_thread(sl._run, "mark_done.py",
                                [drama] + ([] if deleteSource else ["--no-delete"]))
    deleted = False
    if deleteSource:
        src = sl.source_dir() / drama
        if src.exists():
            import shutil
            shutil.rmtree(src, ignore_errors=True)
            deleted = True
    return {"ok": r["ok"], "deleted": deleted,
            "output": "\n".join(r["lines"][-5:])[:400]}

# ---------------- 剧型：模型判型 ----------------
class JudgeReq(BaseModel):
    drama: str
    apply: bool = False
    model: str = ""


@router.post("/slice/judge")
async def slice_judge(req: JudgeReq):
    """用模型判型（比关键词准）。"""
    from app.services import type_llm as tl
    return await asyncio.to_thread(tl.judge, req.drama, req.model, req.apply)


class JudgeBatchReq(BaseModel):
    onlyFallback: bool = True
    apply: bool = True
    limit: int = 0


@router.post("/slice/judge-batch")
async def slice_judge_batch(req: JudgeBatchReq):
    """批量用模型判型。"""
    from app.services import type_llm as tl
    from app.services import slicing as sl

    rep = await asyncio.to_thread(sl.type_report)
    targets = [x for x in rep if x.get("drama")]
    if req.onlyFallback:
        targets = [x for x in targets if not x.get("matched")]
    names = [x["drama"] for x in targets]
    if req.limit:
        names = names[:req.limit]
    if not names:
        return {"ok": True, "total": 0, "results": [],
                "note": "没有需要判型的剧"}
    return await asyncio.to_thread(
        tl.judge_batch, names, "", req.apply, False)


class SetTypeReq(BaseModel):
    drama: str
    typeName: str = ""


@router.post("/slice/set-type")
async def slice_set_type(req: SetTypeReq):
    """手动指定剧型（typeName 空 = 取消）。"""
    from app.services import slicing as sl
    return await asyncio.to_thread(sl.set_type_override,
                                   req.drama, req.typeName)


@router.get("/slice/type-report")
async def slice_type_report():
    """所有剧的判定报告。"""
    from app.services import slicing as sl
    items = await asyncio.to_thread(sl.type_report)
    fb = [x for x in items if not x.get("matched")]
    return {"ok": True, "total": len(items),
            "fallbackCount": len(fb), "items": items}

@router.get("/slice/debug-state")
async def debug_state():
    """调试：看 state 目录解析对不对。"""
    import os
    from app import paths
    from app.services import type_llm as tl
    from app.services import slicing as sl

    st = tl._state()
    subs = os.path.join(st, "subs")
    cnt = 0
    if os.path.isdir(subs):
        cnt = len([f for f in os.listdir(subs)
                   if f.endswith("_transcript.json")])
    return {
        "stateDir": st,
        "stateFromSlicing": str(sl.state_dir()),
        "pathsStateDir": str(paths.state_dir()),
        "toolsDir": str(paths.tools_dir()),
        "subsExists": os.path.isdir(subs),
        "subsCount": cnt,
    }


# ══════════════════════════════════════════════════════════════════
#  批量切片（2026-11-17 新增）
#
#  用户要求：
#    · 每部剧处理后面一半（前面的有些已切过）
#    · 切完且成功就删原始素材
#    · 要知道哪些没处理（之前切过但没删原片，分不清）
# ══════════════════════════════════════════════════════════════════

@router.get("/slice/batch/progress")
async def slice_batch_progress():
    """每部剧的切片进度：总集数 / 已切 / 待切（精确到集）。"""
    from app.services import batch_slice as bs
    return {"ok": True, "items": await asyncio.to_thread(bs.list_source_dramas)}


class BatchSliceReq(BaseModel):
    drama: str
    half: str = "second"        # all | first | second（默认后半）
    target: float = 45.0        # 每集目标时长（秒）
    deleteSource: bool = True   # 切成功就删原片
    limit: int = 0              # 0 = 不限；>0 只切这么多集


@router.post("/slice/batch")
async def slice_batch_api(req: BatchSliceReq):
    """批量切一部剧。

    half='second' → 只切后半部分（用户要求：前面有些已经切过）
    deleteSource=True → 每切成功一集就删掉对应的原始文件
    """
    from app.services import batch_slice as bs

    job_id = "job-" + uuid.uuid4().hex[:12]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at,started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "slice",
             f"切片 {req.drama}（{'后半' if req.half == 'second' else '前半' if req.half == 'first' else '全部'}）",
             "running", 0, json.dumps([], ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False),
             now_iso(), now_iso()))

    async def _bg():
        try:
            r = await asyncio.to_thread(
                bs.slice_batch, req.drama, req.half, req.target,
                req.deleteSource, job_id, req.limit)
            db.exec("UPDATE jobs SET status=?,progress=100,result=?,ended_at=? "
                    "WHERE id=?",
                    ("done" if r.get("ok") else "blocked",
                     json.dumps(r, ensure_ascii=False), now_iso(), job_id))
            db.log_event("ok" if r.get("ok") else "warn", "slice",
                         f"{req.drama}: {r.get('note')}")
        except Exception as e:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (str(e)[:400], now_iso(), job_id))

    asyncio.create_task(_bg())
    return {"ok": True, "jobId": job_id}


@router.get("/slice/processed")
async def slice_processed(drama: str = "", limit: int = 200):
    """已处理记录（哪些原始素材切过、切出什么、有没有删原片）。"""
    sql = "SELECT * FROM processed_sources WHERE 1=1"
    params: list = []
    if drama:
        sql += " AND drama=?"
        params.append(drama)
    sql += " ORDER BY processed_at DESC LIMIT ?"
    params.append(min(limit, 1000))
    return {"ok": True, "items": db.q(sql, params),
            "total": db.q1("SELECT COUNT(*) c FROM processed_sources")["c"]}

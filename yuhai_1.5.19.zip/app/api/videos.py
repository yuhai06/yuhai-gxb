"""视频数据 API（推广矩阵形态）。

数据粒度：**单条视频**（unit），不是剧、不是主页。
一次发布 = 一个 unit，可跨任意题材；剧目只是可选标签。
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from app.db import db, now_iso

log = logging.getLogger("yuhai.api.videos")
router = APIRouter(tags=["videos"])


# ---------------- 视频列表 ----------------
@router.get("/videos")
async def list_videos(page_id: str = "", state: str = "all", q: str = "",
                      days: int = Query(0, ge=0, le=3650), limit: int = 2000):
    """视频列表。days=0（默认）返回**全部**；>0 时才按天数过滤。

    ⚠ 2026-11-17 改默认 limit：500 → 2000

    用户反馈："网易发布号不可能那么少播放量"。
    实测根因：默认 limit=500，而实际有 776 条视频，
    前端按这 500 条累加播放量 → 显示 3.8万（真实是 14.5万）。

    视频数量迟早会超过 2000，所以：
      · 默认拉到 2000（接口硬上限）
      · 前端在列表页不再靠这个接口算全局播放，改用 overview 接口
    """
    sql = """SELECT u.*, p.name AS page_name
             FROM units u LEFT JOIN pages p ON p.page_id = u.page_id
             WHERE 1=1"""
    params: list[Any] = []
    if page_id:
        sql += " AND u.page_id=?"
        params.append(page_id)
    if state != "all":
        sql += " AND u.state=?"
        params.append(state)
    if q:
        sql += " AND (u.title LIKE ? OR u.post_id LIKE ? OR u.tags LIKE ?)"
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    # days=0 → 不限制时间，返回全部
    # 兼容旧行为：解析不出 published_date 时退回 created_at
    if days and days > 0:
        since = (date.today() - timedelta(days=days)).isoformat()
        sql += (" AND (COALESCE(NULLIF(u.published_date,''), "
                "substr(u.created_at,1,10)) >= ?)")
        params.append(since)
    sql += " ORDER BY COALESCE(NULLIF(u.published_date,''), substr(u.created_at,1,10)) DESC, u.created_at DESC LIMIT ?"
    params.append(min(limit, 2000))
    rows = db.q(sql, params)

    # ⚠ 2026-11-17 一次性取全部指标，避免 N+1 查询：
    #   旧写法在 for 循环里对每条视频执行 2 次 q1 → 776 条 = 1552 次 SQL，
    #   日志里 `slow 67517ms GET /api/videos` 就是这么来的。
    #   现在改成：一条 SQL 把「每条视频的最新快照 + 最早快照」全取出来。
    ids = [r["id"] for r in rows]
    latest_map: dict[str, dict] = {}
    first_map: dict[str, dict] = {}
    if ids:
        ph = ",".join("?" * len(ids))
        for m in db.q(
            f"""SELECT um.* FROM unit_metrics um
                WHERE um.unit_id IN ({ph})
                  AND um.date = (SELECT MAX(m2.date) FROM unit_metrics m2
                                 WHERE m2.unit_id = um.unit_id)""", ids):
            latest_map[m["unit_id"]] = m
        for m in db.q(
            f"""SELECT um.* FROM unit_metrics um
                WHERE um.unit_id IN ({ph})
                  AND um.date = (SELECT MIN(m2.date) FROM unit_metrics m2
                                 WHERE m2.unit_id = um.unit_id)""", ids):
            first_map[m["unit_id"]] = m

    out = []
    for r in rows:
        # 取该视频**最新一天**的快照（不管是不是今天）——
        # 这才是「当前累计播放」。旧代码只取 today，导致 360 条视频读成 0。
        m = latest_map.get(r["id"]) or {}
        m0 = first_map.get(r["id"]) or {}
        growth = 0
        if m0.get("plays") and m.get("plays"):
            growth = round((m["plays"] - m0["plays"]) / max(1, m0["plays"]) * 100, 1)
        out.append({
            "id": r["id"],
            "postId": r["post_id"],
            "pageId": r["page_id"],
            "pageName": r["page_name"],
            "assetId": r["asset_id"],
            "title": r["title"] or "",
            "tags": json.loads(r["tags"] or "[]") if r["tags"] else [],
            "publishedAt": r["published_at"],
            "publishedDate": r.get("published_date") or "",
            "state": r["state"],
            "tracker": r["tracker"],
            "metrics": {
                "plays": m.get("plays") or 0,
                "reach": m.get("reach") or 0,
                "reactions": m.get("reactions") or 0,
                "comments": m.get("comments") or 0,
                "shares": m.get("shares") or 0,
                "saves": m.get("saves") or 0,
                "avgWatch": m.get("avg_watch") or 0,
                "completion": m.get("completion") or 0,
                "clicks": m.get("clicks") or 0,
            },
            "firstPlays": m0.get("plays") or 0,
            "growthPct": growth,
            "collectedAt": m.get("collected_at"),
        })
    return {"items": out, "count": len(out)}


# ---------------- 单条视频详情 ----------------
@router.get("/videos/{unit_id}")
async def video_detail(unit_id: str):
    r = db.q1("SELECT u.*, p.name AS page_name FROM units u "
              "LEFT JOIN pages p ON p.page_id=u.page_id WHERE u.id=?", (unit_id,))
    if not r:
        raise HTTPException(404, "视频不存在")
    series = db.q(
        "SELECT date,plays,reach,reactions,comments,shares,clicks,completion "
        "FROM unit_metrics WHERE unit_id=? ORDER BY date", (unit_id,))
    total = db.q1(
        "SELECT MAX(plays) plays, MAX(reach) reach, MAX(reactions) reactions,"
        " MAX(comments) comments, MAX(shares) shares, MAX(clicks) clicks "
        "FROM unit_metrics WHERE unit_id=?", (unit_id,)) or {}
    return {
        "id": r["id"], "postId": r["post_id"], "pageId": r["page_id"],
        "pageName": r["page_name"], "title": r["title"],
        "publishedAt": r["published_at"],
        "publishedDate": r.get("published_date") or "",
        "state": r["state"],
        "tracker": r["tracker"],
        "series": series,
        "total": {k: v or 0 for k, v in total.items()},
    }


# ---------------- 汇总 ----------------
@router.get("/videos/summary/overview")
async def overview(days: int = Query(14, ge=1, le=3650)):
    """矩阵总览：按天聚合 + 分主页 + Top 视频。

    ⚠ 2026-11-17 重大修正 —— 之前这里一直在重复累加：

    背景：
        unit_metrics 是**按天快照**表。同一条视频在 11-10 / 11-13 / 11-17
        各有一行（累计播放值的快照）。
        旧代码 `SUM(m.plays)` 把这些行**全加起来**，等于把累计值重复累加。

        实测：776 条视频，真实累计播放 92,035，
             旧 overview 报 145,980（虚高 58%）。

    正确口径（和「视频列表」页保持一致）：
        · 每一条视频只取它**最新一天**的那行
        · 再对这些值求和 = 当前总播放
    """
    since = (date.today() - timedelta(days=days)).isoformat()

    # 每条视频的「最新一行」——这是求和唯一正确的来源
    LATEST = (
        "SELECT um.* FROM unit_metrics um "
        "WHERE um.date = (SELECT MAX(m2.date) FROM unit_metrics m2 "
        "                 WHERE m2.unit_id = um.unit_id)"
    )

    daily = db.q(
        f"""SELECT d.date,
                   SUM(d.plays) plays, SUM(d.reach) reach,
                   SUM(d.reactions) reactions, SUM(d.comments) comments,
                   SUM(d.shares) shares, SUM(d.clicks) clicks,
                   COUNT(DISTINCT d.unit_id) videos
            FROM ({LATEST}) d
            WHERE d.date >= ?
            GROUP BY d.date ORDER BY d.date""", (since,))

    by_page = db.q(
        f"""SELECT p.page_id, p.name, p.health,
                   COUNT(DISTINCT u.id) videos,
                   COALESCE(SUM(m.plays),0) plays,
                   COALESCE(SUM(m.clicks),0) clicks
            FROM pages p
            LEFT JOIN units u ON u.page_id = p.page_id
            LEFT JOIN ({LATEST}) m ON m.unit_id = u.id
            GROUP BY p.page_id ORDER BY plays DESC""")

    top = db.q(
        f"""SELECT u.id, u.title, u.post_id, p.name AS page_name,
                   m.plays, m.reactions, m.clicks
            FROM units u
            LEFT JOIN pages p ON p.page_id=u.page_id
            JOIN ({LATEST}) m ON m.unit_id=u.id
            ORDER BY plays DESC LIMIT 20""")

    totals = db.q1(
        f"""SELECT COALESCE(SUM(m.plays),0) plays,
                   COALESCE(SUM(m.reach),0) reach,
                   COALESCE(SUM(m.reactions),0) reactions,
                   COALESCE(SUM(m.clicks),0) clicks,
                   COALESCE(SUM(m.comments),0) comments,
                   COALESCE(SUM(m.shares),0) shares
            FROM ({LATEST}) m""") or {}

    return {
        "days": days,
        "daily": daily,
        "byPage": by_page,
        "topVideos": top,
        "totals": totals,
        "videoCount": db.q1("SELECT COUNT(*) c FROM units")["c"],
    }


# ---------------- 手动录入指标 ----------------
class MetricsReq(BaseModel):
    unitId: str
    date: str = ""
    plays: int | None = None
    reach: int | None = None
    reactions: int | None = None
    comments: int | None = None
    shares: int | None = None
    clicks: int | None = None
    note: str = ""


# ---------------- 发布前预览：随机链接 + 随机标题 ----------------
class PreviewReq(BaseModel):
    pageIds: list[str]
    reference: str = ""
    titleCount: int = 5
    model: str = ""


@router.post("/videos/preview-captions")
async def preview_captions(req: PreviewReq):
    """给每个主页预览：这次会用哪个链接、哪个标题。

    链接与标题都从池里随机取，且避开最近用过的。
    """
    from app.services import caption
    out = []
    for pid in req.pageIds:
        p = db.q1("SELECT name,asset_id FROM pages WHERE page_id=?", (pid,))
        link = caption.pick_link(pid)
        # 标题：按剧实时生成（不落库），这里只取一条做预览
        drama = ""
        if req.reference:
            drama = req.reference
        r = await caption.generate_for_drama(drama, 1) if drama else {
            "titles": [], "source": "none"}
        one = (r.get("titles") or [""])[0] or req.reference \
            or caption.REFERENCE_TITLE
        out.append({
            "pageId": pid,
            "pageName": (p or {}).get("name") or pid,
            "hasAsset": bool((p or {}).get("asset_id")),
            "link": {"id": link["id"], "label": link["label"],
                     "url": link["url"]} if link else None,
            "title": one,
            "titleSource": r.get("source") or "model",
            "titleId": None,
            "poolSize": 0,          # 标题不再落库
            "linkCount": len([x for x in caption.list_links(pid) if x["enabled"]]),
        })
    return {"items": out, "reference": req.reference or caption.REFERENCE_TITLE}


@router.post("/videos/metrics")
async def set_metrics(req: MetricsReq):
    r = db.q1("SELECT * FROM units WHERE id=?", (req.unitId,))
    if not r:
        raise HTTPException(404, "视频不存在")
    d = req.date or date.today().isoformat()
    cur = db.q1("SELECT * FROM unit_metrics WHERE unit_id=? AND date=?",
                (req.unitId, d)) or {}
    vals = {
        "plays": req.plays if req.plays is not None else cur.get("plays", 0),
        "reach": req.reach if req.reach is not None else cur.get("reach", 0),
        "reactions": req.reactions if req.reactions is not None else cur.get("reactions", 0),
        "comments": req.comments if req.comments is not None else cur.get("comments", 0),
        "shares": req.shares if req.shares is not None else cur.get("shares", 0),
        "clicks": req.clicks if req.clicks is not None else cur.get("clicks", 0),
    }
    db.exec(
        "INSERT INTO unit_metrics(unit_id,date,plays,reach,reactions,comments,shares,"
        "clicks,collected_at,source) VALUES(?,?,?,?,?,?,?,?,?,'manual')"
        " ON CONFLICT(unit_id,date) DO UPDATE SET plays=excluded.plays,"
        " reach=excluded.reach, reactions=excluded.reactions,"
        " comments=excluded.comments, shares=excluded.shares, clicks=excluded.clicks,"
        " collected_at=excluded.collected_at, source='manual'",
        (req.unitId, d, vals["plays"], vals["reach"], vals["reactions"],
         vals["comments"], vals["shares"], vals["clicks"], now_iso()))
    return {"ok": True, "date": d}


# ---------------- 触发采集 ----------------
class CollectReq(BaseModel):
    pageIds: list[str] = []
    envCode: str = ""
    useGraphApi: bool = True
    windowDays: int = 0         # 0=全部；>0 时才限制最近 N 天


# ---------------- Graph Token 自动获取（2026-11-16） ----------------
#
# 用户："我是想用来拿数据的，现在收集视频数据不准还慢"
# 证据：unit_metrics 180 条全是 0，source='suite_table'（页面正则抓空）
# Graph API 才准确，但手动填 token 太麻烦 → 自动从登录态抠出来

class TokenAutoReq(BaseModel):
    envCode: str = ""


@router.get("/videos/graph/status")
async def graph_status():
    """当前 Graph token 状态：有没有、有效期、能读到几个主页。"""
    from app.services import graph_collect as gc
    try:
        return {"ok": True, **gc.token_status()}
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}


@router.get("/videos/graph/steps")
async def graph_steps():
    """手动获取 token 的步骤（自动失败时的兜底）。"""
    from app.services import graph_collect as gc
    try:
        return {"ok": True, "steps": gc.token_steps(),
                "explorerUrl": gc.explorer_url()}
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}


@router.post("/videos/graph/auto-token")
async def graph_auto_token(req: TokenAutoReq):
    """从已登录的浏览器自动获取 Graph token。

    不需要用户去 Graph API Explorer 手点，直接从页面 JS 上下文抠。
    """
    from app.services import graph_collect as gc
    try:
        r = await asyncio.to_thread(gc.auto_fetch_token, req.envCode)
        db.log_event("ok" if r.get("ok") else "warn", "graph",
                     f"自动获取 token: {'成功' if r.get('ok') else r.get('error')}")
        return r
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


@router.post("/videos/graph/refresh-pages")
async def graph_refresh_pages(req: TokenAutoReq):
    """用 user token 换取所有主页的 page token（采集必须用 page token）。"""
    from app.services import graph_collect as gc
    try:
        r = await asyncio.to_thread(gc.refresh_page_tokens, req.envCode)
        return r
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


# ═══════════════════════════════════════════════════════════════════
#  Graph 通道完整接口（2026-11-17 补回）
#
#  背景：本机 app/api/videos.py 曾被旧版本覆盖，导致下面这些接口丢失。
#  服务层 graph_collect.py 里的函数一直完好，这里只是把 HTTP 层补齐。
# ═══════════════════════════════════════════════════════════════════

class GraphTokenReq(BaseModel):
    token: str = ""
    test: bool = True


class GraphAppReq(BaseModel):
    appId: str = ""
    appSecret: str = ""


class GraphCollectReq(BaseModel):
    pageIds: list[str] = []
    windowDays: int = 0
    useBatch: bool = True
    refreshTokens: bool = True


class PageDailyReq(BaseModel):
    pageIds: list[str] = []
    days: int = 30


class AppReq(BaseModel):
    appId: str = ""
    label: str = ""
    appSecret: str = ""
    role: str = "primary"
    note: str = ""


@router.post("/videos/graph/token")
async def graph_set_token(req: GraphTokenReq):
    """保存 User Access Token 并同步主页。

    这是前端「保存并同步主页」按钮调用的接口。
    之前因为文件被旧版覆盖而 404，现在补回。
    """
    from app.services import graph_collect as gc
    tok = (req.token or "").strip()
    if not tok:
        raise HTTPException(400, "token 为空")
    r = gc.save_graph_token(tok)
    db.log_event("ok", "graph", "Graph token 已更新")
    out: dict = {"ok": True, **r}
    if req.test:
        out["test"] = await gc.self_test()
        if out["test"].get("ok"):
            out["sync"] = await gc.sync_page_tokens()
            try:
                db.exec("UPDATE integrations SET state='connected', last_test=?,"
                        " last_error=NULL WHERE id='graph'", (now_iso(),))
            except Exception:
                pass
        else:
            try:
                db.exec("UPDATE integrations SET state='error', last_test=?,"
                        " last_error=? WHERE id='graph'",
                        (now_iso(), str(out["test"].get("error"))[:200]))
            except Exception:
                pass
    return out


@router.post("/videos/graph/sync-pages")
async def graph_sync_pages():
    """只同步主页清单 + 各自主页 token。"""
    from app.services import graph_collect as gc
    return await gc.sync_page_tokens()


@router.get("/videos/graph/test")
async def graph_test():
    """真发一次请求验证 token / 权限 / 指标名。"""
    from app.services import graph_collect as gc
    return await gc.self_test()


@router.get("/videos/graph/diag")
async def graph_diag():
    """诊断令牌：种类、有效期、权限、该做什么。"""
    from app.services import graph_collect as gc
    diag = await gc.token_diag()
    c = gc.app_creds()
    diag["appCreds"] = {"hasAppId": bool(c["appId"]),
                        "hasSecret": bool(c["appSecret"])}
    return diag


@router.post("/videos/graph/app")
async def graph_set_app(req: GraphAppReq):
    """保存应用编号 / 密钥（换长期令牌、核对都用它）。"""
    from app.services import graph_collect as gc
    r = gc.save_app_creds(req.appId, req.appSecret)
    db.log_event("info", "graph", "Graph app 凭据已更新")
    return r


@router.post("/videos/graph/long-lived")
async def graph_long_lived(appId: str = ""):
    """换成 60 天长期用户令牌。

    ⚠ 这只到 60 天，还不是永久。要永久的**主页令牌**用 /graph/permanent。
    """
    from app.services import graph_collect as gc
    r = await gc.upgrade_to_long_lived(appId)
    if r.get("ok"):
        try:
            r["sync"] = await gc.sync_page_tokens(owner_app_id=r.get("appId") or "")
        except Exception as e:
            r["sync"] = {"ok": False, "error": str(e)[:150]}
    return r


@router.post("/videos/graph/permanent")
async def graph_permanent(appId: str = ""):
    """一步拿**永久主页令牌**。

    正确顺序：① 用户令牌 → 60 天长期令牌
              ② 用长期令牌同步主页 → 主页令牌永不过期
              ③ 已是系统用户/永久令牌时直接同步
    """
    from app.services import graph_collect as gc
    return await gc.obtain_permanent_tokens(appId)


@router.get("/videos/graph/probe-business")
async def graph_probe_business():
    """探测有没有 Business Manager（决定能否走系统用户永久令牌）。"""
    from app.services import graph_collect as gc
    return await gc.probe_business()


@router.get("/videos/graph/token-kinds")
async def graph_token_kinds():
    """令牌种类说明 + 各来源链接。"""
    from app.services import graph_collect as gc
    return {
        "kinds": gc.TOKEN_KIND_TEXT,
        "links": {
            "apps": "https://developers.facebook.com/apps/",
            "explorer": gc.explorer_url(),
            "business": "https://business.facebook.com/settings/",
            "systemUsers": "https://business.facebook.com/settings/system-users",
            "tokensDoc": ("https://developers.facebook.com/docs/facebook-login/"
                          "guides/access-tokens/"),
            "pagesTokensDoc": "https://developers.facebook.com/docs/pages/access-tokens/",
        },
        "note": ("主页令牌的有效期跟着「签发它的用户令牌」走。"
                 "长期用户令牌（60 天）派生的主页令牌是永久的；"
                 "探索器短效令牌派生的是短期的。"),
    }


@router.get("/videos/graph/token-steps")
async def graph_token_steps(appId: str = ""):
    """取令牌的标准步骤 —— 全站唯一来源。"""
    from app.services import graph_collect as gc
    label = ""
    if appId:
        r = db.q1("SELECT label FROM fb_apps WHERE app_id=?", (appId,))
        label = (r or {}).get("label") or ""
    steps = gc.token_steps(appId, label)
    return {"steps": steps, "count": len(steps),
            "permissions": gc.TOKEN_PERMISSIONS,
            "explorer": gc.explorer_url(),
            "appId": appId or None, "appLabel": label or None}


@router.post("/videos/graph/collect")
async def graph_collect(req: GraphCollectReq):
    """纯 API 采集：不开浏览器、不需要发布号环境。"""
    from app.services import graph_collect as gc
    if not gc.graph_token() and not db.q1("SELECT 1 FROM fb_page_tokens LIMIT 1"):
        raise HTTPException(
            400, "未配置 Graph token。到「第三方对接 → Meta Graph API」填 User Access Token")
    job_id = "job-" + uuid.uuid4().hex[:12]
    mode = f"纯 API 采集 {len(req.pageIds) or '全部'} 个主页"
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at,started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "metrics",
             mode + (f" · 最近 {req.windowDays} 天" if req.windowDays else " · 全部"),
             "running", 0,
             json.dumps([{"name": "同步 token", "state": "run", "note": ""}],
                        ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False),
             now_iso(), now_iso()))

    async def _bg() -> None:
        try:
            res = await gc.collect_all_api(
                page_ids=req.pageIds or None,
                window_days=req.windowDays, use_batch=req.useBatch,
                refresh_tokens=req.refreshTokens, job_id=job_id)
            ok = res.get("ok", 0)
            db.exec("UPDATE jobs SET status=?,progress=100,result=?,ended_at=? "
                    "WHERE id=?",
                    ("done" if ok else "blocked",
                     json.dumps(res, ensure_ascii=False), now_iso(), job_id))
            db.log_event("ok" if ok else "warn", "graph",
                         f"API 采集：{ok}/{res.get('total',0)} 主页 · "
                         f"{res.get('saved',0)} 条视频")
        except Exception as e:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (str(e)[:400], now_iso(), job_id))
    asyncio.create_task(_bg())
    return {"ok": True, "jobId": job_id, "mode": "graph_api"}


@router.post("/videos/graph/page-daily")
async def graph_page_daily(req: PageDailyReq):
    """主页级每日指标（数据 24h 才更新，别高频跑）。"""
    from app.services import graph_collect as gc
    if not gc.graph_token():
        raise HTTPException(400, "未配置 Graph token")
    job_id = "job-" + uuid.uuid4().hex[:12]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at,started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "insights", f"主页每日指标 · {req.days} 天", "running", 0,
             json.dumps([], ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False),
             now_iso(), now_iso()))

    async def _bg() -> None:
        try:
            res = await gc.collect_page_daily(page_ids=req.pageIds or None,
                                              days=req.days)
            db.exec("UPDATE jobs SET status='done',progress=100,result=?,"
                    "ended_at=? WHERE id=?",
                    (json.dumps(res, ensure_ascii=False), now_iso(), job_id))
        except Exception as e:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (str(e)[:400], now_iso(), job_id))
    asyncio.create_task(_bg())
    return {"ok": True, "jobId": job_id}


# ---------------- 多 App 管理 ----------------
@router.get("/videos/graph/apps")
async def graph_apps():
    """已登记的 App 清单（含各自撑了多少主页）。"""
    from app.services import graph_collect as gc
    return {"items": gc.list_apps(), "blast": gc.blast_radius()}


@router.post("/videos/graph/apps")
async def graph_app_save(req: AppReq):
    """新增/更新一个 App 登记。"""
    from app.services import graph_collect as gc
    r = gc.save_app(req.appId, req.label, req.appSecret, req.role, req.note)
    if r.get("ok"):
        db.log_event("info", "graph",
                     f"App 已登记：{req.label or req.appId}（{req.role}）")
    return r


@router.delete("/videos/graph/apps/{app_id}")
async def graph_app_delete(app_id: str):
    """移除 App 登记（不删主页 token）。"""
    from app.services import graph_collect as gc
    r = gc.delete_app(app_id)
    db.log_event("warn", "graph", f"App 已移除登记：{app_id}")
    return r


@router.post("/videos/graph/apps/{app_id}/check")
async def graph_app_check(app_id: str):
    """验证某个 App 的密钥是否正确。"""
    from app.services import graph_collect as gc
    return await gc.check_app(app_id)


@router.post("/videos/graph/apps/{app_id}/switch")
async def graph_app_switch(app_id: str):
    """把某个 App 设为主用（原主用降级为备用）。"""
    from app.services import graph_collect as gc
    return await gc.switch_to_app(app_id)


@router.get("/videos/graph/apps/{app_id}/guide")
async def graph_app_guide(app_id: str):
    """切换后的分步引导。"""
    from app.services import graph_collect as gc
    return gc.switch_guide(app_id)


@router.get("/videos/graph/blast-radius")
async def graph_blast_radius():
    """爆炸半径：某个 App 挂了会让多少主页停采。"""
    from app.services import graph_collect as gc
    return gc.blast_radius()


@router.post("/videos/graph/detect-app")
async def graph_detect_app():
    """从当前 token 反查属于哪个 App 并自动登记。"""
    from app.services import graph_collect as gc
    return await gc.detect_token_app()


@router.get("/videos/graph/pending-switch")
async def graph_pending_switch():
    """还没完成的切换。"""
    from app.services import graph_collect as gc
    p = gc.pending_switch()
    if not p.get("appId"):
        return {"pending": False}
    return {"pending": True, **p, "guide": gc.switch_guide(p["appId"])}


@router.post("/videos/graph/pending-switch/cancel")
async def graph_pending_cancel():
    """取消未完成的切换标记。"""
    from app.services import graph_collect as gc
    gc.clear_pending_switch()
    db.log_event("info", "graph", "已取消未完成的 App 切换")
    return {"ok": True}


@router.get("/videos/graph/verify-token-app")
async def graph_verify_token_app():
    """用 app token 核对当前 token 属于哪个 App（最可靠）。"""
    from app.services import graph_collect as gc
    tok = gc.graph_token()
    if not tok:
        return {"ok": False, "error": "未配置 token"}
    d = await gc.debug_token_with_app(tok)
    if d.get("_error"):
        return {"ok": False, "error": d["_error"],
                "hint": d.get("_hint") or "填一下应用密钥就能自动核对"}
    app = d.get("application")
    exp = d.get("expires_at") or 0
    left = int(exp - time.time()) if exp else 0
    return {"ok": True, "appId": d.get("app_id"),
            "appName": app.get("name") if isinstance(app, dict) else None,
            "type": d.get("type"), "valid": d.get("is_valid"),
            "scopes": d.get("scopes") or [],
            "expiresAt": exp, "neverExpires": exp == 0,
            "expiresInSec": left, "verifiedViaApp": d.get("_via_app"),
            "userId": d.get("user_id")}


@router.get("/videos/{unit_id}/trend")
async def unit_trend(unit_id: str, metric: str = "fb_reels_total_plays",
                     days: int = 30):
    """单条视频的真实每日新增（累计值差分）。"""
    from app.services import graph_collect as gc
    rows = db.q("SELECT metric, COUNT(*) n FROM metric_snapshots "
                "WHERE unit_id=? GROUP BY metric ORDER BY n DESC", (unit_id,))
    metrics = [r["metric"] for r in rows]
    use = metric if metric in metrics else (metrics[0] if metrics else metric)
    return {"unitId": unit_id, "metric": use, "available": metrics,
            "series": gc.daily_delta(unit_id, use, days)}


@router.post("/videos/collect")
async def collect(req: CollectReq):
    env = None
    if req.envCode:
        env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,))
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "没有运行中的发布号环境，先启动再采集")

    token = ""
    if req.useGraphApi:
        integ = db.q1("SELECT * FROM integrations WHERE id='graph'")
        if integ:
            try:
                token = (json.loads(integ["config"] or "{}")).get("token", "")
            except Exception:
                token = ""

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": f"{len(req.pageIds) or '全部'} 个主页", "state": "wait", "note": ""}]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,"
            "started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "metrics",
             (f"采集最近 {req.windowDays} 天视频数据"
              if req.windowDays else "采集全部视频数据"), "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run(job_id, env, req, token))
    return {"ok": True, "jobId": job_id, "usedGraphApi": bool(token),
            "windowDays": req.windowDays}


async def _run(job_id: str, env: dict, req: CollectReq, token: str) -> None:
    from app.services import metrics as mx
    try:
        res = await mx.collect_all(env["container_code"], int(env["cdp_port"]),
                                   token=token, page_ids=req.pageIds or None,
                                   window_days=req.windowDays)
        status = "blocked" if res["guard"] else ("done" if not res["error"] else "blocked")
        db.exec("UPDATE jobs SET status=?,progress=100,result=?,ended_at=? WHERE id=?",
                (status, json.dumps(res, ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok" if not res["guard"] else "warn", "metrics",
                     f"采集完成 入库 {res['saved']} · 超窗跳过 {res['skippedOutWindow']} "
                     f"· guard={res['guard']} · err={res['error']}")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "metrics", str(e)[:200])


# ---------------- 标签（替代剧名） ----------------
class TagReq(BaseModel):
    unitId: str
    tags: list[str]


@router.post("/videos/tags")
async def set_tags(req: TagReq):
    db.exec("UPDATE units SET tags=? WHERE id=?",
            (json.dumps(req.tags, ensure_ascii=False), req.unitId))
    return {"ok": True}

# -*- coding: utf-8 -*-
"""
mcp_server.py — 把工作台暴露成 MCP 服务，让外部 Agent 直接操作

设计（按 MCP 2.x 规范 + 2026-07-28 最佳实践）：
  ① stateless：状态不挂连接，长任务用 job_id handle
  ② 工具名 snake_case，1-128 字符
  ③ inputSchema 用 JSON Schema
  ④ 失败返回 isError + 可操作消息
  ⑤ 工具列表静态，不随连接变化

挂载方式（main.py）：
    from app.mcp_server import mcp
    app.mount("/mcp", mcp.streamable_http_app())

外部 agent 连接：
    {"mcpServers": {"yuhai": {"url": "http://127.0.0.1:PORT/mcp",
                              "transport": "streamable-http"}}}
"""
from __future__ import annotations

import json
import logging
import os

from mcp.server.mcpserver import MCPServer
import time

log = logging.getLogger("yuhai.mcp")

mcp = MCPServer(
    name="yuhai-workbench",
    title="雨海工作台",
    description="短剧运营工作台：抓取、切片、发布、数据分析",
    instructions=(
        "这是短剧运营工作台。常用流程：\n"
        "1. slice_env_check 先看环境是否就绪\n"
        "2. slice_list_dramas 看有哪些剧可切\n"
        "3. slice_run 开始切片（返回 job_id）\n"
        "4. slice_status(job_id) 查进度\n"
        "5. slice_result 拿成片列表\n"
        "\n"
        "【短剧下载（推荐）】多站点下载：\n"
        "  dl_sites 看有哪些站点 →\n"
        "  dl_search(site, keyword) 搜剧拿 slug →\n"
        "  dl_check(site, slug) 看详情和 freeEps 免费集 →\n"
        "  dl_download_eps(site, slug, eps) 下载拿 task_id →\n"
        "  dl_task(task_id) 查进度 →\n"
        "  dl_library 列已下载 → dl_send_to_slice(site, dir) 送去切片\n"
        "  站点：pinedrama / dramabox / moboreels / goodshort / tiktok / tiktok_drama\n"
        "  TikTok：dl_tiktok_meta(id) 查信息，dl_tiktok_download(id) 下载\n"
        "\n"
        "【TK短剧（TikTok 内的短剧板块）】\n"
        "  ID 来自地址 tiktok.com/shortdrama/episode/<ID>/1\n"
        "  dl_sd_meta(id) 查详情 → dl_sd_batch([id1,id2,...]) 批量查\n"
        "  dl_sd_history() 看查过哪些（避免重复）\n"
        "  dl_sd_browser('start'|'stop'|'status'|'login') 管调试浏览器\n"
        "\n"
        "  ⚠ 下载前提：必须在 Chrome 里登录 TikTok，否则接口不下发 playAddr。\n"
        "    先调 dl_sd_login() 确认 loggedIn=true，再下载。\n"
        "    没登录就 dl_sd_browser(action='login') 开窗，让用户手动登录。\n"
        "\n"
        "  ⚠ 下载要用剧自己的 ID，不是自己猜的：\n"
        "    dl_check(site='tiktok_drama', slug=<剧ID>) 看 total 和免费集\n"
        "    dl_download_eps(site='tiktok_drama', slug=<剧ID>, eps=[1,2,3])\n"
        "    然后 dl_task_detail(task_id) 逐集确认 state/duration，\n"
        "    不要只看 ok 计数 —— 时长和接口声明差太多就是下错了。\n"
        "\n"
        "⚠ 下载/抓取只用 dl_* 系列。旧版 grab_* 已停用，不要调用。\n"
        "\n"
        "【发布全流程（必须遵守）】\n"
        "  1. 发布前先调 publish_sync_pages() 提取在线账号的最新主页 PID，\n"
        "     看清当前账号有多少主页、有没有新加的主页（不要漏发新主页！）。\n"
        "     默认 autoStart=false，绝不擅自频繁启动/重启浏览器消耗 HubStudio 次数。\n"
        "  2. 调 publish_sources() 看可发素材数（已去重）与可发主页（已自动排除死号）。\n"
        "  3. 用 publish_preview / publish_now（默认 4 行模板）发布；\n"
        "     失败单用 publish_retry_failed，取消用 publish_cancel_order 或 publish_stop_all（软停不杀浏览器）。\n"
        "\n"
        "【指纹浏览器与死号处理（一环境一账号）】\n"
        "  · 账号被封/死了 → 调 env_mark_dead(code, reason, handoverToEnv=...) 一步标死号 + 暂停主页 + 可选交接主页给存活环境\n"
        "  · 同环境换登新账号 → 调 env_rebind_account(code) 清旧绑定后登新号再提取\n"
        "  · 迁移主页/创建环境/改代理/分组 → env_migrate / env_create / env_set_proxy / env_set_group\n"
        "\n"
        "【全站接管能力】\n"
        "  你已掌控工作台全部功能：下载(dl_*)、切片(slice_*)、视频微调(video_*)、素材库(library_*)、\n"
        "  发布(publish_*)、排期(schedule_*)、指纹浏览器(env_*)、主页与授权(page_*/authz_*/account_*)、\n"
        "  风控(guard_*)、评论维护(comment_*)、视频数据(data_*)、全自动总控(auto_*)、\n"
        "  邮箱验证码(mail_*)、系统设置与进程(system_*)；如有小众接口可用 workbench_api 调用本机 /api/*。\n"
        "记忆：memory_set / memory_get 记住跨会话状态\n"
        "\n"
        "════════ 强制行为规范（必须遵守）════════\n"
        "\n"
        "【一】参数不确定时，绝不能自己填默认值\n"
        "  调任何工具前，如果用户没说清「数量 / 目标 / 模式」，\n"
        "  工具会返回 { needsChoice: true, question: ..., options: [...] }。\n"
        "  这时你**必须**：\n"
        "    ① 把 question 原样问用户\n"
        "    ② 把 options 渲染成选项框/按钮让用户点（不要自己挑一个）\n"
        "    ③ allowCustom=true 时额外提供「自定义」入口\n"
        "    ④ 等用户明确回答后，用他选的值重新调用工具\n"
        "  典型例子：\n"
        "    · 用户说「发一下视频」→ 不能直接发 1 条，要先问：\n"
        "      发哪些主页？每个主页几条？怎么排期？素材怎么分配？\n"
        "    · 用户说「切一下这个剧」→ 要先问：每集多长？出单集还是含主线？\n"
        "  只有用户明确说「你决定 / 随便 / 都行」时，才可以用 defaultHint。\n"
        "\n"
        "【二】执行中要随时用自然语言说明正在做什么\n"
        "  不要只显示「调用 publish_now」。要像人一样说：\n"
        "    ✓ 「正在检查素材（12 个主页 × 5 条）」\n"
        "    ✓ 「正在发布 Y03 第 2/5 条」\n"
        "    ✓ 「正在切片 我的帥T室友 第 3/8 集」\n"
        "    ✗ 「执行工具 publish_now({...})」\n"
        "  已经完成的事可以合并成一行，**正在进行的事必须准确**。\n"
        "\n"
        "【三】任务结束后给用户一份简洁报告\n"
        "  工具返回里通常带 report 字段（已经是人话），直接用它，不要自己重编。\n"
        "  报告格式：一句话结论 + 关键数字 + 失败明细（如有）。\n"
        "  例：\n"
        "    「全部发布成功：110 条视频，成功 110 条」\n"
        "    「部分成功：110 条，成功 105 条，失败 5 条\n"
        "      失败明细：\n"
        "        · Y03：排期控件无法识别\n"
        "        · Z01：页面操作超时」\n"
        "  不要贴原始 JSON，不要罗列成功项。"
    ),
    version="1.0.0",
)


def _ok(**kw):
    return {"ok": True, **kw}


def _err(msg: str, **kw):
    return {"ok": False, "error": msg, **kw}


# ═══════════════════════════════════════════════
#  「不确定就问用户」守卫（2026-11-16）
#
#  用户原话：
#    "用户发的要求不详细不应该选择默认操作，应该先告诉用户让用户选择
#     详细的数量，比如创建主页发布这种 agent 都不知道发多少条还发，
#     到时候用户又不满意。把这些不确定的用选项框方式让用户选择或者自定义，
#     不要让模型盲猜。包括全部功能不确定的都要让用户选择。"
#
#  设计：
#    · 关键参数（数量/目标/模式）不给默认值，缺失就返回 needsChoice
#    · needsChoice 里带 options（选项框）+ allowCustom（可自定义）
#    · agent 必须把这些呈现给用户，用户选完再带着答案重调
#    · 这样模型永远不会"以为 1 条就行"就发出去
# ═══════════════════════════════════════════════

def _need(field: str, question: str, options: list[dict],
          allow_custom: bool = True, default_hint: str = "",
          extra: dict | None = None) -> dict:
    """返回"请用户选择"的响应。

    field    参数名（agent 拿到答案后回填这个参数）
    question 要问用户的话（直接可以念给用户听）
    options  [{label, value, desc}]，前端会渲染成选项框
    """
    return {
        "ok": False,
        "needsChoice": True,
        "field": field,
        "question": question,
        "options": options,
        "allowCustom": allow_custom,
        "defaultHint": default_hint,
        # 明确告诉 agent 该怎么做，避免它自己编一个值
        "instruction": (
            f"不要自己猜 {field}。把 question 和 options 原样呈现给用户"
            f"（用选项框/按钮），等用户明确选择或自定义输入后，"
            f"再把选中的值作为 {field} 重新调用本工具。"
            + (f" 若用户说「随便/你定」，才可以用 defaultHint 里的值：{default_hint}"
               if default_hint else "")
        ),
        **(extra or {}),
    }


def _need_multi(fields: list[dict]) -> dict:
    """一次问多个参数（多个不确定项一起让用户选）。"""
    return {
        "ok": False,
        "needsChoice": True,
        "fields": fields,
        "instruction": (
            "以下参数不确定，**一次性全部问用户**，不要分批问也不要自己猜。"
            "把每个 question + options 呈现给用户（选项框），"
            "用户全部选完后带着完整参数重新调用本工具。"
        ),
        "questions": [{"field": f["field"], "question": f["question"],
                       "options": f["options"],
                       "allowCustom": f.get("allowCustom", True)}
                      for f in fields],
    }


# 常用选项集（复用，保证说法一致）
OPT_CLIPS = [
    {"label": "1 条", "value": 1, "desc": "每个主页只发 1 条"},
    {"label": "3 条", "value": 3, "desc": "每个主页发 3 条"},
    {"label": "5 条", "value": 5, "desc": "每个主页发 5 条（推荐）"},
    {"label": "10 条", "value": 10, "desc": "每个主页发 10 条"},
]

OPT_SPACING = [
    {"label": "全部立即发", "value": 0, "desc": "不排期，连着发出去"},
    {"label": "间隔 30 分钟", "value": 30, "desc": "第 1 条立即，之后每 30 分钟一条"},
    {"label": "间隔 1 小时", "value": 60, "desc": "错峰更自然"},
    {"label": "间隔 2 小时", "value": 120, "desc": "长间隔，铺一整天"},
]

OPT_ALLOC = [
    {"label": "全库混发", "value": "merge",
     "desc": "每个主页都发不同的剧，随机分配"},
    {"label": "按剧绑定", "value": "per_drama",
     "desc": "只发在「主页与授权」里绑定了的剧"},
]


# ═══════════════════════════════════════════════
#  自然语言进度播报（2026-11-16）
#
#  用户原话：
#    "调用工具用户看不懂，用自然语言代替，比如调用发布工具就显示
#     '正在发布某主页'，一定是要准确的正在做的事。做完的可以隐藏，
#     但是现在正在做的事一定要准确和简单明了。"
#
#  做法：
#    · 每个长任务在**开始前**把一句人话写进 jobs 表（stage 字段）
#    · 前端/agent 轮询就能看到"正在发布 Y03 第 2/5 条"这种描述
#    · 完成后的记录标 done，前端可折叠
# ═══════════════════════════════════════════════

_PROGRESS_ID: list[str] = [""]


def _say(text: str, *, job_id: str = "", progress: int = -1) -> None:
    """写一句人话进度到 jobs.steps（同时打日志）。

    ⚠ jobs 表没有 stage 列，只有 steps(JSON) / progress / title。
       把当前正在做的事写进 steps[0]，前端和 agent 都能读到。
    """
    import json as _json
    try:
        from app.db import db
        jid = job_id or (_PROGRESS_ID[0] if _PROGRESS_ID else "")
        if jid:
            step = [{"name": str(text)[:200], "state": "run", "note": ""}]
            if progress >= 0:
                db.exec("UPDATE jobs SET steps=?, progress=? WHERE id=?",
                        (_json.dumps(step, ensure_ascii=False),
                         int(progress), jid))
            else:
                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                        (_json.dumps(step, ensure_ascii=False), jid))
        log.info("[progress] %s", text)
    except Exception:
        try:
            log.info("[progress] %s", text)
        except Exception:
            pass


def _progress_job(title: str) -> str:
    """新建一条进度 job，返回 job_id。完成后调 _finish_job。"""
    import uuid
    from app.db import db, now_iso
    jid = "job-" + uuid.uuid4().hex[:12]
    try:
        db.exec(
            "INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at,started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (jid, "progress", title, "running", 0, "[]", "{}",
             now_iso(), now_iso()))
        _PROGRESS_ID[0] = jid
    except Exception:
        pass
    return jid


def _finish_job(job_id: str, ok: bool = True, note: str = "") -> None:
    import json as _json
    from app.db import db, now_iso
    try:
        step = [{"name": note[:200], "state": "done" if ok else "fail",
                 "note": ""}]
        db.exec("UPDATE jobs SET status=?, progress=100, steps=?, ended_at=? "
                "WHERE id=?",
                ("done" if ok else "failed",
                 _json.dumps(step, ensure_ascii=False), now_iso(), job_id))
    except Exception:
        pass
    if _PROGRESS_ID and _PROGRESS_ID[0] == job_id:
        _PROGRESS_ID[0] = ""


# ═══════════════════════════════════════════════
#  素材库铁律（2026-11-16 加入，随每个相关工具一起返回）
#
#  用户原话："怎么 agent 不知道里面的要求，素材库需要整理成发布要求"
#  —— agent 切完片就报告"完成"，但没管素材库要求的目录结构和入库状态。
#  把规则写成常量，在工具返回值里带上，agent 每次调用都能看到。
# ═══════════════════════════════════════════════

MATERIAL_RULE = (
    "素材库铁律（不遵守则无法发布）：\n"
    "1. 切片产物默认在「处理好素材」，**不能直接发布**，必须先整理入库。\n"
    "2. 素材库标准结构：<素材库根>/<剧名>/<剧名>_EP01.mp4（或 <剧名>_主线.mp4）。\n"
    "3. 整理 = 把文件搬进素材库并按剧名建目录 + 文件名规范化，"
    "同时写库记录（library.organized=1）。\n"
    "4. 未整理（organized=0）的素材发布时会被过滤，前端显示「可发 0 条」。\n"
    "5. 用 library_organize(ids=[], lang='keep', dryRun=false) 执行整理；\n"
    "   先 library_organize_plan() 预览要搬哪些、改什么名。\n"
    "6. 整理完用 library_audit() 体检：文件缺失/重复/文件名不规范/时长过短。"
)


def _eps_of(vids) -> list[int]:
    """从文件名里抽集号。支持 EP01 / -01 / _01 / 01.mp4 等写法。"""
    import re as _re
    eps: set[int] = set()
    for f in vids:
        stem = f.stem
        # 优先 EPxx / epxx
        m = _re.search(r"[Ee][Pp]?\s*(\d{1,4})", stem)
        if m:
            eps.add(int(m.group(1)))
            continue
        # 形如 剧名-01 / 剧名_01 / 剧名 01
        hits = _re.findall(r"(\d{1,4})", stem)
        if hits:
            # 取最后一组（避开剧名里的数字）
            eps.add(int(hits[-1]))
    return sorted(eps)


# ═══════════════════════════════════════════════
#  切片
# ═══════════════════════════════════════════════
@mcp.tool(description="环境自检：Python包/FFmpeg/ASR模型/脚本/GPU/代理")
def slice_env_check() -> dict:
    from app.services import envcheck
    r = envcheck.full_check()
    return _ok(
        ready=r["ok"],
        python_ok=all(p["ok"] for p in r["python"] if p["required"]),
        ffmpeg=r["ffmpeg"]["ok"],
        nvenc=r["ffmpeg"].get("nvenc"),
        model={"ok": r["model"]["ok"], "name": r["model"]["name"],
               "sizeMb": r["model"].get("sizeMb")},
        tools={"ok": r["tools"]["ok"],
               "stale": len(r["tools"].get("stale") or [])},
        gpu={"name": r["gpu"].get("name"), "cuda": r["gpu"].get("cuda")},
        warnings=r["warnings"],
        fixable=[f["what"] for f in (r.get("fixable") or [])],
    )


@mcp.tool(description="修环境。what: all|python|ffmpeg|whisper|tools|cuda")
def slice_env_install(what: str = "all") -> dict:
    from app.services import envcheck
    r = envcheck.install_one(what)
    return _ok(what=what, ok=r.get("ok"),
               note=r.get("note") or r.get("error") or "")


@mcp.tool(description="列出所有短剧及处理状态（哪些能切、切到哪一步）")
def slice_list_dramas() -> dict:
    from app.services import slicing as sl
    items = sl.list_dramas()
    out = []
    for d in items:
        st = d.get("steps") or {}
        out.append({
            "drama": d["drama"],
            "title": d.get("title"),
            "sourceEpisodes": d.get("sourceEpisodes") or 0,
            "hasSource": d.get("hasSource"),
            "state": d.get("state"),
            "transcribed": bool((st.get("transcribe") or {}).get("done")),
            "segments": (st.get("transcribe") or {}).get("segments") or 0,
            "type": (st.get("classify") or {}).get("typeName") or "",
            "tensionSegs": (st.get("tension") or {}).get("segments") or 0,
            "singles": (st.get("single") or {}).get("count") or 0,
            "premiums": (st.get("premium") or {}).get("count") or 0,
        })
    return _ok(count=len(out), items=out)


@mcp.tool(description=(
    "开始切片。mode: auto（智能，自动补齐前置步骤，推荐）|"
    "full（完整流水线）|transcribe|voice|classify|tension|"
    "single|premium|all。返回 job_id，用 slice_status 查进度"))
def slice_run(drama: str, mode: str = "auto", eps: str = "",
              target: int = 0, model: str = "", quality: str = "") -> dict:
    """切片。

    ⚠ 2026-11-16（用户："不确定的都要让用户选择，不要让模型盲猜"）：
        target（每集目标秒数）和 quality（成片质量档）都不给默认值。
          target  默认 0  = 未指定 → 必须问用户
          quality 默认 "" = 未指定 → 必须问用户
        model 保持 small 默认（只是转录精度，不影响用户对结果满意度）。
    """
    from app.services import slicing as sl
    import uuid

    # ── 关键参数守卫 ──
    missing: list[dict] = []
    if not target or int(target) <= 0:
        missing.append({
            "field": "target",
            "question": "每集切成多长？（秒）",
            "options": [
                {"label": "30 秒", "value": 30, "desc": "短平快，适合强钩子"},
                {"label": "45 秒", "value": 45, "desc": "Reels 常用长度"},
                {"label": "60 秒", "value": 60, "desc": "内容完整，完播率略低"},
                {"label": "90 秒", "value": 90, "desc": "长内容，适合剧情铺垫"},
            ],
            "allowCustom": True,
            "defaultHint": "45",
        })
    if not quality:
        missing.append({
            "field": "quality",
            "question": "成片质量档位？",
            "options": [
                {"label": "单集（快速）", "value": "single",
                 "desc": "只切单集，不出主线混剪"},
                {"label": "单集 + 主线版", "value": "single_main",
                 "desc": "额外生成一条主线混剪"},
                {"label": "全部（含精品）", "value": "all",
                 "desc": "单集 + 主线 + 精品混剪，耗时最长"},
            ],
            "allowCustom": False,
            "defaultHint": "single_main",
        })
    if missing:
        return _need_multi(missing)

    model = (model or "small").strip()      # 转录精度，不影响成片质量
    eps_list = [e.strip() for e in eps.split(",") if e.strip()] if eps else None

    try:
        # ── auto：检查缺哪步就补哪步 ──
        if mode == "auto":
            _st = sl.drama_status(drama)
            st = _st.get("steps") or _st      # 状态在 steps 里
            result = {}
            ran = []

            if not (st.get("transcribe") or {}).get("done"):
                result["transcribe"] = sl.step_transcribe(job_id, drama, model=model)
                ran.append("转录")
            if not (st.get("voice") or {}).get("done"):
                result["voice"] = sl.step_voice(job_id, drama)
                ran.append("语音")
            if not (st.get("classify") or {}).get("done"):
                cr = sl.step_classify(job_id, drama)
                result["classify"] = cr
                # 类型判定失败不阻塞出片（台词太少/小语种都会失败）
                ran.append("分类" if cr.get("ok") else "分类(跳过-不影响出片)")
            if not (st.get("tension") or {}).get("done"):
                result["tension"] = sl.step_tension(job_id, drama)
                ran.append("张力")

            result["single"] = sl.step_single(job_id, drama, eps_list, target)
            result["premium"] = sl.step_premium(job_id, drama)
            ran += ["单集", "精品"]

            return _ok(job_id=job_id, drama=drama, mode="auto",
                       stepsRun=ran, result=result,
                       hint="用 slice_status 查详情，slice_result 看成片")

        # ── 单步 ──
        if mode == "transcribe":
            return _ok(job_id=job_id, drama=drama,
                       result=sl.step_transcribe(job_id, drama, model=model))
        if mode == "voice":
            return _ok(job_id=job_id, drama=drama,
                       result=sl.step_voice(job_id, drama))
        if mode == "classify":
            return _ok(job_id=job_id, drama=drama,
                       result=sl.step_classify(job_id, drama))
        if mode == "tension":
            return _ok(job_id=job_id, drama=drama,
                       result=sl.step_tension(job_id, drama))

        # ── full：硬跑全流程 ──
        if mode == "full":
            result = {}
            result["transcribe"] = sl.step_transcribe(job_id, drama, model=model)
            result["voice"] = sl.step_voice(job_id, drama)
            result["classify"] = sl.step_classify(job_id, drama)
            result["tension"] = sl.step_tension(job_id, drama)
            result["single"] = sl.step_single(job_id, drama, eps_list, target)
            result["premium"] = sl.step_premium(job_id, drama)
            return _ok(job_id=job_id, drama=drama, mode="full", result=result)

        # ── 出片（要求已有台词本，缺了明确报错）──
        result = {}
        if mode in ("single", "all"):
            tr = sl.read_transcript(drama)
            if not tr:
                return _err(
                    "缺少台词本，无法出片。请用 mode='auto' 自动补转录，"
                    "或先调 slice_run(mode='transcribe')",
                    drama=drama, missing="transcript")
            result["single"] = sl.step_single(job_id, drama, eps_list, target)
        if mode in ("premium", "all"):
            result["premium"] = sl.step_premium(job_id, drama)
        return _ok(job_id=job_id, drama=drama, mode=mode, result=result,
                   hint=f"用 slice_status('{job_id}') 查详情")
    except Exception as e:
        import traceback
        return _err(f"切片失败: {str(e)[:200]}", drama=drama,
                    trace=traceback.format_exc()[-400:])


@mcp.tool(description="查 job 进度")
def slice_status(job_id: str) -> dict:
    from app.db import db
    r = db.q1("SELECT * FROM jobs WHERE id=?", (job_id,))
    if not r:
        return _err(f"没有这个 job: {job_id}", available_hint="用 slice_run 创建")
    return _ok(
        id=r["id"], kind=r.get("kind"), status=r.get("status"),
        progress=r.get("progress"),
        steps=json.loads(r.get("steps") or "[]"),
        result=json.loads(r.get("result") or "{}") if r.get("result") else {},
        error=r.get("error") or "",
    )


@mcp.tool(description="列出成片（单集/精品）")
def slice_result(drama: str = "") -> dict:
    from app import paths
    out = []
    base = paths.output_root()

    # ⚠ 2026-11-16 修（用户："怎么 agent 不知道里面的要求素材库需要整理成发布要求"）：
    #   原来只扫 单集_*/<剧名>/*.mp4 这种两层结构。
    #   但切片脚本实际可能把**单集直接写在 output_root 根目录**：
    #       处理好素材\我的帥T室友_EP01.mp4
    #       处理好素材\精品混剪_2026-11-16\我的帥T室友\我的帥T室友_主线版.mp4
    #   根目录那些扫不到 → agent 报告"成片 0 条"，用户看到文件却查不到。
    #   现在两种位置都扫。

    # ① 标准两层：单集_2026-11-08/<剧名>/xxx.mp4
    for pat in ("单集_*", "精品混剪_*"):
        for d in base.glob(pat):
            if not d.is_dir():
                continue
            for sub in d.iterdir():
                if not sub.is_dir():
                    continue
                if drama and drama.lower() not in sub.name.lower():
                    continue
                vids = [f for f in sub.glob("*.mp4")]
                if not vids:
                    continue
                out.append({
                    "kind": "single" if "单集" in pat else "premium",
                    "drama": sub.name,
                    "date": d.name.split("_")[-1],
                    "count": len(vids),
                    "location": str(sub),
                    "files": [{"name": f.name,
                               "mb": round(f.stat().st_size / 1048576, 1)}
                              for f in vids[:20]],
                })

    # ② 根目录散落（切片脚本把单集写在外面）
    root_vids = [f for f in base.glob("*.mp4") if f.is_file()]
    if root_vids:
        by_drama: dict[str, list] = {}
        for f in root_vids:
            if drama and drama.lower() not in f.name.lower():
                continue
            # 文件名形如 <剧名>_EP01.mp4 / <剧名>_主线版.mp4
            stem = f.stem
            name = stem
            for sep in ("_EP", "_主线", "_ep", "_Main"):
                if sep in stem:
                    name = stem.split(sep)[0]
                    break
            by_drama.setdefault(name, []).append(f)
        for name, vids in by_drama.items():
            out.append({
                "kind": "single",
                "drama": name,
                "date": "",
                "count": len(vids),
                "location": str(base),
                "note": "⚠ 直接放在成片根目录，必须整理进素材库才能发布",
                "files": [{"name": f.name,
                           "mb": round(f.stat().st_size / 1048576, 1)}
                          for f in sorted(vids)[:20]],
            })

    return _ok(count=len(out), items=out,
               materialRule=(MATERIAL_RULE if "MATERIAL_RULE" in globals()
                             else ""))


@mcp.tool(description="校验成片：台词完整/无重叠/无静音")
def slice_verify(video_path: str) -> dict:
    from app.services import slicing as sl
    try:
        return _ok(**sl.verify_output(video_path))
    except Exception as e:
        return _err(f"校验失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  素材库（2026-11-16 新增）
#
#  用户原话："怎么 agent 不知道里面的要求，素材库需要整理成发布要求"
#  —— 之前 agent 只能调 slice_* 和 dl_*，完全没有素材库工具，
#     所以切完片就结束，不知道还要整理入库才能发布。
# ═══════════════════════════════════════════════

@mcp.tool(description="查看素材库标准与当前状态：目录结构、可发/未整理条数、铁律")
def library_rule() -> dict:
    """素材库规则 + 现状。agent 动手前先调这个。"""
    from app import paths
    from app.db import db
    try:
        total = db.q1("SELECT COUNT(*) AS n FROM library")["n"]
        ready = db.q1(
            "SELECT COUNT(*) AS n FROM library "
            "WHERE state='ready' AND organized=1")["n"]
        unorganized = db.q1(
            "SELECT COUNT(*) AS n FROM library WHERE IFNULL(organized,0)=0")["n"]
        used = db.q1("SELECT COUNT(*) AS n FROM library WHERE state='used'")["n"]
    except Exception:
        total = ready = unorganized = used = 0

    # 成片目录里有没有还没入库的文件
    pending = []
    try:
        base = paths.output_root()
        for f in base.glob("*.mp4"):
            if f.is_file():
                pending.append(f.name)
        for d in base.glob("*"):
            if d.is_dir() and any(d.glob("*.mp4")):
                pending.append(f"{d.name}/")
    except Exception:
        pass

    return _ok(
        rule=MATERIAL_RULE,
        paths={
            "素材库（发布用）": str(paths.library_root()),
            "处理好素材（成片）": str(paths.output_root()),
            "原始素材（下载）": str(paths.source_root()),
        },
        library={"total": total, "ready": ready, "used": used,
                 "unorganized": unorganized},
        pendingInOutput=pending[:20],
        pendingCount=len(pending),
        nextStep=("先 library_organize_plan() 预览，再 library_organize() 执行"
                  if unorganized or pending else "素材已就绪，可以发布"),
    )


@mcp.tool(description="扫描成片目录并入库（把「处理好素材」的文件登记进素材库）")
def library_scan(dryRun: bool = False) -> dict:
    """扫描成片目录，把新文件加进 library 表。

    ⚠ 只登记记录，不搬文件。要搬进素材库用 library_organize。
    """
    import asyncio
    from app.api import library as lib_api
    try:
        # scan() 是 async，这里同步跑
        r = asyncio.run(lib_api.scan(None))
        return _ok(rule=MATERIAL_RULE, **(r if isinstance(r, dict) else {}))
    except Exception as e:
        return _err(f"扫描失败: {str(e)[:150]}")


@mcp.tool(description="预览整理计划：哪些素材要搬进素材库、改成什么名")
def library_organize_plan(mode: str = "keep", ids: str = "") -> dict:
    """mode: keep|zh|en（剧名语言），ids: 逗号分隔的库 id（空=全部）"""
    from app.api import organize as og
    try:
        id_list = [x.strip() for x in (ids or "").split(",") if x.strip()]
        plans = og.build_plan(id_list, mode=mode)
        moves = [p for p in plans if not p.skip]
        skips = [p for p in plans if p.skip]
        return _ok(
            rule=MATERIAL_RULE,
            total=len(plans), willMove=len(moves), willSkip=len(skips),
            preview=[{
                "from": p.file_old, "to": p.file_new,
                "drama": f"{p.drama_old} → {p.drama_new}"
                         if p.drama_old != p.drama_new else p.drama_new,
                "reason": p.reason or "",
            } for p in moves[:30]],
            skipped=[{"file": p.file_old, "reason": p.reason}
                     for p in skips[:10]],
        )
    except Exception as e:
        return _err(f"生成计划失败: {str(e)[:150]}")


@mcp.tool(description="执行整理：把素材搬进素材库标准目录并规范化文件名")
def library_organize(mode: str = "keep", ids: str = "", dryRun: bool = False) -> dict:
    """真搬文件。dryRun=true 只算不动。"""
    import asyncio
    from app.api import organize as og
    try:
        id_list = [x.strip() for x in (ids or "").split(",") if x.strip()]
        req = og.OrganizeReq(ids=id_list, lang=mode, dryRun=dryRun)
        r = asyncio.run(og.organize_run(req))
        return _ok(rule=MATERIAL_RULE,
                   **(r if isinstance(r, dict) else {"result": r}))
    except Exception as e:
        return _err(f"整理失败: {str(e)[:150]}")


@mcp.tool(description="素材库体检：文件缺失/重复/文件名不规范/时长过短")
def library_audit() -> dict:
    import asyncio
    from app.api import library as lib_api
    try:
        r = asyncio.run(lib_api.audit())
        return _ok(rule=MATERIAL_RULE, **(r if isinstance(r, dict) else {}))
    except Exception as e:
        return _err(f"体检失败: {str(e)[:150]}")


@mcp.tool(description="查已下载的短剧记录（判断哪些下过、下到第几集）")
def dl_grabbed(site: str = "") -> dict:
    """已下载记录。⚠ 2026-11-16 修正：按实际目录扫描，不只看数据库。

    用户原话："短剧下载它把下过的也下了一遍，你知道那些没下过那些下过了吗"
    —— 根因：grab_records 表记录的是历史路径（D:\\素材），
       目录早就不在了，但表里还留着，导致查不到"其实已经下过"。
       现在以**实际磁盘目录**为准：扫原始素材目录下的剧文件夹，
       数出每部剧有几集，同时对照数据库记录。
    """
    import json as _json
    from pathlib import Path
    from app import paths
    from app.db import db

    # ⚠ 2026-11-16 修（用户："短剧下载它把下过的也下了一遍"）：
    #   根因有两层：
    #     ① grab_records 记的是历史路径（D:\素材），目录早没了 → 查不到"下过"
    #     ② dl.out_root() 指向「视频素材」，但实际片子下到了
    #        「素材库\原始素材」→ 扫错目录，永远扫出 0 部
    #   现在把所有可能的下载目录都扫一遍，合并结果。
    roots: list[Path] = []
    for cand in (paths.source_root(), paths.library_root() / "原始素材",
                 paths.video_root() if hasattr(paths, "video_root") else None):
        if cand and Path(cand).is_dir() and Path(cand) not in roots:
            roots.append(Path(cand))
    try:
        from app.services import dl as _dl
        r0 = _dl.out_root()
        if r0 and Path(r0).is_dir() and Path(r0) not in roots:
            roots.append(Path(r0))
    except Exception:
        pass

    on_disk = {}
    for root in roots:
        try:
            for d in Path(root).iterdir():
                if not d.is_dir():
                    continue
                # 跳过容器目录（里面还有一层剧）
                sub_dirs = [x for x in d.iterdir() if x.is_dir()]
                vids = [f for f in d.glob("*.mp4") if f.is_file()]
                if not vids and sub_dirs:
                    # 这是容器（如「短剧下载」），进去再扫一层
                    for sd in sub_dirs:
                        sv = [f for f in sd.glob("*.mp4") if f.is_file()]
                        if sv:
                            on_disk[f"{d.name}/{sd.name}"] = {
                                "dir": str(sd), "count": len(sv),
                                "episodes": _eps_of(sv),
                            }
                    continue
                if not vids:
                    continue
                on_disk[d.name] = {
                    "dir": str(d), "count": len(vids),
                    "episodes": _eps_of(vids),
                }
        except Exception:
            continue

    db_records = []
    try:
        for r in db.q("SELECT cid, title, episodes, total_eps, dir, grabbed_at "
                      "FROM grab_records ORDER BY grabbed_at DESC"):
            eps = []
            try:
                eps = _json.loads(r["episodes"] or "[]")
            except Exception:
                pass
            exists = bool(r["dir"]) and Path(r["dir"]).is_dir()
            db_records.append({
                "cid": r["cid"], "title": r["title"],
                "episodes": eps, "total": r["total_eps"],
                "dir": r["dir"], "dirExists": exists,
                "grabbedAt": r["grabbed_at"],
            })
    except Exception:
        pass

    # 数据库记录里目录失效的（应该清理，否则会误判"没下过"）
    stale = [x for x in db_records if not x["dirExists"]]

    return _ok(
        sourceRoot=" | ".join(str(r) for r in roots),
        scannedRoots=[str(r) for r in roots],
        downloaded=on_disk,
        downloadedCount=len(on_disk),
        dbRecords=db_records,
        staleRecords=len(stale),
        warning=(f"{len(stale)} 条数据库记录指向的目录已不存在，"
                 f"下载去重会误判成「没下过」。用 dl_grabbed_fix() 修正"
                 if stale else ""),
    )


@mcp.tool(description="修正下载记录：把失效路径改成实际目录，避免重复下载")
def dl_grabbed_fix() -> dict:
    """扫描实际目录，重建 grab_records 的 dir 字段。

    ⚠ 这是"下过的又下一遍"的根治：数据库记录的路径失效后，
       去重逻辑查不到，就会重新下。
    """
    import json as _json
    from pathlib import Path
    from app import paths
    from app.db import db, now_iso

    # 与 dl_grabbed 用同一套根目录（2026-11-16）
    roots: list[Path] = []
    for cand in (paths.source_root(), paths.library_root() / "原始素材"):
        if cand and Path(cand).is_dir() and Path(cand) not in roots:
            roots.append(Path(cand))
    try:
        from app.services import dl as _dl
        r0 = _dl.out_root()
        if r0 and Path(r0).is_dir() and Path(r0) not in roots:
            roots.append(Path(r0))
    except Exception:
        pass

    # 汇总所有剧目录（容器目录往下钻一层）
    found: dict[str, Path] = {}
    for root in roots:
        try:
            for d in Path(root).iterdir():
                if not d.is_dir():
                    continue
                vids = [f for f in d.glob("*.mp4") if f.is_file()]
                if vids:
                    found.setdefault(d.name, d)
                    continue
                for sd in (x for x in d.iterdir() if x.is_dir()):
                    if any(sd.glob("*.mp4")):
                        found.setdefault(sd.name, sd)
        except Exception:
            continue

    fixed = 0
    added = 0
    try:
        # ① 修正已有记录：路径失效的，按剧名重新定位
        for r in db.q("SELECT cid, title, dir FROM grab_records"):
            old = Path(r["dir"] or "")
            if old.is_dir() and any(old.glob("*.mp4")):
                continue
            title = (r["title"] or "").strip()
            hit = found.get(title)
            if not hit:
                for name, p in found.items():
                    if title and (title in name or name in title):
                        hit = p
                        break
            if hit:
                vids = [f for f in hit.glob("*.mp4") if f.is_file()]
                db.exec(
                    "UPDATE grab_records SET dir=?, episodes=?, grabbed_at=? "
                    "WHERE cid=?",
                    (str(hit), _json.dumps(_eps_of(vids)),
                     now_iso(), r["cid"]))
                fixed += 1

        # ② 目录里有但数据库没记录的，补进去
        known_titles = {r["title"] for r in db.q("SELECT title FROM grab_records")}
        for name, p in found.items():
            if name in known_titles:
                continue
            vids = [f for f in p.glob("*.mp4") if f.is_file()]
            if not vids:
                continue
            cid = ""
            if "_" in name:
                tail = name.rsplit("_", 1)[-1]
                if tail.isdigit():
                    cid = tail
            db.exec(
                "INSERT OR IGNORE INTO grab_records"
                "(cid,title,episodes,total_eps,dir,grabbed_at,attempts) "
                "VALUES(?,?,?,?,?,?,?)",
                (cid or name, name, _json.dumps(_eps_of(vids)),
                 len(vids), str(p), now_iso(), 1))
            added += 1
    except Exception as e:
        return _err(f"修正失败: {str(e)[:150]}")

    return _ok(fixed=fixed, added=added, scanned=len(found),
               note=f"扫描 {len(found)} 个剧目录，修正 {fixed} 条失效路径，"
                    f"补充 {added} 条缺记录")


@mcp.tool(description="检查软件更新：当前版本、远程最新版、是否需要更新")
def system_update_check() -> dict:
    """查版本。⚠ 2026-11-16 加（用户："软件更新是不是没和 agent 同步"）。

    原来 agent 完全查不到版本信息，因为远程源只存在前端 localStorage。
    现在后端有默认源，agent 直接调这个就知道要不要更新。
    """
    import urllib.request
    import json as _json
    from app.config import settings
    from app.services import updater as up

    cur = str(settings.VERSION or "")
    out = {"current": cur, "remote": up.DEFAULT_REMOTE_MANIFEST}
    try:
        man = None
        try:
            req = urllib.request.Request(
                up.DEFAULT_REMOTE_MANIFEST + "?_t=" + str(int(__import__("time").time())),
                headers={"User-Agent": "yuhai-updater",
                         "Cache-Control": "no-cache"})
            with urllib.request.urlopen(req, timeout=12) as r:
                man = _json.loads(r.read().decode("utf-8"))
        except Exception as e:
            out["fetchError"] = str(e)[:120]

        if man:
            latest = str(man.get("version") or "")
            out["latest"] = latest
            out["sizeMb"] = man.get("sizeMb")
            out["packageUrl"] = man.get("url") or ""
            # 简单版本比较：逐段数字
            def _v(s):
                return [int(x) for x in str(s).replace("-", ".").split(".")
                        if x.isdigit()]
            try:
                out["hasUpdate"] = _v(latest) > _v(cur)
            except Exception:
                out["hasUpdate"] = latest != cur
            if out.get("hasUpdate"):
                out["nextStep"] = ("前端「设置→系统更新→检查更新→应用更新」，"
                                   "或调 system_update_apply()")
        else:
            out["hasUpdate"] = False
    except Exception as e:
        return _err(f"检查失败: {str(e)[:150]}")
    return _ok(**out)


@mcp.tool(description="一键更新到最新版（下载+应用+重启），phase=check|apply")
def system_update_apply(phase: str = "check") -> dict:
    """phase=check 只查；phase=apply 真更新（会重启软件）。"""
    import asyncio
    if phase == "check":
        return system_update_check()
    try:
        from app.api import update as upd_api
        r = asyncio.run(upd_api.auto_update(restart=True, remote=""))
        return _ok(**(r if isinstance(r, dict) else {"result": str(r)}))
    except Exception as e:
        return _err(f"更新失败: {str(e)[:150]}")


# ═══════════════════════════════════════════════
#  旧版抓取工具（已停用）
# ═══════════════════════════════════════════════
# 这两条工具已从 MCP 隐藏，避免 Agent 误用旧的 PineDrama 抓取链路。
# 替代方案：dl_sites → dl_search → dl_check → dl_download_eps
#
# 如需临时恢复（调试用）：
#     set YUHAI_ENABLE_LEGACY_GRAB=1
# 恢复后 grab_search / grab_download 会重新出现在工具列表里。
# 默认开启：用户要求把全部功能暴露给 agent，不再隐藏任何工具。
# 想临时关闭：set YUHAI_ENABLE_LEGACY_GRAB=0
_LEGACY_GRAB = os.getenv("YUHAI_ENABLE_LEGACY_GRAB", "1").strip() not in (
    "0", "false", "no", "")

if _LEGACY_GRAB:
    @mcp.tool(description="[旧版] 搜剧（PineDrama），返回剧名/集数/cid。"
                          "新流程请用 dl_search")
    def grab_search(keyword: str, limit: int = 15) -> dict:
        from app.services import grab as g
        try:
            r = g.search(keyword) if hasattr(g, "search") else {}
            if not r:
                r = g.hot_list() if hasattr(g, "hot_list") else {}
            items = (r.get("items") or r.get("collections") or [])[:limit]
            return _ok(keyword=keyword, count=len(items), items=items)
        except Exception as e:
            return _err(f"搜索失败: {str(e)[:100]}")

    @mcp.tool(description="[旧版] 下载剧集。cid 来自 grab_search；eps 如 '1-10'。"
                          "新流程请用 dl_download_eps")
    def grab_download(cid: str, eps: str = "1-10") -> dict:
        from app.services import grab as g
        try:
            r = g.download(cid, eps) if hasattr(g, "download") else {}
            return _ok(cid=cid, result=r)
        except Exception as e:
            return _err(f"下载失败: {str(e)[:100]}")
else:
    log.info("legacy grab MCP tools disabled (set YUHAI_ENABLE_LEGACY_GRAB=1 to enable)")


# ═══════════════════════════════════════════════
#  短剧下载（多站点）—— 与「短剧下载」页面同一套后端
# ═══════════════════════════════════════════════
@mcp.tool(description=(
    "列可用下载站点。返回 id（pinedrama/dramabox/moboreels/goodshort/"
    "tiktok/tiktok_drama）和名称"))
def dl_sites() -> dict:
    from app.services import dl
    try:
        items = [{"id": k, "name": v["name"]} for k, v in dl.SITES.items()]
        items.append({"id": "tiktok", "name": "TikTok"})
        items.append({"id": "tiktok_drama", "name": "TK短剧"})
        return _ok(count=len(items), items=items, root=str(dl.out_root()))
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "在多站点里搜剧。site 见 dl_sites；keyword 为空则返回该站全部目录。"
    "返回 slug 列表（后续传给 dl_check / dl_download_eps）"))
def dl_search(site: str = "pinedrama", keyword: str = "", limit: int = 20) -> dict:
    from app.services import dl
    try:
        r = dl.search(site, keyword, limit)
        return _ok(site=site, keyword=keyword, total=r["total"], slugs=r["slugs"])
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "查一部剧的详情：剧名/总集数/免费集/封面/简介。"
    "site + slug（slug 来自 dl_search）。返回 freeEps 是可直接下载的集号"))
def dl_check(site: str, slug: str) -> dict:
    from app.services import dl
    try:
        # TK短剧走 sd_drama，其它走 fetch_meta
        if site == "tiktok_drama":
            m = dl.sd_drama(slug)
        elif site == "tiktok":
            vid = dl.tk_id_from(slug)
            m = dl.tk_meta(vid) if vid else {}
            if not m:
                return _err("没识别到 TikTok 作品 ID")
        else:
            m = dl.fetch_meta(site, slug)

        eps = m.get("eps") or []
        free = [e["ep"] for e in eps if e.get("free")]
        # TK短剧额外给出时长信息，方便判断片子长短
        durs = {}
        if site == "tiktok_drama":
            for e in eps:
                if e.get("duration"):
                    durs[str(e["ep"])] = int(e["duration"])
        return _ok(site=site, slug=slug, name=m.get("name"),
                   total=m.get("total"), freeEps=free,
                   freeCount=len(free), rating=m.get("rating"),
                   desc=(m.get("desc") or "")[:240],
                   cover=m.get("cover"), folder=m.get("folder") or "",
                   durations=durs or None,
                   degraded=bool(m.get("degraded")))
    except Exception as e:
        return _err(str(e)[:200])


@mcp.tool(description=(
    "按集下载。site + slug（来自 dl_search/dl_check）+ eps 列表如 [1,2,3]。"
    "会自动跳过本地已有的集（force=true 强制重下）。"
    "返回 task_id，用 dl_task 查进度"))
def dl_download_eps(site: str, slug: str, eps: list[int] = [],
                    lang: str = "en", force: bool = False) -> dict:
    from app.services import dl, dlq
    try:
        eps = sorted({int(x) for x in eps if int(x) > 0})
        if not eps:
            return _err("eps 不能为空，例如 [1,2,3]")

        # 按站点取元数据
        if site == "tiktok_drama":
            m = dl.sd_drama(slug)
        else:
            m = dl.fetch_meta(site, slug)

        name = m.get("name") or slug

        # ⚠ 2026-11-16 加去重（用户："短剧下载它把下过的也下了一遍，
        #  你知道哪些没下过哪些下过了吗"）
        #  原来直接把用户给的 eps 全丢给下载队列，完全不看本地。
        #  现在先扫磁盘：已经存在且文件够大的集直接跳过。
        already: list[int] = []
        todo: list[int] = list(eps)
        if not force:
            try:
                root = dl.out_root()
                # 该剧的目录（可能带 cid 后缀，模糊匹配）
                cands = [d for d in root.glob("*")
                         if d.is_dir() and (d.name == name
                                            or d.name.startswith(name)
                                            or name in d.name)]
                if cands:
                    vids = []
                    for d in cands:
                        vids.extend(d.glob("*.mp4"))
                    existing_eps = set()
                    for f in vids:
                        if f.stat().st_size < 100 * 1024:
                            continue
                        for tok in f.stem.replace("-", "_").split("_"):
                            if tok.isdigit():
                                existing_eps.add(int(tok))
                                break
                        # 形如 剧名-01.mp4
                        import re as _re
                        hit = _re.findall(r"[-_](\d+)", f.stem)
                        if hit:
                            existing_eps.add(int(hit[-1]))
                    already = sorted(set(eps) & existing_eps)
                    todo = [e for e in eps if e not in existing_eps]
            except Exception as e:
                log.warning("本地去重检查失败（继续全下）: %s", e)

        if not todo:
            return _ok(skipped=len(already), alreadyHad=already,
                       downloaded=0, task_id=None,
                       note=f"这 {len(already)} 集本地已经有，无需重复下载。"
                            f"要强制重下用 force=true")

        t = dlq.new_task(site, slug, name,
                         m.get("cover") or "", todo, lang)
        dlq.submit(t)
        return _ok(task_id=t["id"], site=site, slug=slug,
                   name=name, count=len(todo),
                   skipped=len(already), alreadyHad=already,
                   downloading=todo,
                   hint=("TK短剧下载较慢，每集约 30-60 秒；"
                         "用 dl_task_detail(task_id) 逐集确认时长是否正确")
                        if site == "tiktok_drama" else None)
    except Exception as e:
        return _err(str(e)[:200])


@mcp.tool(description=(
    "查下载任务进度。task_id 留空则返回全部任务。"
    "注意：顶层 ok 是「调用成功」，items[].ok 是「该任务成功的集数」，别搞混；"
    "要逐集看真实时长/大小请用 dl_task_detail"))
def dl_task(task_id: int = 0) -> dict:
    from app.services import dlq
    try:
        items = dlq.snapshot()
        if task_id:
            items = [x for x in items if x["id"] == int(task_id)]
            if not items:
                return _err(f"任务 {task_id} 不存在")
        return _ok(count=len(items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description="列本地已下载的短剧（含站点/集数/大小/目录）")
def dl_library() -> dict:
    from app.services import dl
    try:
        items = dl.scan_local()
        return _ok(series=len(items), files=sum(i["count"] for i in items),
                   bytes=sum(i["bytes"] for i in items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "把已下载的剧送去切片（硬链接到源素材根，切片页可直接选）。"
    "site + dir（dir 来自 dl_library）"))
def dl_send_to_slice(site: str, dir: str) -> dict:
    from app.services import dl
    try:
        r = dl.send_to_slice(site, dir)
        return _ok(**r)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "TikTok 作品元数据。id 可以是作品 ID 或整条链接。"
    "返回作者/播放/点赞/评论/分享/时长/直链数"))
def dl_tiktok_meta(id: str) -> dict:
    from app.services import dl
    try:
        vid = dl.tk_id_from(id)
        if not vid:
            return _err("没识别到作品 ID（需要 15–25 位数字）")
        m = dl.tk_meta(vid)
        return _ok(id=vid, author=(m.get("author") or {}).get("uniqueId"),
                   desc=(m.get("desc") or "")[:160],
                   duration=m.get("duration"), stats=m.get("stats"),
                   web_url=m.get("web_url"), cover=m.get("cover"))
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description="下载 TikTok 作品（走 yt-dlp）。id 为作品 ID 或链接，返回 task_id")
def dl_tiktok_download(id: str) -> dict:
    from app.services import dl, dlq
    try:
        vid = dl.tk_id_from(id)
        if not vid:
            return _err("没识别到作品 ID")
        m = dl.tk_meta(vid)
        t = dlq.new_task("tiktok", vid, (m.get("desc") or vid)[:60],
                         m.get("cover") or "", [1], "")
        t["web_url"] = m.get("web_url")
        dlq.submit(t)
        return _ok(task_id=t["id"], vid=vid, url=m.get("web_url"))
    except Exception as e:
        return _err(str(e)[:140])


# ═══════════════════════════════════════════════
#  TK短剧（shortdrama）—— 需要本机 Chrome 调试端口
# ═══════════════════════════════════════════════
@mcp.tool(description=(
    "查 TikTok 短剧详情。id 是 tiktok.com/shortdrama/episode/<ID>/1 里的 ID。"
    "返回剧名/总集数/观看量/分集数。浏览器没开会自动拉起（无头，不弹窗）"))
def dl_sd_meta(id: str) -> dict:
    from app.services import dl
    try:
        m = dl.sd_drama(id)
        return _ok(id=m.get("id"), name=m.get("name"), total=m.get("total"),
                   watched=m.get("watched"), eps=len(m.get("eps") or []),
                   author=(m.get("author") or {}).get("uniqueId"),
                   degraded=bool(m.get("degraded")),
                   cover=m.get("cover") or "")
    except Exception as e:
        return _err(str(e)[:300])


@mcp.tool(description=(
    "批量查 TikTok 短剧。ids 是 ID 列表（最多 50 个）。"
    "串行+节流避免风控；每部最多 90 秒，超时自动跳过不影响其它。"
    "大批量（>5 部）会先返回 jobId，后台继续跑，可用 dl_sd_batch_status 查进度"))
def dl_sd_batch(ids: list[str]) -> dict:
    from app.services import dl
    try:
        ids = [str(x).strip() for x in (ids or []) if str(x).strip()]
        if not ids:
            return _err("ids 不能为空")
        ids = ids[:50]

        # 少量（<=5）直接同步跑，结果立即返回
        if len(ids) <= 5:
            r = dl.sd_batch(ids, timeout_each=90.0)
            return _ok(total=r["total"], ok=r["ok"],
                       elapsed=r.get("elapsed"), items=r["items"])

        # 大批量：起后台线程，立即返回 jobId，避免 agent 长时间无响应
        import threading
        import uuid as _uuid
        job_id = "sdb-" + _uuid.uuid4().hex[:10]
        _SD_BATCH_JOBS[job_id] = {
            "jobId": job_id, "status": "running", "total": len(ids),
            "done": 0, "ok": 0, "items": [], "startedAt": time.time(),
        }

        def _bg():
            st = _SD_BATCH_JOBS[job_id]

            def _prog(i, total, did, result):
                st["done"] = i
                st["total"] = total
                st["items"].append(result)
                if result.get("ok"):
                    st["ok"] += 1

            try:
                r = dl.sd_batch(ids, timeout_each=90.0, on_progress=_prog)
                st["status"] = "done"
                st["ok"] = r.get("ok", st["ok"])
                st["elapsed"] = r.get("elapsed")
            except Exception as e:
                st["status"] = "failed"
                st["error"] = str(e)[:200]
            finally:
                st["endedAt"] = time.time()

        threading.Thread(target=_bg, daemon=True,
                         name="sdbatch-" + job_id).start()
        return _ok(
            jobId=job_id, total=len(ids), status="running",
            hint=("已在后台开始，共 %d 部，每部最多 90 秒。"
                  "用 dl_sd_batch_status(jobId) 查进度，"
                  "别重复提交同一批。" % len(ids)))
    except Exception as e:
        return _err(str(e)[:200])


@mcp.tool(description=(
    "判断短剧是不是百合(GL/女女)。传剧名+介绍文本，用当前模型判定。"
    "返回 isGL / confidence / reason。批量时传 items=[{name,desc}]，"
    "最多 30 条，一次调用搞定"))
def drama_gl_check(name: str = "", desc: str = "",
                   items: list[dict] = []) -> dict:
    """用模型判断剧集是否为百合(GL)。"""
    from app.services import agent_chat as ac

    def _judge_one(nm: str, ds: str) -> dict:
        prompt = (
            "判断下面这部短剧是不是百合(GL/女女恋爱)。\n\n"
            "剧名：%s\n介绍：%s\n\n"
            "判定规则：\n"
            "- GL：两个女性之间的恋爱关系是主线\n"
            "- BG：男女恋爱（哪怕女主戏份重、男性出场少，也是BG）\n"
            "- 注意：女主复仇/宅斗/真假千金/雌竞 都不是百合\n"
            "- 注意：只有一名女性主角、男性角色少，也不等于百合\n"
            "- 不确定就回答 unclear，不要猜\n\n"
            "只输出一行 JSON，不要解释：\n"
            '{"verdict":"GL|BG|unclear","confidence":0.0-1.0,'
            '"reason":"20字内依据"}'
            % (nm[:120], (ds or "")[:600])
        )
        try:
            pk = ac.pick_model()
            if not pk.get("ok"):
                return {"ok": False, "error": "无可用模型"}
            r = ac._post_chat(pk["endpoint"], pk["model"],
                              [{"role": "user", "content": prompt}],
                              None, pk.get("apiKey", ""))
            if not r.get("ok"):
                return {"ok": False, "error": str(r.get("error"))[:100]}
            rep = ac._parse_reply(r["data"], "11434" in pk["endpoint"])
            txt = (rep.get("content") or "").strip()
            # 抠 JSON
            import re as _re
            m = _re.search(r"\{.*\}", txt, _re.S)
            if m:
                try:
                    j = json.loads(m.group(0))
                    return {"ok": True, **j}
                except Exception:
                    pass
            return {"ok": True, "verdict": "unclear", "confidence": 0.0,
                    "reason": txt[:60]}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, str(e)[:80])}

    # 批量模式
    if items:
        out = []
        gl_list = []
        for it in items[:30]:
            nm = (it.get("name") or "").strip()
            ds = (it.get("desc") or "").strip()
            cid = (it.get("id") or "").strip()
            if not nm:
                continue
            j = _judge_one(nm, ds)
            item = {"id": cid, "name": nm,
                    "verdict": j.get("verdict") or "unclear",
                    "confidence": j.get("confidence") or 0,
                    "reason": j.get("reason") or j.get("error") or ""}
            out.append(item)
            if item["verdict"] == "GL":
                gl_list.append(item)
        return _ok(checked=len(out), glCount=len(gl_list),
                   gl=gl_list, all=out)

    # 单条模式
    if not name:
        return _err("name 不能为空（或传 items 批量）")
    j = _judge_one(name, desc)
    return _ok(name=name, **j)


@mcp.tool(description=(
    "创建任务清单。接到多步骤任务时**必须先调这个**，把要做的事拆成条目。"
    "之后每完成一项调 task_done。全部打勾前不允许结束任务。"
    "例：items=['下载3部百合剧各6集','切片','确认成片','发布到Y03']"))
def task_create(items: list[str] = [], planId: str = "") -> dict:
    from app.services import task_plan as tp
    if not items:
        return _err("items 不能为空")
    r = tp.create(items, planId)
    return _ok(**r, hint="记住 planId，完成每项后调 task_done")


@mcp.tool(description=(
    "标记任务项完成。seq=第几项（从1开始），或 keyword=标题关键词。"
    "note 写完成说明（如'出片6集'）"))
def task_done(planId: str, seq: int = 0, keyword: str = "",
              note: str = "") -> dict:
    from app.services import task_plan as tp
    if not planId:
        return _err("planId 不能为空")
    r = tp.done(planId, seq=seq, keyword=keyword, note=note)
    if not r.get("ok"):
        return _err(r.get("error") or "标记失败")
    # 顺便返回进度
    st = tp.status(planId)
    return _ok(**r, progress="%d/%d" % (st["done"], st["total"]),
               allDone=st["allDone"], pending=st["pending"],
               nextPending=st["nextPending"])


@mcp.tool(description="查任务清单进度：哪些做完了、还剩什么")
def task_status(planId: str = "") -> dict:
    from app.services import task_plan as tp
    if not planId:
        r = tp.latest_plan()
        if not r.get("ok"):
            return _err("没有进行中的计划")
        return _ok(**r)
    return _ok(**tp.status(planId))


@mcp.tool(description="清除任务清单（任务彻底结束或放弃时用）")
def task_clear(planId: str) -> dict:
    from app.services import task_plan as tp
    if not planId:
        return _err("planId 不能为空")
    return _ok(**tp.clear(planId))


@mcp.tool(description=(
    "查下载台账：哪些剧下过、下过多少集、多少集还在磁盘上。"
    "发布后删掉的集也记着（state=deleted），不会重复下载"))
def dl_ledger_list() -> dict:
    from app.services import dl_ledger as ledger
    rows = ledger.list_dramas()
    st = ledger.stats()
    return _ok(count=len(rows), stats=st, dramas=rows)


@mcp.tool(description=(
    "查某部剧的下载台账：哪些集下过、哪些还在、哪些被删了。"
    "下之前用它确认，避免重复下载"))
def dl_ledger_of(tkId: str) -> dict:
    from app.services import dl_ledger as ledger
    tid = str(tkId or "").strip()
    if not tid:
        return _err("tkId 不能为空")
    recs = ledger.get_done(tid)
    alive, deleted = [], []
    for ep, r in sorted(recs.items()):
        if r["state"] == "done":
            alive.append(ep)
        else:
            deleted.append(ep)
    return _ok(
        tkId=tid, totalRecorded=len(recs),
        alive=alive, deleted=deleted,
        details={str(k): v for k, v in sorted(recs.items())})


@mcp.tool(description=(
    "把磁盘上已有的下载补进台账（首次启用台账、或台账丢了时用）。"
    "dirs 不传则扫所有已知下载目录"))
def dl_ledger_sync(tkIds: list[str] = [], dirs: list[str] = []) -> dict:
    from app.services import dl_ledger as ledger
    from app.services import dl
    from pathlib import Path as _P

    scan = dirs or []
    if not scan:
        try:
            scan.append(str(dl.slice_target_root()))
        except Exception:
            pass
        try:
            scan.append(str(dl.out_root()))
        except Exception:
            pass
        from app import paths
        scan.append(str(_P(paths.DATA_DIR) / "tk_downloads"))
        scan.append(r"E:\tmp\gl_test")

    ids = [str(x).strip() for x in (tkIds or []) if str(x).strip()]
    if not ids:
        return _err("tkIds 不能为空（要同步哪些剧）")

    out = []
    total = 0
    for tid in ids[:50]:
        try:
            r = ledger.sync_from_disk(tid, scan)
            out.append(r)
            total += r.get("synced") or 0
        except Exception as e:
            out.append({"tkId": tid, "error": str(e)[:80]})

    return _ok(totalSynced=total, scannedDirs=scan, items=out)


@mcp.tool(description=(
    "从剧库里筛出指定类型的剧。rel: GL(百合)/BG(男女)/BL(男男)/none/unclear。"
    "genre: 按官方题材标签过滤（如 Sismance/Werewolf/Mafia/Vampire）。"
    "用于「给我找 N 部百合剧」这类需求，直接从已扫好的 1089 部库里查，秒回"))
def drama_find(rel: str = "", genre: str = "", limit: int = 50) -> dict:
    """按关系类型/题材从剧库筛选。"""
    from app.db import db

    sql = "SELECT tk_id, name, rel, confidence, genres, reason FROM drama_genre WHERE 1=1"
    params = []

    if rel:
        sql += " AND rel=?"
        params.append(rel.strip().upper())

    if genre:
        # genres 存在为 JSON 数组字符串，例如 ["Werewolf", "City"]
        # 用 LIKE '%"Werewolf"%' 精确匹配单个标签（注意引号）
        g = genre.strip()
        sql += " AND genres LIKE ?"
        params.append('%"' + g + '"%')

    sql += " ORDER BY confidence DESC LIMIT ?"
    params.append(min(int(limit or 50), 500))

    try:
        rows = db.q(sql, tuple(params))
    except Exception as e:
        # 附带 SQL 和参数，便于定位
        import traceback
        return _err(
            "查询失败: %s: %s" % (type(e).__name__, str(e)[:150]),
            sql=sql, params=[str(p) for p in params],
            trace=traceback.format_exc()[-400:])

    import json as _j
    items = []
    for r in rows:
        try:
            g = _j.loads(r["genres"] or "[]")
        except Exception:
            g = []
        items.append({
            "tkId": r["tk_id"], "name": r["name"], "rel": r["rel"],
            "confidence": r["confidence"], "genres": g,
        })

    return _ok(count=len(items), rel=rel or "全部",
               genre=genre or "全部", items=items)


@mcp.tool(description="查剧库统计：各关系类型有多少部、有哪些题材标签")
def drama_stats() -> dict:
    from app.db import db
    import json as _j
    from collections import Counter

    rows = db.q("SELECT rel, genres FROM drama_genre")
    rel_c = Counter()
    genre_c = Counter()
    for r in rows:
        rel_c[r["rel"]] += 1
        try:
            for g in _j.loads(r["genres"] or "[]"):
                genre_c[str(g)] += 1
        except Exception:
            pass

    return _ok(
        total=len(rows),
        byRel=dict(rel_c),
        topGenres=[{"genre": g, "count": n}
                   for g, n in genre_c.most_common(30)],
    )


@mcp.tool(description=(
    "判断短剧的情感主线类型（GL女女/BG男女/BL男男/none无/none无感情线）。"
    "tkId=剧集id。会自动从 TK 拉真实剧情简介再判断，准确度高。"
    "返回 rel/confidence/genres(题材标签)/lead(主角是谁)/reason。"
    "单部直接传 tkId；批量传 tkIds 列表（最多50）"))
def drama_genre_check(tkId: str = "", tkIds: list[str] = [],
                      useCache: bool = True) -> dict:
    """判断短剧是不是百合，并提取题材标签。"""
    from app.services import drama_genre as dg

    ids = []
    if tkId:
        ids.append(str(tkId).strip())
    for x in (tkIds or []):
        s = str(x).strip()
        if s and s not in ids:
            ids.append(s)
    if not ids:
        return _err("tkId 或 tkIds 不能为空")

    ids = ids[:50]
    out = []
    gl = []
    for tid in ids:
        r = dg.classify_one("", "", "", tid, use_cache=useCache,
                            fetch_meta=True)
        out.append(r)
        if r.get("rel") == "GL" and (r.get("confidence") or 0) >= 0.6:
            gl.append(r)

    if len(ids) == 1:
        return _ok(**out[0])
    return _ok(checked=len(out), glCount=len(gl), gl=gl, all=out)


@mcp.tool(description="查剧型识别统计（已判多少部、各类型分布）")
def drama_genre_stats() -> dict:
    from app.services import drama_genre as dg
    return _ok(**dg.stats())

@mcp.tool(description=(
    "下载 TikTok 短剧的指定集（本地无片源时用这个）。"
    "tkId=剧集id(collection_id，19位数字)；eps=集号列表如[1,2,3]；"
    "dest=保存目录(可选，默认库目录)。返回每集下载结果与文件路径。"
    "⚠ 这是唯一能从 TK id 直接下片的入口，不要用 dl_check/dl_tiktok_download"))
def dl_tk_eps(tkId: str, eps: list[int] = [], dest: str = "",
              force: bool = False) -> dict:
    """按 TK collection_id 下载指定集。

    台账机制：下载前先查 dl_ledger，
      已下过且文件在 → 跳过
      已下过但文件被删 → 默认也跳过（避免重复下载），
                        要重下请传 force=True
    """
    import subprocess as _sp
    import os as _os
    from pathlib import Path as _P
    from app.services import dl
    from app.services import dl_ledger as ledger

    tid = str(tkId or "").strip()
    if not tid:
        return _err("tkId 不能为空")
    nums = sorted({int(x) for x in (eps or []) if int(x) > 0})
    if not nums:
        return _err("eps 不能为空，例如 [1,2,3]")

    try:
        exe = dl.py_exe()
    except Exception as e:
        return _err("找不到 Python: " + str(e)[:120])

    script = _P(__file__).resolve().parent / "tk_ep_download.py"
    if not script.exists():
        return _err("找不到下载脚本: " + str(script))

    # 目录：优先用户指定；否则直接落到「切片能识别的源素材根」
    # ⚠ 关键：切片只扫 source_roots() 下的目录，下到别处等于白下
    if dest:
        base = _P(dest)
    else:
        try:
            root = dl.slice_target_root()      # 切片真正读的目录
            # 用剧名做目录名（切片按目录名建剧），拿不到剧名就用 id
            title = ""
            try:
                _m = dl.sd_drama(tid)
                title = (_m.get("name") or "").strip()
            except Exception:
                pass
            dirname = ("%s_%s" % (title[:40], tid)) if title else tid
            # 去掉 Windows 非法字符
            for ch in '<>:"/\\|?*':
                dirname = dirname.replace(ch, "_")
            base = _P(root) / dirname
        except Exception:
            from app import paths
            base = _P(paths.DATA_DIR) / "tk_downloads" / tid
    base.mkdir(parents=True, exist_ok=True)

    # 拿剧名（写台账用）
    drama_name = ""
    try:
        _mm = dl.sd_drama(tid)
        drama_name = (_mm.get("name") or "").strip()
    except Exception:
        pass

    # ⭐ 台账判断：哪些要下、哪些跳过
    plan = ledger.plan_eps(tid, nums[:30], force=force, check_file=True)
    to_download = plan["toDownload"]
    skip_list = plan["skipped"]

    results = []
    ok_n = 0

    # 先记跳过的
    for ep in skip_list:
        rec = ledger.get_done(tid).get(int(ep)) or {}
        results.append({
            "ep": ep, "ok": True, "skipped": plan["details"].get(ep, "已下载过"),
            "bytes": rec.get("size") or 0,
            "path": rec.get("path") or "",
        })
        ok_n += 1

    for ep in to_download:
        try:
            pr = _sp.run(
                [exe, str(script), tid, str(ep), str(out)],
                capture_output=True, text=True, timeout=300,
                encoding="utf-8", errors="replace",
                creationflags=(0x08000000 if _os.name == "nt" else 0))
            raw = (pr.stdout or "").strip()
            line = raw.splitlines()[-1] if raw else ""
            try:
                j = json.loads(line)
            except Exception:
                j = {}
            good = bool(j.get("ok")) and out.exists()
            if good:
                ok_n += 1
                # ⭐ 写台账
                try:
                    ledger.mark_done(
                        tid, ep,
                        size=j.get("bytes") or (out.stat().st_size if out.exists() else 0),
                        duration=float(j.get("duration") or 0),
                        path=str(out) if out.exists() else "",
                        dramaname=drama_name)
                except Exception:
                    pass
            results.append({
                "ep": ep, "ok": good,
                "bytes": j.get("bytes") or (out.stat().st_size if out.exists() else 0),
                "path": str(out) if out.exists() else "",
                "err": (j.get("err") or "")[:150] or
                       ("" if good else (pr.stderr or "")[:150]),
            })
        except _sp.TimeoutExpired:
            results.append({"ep": ep, "ok": False, "err": "超时(300s)"})
        except Exception as e:
            results.append({"ep": ep, "ok": False,
                            "error": "%s: %s" % (type(e).__name__, str(e)[:120])})

    return _ok(
        tkId=tid, dramaname=drama_name,
        requested=len(nums), success=ok_n,
        downloaded=len(to_download), skippedAlready=len(skip_list),
        destDir=str(base), items=results,
        plan=plan["details"],
        hint=("下载 %d 集 / 跳过 %d 集（已下过），文件在 %s"
              % (len(to_download), len(skip_list), base)))


# 批量查询任务状态表（内存，进程内有效）
_SD_BATCH_JOBS: dict = {}


@mcp.tool(description="查批量短剧查询任务的进度。jobId 从 dl_sd_batch 返回")
def dl_sd_batch_status(jobId: str = "") -> dict:
    if not jobId:
        # 没传就返回全部
        items = []
        for jid, st in _SD_BATCH_JOBS.items():
            items.append({
                "jobId": jid, "status": st.get("status"),
                "done": st.get("done"), "total": st.get("total"),
                "ok": st.get("ok"),
                "elapsed": round((st.get("endedAt") or time.time())
                                 - st.get("startedAt", 0), 1),
            })
        return _ok(count=len(items), jobs=items)

    st = _SD_BATCH_JOBS.get(jobId)
    if not st:
        return _err("找不到任务: " + jobId)
    return _ok(
        jobId=jobId, status=st.get("status"),
        done=st.get("done"), total=st.get("total"), ok=st.get("ok"),
        elapsed=round((st.get("endedAt") or time.time())
                      - st.get("startedAt", 0), 1),
        items=st.get("items") or [],
        error=st.get("error"))


@mcp.tool(description=(
    "查已搜过的 TikTok 短剧历史（本地保留最近 300 条，含剧名/集数/观看量）。"
    "可以用来避免重复查询，或找回之前查过的剧"))
def dl_sd_history(limit: int = 50) -> dict:
    from app.services import dl
    try:
        items = dl.sd_history()[:limit]
        return _ok(count=len(items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "管理 TK短剧用的调试浏览器。action: status|start|stop|login。"
    "headless=true 时不显示窗口；stop 会彻底关闭释放内存"))
def dl_sd_browser(action: str = "status", headless: bool = True) -> dict:
    try:
        from app.services import tk_browser
        a = (action or "status").lower()
        if a == "start":
            r = tk_browser.start(headless=headless)
            return _ok(**r)
        if a == "stop":
            r = tk_browser.stop()
            return _ok(**r)
        if a == "login":
            # 开有头窗口让用户手动登录（下载必须登录才有 playAddr）
            r = tk_browser.start(headless=False)
            return _ok(**r, hint="Chrome 已打开，请让用户手动登录 TikTok，"
                                 "登录后调 action=verify 确认")
        if a in ("verify", "check"):
            return _sd_login_check()
        return _ok(**tk_browser.status())
    except Exception as e:
        return _err(str(e)[:200])


def _sd_login_check() -> dict:
    """检查调试浏览器里 TikTok 是否已登录（决定能否下载）"""
    try:
        from playwright.sync_api import sync_playwright
        from app.services import tk_browser
        if not tk_browser.cdp_alive():
            return _err("调试浏览器没启动，先 dl_sd_browser(action='start')")
        with sync_playwright() as pw:
            br = pw.chromium.connect_over_cdp(tk_browser.CDP_URL, timeout=30000)
            ctx = br.contexts[0]
            pg = None
            for x in ctx.pages:
                if "tiktok.com" in (x.url or ""):
                    pg = x
                    break
            if pg is None:
                pg = ctx.new_page()
                pg.goto("https://www.tiktok.com/", wait_until="domcontentloaded",
                        timeout=40000)
                time.sleep(3)
            r = pg.evaluate("""async () => {
                try {
                    const res = await fetch(
                        'https://www.tiktok.com/passport/web/account/info/?aid=1459',
                        {credentials: 'include'});
                    const t = await res.text();
                    let d = null;
                    try { d = JSON.parse(t); } catch(e) {}
                    const uid = d && ((d.data && d.data.user_id) || d.user_id);
                    return {ok: !!uid, userId: uid || null,
                            msg: (d && (d.message || d.msg)) || null};
                } catch(e) { return {ok: false, err: String(e).slice(0, 60)}; }
            }""")
            # 只关自己开的页
            return _ok(loggedIn=bool(r.get("ok")),
                       userId=r.get("userId"),
                       note=("已登录，可以正常下载" if r.get("ok")
                             else "未登录 —— playAddr 不会下发，下载会失败。"
                                  "调用 dl_sd_browser(action='login') 开窗让用户登录"))
    except Exception as e:
        return _err(str(e)[:200])


@mcp.tool(description=(
    "检查 TikTok 登录状态。下载 TK短剧必须先登录，否则接口不给 playAddr。"
    "返回 loggedIn / userId"))
def dl_sd_login() -> dict:
    return _sd_login_check()


@mcp.tool(description=(
    "看某个下载任务的逐集明细：state（ok/fail/skip）/ 大小 / 实际时长 / 清晰度档位。"
    "用来确认下载是否真的对（不只看 ok 计数）"))
def dl_task_detail(task_id: int) -> dict:
    from app.services import dlq
    try:
        items = dlq.snapshot()
        x = next((i for i in items if i["id"] == int(task_id)), None)
        if not x:
            return _err(f"任务 {task_id} 不存在")
        eps = []
        for e in x.get("eps") or []:
            eps.append({
                "ep": e.get("ep"), "state": e.get("state"),
                "bytes": e.get("bytes") or 0,
                "mb": round((e.get("bytes") or 0) / 1048576.0, 2),
                "duration": e.get("duration") or 0,
                "quality": e.get("quality") or "",
                "msg": e.get("msg") or "",
            })
        return _ok(task_id=task_id, site=x.get("site"), name=x.get("name"),
                   done=x.get("done"), total=x.get("total"),
                   finished=x.get("finished"),
                   okCount=x.get("ok"),          # 成功集数（避免和 ok 布尔冲突）
                   bytes=x.get("bytes"), eps=eps)
    except Exception as e:
        return _err(str(e)[:160])


# ═══════════════════════════════════════════════
#  素材 / 成片
# ═══════════════════════════════════════════════
@mcp.tool(description="列素材库")
def library_list(limit: int = 50) -> dict:
    from app.api import library as lib
    try:
        r = lib.list_items(limit=limit) if hasattr(lib, "list_items") else None
        if r is None:
            from app.services import slicing as sl
            ds = sl.list_dramas()
            return _ok(count=len(ds), items=ds[:limit])
        return _ok(**r) if isinstance(r, dict) else _ok(items=r)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  发布
# ═══════════════════════════════════════════════
@mcp.tool(description=(
    "【归档本轮·推荐】调 worker 的 archiveRun，等同 ReelsPublisher GUI 的"
    "「结束本轮/归档」。\n"
    "用途：publish_batch 报 RUN_ACTIVE 时先调它；或本轮做完想收尾。\n"
    "会正确把 currentRun.state 改成 archived 并保存历史\n"
    "（比手改 state.json 安全，不漏字段）"))
def pub_archive() -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.archive_via_worker()
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "归档失败")
    except Exception as e:
        return _err(f"归档失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【确保内核可用】查状态，state 不在 completed/archived 就自动归档，"
    "然后确认已就绪。\n"
    "发布前调一次，规避绝大多数 RUN_ACTIVE 报错"))
def pub_ready() -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.activate_via_worker()
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "准备失败")
    except Exception as e:
        return _err(f"准备失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【继续未成功的主页】不等整轮重来，只重试本轮没成功的主页。\n"
    "安全保证：已经点击发布 / 结果不确定的主页会**跳过**，不会重复发。\n"
    "什么时候用：一轮跑完有失败页，想补发剩下的"))
def pub_continue() -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.continue_unsuccessful()
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "继续失败")
    except Exception as e:
        return _err(f"继续失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【恢复卡住的浏览器环境】重新接管某个环境的未完成任务。\n"
    "参数：environmentId（从 publish_pages 或 state 里拿到的环境 ID）\n"
    "什么时候用：某个号卡死/中断后，想让它继续跑剩下没发的"))
def pub_recover_env(environmentId: str) -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.recover_environment(environmentId)
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "恢复失败")
    except Exception as e:
        return _err(f"恢复失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【停止发布】不传 environmentId = 停全部；传了就只停那个环境。\n"
    "注意：这是让 worker 优雅停止，比杀进程安全（会记录状态）"))
def pub_stop(environmentId: str = "") -> dict:
    from app.services import publish_admin as pa
    try:
        r = (pa.stop_environment(environmentId) if environmentId
             else pa.stop_all())
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "停止失败")
    except Exception as e:
        return _err(f"停止失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【清空全部记录·危险】调 worker 的 clearHistory。\n"
    "会一次性清掉：bindings / plan / browserCheck / discovery /\n"
    "  pageDiscovery / currentRun / history / usedHashes\n"
    "⚠ usedHashes 被清 = 之前发过的视频可以重发，很容易重复发！\n"
    "调前会自动备份 state.json，并把 usedHashes 单独存一份到 data/ 下。\n"
    "只在换批、彻底重来的时候用"))
def pub_clear_history() -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.clear_history()
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "清空失败")
    except Exception as e:
        return _err(f"清空失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【实时 run 详情】直接问 worker 要当前 run 状态（比读 state.json 新）。\n"
    "返回：每个主页的 state/stage、assignment 数量、plan/browserCheck 摘要\n"
    "发布过程中想看进度就用它"))
def pub_run_detail() -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.run_status_detail()
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "查询失败")
    except Exception as e:
        return _err(f"查询失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【查已发 hash】列 usedHashes（内核用来拦重复发的 sha256 列表），"
    "并尽量从 _pub_log.jsonl 反查出对应文件和主页。\n"
    "发布前用它确认某个文件是不是已经发过"))
def pub_used_list(limit: int = 30) -> dict:
    from app.services import publish_admin as pa
    try:
        return _ok(**pa.list_used(limit=limit))
    except Exception as e:
        return _err(f"读取失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【释放已发记录】把某个文件从 usedHashes 里放出来，允许重发。\n"
    "两种用法：\n"
    "  filePath  传文件完整路径（自动算 sha256 再释放）→ 推荐\n"
    "  hashValue 直接传 sha256\n"
    "什么时候用：某文件确认没发出去（例如 Yu02 的 EP01），"
    "但内核认为它发过了、拦着不让重发。\n"
    "⚠ 只在确认没发出去时用，否则会重复发"))
def pub_release(filePath: str = "", hashValue: str = "") -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.release_hash(file_path=filePath, hash_value=hashValue)
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "释放失败")
    except Exception as e:
        return _err(f"释放失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【能力自检】查雨海各个能力现在能不能用。\n"
    "返回每一类（下载/切片/发布/采集/浏览器）的可用状态和不可用原因。\n"
    "什么时候用：\n"
    "  · 想做某件事之前，先查这项能力是否 ready\n"
    "  · 雨海工具报错后，用它确认是环境问题还是参数问题\n"
    "  · 不可用时就告诉用户缺什么，不要自己用 pwsh 绕过"))
def env_capability() -> dict:
    from pathlib import Path
    out = {}
    problems = []

    # ① 切片环境
    try:
        from app.services import envcheck
        e = envcheck.full_check()
        ok = bool(e.get("ok"))
        out["slice"] = {
            "ready": ok,
            "gpu": (e.get("gpu") or {}).get("name") or "",
            "cuda": (e.get("gpu") or {}).get("cuda"),
            "warnings": (e.get("warnings") or [])[:5],
        }
        if not ok:
            problems.append("切片环境未就绪：" +
                            "；".join((e.get("warnings") or ["未知"])[:2]))
    except Exception as ex:
        out["slice"] = {"ready": False, "error": str(ex)[:100]}
        problems.append("切片环境检查失败: " + str(ex)[:60])

    # ② ReelsPublisher
    try:
        from app.services import portable
        r = portable.reels_root()
        out["publish"] = {
            "ready": bool(r),
            "reelsRoot": str(r) if r else "",
        }
        if not r:
            problems.append("找不到 ReelsPublisher（用 portable_set 设置目录）")
    except Exception as ex:
        out["publish"] = {"ready": False, "error": str(ex)[:100]}
        problems.append("发布内核检查失败: " + str(ex)[:60])

    # ③ 指纹浏览器
    try:
        import json as _j
        import urllib.request as _u
        from app.config import settings as _s
        port = int(_s.port or 8710)
        with _u.urlopen("http://127.0.0.1:%d/api/envs?refresh=false" % port,
                        timeout=20) as rr:
            envs = _j.loads(rr.read().decode("utf-8", "replace"))
        items = envs.get("items") if isinstance(envs, dict) else envs
        items = items if isinstance(items, list) else []
        running = [x for x in items if str(x.get("status")) == "running"]
        out["browser"] = {
            "ready": bool(running),
            "running": len(running),
            "total": len(items),
            "cdpPorts": [x.get("cdpPort") for x in running
                         if x.get("cdpPort")],
        }
        if not running:
            problems.append("没有 running 的指纹浏览器，先启动一个号")
    except Exception as ex:
        out["browser"] = {"ready": False, "error": str(ex)[:100]}
        problems.append("浏览器检查失败: " + str(ex)[:60])

    # ④ 素材目录
    try:
        from app.services import portable
        roots = portable.material_roots()
        total = 0
        for r in roots:
            try:
                total += len(list(Path(r).rglob("*.mp4")))
            except Exception:
                pass
        out["material"] = {
            "ready": bool(roots),
            "roots": [str(x) for x in roots],
            "mp4Count": total,
        }
        if not roots:
            problems.append("找不到素材目录（用 portable_set 设置）")
        elif total == 0:
            problems.append("素材目录里没有 mp4")
    except Exception as ex:
        out["material"] = {"ready": False, "error": str(ex)[:100]}

    # ⑤ 切片脚本
    try:
        from app.services import portable
        td = portable.tools_dir()
        has = bool(td) and (Path(td) / "cut_ep2.py").exists()
        out["sliceScript"] = {"ready": has,
                              "toolsDir": str(td) if td else ""}
        if not has:
            problems.append("找不到 cut_ep2.py（用 portable_set 设置 toolsDir）")
    except Exception as ex:
        out["sliceScript"] = {"ready": False, "error": str(ex)[:100]}

    # ⑥ 链接池
    try:
        from app.services import link_pool as lp
        st = lp.stats()
        out["linkPool"] = {"ready": (st.get("total") or 0) > 0, **st}
        if not (st.get("total") or 0):
            problems.append("链接池是空的（用 link_add 加链接）")
    except Exception as ex:
        out["linkPool"] = {"ready": False, "error": str(ex)[:100]}

    ready_n = sum(1 for v in out.values() if v.get("ready"))
    return _ok(
        allReady=not problems,
        readyCount=ready_n,
        totalCount=len(out),
        capabilities=out,
        problems=problems,
        guide=("能力齐全，直接用雨海工具干活"
               if not problems
               else "有 " + str(len(problems)) + " 项不可用，"
                    "先告诉用户这些问题，不要用 pwsh 绕过"),
    )


@mcp.tool(description=(
    "【路径自检·换电脑必看】检查 ReelsPublisher / 素材根目录 / 切片脚本"
    "在本机能不能找到。\n"
    "换电脑、换盘符后先跑它：missing 为空就说明一切正常；"
    "有缺项就用 portable_set 补上。\n"
    "这些路径存在 data/portable.json 里，跟着数据走，不写死在代码里"))
def portable_status() -> dict:
    from app.services import portable
    try:
        return _ok(**portable.status())
    except Exception as e:
        return _err(f"读取失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【设置路径】手动指定 ReelsPublisher 目录 / 素材根目录 / 切片脚本目录。\n"
    "换电脑后如果 portable_status 报 missing，用这个补：\n"
    "  reelsPublisher  ReelsPublisher-v19.7-Portable 目录"
    "（里面要有 Reels Publisher.exe）\n"
    "  materialRoots   素材根目录列表（绝对路径数组，按本机实际情况填）\n"
    "  toolsDir        切片脚本目录（里面要有 cut_ep2.py）\n"
    "只传要改的字段，其余保持原样。写进 data/portable.json"))
def portable_set(reelsPublisher: str = "",
                 materialRoots: list[str] = [],
                 toolsDir: str = "") -> dict:
    from app.services import portable
    try:
        r = portable.set_paths(
            reelsPublisher=reelsPublisher,
            materialRoots=(materialRoots if materialRoots else None),
            toolsDir=toolsDir)
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "设置失败")
    except Exception as e:
        return _err(f"设置失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【重新探测】自动扫描本机常见位置，找 ReelsPublisher / 素材目录 / 切片脚本。\n"
    "换电脑后先跑 portable_autodetect，找不到的再用 portable_set 手填。\n"
    "会覆盖 data/portable.json 里对应的空字段"))
def portable_autodetect() -> dict:
    from app.services import portable
    try:
        r = portable.bootstrap(force=False)
        return _ok(**portable.status())
    except Exception as e:
        return _err(f"探测失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【浏览器状态】查所有指纹浏览器：running 的 PID、CDP 端口、容器号。\n"
    "提取主页 / 发布前用它确认哪个号是活的"))
def env_running() -> dict:
    import json
    import urllib.request
    from app.config import settings
    port = int(settings.port or 8710)
    try:
        with urllib.request.urlopen(
                "http://127.0.0.1:%d/api/envs?refresh=false" % port,
                timeout=30) as r:
            envs = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return _err("读取失败: " + str(e)[:120])
    items = envs.get("items") if isinstance(envs, dict) else envs
    if not isinstance(items, list):
        items = []
    running = []
    closed = 0
    for it in items:
        st = str(it.get("status") or "")
        if st == "running":
            running.append({
                "containerId": str(it.get("containerCode")
                                   or it.get("containerId") or ""),
                "name": it.get("name") or "",
                "pid": it.get("pid"),
                "cdpPort": it.get("cdpPort"),
                "role": it.get("roleLabel") or it.get("role") or "",
            })
        else:
            closed += 1
    return _ok(runningCount=len(running), closedCount=closed,
               running=running,
               hint=("用 page_extract_auto 可从这些号提取主页"
                     if running else "没有 running 的号，先去启动"))


@mcp.tool(description=(
    "【提取主页·推荐】从运行中的指纹浏览器自动提取该号名下所有主页。"
    "不用传 PID —— 会自动找 running 状态的浏览器。\n"
    "参数：containerId 指定容器号（空=所有 running 的）；"
    "parallel 并发数（默认2）\n"
    "这是 page_extract 的友好版本，解决「400: PID 不能为空」"))
def page_extract_auto(containerId: str = "", parallel: int = 2) -> dict:
    import json
    import urllib.request
    from app.config import settings

    port = int(settings.port or 8710)
    base = "http://127.0.0.1:%d" % port

    try:
        with urllib.request.urlopen(base + "/api/envs?refresh=false",
                                    timeout=30) as r:
            envs = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return _err("读环境列表失败: " + str(e)[:120])

    items = envs.get("items") if isinstance(envs, dict) else envs
    if not isinstance(items, list):
        items = []

    pids = []
    picked = []
    for it in items:
        if str(it.get("status") or "") != "running":
            continue
        p_ = it.get("pid")
        if not p_:
            continue
        cid = str(it.get("containerCode") or it.get("containerId") or "")
        if containerId and cid != str(containerId):
            continue
        pids.append(str(p_))
        picked.append({"containerId": cid, "pid": p_,
                       "cdpPort": it.get("cdpPort"),
                       "name": it.get("name") or ""})

    if not pids:
        return _err("没有 running 的指纹浏览器（或都没有 pid）。\n"
                    "请先在「指纹浏览器」页启动至少一个号。")

    body = json.dumps({"pids": pids,
                       "parallel": max(1, int(parallel or 2)),
                       "createMissing": True}).encode()
    req = urllib.request.Request(
        base + "/api/pages/extract", data=body,
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            res = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return _err("提取失败: " + str(e)[:200])

    return _ok(usedEnvs=picked, pidCount=len(pids), result=res,
               hint="提取完成后用 page_list 看全部主页")


@mcp.tool(description=(
    "【已发台账】查哪些文件已经发过了（按 sha256），避免重复发布。\n"
    "返回：已发文件列表、对应主页、发到哪个 @、时间。\n"
    "发布前用它可以确认哪些不能重发"))
def pub_sent_log(limit: int = 50) -> dict:
    import json
    from pathlib import Path
    cands = []
    try:
        from app.services import portable
        cands.append(portable.publish_log())
        r = portable.reels_root()
        if r:
            cands.append(r / "resources" / "data" / "_pub_log.jsonl")
    except Exception:
        pass
    cands.append(Path(r"E:\雨海工作台\_pub_log.jsonl"))
    rows = []
    src_file = ""
    for c in cands:
        if not c.exists():
            continue
        src_file = str(c)
        try:
            lines = c.read_text(encoding="utf-8", errors="replace").split("\n")
        except Exception:
            continue
        for ln in lines[-max(1, int(limit or 50)):]:
            ln = ln.strip()
            if not ln:
                continue
            try:
                rows.append(json.loads(ln))
            except Exception:
                pass
        break
    # 顺带读 usedHashes（内核锁）
    used_n = 0
    try:
        sp = Path(r"E:\ReelsPublisher-v19.7-Portable\resources\data\state.json")
        if sp.exists():
            st = json.loads(sp.read_text(encoding="utf-8"))
            used_n = len(st.get("usedHashes") or {})
    except Exception:
        pass
    return _ok(source=src_file, count=len(rows), usedHashes=used_n,
               items=rows[-max(1, int(limit or 50)):])


@mcp.tool(description=(
    "【剧名翻译】中文剧名 → 英文剧名（用于美区发布）。\n"
    "传中文名，返回建议英文名；库里有映射就直接给，没有就按规则转。\n"
    "多个用逗号分隔：names=\"带五萌娃,爱上我的恶霸\""))
def drama_name_en(names: str) -> dict:
    from app.services import reel_caption as rc
    raw = [x.strip() for x in str(names or "").replace("，", ",").split(",")
           if x.strip()]
    if not raw:
        return _err("names 不能为空")
    out = {}
    for n in raw:
        if not rc.has_chinese(n):
            out[n] = n
            continue
        eng = rc.ensure_english(n)
        out[n] = eng or ""
    missing = [k for k, v in out.items() if not v]
    return _ok(mapping=out, missing=missing,
               hint=("缺失的用 link_add 那种方式补映射，"
                     "或直接把英文名传给 publish_batch(fixed_title=...)"
                     if missing else "全部有英文名"))


@mcp.tool(description=(
    "[旧链路·推荐用 publish_now] 把目录里的视频批量发到 Facebook Reels。\n注意：这个工具直接调 rl.publish，不带按剧 AI 标题和引导语，新代码请用 publish_now。"
    "一个目录 → 多个主页，支持标题池随机、链接池、每页发几条。\n"
    "参数：\n"
    "  directory    素材目录（整目录内所有 mp4 都会被发，不用一个个列）\n"
    "  pages        主页 ID 列表（空=全部已授权主页）\n"
    "  clips_per_page  每个主页发几条（默认1，发6条就传 6）\n"
    "  description  文案（留空会自动按目录名推剧名生成标准模板）\n"
    "  link_pool    链接池，留空用固定链接 https://pinedrama.onelink.me/tR68/tq54sj7s\n"
    "\n"
    "【文案标准模板（必须含固定链接，每条不同）】\n"
    "  🎬NEXT EPISODE👉🏻<固定链接>\n"
    "  🌟Watch all episodes for FREE\n"
    "  🔍Title: \"<英文剧名>\".\n"
    "  Click the link in the title to search the show name, don’t miss any episode!✨\n"
    "  剧名用英文（如 Fire: The Shy Girl Is MVP），不要用中文\n"
    "  title_mode   random=从标题库随机抽 | fixed=用 fixed_title | ref=用 reference_title\n"
    "  fixed_title  固定标题（title_mode=fixed 时用）\n"
    "  reference_title  参考标题（生成相似文案用）\n"
    "  publish_mode 三选一（默认 merge）：\n"
    "    merge      所有视频混池 → shuffle → 按主页顺序分配。\n"
    "               ⚠ 多主页时哪个视频给哪个主页是随机的，容易串。\n"
    "               单主页 + clips_per_page=N 是确定的（不会串）。\n"
    "    per_folder 每个子文件夹对应一组主页，文件不跨文件夹混用。\n"
    "               ✅ 多主页 + 每部剧发不同主页时用这个，绝不会串。\n"
    "               要求：页面数 >= 文件夹数\n"
    "    separate   每个视频独立一条（精确控制用 publish_files）\n"
    "  materials    限定用目录里哪几个文件（空=全部）\n"
    "  concurrency  并发数（默认1，可 2-3 提速）\n"
    "示例：publish_batch(directory=\"<素材目录的绝对路径>\", pages=[\"PAGE_ID\"], "
    "clips_per_page=6, title_mode=\"random\", link_pool=\"https://a.com\\nhttps://b.com\")"
))
def publish_batch(directory: str, pages: list[str] = [],
                  clips_per_page: int = 1,
                  description: str = "",
                  link_pool: str = "",
                  title_mode: str = "random",
                  fixed_title: str = "",
                  reference_title: str = "",
                  lang: str = "",
                  intervalMinutes: int = 30,
                  publish_mode: str = "merge",
                  folderPages: dict = {},
                  materials: list[str] = [],
                  concurrency: int = 1,
                  browserIds: list[str] = [],
                  timeout_s: int = 3600,
                  jobId: str = "") -> dict:
    import asyncio
    from pathlib import Path
    from app.services import reels as rl

    d = str(directory or "").strip()
    if not d:
        return _err("directory 不能为空（素材目录）")
    if not Path(d).exists():
        return _err("目录不存在: " + d)

    # 统计目录里有多少可发文件
    try:
        mp4s = [f for f in Path(d).rglob("*.mp4")]
    except Exception:
        mp4s = []
    if not mp4s:
        return _err("目录里没有 mp4: " + d)

    # ⭐ per_folder 模式：每个子文件夹单独发一组主页，绝不串
    if (publish_mode or "").lower() == "per_folder":
        subs = [x for x in Path(d).iterdir() if x.is_dir()]
        subs = [x for x in subs if any(x.rglob("*.mp4"))]
        if not subs:
            return _err("per_folder 模式需要子文件夹，每个子文件夹一部剧")
        if not folderPages:
            return _err(
                "per_folder 模式必须传 folderPages，指定「哪个文件夹发哪些主页」。\n"
                "例：folderPages={\"Fire The Shy Girl Is MVP\": [\"1400378459825763\"]}")
        results = []
        for sub in subs:
            key = sub.name
            pgs = folderPages.get(key)
            if not pgs:
                # 允许用前缀/包含匹配
                for k2, v2 in folderPages.items():
                    if k2 in key or key in k2:
                        pgs = v2
                        break
            if not pgs:
                results.append({"folder": key, "ok": False,
                                "error": "folderPages 里没配这个文件夹"})
                continue
            # 这个文件夹的剧名
            nm = rc.drama_name_from_dir(key)
            use_lang = lang or rc.detect_lang(nm)
            try:
                from app.services import link_pool as _lp3
                _lp3.seed_defaults()
                _links3 = _lp3.pick(n=max(1, int(clips_per_page or 1)))
            except Exception:
                _links3 = []
            folder_cap = rc.build_auto(nm, variant=0, lang=use_lang,
                                       link=(_links3[0] if _links3 else ""))
            folder_lp = lp or "\n".join(_links3) or rc.FIXED_LINK
            try:
                rr = asyncio.run(rl.publish(
                    directory=str(sub),
                    description=folder_cap,
                    link_pool=folder_lp,
                    clips_per_page=int(clips_per_page or 1),
                    concurrency=int(concurrency or 1),
                    publish_mode="merge",
                    browser_ids=browserIds or None,
                    pages=list(pgs),
                    title_mode="fixed",
                    fixed_title=folder_cap,
                    use_random_link=bool(folder_lp),
                    timeout_s=float(timeout_s or 3600),
                    interval_minutes=int(intervalMinutes or 30),
                ))
                o = rr if isinstance(rr, dict) else {"result": rr}
                o.update({"folder": key, "ok": True, "pages": pgs,
                          "lang": use_lang, "caption": folder_cap[:120]})
                results.append(o)
            except Exception as e2:
                results.append({"folder": key, "ok": False,
                                "error": str(e2)[:200]})
        okn = sum(1 for x in results if x.get("ok"))
        return _ok(mode="per_folder", folders=len(subs), success=okn,
                   results=results, clipsPerPage=clips_per_page,
                   intervalMinutes=intervalMinutes,
                   hint=("逐个文件夹发完，共 %d/%d 成功" % (okn, len(subs))))

    # ⭐ 标题与链接硬校验：空标题/空链接等于白发，直接拒绝
    from app.services import reel_caption as rc

    desc = (description or "").strip()
    fixed = (fixed_title or "").strip()
    lp = (link_pool or "").strip()

    # 没给标题 → 从目录名推剧名，语言跟着剧名走（不强制英文）
    if not desc and not fixed:
        guessed = rc.drama_name_from_dir(Path(d).parts[-1])
        if not guessed:
            return _err(
                "无法从目录名推断剧名 —— 空标题发布等于白发。\n"
                "请把素材目录命名成剧名（中文英文都行），或显式传 fixed_title")
        # 语言：调用方指定优先，否则按剧名自动判断
        use_lang = lang or rc.detect_lang(guessed)
        # 从链接池抽链接（池空会回落固定链接）
        try:
            from app.services import link_pool as _lp
            _lp.seed_defaults()
            _links = _lp.pick(n=max(1, int(clips_per_page or 1)))
        except Exception:
            _links = []
        desc = rc.build_auto(guessed, variant=0, lang=use_lang,
                             link=(_links[0] if _links else ""))
        if title_mode in ("fixed", "", None):
            fixed = desc
            title_mode = "fixed"

    # ⭐ 就算调用方自己传了 description，也要查里面是不是中文剧名
    for _t in (desc, fixed):
        if _t and rc.has_chinese(_t) and "NEXT EPISODE" in _t:
            # 标准模板里混了中文剧名 → 抽出来换英文
            import re as _re2
            m = _re2.search(r'Title:\s*"([^"]+)"', _t)
            if m:
                cn = m.group(1)
                eng = rc.ensure_english(cn)
                if not eng:
                    return _err(
                        '文案里的剧名是中文（"%s"），必须换成英文剧名后再发' % cn)
                _t = _t.replace(cn, eng)
                if _t == desc:
                    desc = _t
                else:
                    fixed = _t

    # ⭐ 最硬的拦：最终文案必须含固定链接
    final_check = rc.validate(fixed or desc)
    if not final_check["ok"]:
        return _err("文案不合规，拒绝发布：" + "；".join(final_check["problems"]))

    # 没给链接 → 从链接池抽（池空回落固定链接）
    if not lp:
        try:
            from app.services import link_pool as _lp2
            _lp2.seed_defaults()
            lp = _lp2.as_text(n=max(1, int(clips_per_page or 1)))
        except Exception:
            lp = ""
    if not lp:
        lp = rc.FIXED_LINK

    # 校验模板合规性（必须有固定链接、Title 行等）
    check = rc.validate(desc or fixed)
    if not check["ok"] and not desc:
        return _err("文案不合规：" + "；".join(check["problems"]))



    try:
        r = asyncio.run(rl.publish(
            directory=d,
            description=desc,
            link_pool=lp,
            clips_per_page=int(clips_per_page or 1),
            concurrency=int(concurrency or 1),
            publish_mode=publish_mode or "merge",
            browser_ids=browserIds or None,
            pages=pages or None,
            materials=materials or None,
            title_mode=title_mode or "random",
            reference_title=reference_title or "",
            use_random_link=bool(link_pool),
            fixed_title=fixed_title or "",
            timeout_s=float(timeout_s or 3600),
            job_id=jobId or "",
            interval_minutes=int(intervalMinutes or 30),
        ))
        out = r if isinstance(r, dict) else {"result": r}
        out.setdefault("directory", d)
        out.setdefault("fileCount", len(mp4s))
        out.setdefault("targetPages", len(pages) if pages else "全部")
        out.setdefault("clipsPerPage", clips_per_page)
        return _ok(**out)
    except Exception as e:
        return _err(f"批量发布失败: {str(e)[:200]}")


@mcp.tool(description=(
    "【发布·推荐】走「发布中心」同一条链路发到 Facebook Reels，agent 发视频首选。\n"
    "和 UI 里的「发布中心」完全等价：\n"
    "  · 素材从库/队列自动分配（按 sha256 去重，不会发重）\n"
    "  · 标题按剧名用 AI 实时生成，同一批内每条不重复\n"
    "  · 正文自动带引导点击文案 + 推广链接\n"
    "  · 同主页多条按间隔分钟错峰排期（等于 UI 的「排期设置」）\n"
    "  · 成功才回写 units / pages.published / library.state\n"
    "参数：pages 主页ID列表 / clipsPerPage 每页几条 / source library|queue /\n"
    "  spacingMinutes 排期间隔 / captionStyle simple|template /\n"
    "  fixedTitle 指定标题 / fixedLink 指定链接 / referenceTitle 参考模板 /\n"
    "  dryRun true=只预览不发（建议先跑一次）"
))
def publish_now(pages: list[str] = [],
                clipsPerPage: int = 0,
                source: str = "",
                spacingMinutes: int = -1,
                captionStyle: str = "",
                fixedTitle: str = "",
                fixedLink: str = "",
                referenceTitle: str = "",
                allocMode: str = "",
                language: str = "",
                dryRun: bool = False,
                timeout_s: int = 3600) -> dict:
    """按「发布中心」完整链路发布（agent 首选）。

    ⚠ 2026-11-16 改（用户："agent 都不知道发多少条还发，到时候用户又不满意"）：
        关键参数**不再给默认值**，缺失就返回 needsChoice 让用户选。
          clipsPerPage  默认 0  = 未指定 → 必须问
          spacingMinutes 默认 -1 = 未指定 → 必须问
          allocMode     默认 ""  = 未指定 → 必须问
        只有 source / captionStyle 保持智能默认（不影响用户满意度）。

    2026-11-12 新增。旧的 publish_batch / publish_files 直接调 rl.publish，
    缺三样东西：
        1. 按剧 AI 生成标题（不同剧会共用一套标题）
        2. 链接前的引导点击文案
        3. 素材 hash 与内核 usedHashes 不一致时被静默过滤（报素材不足）
    这个工具走 publish_engine，和 UI 完全同一条链路。
    """
    import asyncio
    from app.api import publish as pub_api

    # ── ① 关键参数守卫：不确定就问用户，不许猜 ──
    missing: list[dict] = []

    if not pages:
        try:
            from app.db import db as _db
            rows = _db.q(
                "SELECT p.page_id, p.name, p.env_code FROM pages p "
                "LEFT JOIN envs e ON e.container_code = p.env_code "
                "WHERE p.asset_id IS NOT NULL AND p.asset_id<>'' "
                "AND p.health='ok' AND IFNULL(p.skip_publish,0)=0 "
                "AND COALESCE(e.account_state,'ok')<>'dead' "
                "ORDER BY p.name")
            opts = [{"label": r["name"], "value": r["page_id"],
                     "desc": r["page_id"]} for r in (rows or [])]
        except Exception:
            opts = []
        missing.append({
            "field": "pages",
            "question": "要发到哪些主页？（可多选；建议先调 publish_sync_pages 确认有没有新加主页）",
            "options": opts,
            "allowCustom": True,
        })

    if not clipsPerPage or int(clipsPerPage) <= 0:
        missing.append({
            "field": "clipsPerPage",
            "question": "每个主页发几条视频？",
            "options": OPT_CLIPS,
            "allowCustom": True,
        })

    if spacingMinutes is None or int(spacingMinutes) < 0:
        missing.append({
            "field": "spacingMinutes",
            "question": "同一主页的多条之间怎么排期？",
            "options": OPT_SPACING,
            "allowCustom": True,
        })

    if not allocMode:
        missing.append({
            "field": "allocMode",
            "question": "素材怎么分配？",
            "options": OPT_ALLOC,
            "allowCustom": False,
        })

    if missing:
        return _need_multi(missing)

    # 这两个不影响满意度，可以智能默认（4 行模板为用户确认的默认格式）
    src = source if source in ("library", "queue") else "library"
    cap_style = (captionStyle if captionStyle in ("simple", "template")
                 else "template")

    try:
        req = pub_api.CreateOrderReq(
            pageIds=[str(p).strip() for p in pages if str(p).strip()],
            clipsPerPage=max(1, int(clipsPerPage)),
            materialSource=src,
            allocMode=allocMode if allocMode in ("merge", "per_drama") else "merge",
            captionStyle=cap_style,
            # 目标语言（2026-11-16）：en 强制英文标题 + 英文剧名
            language=language or "",
            fixedTitle=fixedTitle or "",
            fixedLink=fixedLink or "",
            referenceTitle=referenceTitle or "",
            spacingMinutes=max(0, int(spacingMinutes)),
            dryRun=bool(dryRun),
            autoPrepare=True,
        )
    except Exception as e:
        return _err(f"参数不合法: {str(e)[:160]}")

    # ── ② 进度播报：用自然语言描述正在做什么 ──
    page_n = len([p for p in pages if str(p).strip()])
    job_id = _progress_job(f"发布到 {page_n} 个主页")
    _say(f"正在检查素材和目标主页（{page_n} 个主页 × {int(clipsPerPage)} 条）",
         job_id=job_id)

    try:
        pv = asyncio.run(pub_api.preview(req))
    except Exception as e:
        _finish_job(job_id, False, f"预览失败：{str(e)[:80]}")
        return _err(f"预览失败: {str(e)[:220]}")

    if dryRun:
        _finish_job(job_id, True, "预览完成，未实际发布")
        return _ok(
            dryRun=True,
            # 给 agent 一段可以直接念给用户听的话
            report=(f"预览结果：{pv.get('pageCount')} 个主页，"
                    f"共 {pv.get('itemCount')} 条视频"
                    + (f"，素材不足差 {pv.get('shortage')} 条"
                       if pv.get("shortage") else "，素材充足")),
            pageCount=pv.get("pageCount"),
            itemCount=pv.get("itemCount"),
            shortage=pv.get("shortage"),
            shortageNote=pv.get("shortageNote"),
            titlesByDrama=pv.get("titlesByDrama"),
            items=[{"pageName": it.get("pageName"),
                    "file": it.get("file"),
                    "caption": it.get("caption")}
                   for it in (pv.get("items") or [])],
        )

    if pv.get("shortage"):
        _finish_job(job_id, False, f"素材不足差 {pv.get('shortage')} 条")
        # ⚠ 2026-11-16：把"为什么不够"也说清楚，别让用户以为是软件坏了
        hint = ""
        try:
            from app.db import db
            y03_pid = [p for p in pages if p][0] if pages else ""
            used_n = db.q1(
                "SELECT COUNT(*) AS n FROM library WHERE state='used'")["n"]
            ready_n = db.q1(
                "SELECT COUNT(*) AS n FROM library "
                "WHERE state='ready' AND organized=1")["n"]
            hint = (f"当前可发 {ready_n} 条，已发过 {used_n} 条（已发不会重发）。"
                    f"想继续发可以：① 降低每主页条数 "
                    f"② 减几个主页 ③ 先整理更多素材入库")
        except Exception:
            pass
        return _ok(
            needsUserAction=True,
            question=(
                f"素材不够：需要 {pv.get('materialRequired')} 条，"
                f"只能凑到 {pv.get('materialAvailable')} 条，"
                f"差 {pv.get('shortage')} 条。怎么办？"),
            options=[
                {"label": "减少每主页条数", "value": "reduce_clips",
                 "desc": "比如从 5 条改成 2 条"},
                {"label": "减少主页数量", "value": "reduce_pages",
                 "desc": "少发几个主页"},
                {"label": "先去整理素材", "value": "organize",
                 "desc": "把新切的片子整理进素材库再来"},
            ],
            allowCustom=True,
            report=(f"素材不足：需要 {pv.get('materialRequired')} 条，"
                    f"只能凑到 {pv.get('materialAvailable')} 条。{hint}"),
            shortage=pv.get("shortage"),
            shortageNote=pv.get("shortageNote"),
            materialRequired=pv.get("materialRequired"),
            materialAvailable=pv.get("materialAvailable"),
            pageCount=pv.get("pageCount"),
            itemCount=pv.get("itemCount"))

    _say(f"素材充足，正在创建发布任务（{pv.get('itemCount')} 条视频）",
         job_id=job_id)
    try:
        r = asyncio.run(pub_api.create_order(req))
    except Exception as e:
        _finish_job(job_id, False, f"建单失败：{str(e)[:80]}")
        return _err(f"建单失败: {str(e)[:240]}")

    order_id = (r or {}).get("orderId") or ""
    if not order_id:
        _finish_job(job_id, False, "建单没有返回订单号")
        return _err("建单没有返回 orderId", detail=r)

    # 等终态。
    #
    # 安全性：create_order 现在把发布跑在**独立线程 + 独立事件循环**上，
    # 跟这里的 asyncio.run 完全无关，不会因为本函数返回而被掐掉。
    # （之前用 asyncio.create_task 时会被掐，订单 0 秒变 CANCELLED。）
    import time as _t

    deadline = _t.time() + float(timeout_s or 3600)
    last_stage = ""
    while _t.time() < deadline:
        try:
            o = asyncio.run(pub_api.get_order(order_id))
        except Exception:
            _t.sleep(3)
            continue

        st = str((o or {}).get("state") or "")
        stage = str((o or {}).get("stage") or "")

        # 实时播报：stage 一变就写一句人话
        # 订单 stage 本身已经是"[1/22] Y03 · 5 条"这种格式，直接用
        if stage and stage != last_stage:
            last_stage = stage
            _say(stage, job_id=job_id)

        if st in ("COMPLETED", "FAILED", "CANCELLED", "ATTENTION"):
            ok_n = (o or {}).get("ok_count") or 0
            fail_n = (o or {}).get("fail_count") or 0
            total = (o or {}).get("item_count") or 0

            # ⚠ 2026-11-16（用户："完成后把报告发给用户，简洁明了"）：
            #   report 是给 agent 直接念的一段话，不用它自己组织语言；
            #   summary 是结构化数据，agent 需要细看时才用。
            _finish_job(job_id, st == "COMPLETED",
                        f"发布结束：成功 {ok_n}，失败 {fail_n}")

            title_map = {"COMPLETED": "全部发布成功",
                         "ATTENTION": "部分成功",
                         "FAILED": "发布失败",
                         "CANCELLED": "已取消"}
            lines = [f"{title_map.get(st, st)}："
                     f"{total} 条视频，成功 {ok_n} 条"
                     + (f"，失败 {fail_n} 条" if fail_n else "")]

            fails = [(it.get("page_name"), it.get("file_name"),
                      (it.get("error") or "")[:60])
                     for it in ((o or {}).get("items") or [])
                     if str(it.get("state")) not in ("COMMITTED", "OK")]
            if fails:
                lines.append("失败明细：")
                seen_pages = set()
                for pname, _f, err in fails[:6]:
                    if pname in seen_pages:
                        continue
                    seen_pages.add(pname)
                    lines.append(f"  · {pname}：{err}")

            return _ok(
                orderId=order_id,
                state=st,
                report="\n".join(lines),
                summary={"total": total, "ok": ok_n, "fail": fail_n},
                stage=(o or {}).get("stage"),
                okCount=ok_n,
                failCount=fail_n,
                items=[{"pageName": it.get("page_name"),
                        "slot": it.get("slot"),
                        "file": it.get("file_name"),
                        "state": it.get("state"),
                        "acceptance": it.get("acceptance"),
                        "error": it.get("error")}
                       for it in ((o or {}).get("items") or [])],
            )
        _t.sleep(4)

    _finish_job(job_id, False, "超时未完成")
    return _err(f"超时（{timeout_s}s）未完成，orderId={order_id}，"
                f"用 publish_order_status 继续查")


@mcp.tool(description=(
    "【发布·预览】只算文案和素材分配，不真的发。\n"
    "用于确认「AI 会写什么标题」「哪个视频发到哪个主页」再决定是否真发。\n"
    "参数同 publish_now"))
def publish_preview(pages: list[str] = [],
                    clipsPerPage: int = 0,
                    source: str = "",
                    captionStyle: str = "",
                    fixedTitle: str = "",
                    referenceTitle: str = "",
                    allocMode: str = "") -> dict:
    """预览。⚠ 2026-11-16：关键参数不再给默认值，缺失就问用户。"""
    import asyncio
    from app.api import publish as pub_api

    missing: list[dict] = []
    if not pages:
        try:
            from app.db import db
            rows = db.q("SELECT page_id, name FROM pages "
                        "WHERE asset_id IS NOT NULL AND health='ok' "
                        "AND IFNULL(skip_publish,0)=0 ORDER BY name")
            opts = [{"label": r["name"], "value": r["page_id"],
                     "desc": r["page_id"]} for r in (rows or [])]
        except Exception:
            opts = []
        missing.append({"field": "pages",
                        "question": "要预览哪些主页？（可多选）",
                        "options": opts, "allowCustom": True})
    if not clipsPerPage or int(clipsPerPage) <= 0:
        missing.append({"field": "clipsPerPage",
                        "question": "每个主页几条视频？",
                        "options": OPT_CLIPS, "allowCustom": True})
    if not allocMode:
        missing.append({"field": "allocMode",
                        "question": "素材怎么分配？",
                        "options": OPT_ALLOC, "allowCustom": False})
    if missing:
        return _need_multi(missing)

    try:
        req = pub_api.PreviewReq(
            pageIds=[str(p).strip() for p in pages if str(p).strip()],
            clipsPerPage=max(1, int(clipsPerPage)),
            materialSource=source if source in ("library", "queue") else "library",
            allocMode=allocMode if allocMode in ("merge", "per_drama") else "merge",
            captionStyle=captionStyle if captionStyle in ("simple", "template") else "simple",
            fixedTitle=fixedTitle or "",
            referenceTitle=referenceTitle or "",
        )
        pv = asyncio.run(pub_api.preview(req))
        return _ok(
            itemCount=pv.get("itemCount"),
            shortage=pv.get("shortage"),
            shortageNote=pv.get("shortageNote"),
            titlesByDrama=pv.get("titlesByDrama"),
            items=[{"pageName": it.get("pageName"),
                    "file": it.get("file"),
                    "caption": it.get("caption")}
                   for it in (pv.get("items") or [])],
        )
    except Exception as e:
        return _err(f"预览失败: {str(e)[:220]}")


@mcp.tool(description=(
    "【发布·查状态】查发布订单的进度和逐条结果。\n"
    "参数：orderId（publish_now 返回的），留空则查最近 10 个订单"))
def publish_order_status(orderId: str = "") -> dict:
    import asyncio
    from app.api import publish as pub_api
    try:
        if orderId:
            o = asyncio.run(pub_api.get_order(orderId))
            return _ok(order=o)
        rows = asyncio.run(pub_api.list_orders(limit=10))
        return _ok(orders=rows)
    except Exception as e:
        return _err(f"查询失败: {str(e)[:180]}")


@mcp.tool(description=(
    "[已废弃·请用 publish_now] 发指定文件到指定主页。\n旧实现不走按剧生成标题/引导语，建议改用 publish_now。"
    "适合精确控制：要给某个主页发某几个特定文件时用。\n"
    "参数：\n"
    "  files      视频文件完整路径列表（可多个）\n"
    "  pages      主页 ID 列表\n"
    "  caption    标题/文案\n"
    "  link       要附带的链接（可选）\n"
    "  clips_per_page 每个主页发几条\n"
    "批量发整目录请用 publish_batch（更高效）"
))
def publish_files(files: list[str], pages: list[str] = [],
                  caption: str = "", link: str = "",
                  clips_per_page: int = 1,
                  concurrency: int = 1,
                  timeout_s: int = 1800) -> dict:
    import asyncio
    from pathlib import Path
    from app.services import reels as rl

    fl = [str(f).strip() for f in (files or []) if str(f).strip()]
    if not fl:
        return _err("files 不能为空")
    miss = [f for f in fl if not Path(f).exists()]
    if miss:
        return _err("文件不存在: " + ", ".join(miss[:3]))

    # 取父目录 + materials 限定
    parent = str(Path(fl[0]).parent)
    try:
        r = asyncio.run(rl.publish(
            directory=parent,
            description=caption or "",
            link_pool=link or "",
            clips_per_page=int(clips_per_page or 1),
            concurrency=int(concurrency or 1),
            publish_mode="separate",
            pages=pages or None,
            materials=fl,
            title_mode="fixed" if caption else "random",
            fixed_title=caption or "",
            use_random_link=bool(link),
            timeout_s=float(timeout_s or 1800),
        ))
        out = r if isinstance(r, dict) else {"result": r}
        out.setdefault("requestedFiles", len(fl))
        out.setdefault("targetPages", len(pages) if pages else "全部")
        return _ok(**out)
    except Exception as e:
        return _err(f"发布失败: {str(e)[:200]}")


@mcp.tool(description=(
    "[已废弃·请用 publish_now] 发单个视频到单个主页。"
    "批量请用 publish_batch，精确多发请用 publish_files。"
))
def publish_reels(video_path: str, page_id: str = "",
                  caption: str = "", link: str = "") -> dict:
    return publish_files(
        files=[video_path], pages=[page_id] if page_id else [],
        caption=caption, link=link)


@mcp.tool(description=(
    "【链接池】查所有链接。这些链接持久存在数据库里，"
    "退出软件、装更新都不会丢。\n"
    "发布时 publish_batch 会按 used_count 从少到多自动挑，"
    "保证每个链接用得更均匀。\n"
    "返回：url / label / weight / page_id / used_count / last_used_at"))
def link_list() -> dict:
    from app.services import link_pool as lp
    try:
        lp.seed_defaults()
        items = lp.list_all()
        return _ok(count=len(items), stats=lp.stats(), items=items)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【链接池】加一个链接（已存在会更新权重/备注，不会重复）。\n"
    "参数：url 链接 / label 备注 / weight 权重(越大越常抽) / "
    "pageId 限定某主页(空=所有主页通用)\n"
    "加完立刻写入数据库，退出或更新都不会丢"))
def link_add(url: str, label: str = "", weight: int = 1,
             pageId: str = "") -> dict:
    from app.services import link_pool as lp
    try:
        r = lp.add(url, label=label, weight=weight, page_id=pageId)
        if not r.get("ok"):
            return _err(r.get("error") or "添加失败")
        return _ok(**r, stats=lp.stats())
    except Exception as e:
        return _err(f"添加失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【链接池】删一个链接。传 url 或 linkId（从 link_list 拿）"))
def link_remove(url: str = "", linkId: int = 0) -> dict:
    from app.services import link_pool as lp
    try:
        r = lp.remove(url=url, link_id=linkId)
        if not r.get("ok"):
            return _err(r.get("error") or "删除失败")
        return _ok(**r, stats=lp.stats())
    except Exception as e:
        return _err(f"删除失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【文案预览】在真正发布前先看会生成什么文案，不发出去。\n"
    "参数：drama 剧名 / lang 语言(cn|en|空=自动) / "
    "count 生成几条 / link 指定链接(空=从链接池抽)\n"
    "用来确认语言、剧名替换、链接都对再发"))
def caption_preview(drama: str, lang: str = "", count: int = 3,
                    link: str = "") -> dict:
    from app.services import reel_caption as rc
    from app.services import link_pool as lp
    try:
        L = lang or rc.detect_lang(drama)
        links = [link] if link else []
        if not links:
            try:
                lp.seed_defaults()
                links = lp.pick(n=max(1, int(count or 1)))
            except Exception:
                links = []
        caps = rc.build_many_auto(drama, max(1, int(count or 1)),
                                  lang=L, links=links or None)
        checks = [rc.validate(c) for c in caps]
        return _ok(lang=L, drama=drama, count=len(caps),
                   allValid=all(x["ok"] for x in checks),
                   captions=caps,
                   problems=[x["problems"] for x in checks if not x["ok"]])
    except Exception as e:
        return _err(f"生成失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【发布内核状态】查 ReelsPublisher 内核是否被锁。\n"
    "返回：runState（needs_attention 就是被锁）、haltedPages、"
    "riskyAssignments（停在 submission_intent = 点了发布但结果不确定）。\n"
    "被锁时任何 publish_batch 都会被 RUN_ACTIVE 拦住，"
    "必须先用 pub_unlock 解锁。\n"
    "发布前先调它确认内核空闲"))
def pub_state() -> dict:
    from app.services import publish_admin as pa
    try:
        return _ok(**pa.summary())
    except Exception as e:
        return _err(f"读取失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【解锁发布内核】解除 needs_attention 死锁。\n"
    "什么时候用：pub_state 显示 locked=true / needUnlock=true，"
    "或 publish_batch 报 RUN_ACTIVE。\n"
    "resolve_as 三个选项：\n"
    "  unknown  结果不确定（默认，最保守：当作已发，不会重发）\n"
    "  sent     确认发出去了\n"
    "  failed   确认没发出去（会清 usedHashes，允许重发）\n"
    "会把旧的 currentRun 归档到 history，清空 currentRun，"
    "并自动备份 state.json。\n"
    "⚠ 用前先看 pub_state 里的 riskyAssignments，判断那条到底发没发出去"))
def pub_unlock(resolve_as: str = "unknown", note: str = "") -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.unlock(resolve_as=resolve_as, note=note)
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "解锁失败")
    except Exception as e:
        return _err(f"解锁失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【确认单条发布结果】不整体解锁，只标记某条 assignment 的最终结果。\n"
    "参数：pageId 主页ID / fileHint 文件名片段 / result(sent|failed) / note 备注\n"
    "用于：pub_state 里看到某条停在 submission_intent，"
    "你去 FB 主页人工确认后，用它记录结果。\n"
    "全部 assignment 落定后会自动把 runState 从 needs_attention 改成 completed"))
def pub_resolve(pageId: str = "", fileHint: str = "",
                result: str = "sent", note: str = "") -> dict:
    from app.services import publish_admin as pa
    try:
        r = pa.resolve_assignment(page_id=pageId, file_hint=fileHint,
                                  result=result, note=note)
        return _ok(**r) if r.get("ok") else _err(r.get("error") or "标记失败")
    except Exception as e:
        return _err(f"标记失败: {str(e)[:150]}")


@mcp.tool(description=(
    "【定时发布规则】查 Meta 原生排定发布时间的能力边界。\n"
    "关键：只有 clipsPerPage>1 才启用定时（第1条立即发，"
    "第2/3/4条自动 +30/+60/+90 分钟）。\n"
    "clipsPerPage=1 是全部即时发。\n"
    "要更长间隔走 schedule_queue（排期与队列）。\n"
    "另外：🔍Title 的剧名取自【视频所在文件夹名】，"
    "所以素材目录要按英文剧名命名"))
def pub_delay_rules() -> dict:
    from app.services import publish_admin as pa
    try:
        return _ok(**pa.publish_delay_options())
    except Exception as e:
        return _err(f"读取失败: {str(e)[:120]}")


@mcp.tool(description=(
    "查可发布的主页列表（page_id / 名称 / 已授权状态 / 今日已发数）。"
    "发布前先用它确认要发哪些主页"))
def publish_pages() -> dict:
    from app.services import reels as rl
    try:
        plan = rl.plan_pages() if hasattr(rl, "plan_pages") else []
        return _ok(count=len(plan), pages=plan)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:100]}")


@mcp.tool(description=(
    "查发布历史：最近发过什么、发到哪个主页、成功失败。"
    "可传 pageId 只看某个主页，limit 控制条数"))
def publish_history_list(pageId: str = "", limit: int = 20) -> dict:
    from app.db import db
    try:
        sql = "SELECT * FROM publish_log"
        args: list = []
        if pageId:
            sql += " WHERE page_id=?"
            args.append(pageId)
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(int(limit))
        rows = db.q(sql, tuple(args))
        return _ok(count=len(rows), items=[dict(r) for r in rows])
    except Exception as e:
        return _err(f"读取失败: {str(e)[:120]}")


# ═══════════════════════════════════════════════
#  系统
# ═══════════════════════════════════════════════
@mcp.tool(description="系统健康检查")
def system_health() -> dict:
    from app.db import db
    from app.services import envcheck
    e = envcheck.full_check()
    return _ok(ready=e["ok"], warnings=e["warnings"],
               gpu=e["gpu"].get("name"),
               cuda=e["gpu"].get("cuda"))


@mcp.tool(description="读最近日志")
def system_logs(limit: int = 30) -> dict:
    from app.db import db
    rows = db.q("""SELECT ts, level, source, msg FROM events
                   ORDER BY rowid DESC LIMIT ?""", (limit,))
    return _ok(count=len(rows), items=[dict(r) for r in rows])


# ═══════════════════════════════════════════════
#  记忆（跨会话）
# ═══════════════════════════════════════════════
@mcp.tool(description="写记忆（跨会话保留）。常用键：current_drama / preference / last_step")
def memory_set(key: str, value: str) -> dict:
    from app.services import agent_memory as mem
    return _ok(**mem.set(key, value))


@mcp.tool(description="读记忆")
def memory_get(key: str) -> dict:
    from app.services import agent_memory as mem
    r = mem.get(key)
    if not r.get("ok"):
        return _err(r.get("error") or "没有这个键", key=key)
    return _ok(key=r["key"], value=r["value"], updatedAt=r["updatedAt"])


@mcp.tool(description="列出所有记忆")
def memory_list() -> dict:
    from app.services import agent_memory as mem
    return _ok(**mem.list_all())


# ═══════════════════════════════════════════════
#  Agent 自身的模型信息
# ═══════════════════════════════════════════════
@mcp.tool(description="列出当前接入 Agent 的模型（含可用性）")
def agent_models() -> dict:
    from app.services import agent_models as am
    o = am.overview()
    return _ok(connected=o["connected"], name=o["name"],
               models=[{"id": m["id"], "role": m.get("role"),
                        "tested": bool((m.get("test") or {}).get("at")),
                        "ok": (m.get("test") or {}).get("ok")}
                       for m in (o["visible"] or [])])


_APP_CACHE = None


def get_app():
    """返回挂到 FastAPI 的 Starlette 应用（**单例**）。

    必须单例：lifespan 里启动的 session manager 与挂载的 app
    必须是同一个对象，否则 streamable-http 会报
    "Task group is not initialized"。
    """
    global _APP_CACHE
    if _APP_CACHE is None:
        _APP_CACHE = mcp.streamable_http_app(
            streamable_http_path="/", stateless_http=True)
    return _APP_CACHE


# 全功能工具（账号/主页/授权/发布/失败诊断等）在 mcp_tools_full 里注册
try:
    from app.mcp_tools_full import register as _register_full
    _register_full(mcp)
    log.info("mcp_tools_full registered")
except Exception as _e:
    log.warning("mcp_tools_full register failed: %s", _e)

# 剧型工具（列出/判定/手动指定）
try:
    from app.mcp_type import register as _register_type
    _register_type(mcp)
    log.info("mcp_type registered")
except Exception as _e:
    log.warning("mcp_type register failed: %s", _e)

# 邮箱工具（通道配置/测试/拉取/验证码）
try:
    from app.mcp_mail import register as _register_mail
    _register_mail(mcp)
    log.info("mcp_mail registered")
except Exception as _e:
    log.warning("mcp_mail register failed: %s", _e)

# 视频制作工具（clip/concat/vertical/subs/speed/lufs）
try:
    from app.mcp_video import register as _register_video
    _register_video(mcp)
    log.info("mcp_video registered")
except Exception as _e:
    log.warning("mcp_video register failed: %s", _e)

# 文件系统工具（读/写/列目录/搜索/磁盘）
try:
    from app.mcp_fs import register as _register_fs
    _register_fs(mcp)
    log.info("mcp_fs registered")
except Exception as _e:
    log.warning("mcp_fs register failed: %s", _e)

# 全站运营补齐工具（发布前同步主页 / 死号处理换号 / 全自动总控 / 评论 / 风控 / 通用 /api 兜底）
try:
    from app.mcp_ops import register as _register_ops
    _n_ops = _register_ops(mcp)
    log.info("mcp_ops registered (%d tools)", _n_ops)
except Exception as _e:
    log.warning("mcp_ops register failed: %s", _e)

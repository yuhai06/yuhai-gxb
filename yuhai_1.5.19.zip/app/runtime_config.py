"""运行期配置与路径解析的纯函数。

这一层不读取全局 settings，也不创建目录，便于在临时目录中做单元测试。
配置优先级保持为：环境变量 > config.json > 合理默认值。
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


_MIN_DB_BYTES = 20 * 1024


def normalize_key(key: str) -> str:
    """把历史 camelCase / kebab-case 键统一为 snake_case。"""
    text = str(key or "").strip()
    text = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", text)
    text = re.sub(r"[^\w]+", "_", text, flags=re.UNICODE)
    return re.sub(r"_+", "_", text).strip("_").lower()


def read_config_file(path: Path | str) -> dict[str, Any]:
    """读取 config.json；缺失、损坏或顶层不是对象时返回空字典。"""
    p = Path(path)
    try:
        raw = json.loads(p.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}
    return raw if isinstance(raw, dict) else {}


def normalize_config(raw: dict[str, Any]) -> dict[str, Any]:
    """返回键已规范化的浅拷贝；重复键以文件中后出现的值为准。"""
    out: dict[str, Any] = {}
    for key, value in (raw or {}).items():
        out[normalize_key(str(key))] = value
    return out


def resolve_data_dir(
    *,
    is_frozen: bool,
    repo_root: Path | str,
    env_value: str | None = None,
    localappdata: str | None = None,
    home: Path | str | None = None,
    min_db_bytes: int = _MIN_DB_BYTES,
) -> Path:
    """解析数据目录，兼容开发时的新旧两个 data 位置。

    优先级：
      1. YUHAI_DATA_DIR
      2. 打包模式：%LOCALAPPDATA%/YuhaiWorkbench
      3. 开发模式：仓库 data/，其次 backend/data/；优先已有非空数据库
    """
    if env_value and str(env_value).strip():
        return Path(env_value)

    if is_frozen:
        base = localappdata or str(home or Path.home())
        return Path(base) / "YuhaiWorkbench"

    root = Path(repo_root)
    candidates = [root / "data", root / "backend" / "data"]
    for candidate in candidates:
        db = candidate / "workbench.db"
        try:
            if db.is_file() and db.stat().st_size > int(min_db_bytes):
                return candidate
        except OSError:
            pass
    return candidates[0]


def resolve_frontend_dir(
    *,
    is_frozen: bool,
    repo_root: Path | str,
    exe_dir: Path | str,
    resource_dir: Path | str | None = None,
    env_value: str | None = None,
    configured_value: str | None = None,
) -> Path:
    """解析前端目录。

    源码模式只有一处权威：仓库根 frontend/。
    （backend/frontend/ 副本已于 2026-11-18 删除，避免多份副本长期漂移
      导致「本地改好、打包出来还是旧界面」。）
    打包后优先 exe 同级的可热更新 frontend/，其次 PyInstaller 资源目录。
    显式环境变量/配置可以覆盖以上全部规则。
    """
    if env_value and str(env_value).strip():
        return Path(env_value)
    if configured_value and str(configured_value).strip():
        return Path(configured_value)

    root = Path(repo_root)
    exe = Path(exe_dir)
    res = Path(resource_dir) if resource_dir else None

    if is_frozen:
        candidates = [exe / "frontend"]
        if res is not None:
            candidates.append(res / "frontend")
        candidates.append(exe / "_internal" / "frontend")
        # 注意：不再回退 app/frontend。那是开发期的旧副本，
        # updater 打包时也会跳过它（updater.py 里明确写着"旧副本"）。
        # 一旦命中，用户看到的会是几个月前的界面，而且极难排查。
    else:
        candidates = [
            root / "frontend",
        ]

    for candidate in candidates:
        try:
            if (candidate / "index.html").is_file():
                return candidate
        except OSError:
            continue
    return candidates[0]
"""账号身份与主页归属的统一校验。"""
from __future__ import annotations

import re
from typing import Any

from app.db import db

PROFILE_ID_RE = re.compile(r"^\d{8,20}$")
ACCOUNT_ROLES = {"publisher", "backup"}
AUTHZ_STATES = {"pending", "missing", "active"}
QUOTA_LEVELS = {"new", "limited", "blocked"}


class ValidationError(ValueError):
    """输入不满足业务规则。"""


def normalize_profile_id(value: Any, *, field: str = "profile ID") -> str:
    """profile ID 只允许 8–20 位纯数字，保留字符串形态。"""
    s = "" if value is None else str(value).strip()
    if not PROFILE_ID_RE.fullmatch(s):
        raise ValidationError(f"{field} 必须是 8–20 位纯数字，不接受姓名/邮箱/短编号")
    return s


_PROFILE_URL_RE = re.compile(r"[?&]id=(\d{8,20})")


def extract_profile_id(value: Any) -> str:
    """从「各种可能形态」里提取 profile 数字 ID，提不出来返回空串。

    为什么需要（2026-11-18 实机发现）：
        HubStudio 环境的 c_user 字段有时会被填成主页链接——
            https://www.facebook.com/profile.php?id=PROFILE_ID
        accounts.from_envs 直接 (e["c_user"] or "").strip() 入库，
        于是账号表里就存了一条 URL 当 c_user。后果：
            ① 授权/发布按 ID 比对永远对不上
            ② 那个 URL 里的 id 恰是**另一个号**的 ID，
               「从环境建号」会把 A 号的主页算到 B 号名下
    这里统一把 URL / "profile.php?id=" / 裸数字 都归一成数字 ID。
    注意：不做「纯数字校验」，只是尽力解析；调用方自己决定要不要报错。
    """
    s = "" if value is None else str(value).strip()
    if not s:
        return ""
    if PROFILE_ID_RE.fullmatch(s):
        return s
    m = _PROFILE_URL_RE.search(s)
    if m:
        return m.group(1)
    # 兜底：整串里唯一一段长数字
    nums = re.findall(r"\d{8,20}", s)
    return nums[0] if len(nums) == 1 else ""



def require_page(page_id: Any) -> dict:
    pid = "" if page_id is None else str(page_id).strip()
    if not pid:
        raise ValidationError("pageId 不能为空")
    row = db.q1("SELECT page_id, name, asset_id FROM pages WHERE page_id=?", (pid,))
    if not row:
        raise ValidationError(f"主页不存在: {pid}")
    return row


def require_account(account_id: Any) -> dict:
    aid = "" if account_id is None else str(account_id).strip()
    if not aid:
        raise ValidationError("accountId 不能为空")
    row = db.q1("SELECT * FROM accounts WHERE id=? AND enabled=1", (aid,))
    if not row:
        raise ValidationError(f"号不存在或已停用: {aid}")
    return row


def require_account_for_write(account_id: Any, *, role: str = "") -> dict:
    """写授权/建页前要求账号具备有效、唯一的 profile ID。"""
    acc = require_account(account_id)
    if role and acc.get("role") != role:
        raise ValidationError(f"号 {acc['label']} 不是{role}号")
    c_user = normalize_profile_id(acc.get("c_user"), field=f"号 {acc['label']} 的 c_user")
    dup = db.q1(
        "SELECT id,label FROM accounts WHERE c_user=? AND id<>? AND enabled=1",
        (c_user, acc["id"]))
    if dup:
        raise ValidationError(
            f"profile ID {c_user} 同时属于「{acc['label']}」和「{dup['label']}」，"
            "请先修正重复号")
    return {**acc, "c_user": c_user}


def require_account_env(acc: dict) -> dict:
    """建页/真实授权要求该号绑定且运行中的指纹环境。"""
    env_code = str(acc.get("env_code") or "").strip()
    if not env_code:
        raise ValidationError(f"号 {acc['label']} 未绑定指纹环境")
    env = db.q1("SELECT * FROM envs WHERE container_code=?", (env_code,))
    if not env:
        raise ValidationError(f"号 {acc['label']} 绑定环境不存在: {env_code}")
    if env.get("status") != "running" or not env.get("cdp_port"):
        raise ValidationError(
            f"号 {acc['label']} 的环境未启动或没有 CDP 端口: {env_code}")
    return env

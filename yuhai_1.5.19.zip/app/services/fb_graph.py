"""Meta Graph API 纯 HTTP 客户端（不碰浏览器）。

为什么要这个模块
----------------
原来的单条视频采集走 Business Suite 内容库表格：
    · 必须拨 CDP、开标签、滚动虚拟列表 —— 慢
    · 数字是本地化文本（「1.2万」「3,456」），要正则反解析 —— 容易错
    · 表头/列序一改版就整页采空 —— 经常坏

Graph API 直接返回服务端原始整数，一次 HTTP 就是一条视频的全部指标。
这个模块只做三件事：发请求、翻页、把错误分类。

三条口径（实测 / 官方文档确认）
------------------------------
① `/{video-id}/video_insights?period=lifetime` 返回的是**累计值**，
   不是「当天新增」。要算当天新增必须自己拿两次快照相减。
② Reels 和普通视频是**两套指标名**，混着请求会整条报错，必须分组请求。
   文档：https://developers.facebook.com/docs/graph-api/reference/video/video_insights/
③ 视频 Insights 需要 `read_insights` + `pages_read_engagement`，
   且授权人要在该主页上有 ANALYZE 权限。

限流
----
Graph 用 BUC（Business Use Case）计数，超了返回 code 80001。
单个调用要算一次，batch 里每个子请求也算一次。
这里的策略：全局并发信号量 + 命中限流指数退避，不是死等也不是猛冲。
文档：https://developers.facebook.com/docs/graph-api/overview/rate-limiting
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
from dataclasses import dataclass
from typing import Any, Iterable
from urllib.parse import urlsplit

import httpx

log = logging.getLogger("yuhai.fbgraph")

GRAPH_HOST = "https://graph.facebook.com"
DEFAULT_VERSION = "v21.0"

# 可重试（限流 / 后端抖动）
RETRY_CODES = {1, 2, 4, 17, 32, 341, 613, 80001, 80002, 80003, 80004, 80008}
# token 失效
TOKEN_CODES = {102, 190, 459, 463, 467, 492}
# 权限不足
PERM_CODES = {10, 200, 272, 283, 294, 2500}

# ═══ 视频 Insights 指标分组（2026-11-17 实测校准）═══
#
# 重要：这份清单是**逐个打真接口测出来的**，不是照抄文档。
#
# 实测环境：v21.0 + 真实主页 token + 真实 Reel（脱敏）
# 结果：18 个候选里 9 个可用、9 个报 invalid metric。
#
# 为什么和文档不一致：
#   Meta 在 2024-2026 有多轮弃用（impressions 家族、unique 变体、部分 video_views），
#   文档页面本身还写着"deprecated above v25"这类自相矛盾的说明。
#   所以要按**当前版本实际能返回什么**为准，不能按文档标题判断。

# 实测可用 —— Reels 专属
REELS_METRICS = [
    "fb_reels_total_plays",      # 含重播的总播放
    "blue_reels_play_count",     # 不含重播的首播
    "fb_reels_replay_count",     # 重播次数
]

# 实测可用 —— 通用观看行为
WATCH_METRICS = [
    "post_video_view_time",          # 总观看时长（毫秒）
    "post_video_avg_time_watched",   # 平均观看时长（毫秒）
]

# 实测可用 —— 互动
ENGAGE_METRICS = [
    "post_video_social_actions",          # {COMMENT, SHARE}
    "post_video_followers",               # 带来的关注
    "post_video_likes_by_reaction_type",  # {REACTION_LIKE: n}
]

# 单独一组：返回 40 段留存曲线，体积大，按需才拉
RETENTION_METRICS = [
    "post_video_retention_graph",
]

# 实测**不可用**（v21 报 #100 invalid metric）—— 留档，别再试
DEPRECATED_METRICS = [
    "total_video_views",
    "total_video_views_unique",
    "total_video_view_total_time",
    "total_video_avg_time_watched",
    "total_video_complete_views",
    "total_video_impressions",
    "post_impressions_unique",
    "post_video_views",
    "post_reactions_by_type_total",
]

# 默认请求的组合（不含留存曲线，避免每次拉 40 段数据）
VIDEO_METRICS = REELS_METRICS + WATCH_METRICS + ENGAGE_METRICS
COMMON_METRICS = []

# 主页级每日汇总指标（不含已被 Meta 弃用的，见
# https://developers.facebook.com/docs/platforminsights/page/deprecated-metrics）
PAGE_DAILY_METRICS = [
    "page_media_view",
    "page_video_views",
    "page_video_view_time",
    "page_video_views_organic",
    "page_video_views_paid",
    "page_video_complete_views_30s",
    "page_video_repeat_views",
    "page_post_engagements",
    "page_follows",
]


# ---------------- 错误 ----------------
@dataclass
class GraphError(Exception):
    """一个 Graph 调用失败，带分类，方便上层决定「跳过 / 重试 / 报给用户看」。"""

    code: int = 0
    subcode: int = 0
    message: str = ""
    kind: str = "unknown"      # token|permission|rate|param|transient|http|unknown
    status: int = 0
    path: str = ""

    def __str__(self) -> str:
        who = f"{self.path} " if self.path else ""
        return f"{who}[{self.kind}/{self.code}] {self.message}".strip()[:400]

    @property
    def retryable(self) -> bool:
        return self.kind in ("rate", "transient")

    @property
    def needs_relogin(self) -> bool:
        return self.kind == "token"

    @property
    def needs_permission(self) -> bool:
        return self.kind == "permission"

    @property
    def is_abuse(self) -> bool:
        """被判滥用：这个主页/账号要停手，重试只会加重。"""
        return self.kind == "abuse"


def classify(code: int, subcode: int, message: str, status: int) -> str:
    # ⚠ 先按 code 判，再按 HTTP 状态。
    # 反过来写会把「368 = 被判定为滥用」这类业务码错判成泛化 http 错误，
    # 上层就丢掉了「这个主页别再碰了」的关键信号。
    low = (message or "").lower()
    if code in TOKEN_CODES:
        return "token"
    if code in PERM_CODES:
        return "permission"
    # 368/385：账号或主页被判定为滥用。**不是限流，重试只会火上浇油**，
    # 和 rate 分开，上层看到 abuse 要停止该主页并告警。
    if code in (368, 385):
        return "abuse"
    if code in RETRY_CODES:
        return "rate"
    if code == 100:
        return "param"
    if status and status >= 500:
        return "transient"
    if "rate limit" in low or "too many calls" in low:
        return "rate"
    if "permission" in low or "does not have permission" in low:
        return "permission"
    if "session has been invalidated" in low or "access token" in low:
        return "token"
    if "abusive" in low or "disallowed" in low:
        return "abuse"
    if status and status >= 400:
        return "http"
    return "unknown"


# ---------------- insights 响应拆解 ----------------
def flatten_insights(payload: dict) -> dict[str, Any]:
    """把 insights 响应拆成扁平 dict。

    标量指标：{"name":"fb_reels_total_plays","values":[{"value":123}]}  → 123
    分组指标：values[0]["value"] 是 dict → 判断后决定求和还是原样保留

    ⚠ 分组指标分两种，混为一谈会算错：
      · 维度型（按国家 ID / 年龄桶拆分）key 是数字 → 求和得到总数，有意义
      · 动作型（post_video_social_actions = {COMMENT, SHARE}）key 是枚举名
        → **绝不能求和**，46 既不是评论数也不是分享数，
          必须原样保留让上层按 key 拆。
    """
    out: dict[str, Any] = {}
    for item in (payload or {}).get("data") or []:
        name = item.get("name")
        if not name:
            continue
        vals = item.get("values") or []
        if not vals:
            continue
        v = vals[-1]
        val = v.get("value")
        if isinstance(val, dict):
            keys = list(val.keys())
            numeric_keys = bool(keys) and all(
                isinstance(k, int) or (isinstance(k, str) and k.strip().isdigit())
                for k in keys)
            nums = [x for x in val.values() if isinstance(x, (int, float))]
            if numeric_keys and nums and len(nums) == len(val):
                out[name] = int(sum(nums))
            else:
                out[name] = val        # 动作型枚举 key：原样给上层拆
        elif isinstance(val, (int, float)) and not isinstance(val, bool):
            out[name] = int(val)
    return out


def _num(v: Any) -> int:
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int, float)):
        return int(v)
    return 0


# ---------------- 客户端 ----------------
class Graph:
    """一个 Graph 客户端。token 可以是用户 token 或主页 token。

    并发与退避
    ----------
    · 全局 Semaphore 控制同时在飞的请求数（默认 4）
    · 每页/每次调用之间不额外 sleep：Graph 的限流是计数型，不是频率型
    · 命中 rate 类错误时指数退避 + 抖动，最多重试 retries 次
    """

    def __init__(self, token: str, version: str = DEFAULT_VERSION,
                 timeout: float = 25.0, concurrency: int = 4,
                 retries: int = 4) -> None:
        self.token = (token or "").strip()
        v = (version or DEFAULT_VERSION).strip()
        self.version = v if v.startswith("v") else "v" + v
        self.timeout = timeout
        self.retries = retries
        self._sem = asyncio.Semaphore(max(1, int(concurrency)))
        self._client: httpx.AsyncClient | None = None
        # 统计（给 job result 用）
        self.calls = 0
        self.failures = 0
        self.last_error: str = ""

    # ---- 生命周期 ----
    async def __aenter__(self) -> "Graph":
        await self.open()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    async def open(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout, connect=10.0),
                follow_redirects=True,
                headers={"User-Agent": "yuhai-workbench/graph"},
            )

    async def close(self) -> None:
        if self._client is not None:
            try:
                await self._client.aclose()
            except Exception:
                pass
            self._client = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Graph client 未初始化，先 open()")
        return self._client

    # ---- 单次请求 ----
    async def _request(self, method: str, url: str, params: dict | None = None,
                       data: dict | None = None, path_label: str = "") -> dict:
        await self.open()
        p = dict(params or {})
        # 绝对 URL（paging.next）里已经带过 access_token，不能再塞一个
        if "access_token" not in p and "access_token=" not in url:
            p["access_token"] = self.token

        attempt = 0
        while True:
            attempt += 1
            self.calls += 1
            try:
                async with self._sem:
                    if method == "GET":
                        r = await self.client.get(url, params=p)
                    else:
                        r = await self.client.post(url, params=p, data=data)
            except httpx.HTTPError as e:
                self.failures += 1
                err = GraphError(message=f"网络错误: {e}", kind="transient",
                                 path=path_label)
                if attempt <= self.retries:
                    await asyncio.sleep(self._backoff(attempt))
                    continue
                self.last_error = str(err)
                raise err from None

            if r.status_code == 200:
                try:
                    return r.json()
                except Exception as e:
                    # 200 但 body 不是 JSON：极少数情况下是网关错误页
                    err = GraphError(message=f"响应非 JSON: {e}",
                                     kind="transient", status=r.status_code,
                                     path=path_label)
                    if attempt <= self.retries:
                        await asyncio.sleep(self._backoff(attempt))
                        continue
                    self.last_error = str(err)
                    raise err from None

            # 错误
            try:
                body = r.json()
            except Exception:
                body = {}
            eobj = (body or {}).get("error") or {}
            code = _num(eobj.get("code")) or r.status_code
            subcode = _num(eobj.get("error_subcode"))
            msg = eobj.get("message") or (r.text or "")[:200]
            kind = classify(code, subcode, msg, r.status_code)
            err = GraphError(code=code, subcode=subcode, message=str(msg)[:400],
                             kind=kind, status=r.status_code, path=path_label)
            self.failures += 1
            self.last_error = str(err)

            if kind in ("rate", "transient") and attempt <= self.retries:
                wait = self._backoff(attempt)
                log.warning("graph %s 限流/抖动(%s/%s)，%.1fs 后重试 %d/%d",
                            path_label or url[:60], code, subcode, wait,
                            attempt, self.retries)
                await asyncio.sleep(wait)
                continue
            raise err

    @staticmethod
    def _backoff(attempt: int) -> float:
        base = min(60.0, 2.0 * (2 ** (attempt - 1)))
        return base + random.uniform(0, base * 0.35)

    def url(self, path: str) -> str:
        if path.startswith("http"):
            return path
        return f"{GRAPH_HOST}/{self.version}/{path.lstrip('/')}"

    # ---- GET ----
    async def get(self, path: str, params: dict | None = None) -> dict:
        return await self._request("GET", self.url(path), params, path_label=path[:120])

    # ---- token 工具 ----
    async def debug_token(self, token: str = "") -> dict:
        """用当前 token 自查另一个 token 的有效期/权限/所属 app。

        ⚠ 官方要求用 **app access token**（`{app-id}|{app-secret}`）来 debug，
        用普通 user token 调会报 100/无权限。这里容忍失败并回传原始错误，
        上层据此判断「是 debug 不可用」还是「token 真有问题」。
        """
        try:
            r = await self._request(
                "GET", self.url("debug_token"),
                {"input_token": token or self.token},
                path_label="debug_token")
            return (r or {}).get("data") or {}
        except GraphError as e:
            return {"_error": str(e), "_kind": e.kind}

    async def exchange_long_lived(self, app_id: str, app_secret: str) -> dict:
        """短效 user token → 60 天长期 token。

        Explorer 给的 token 只有 1~2 小时，必须换成长效的才能让定时采集跑起来。
        文档：GET /oauth/access_token?grant_type=fb_exchange_token
        必须带 client_id(client=app id) + client_secret，所以需要 app secret。

        返回 {"access_token": ..., "expires_in": ...} 或抛 GraphError。
        """
        if not app_id or not app_secret:
            raise GraphError(message="缺少 app_id / app_secret，无法换取长期 token",
                             kind="param", path="oauth/access_token")
        # 注意：这个端点走 GET，且 **不能** 自动附加 access_token（否则会报
        # 「不能同时使用两种认证方式」）。用 _request 的 raw 形式绕开。
        await self.open()
        params = {
            "grant_type": "fb_exchange_token",
            "client_id": app_id,
            "client_secret": app_secret,
            "fb_exchange_token": self.token,
        }
        try:
            async with self._sem:
                r = await self.client.get(self.url("oauth/access_token"),
                                          params=params)
        except httpx.HTTPError as e:
            raise GraphError(message=f"网络错误: {e}", kind="transient",
                             path="oauth/access_token") from None
        if r.status_code != 200:
            try:
                eobj = (r.json() or {}).get("error") or {}
            except Exception:
                eobj = {}
            code = _num(eobj.get("code")) or r.status_code
            msg = eobj.get("message") or (r.text or "")[:200]
            raise GraphError(code=code, subcode=_num(eobj.get("error_subcode")),
                             message=str(msg)[:400],
                             kind=classify(code, _num(eobj.get("error_subcode")),
                                           msg, r.status_code),
                             status=r.status_code, path="oauth/access_token")
        return r.json() or {}

    # ---- 翻页 ----
    async def paged(self, path: str, params: dict | None = None,
                    max_pages: int = 20, stop=None) -> list[dict]:
        """按 next 游标翻页，最多 max_pages 页。

        stop(row) 返回 True 时提前停止（比如 created_time 超出窗口）。
        """
        out: list[dict] = []
        d = await self.get(path, params)
        pages = 0
        while True:
            pages += 1
            data = (d or {}).get("data") or []
            stop_hit = False
            for row in data:
                if not isinstance(row, dict):
                    continue
                out.append(row)
                if stop is not None:
                    try:
                        if stop(row):
                            stop_hit = True
                            break
                    except Exception:
                        pass
            nxt = ((d or {}).get("paging") or {}).get("next")
            if stop_hit or not nxt or pages >= max_pages:
                break
            d = await self._request("GET", nxt, None, path_label=path[:120] + "(next)")
        return out

    # ---- batch ----
    async def batch(self, requests: list[dict], chunk: int = 50) -> list[dict]:
        """批量请求。每个子请求独立成败，返回顺序与入参一致。

        requests 元素：{"method":"GET","relative_url":"..."}
        chunk 默认 50（Graph 硬上限）。
        文档：https://developers.facebook.com/docs/graph-api/batch-requests
        """
        out: list[dict] = []
        for i in range(0, len(requests), max(1, chunk)):
            part = requests[i:i + chunk]
            body = {
                "batch": json.dumps(part, ensure_ascii=False),
                "include_headers": "false",
                "access_token": self.token,
            }
            try:
                raw = await self._request("POST", self.url(""), None, data=body,
                                         path_label="batch")
            except GraphError as e:
                log.warning("batch 失败: %s", e)
                out.extend([{"ok": False, "error": str(e)}] * len(part))
                continue
            items = raw if isinstance(raw, list) else (raw.get("data") or [])
            for it in items:
                if not isinstance(it, dict):
                    out.append({"ok": False, "error": "bad batch item"})
                    continue
                code = it.get("code")
                bd = it.get("body")
                if code == 200 and bd:
                    try:
                        out.append({"ok": True, "data": json.loads(bd)})
                    except Exception:
                        out.append({"ok": False, "error": "body 非 JSON"})
                else:
                    msg = ""
                    try:
                        msg = ((json.loads(bd or "{}").get("error") or {})
                               .get("message") or "")
                    except Exception:
                        msg = str(bd)[:150]
                    out.append({"ok": False, "code": code, "error": msg[:200]})
            # 补齐（部分超时批次会少返回）
            while len(out) < i + len(part):
                out.append({"ok": False, "error": "batch 未返回该项"})
        return out

    # ================= 业务接口 =================
    async def me(self) -> dict:
        return await self.get("me", {"fields": "id,name"})

    async def me_accounts(self, limit: int = 100) -> list[dict]:
        rows = await self.paged(
            "me/accounts",
            {"fields": "id,name,access_token,tasks,followers_count",
             "limit": limit},
            max_pages=10,
        )
        return rows

    async def page_videos(self, page_id: str, since_ts: int | None = None,
                          limit: int = 100, max_pages: int = 20) -> list[dict]:
        """主页的视频清单（含 reels，因为 reels 也是 video 对象）。

        只取清单需要的轻字段；指标走 video_insights。
        """
        fields = ("id,title,description,created_time,length,permalink_url,"
                  "status,updated_time")
        rows = await self.paged(
            f"{page_id}/videos",
            {"fields": fields, "limit": limit},
            max_pages=max_pages,
            stop=(lambda r: _created_ts(r) < since_ts) if since_ts else None,
        )
        if since_ts:
            rows = [r for r in rows if (_created_ts(r) or 0) >= since_ts]
        return rows

    # ---- 永久令牌：系统用户 ----
    async def my_businesses(self) -> list[dict]:
        """当前身份所属的 Business Manager 列表。

        用来判断「能不能走系统用户这条路」（系统用户令牌永不过期）。
        """
        try:
            rows = await self.paged("me/businesses",
                                    {"fields": "id,name", "limit": 50},
                                    max_pages=2)
            return rows
        except GraphError as e:
            if e.needs_permission:
                return []
            raise

    async def business_pages(self, business_id: str) -> list[dict]:
        """某个 BM 名下管理的主页（自有 + 客户）。"""
        out: list[dict] = []
        for edge in ("owned_pages", "client_pages"):
            try:
                rows = await self.paged(
                    f"{business_id}/{edge}",
                    {"fields": "id,name", "limit": 100}, max_pages=10)
                out.extend(rows)
            except GraphError as e:
                log.debug("bm %s %s: %s", business_id, edge, e)
        return out

    async def page_token_from_page(self, page_id: str) -> str:
        """用当前令牌换取某个主页的**专属主页令牌**。

        关键用途：
          · 当前令牌是 **长期用户令牌**（60 天）→ 换出的主页令牌**永不过期**
          · 当前令牌是 **系统用户令牌**（永不过期）→ 换出的主页令牌**永不过期**
          · 当前令牌是短效令牌 → 换出的主页令牌也是短效的（无意义）

        这就是「永久令牌」的正确做法：先把用户令牌换成长期，
        再派生主页令牌，而不是直接用探索器的短效令牌。
        文档：GET /{page-id}?fields=access_token
        """
        d = await self.get(page_id, {"fields": "access_token,name"})
        return str((d or {}).get("access_token") or "").strip()

    async def video_insights(self, video_id: str,
                             groups: Iterable[list[str]] | None = None,
                             period: str = "lifetime",
                             with_retention: bool = False) -> dict[str, Any]:
        """单条视频的全部累计指标。

        分组请求：一组全废不影响别组。返回扁平 dict（可能为空）。

        with_retention=True 时才拉留存曲线（返回 40 段数据，体积大）。
        默认组用 VIDEO_METRICS（已按实测校准过，只含可用的指标名）。
        """
        if groups is None:
            gs: list[list[str]] = [VIDEO_METRICS]
            if with_retention:
                gs.append(RETENTION_METRICS)
        else:
            gs = list(groups)
        groups = gs
        out: dict[str, Any] = {}
        errors: list[str] = []
        for g in groups:
            if not g:
                continue
            try:
                d = await self.get(
                    f"{video_id}/video_insights",
                    {"metric": ",".join(g), "period": period})
                out.update(flatten_insights(d))
            except GraphError as e:
                errors.append(f"{','.join(g[:2])}…: {e}")
                if e.needs_relogin:
                    # token 废了，后面几组也没意义
                    break
                continue
        if errors:
            out["_errors"] = errors
        return out

    async def batch_video_insights(self, video_ids: list[str],
                                   period: str = "lifetime") -> dict[str, dict]:
        """批量拉多条视频的指标（一次 batch 拿全部可用指标）。

        比逐条请求少 N 倍往返，但内部每个子请求仍然计一次配额。
        用 VIDEO_METRICS（实测校准过的清单），不拉留存曲线。
        """
        result: dict[str, dict] = {vid: {} for vid in video_ids}
        if not video_ids:
            return result
        for g in (VIDEO_METRICS,):
            reqs = [{"method": "GET",
                     "relative_url": f"{vid}/video_insights"
                                     f"?metric={','.join(g)}&period={period}"}
                    for vid in video_ids]
            res = await self.batch(reqs)
            for vid, item in zip(video_ids, res):
                if item.get("ok"):
                    result.setdefault(vid, {}).update(
                        flatten_insights(item.get("data") or {}))
        return result

    async def page_insights(self, page_id: str, metrics: list[str] | None = None,
                            since: str = "", until: str = "",
                            period: str = "day") -> dict[str, Any]:
        """主页级每日指标。

        · 多数指标约 24 小时更新一次，不需要高频拉
        · 点赞数不足 100 的主页可能没有数据
        · since/until 一次最多查 90 天
        """
        metrics = metrics or PAGE_DAILY_METRICS
        params: dict[str, Any] = {"metric": ",".join(metrics), "period": period}
        if since:
            params["since"] = since
        if until:
            params["until"] = until
        try:
            d = await self.get(f"{page_id}/insights", params)
            return flatten_insights(d)
        except GraphError as e:
            # 指标可能因弃用而整条报错，退化成逐个请求
            log.info("page_insights 整组失败(%s)，改逐个请求", e)
            out: dict[str, Any] = {}
            for m in metrics:
                try:
                    d = await self.get(f"{page_id}/insights",
                                       {**params, "metric": m})
                    out.update(flatten_insights(d))
                except GraphError:
                    continue
            return out

    async def page_insights_series(self, page_id: str,
                                   metrics: list[str] | None = None,
                                   since: str = "", until: str = "",
                                   period: str = "day") -> dict[str, list[dict]]:
        """主页级**按天序列**（保留每天的值，用于画趋势图）。"""
        metrics = metrics or PAGE_DAILY_METRICS
        params: dict[str, Any] = {"metric": ",".join(metrics), "period": period}
        if since:
            params["since"] = since
        if until:
            params["until"] = until
        try:
            d = await self.get(f"{page_id}/insights", params)
        except GraphError as e:
            log.info("page_insights_series 失败: %s", e)
            return {}
        out: dict[str, list[dict]] = {}
        for item in (d or {}).get("data") or []:
            name = item.get("name")
            if not name:
                continue
            out[name] = item.get("values") or []
        return out


def _created_ts(row: dict) -> int:
    """created_time（ISO8601）→ unix 秒；解析不了返回 0。"""
    s = (row or {}).get("created_time") or ""
    if not s:
        return 0
    try:
        import datetime as _dt
        # 形如 2026-11-12T07:51:00+0000
        return int(_dt.datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S")
                   .replace(tzinfo=_dt.timezone.utc).timestamp())
    except Exception:
        return 0


def iso_date(created_time: str) -> str:
    """created_time → 本地日期 YYYY-MM-DD。"""
    if not created_time:
        return ""
    try:
        import datetime as _dt
        s = created_time.replace("Z", "+0000")
        for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S"):
            try:
                dt = _dt.datetime.strptime(s, fmt)
                if dt.tzinfo:
                    dt = dt.astimezone()
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                continue
    except Exception:
        pass
    return (created_time or "")[:10]


def token_of_url(url: str) -> str:
    """从 paging.next 里抠 access_token（调试用）。"""
    try:
        q = urlsplit(url).query
        for kv in q.split("&"):
            if kv.startswith("access_token="):
                return kv.split("=", 1)[1]
    except Exception:
        pass
    return ""

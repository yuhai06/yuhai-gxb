# -*- coding: utf-8 -*-
"""dsh_setup.py — 自动配置 DSH headless profile

作用
----
用户显式点"修复 DSH 接入"时，把模板写进
~/.dsh/profiles/headless/cordis.patch.yml，内容是：
  - 补权限预设
  - 禁用 DSH 自带的重叠工具（bash/fs/search/workflow/subagent）
  - 挂雨海 MCP（端口按实际监听端口）

安全边界
--------
启动过程不再自动写外部 profile。只有显式安装 API 才会调用 install()。

已有文件只有在「与当前模板逐字一致，仅端口不同」时才视为托管配置，
默认仅允许更新端口。任何其他修改都视为用户自定义配置：默认拒绝覆盖，
必须显式 force=True；强制覆盖前必须成功备份，否则原文件保持不变。
"""
from __future__ import annotations

import logging
import os
import re
import shutil
import time
from pathlib import Path

log = logging.getLogger("yuhai.dsh.setup")

TEMPLATE_REL = Path("app") / "templates" / "dsh_headless_patch.yml"
PORT_TOKEN = "{PORT}"
MCP_MARK = "mcp-yuhai"
MCP_URL_TEMPLATE = "http://127.0.0.1:%d/mcp/"


def dsh_home() -> Path:
    return Path(os.path.expanduser("~")) / ".dsh"


def patch_path() -> Path:
    return dsh_home() / "profiles" / "headless" / "cordis.patch.yml"


def template_path() -> Path:
    """模板文件位置（兼容打包后的 frozen 布局）。"""
    import sys
    base = Path(getattr(sys, "_MEIPASS", "")) if getattr(sys, "frozen", False) else None
    if base:
        p = base / TEMPLATE_REL
        if p.exists():
            return p
    # 从本文件回溯到 backend 根
    here = Path(__file__).resolve()
    for parent in [here.parent.parent, here.parent.parent.parent]:
        p = parent / "app" / "templates" / "dsh_headless_patch.yml"
        if p.exists():
            return p
        p = parent / TEMPLATE_REL
        if p.exists():
            return p
    return Path("")


def _read_template_text() -> str:
    tpl = template_path()
    if not tpl or not tpl.exists():
        raise FileNotFoundError("找不到配置模板: %s" % tpl)
    text = tpl.read_text(encoding="utf-8")
    if PORT_TOKEN not in text:
        raise ValueError("配置模板缺少 %s 占位符" % PORT_TOKEN)
    return text


def _normalize_newlines(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def _managed_template_port(text: str, template_text: str) -> int | None:
    """返回托管配置中的端口；不是托管配置则返回 None。

    判定必须保守：除端口占位符外，全文必须与模板完全一致。
    这样用户只要改过其它任何一行，就不会被当作可自动改端口的托管文件。
    """
    tpl = _normalize_newlines(template_text)
    cur = _normalize_newlines(text)
    parts = tpl.split(PORT_TOKEN)
    if len(parts) < 2:
        return None
    pattern = re.escape(parts[0])
    for index, part in enumerate(parts[1:]):
        pattern += r"(?P<port%d>[0-9]{1,5})" % index
        pattern += re.escape(part)
    match = re.fullmatch(pattern, cur)
    if not match:
        return None
    ports = {int(match.group("port%d" % index))
             for index in range(len(parts) - 1)}
    if len(ports) != 1:
        return None
    port = ports.pop()
    if port < 1 or port > 65535:
        return None
    return port


def _render_template(template_text: str, port: int) -> str:
    return template_text.replace(PORT_TOKEN, str(port))


def _find_yuhai_mcp_url(text: str) -> str:
    """只读取 id 为 mcp-yuhai 的条目的 url，避免抓错其它 MCP。"""
    lines = text.splitlines()
    id_re = re.compile(
        r"^(?P<indent>[ \t]*)-[ \t]+id:[ \t]*['\"]?mcp-yuhai['\"]?[ \t]*(?:#.*)?$"
    )
    url_re = re.compile(r"^[ \t]*url:[ \t]*(?P<value>[^#\r\n]+?)[ \t]*(?:#.*)?$")
    for index, line in enumerate(lines):
        match = id_re.match(line)
        if not match:
            continue
        base_indent = len(match.group("indent"))
        for candidate in lines[index + 1:]:
            stripped = candidate.strip()
            if not stripped or stripped.startswith("#"):
                continue
            indent = len(candidate) - len(candidate.lstrip(" \t"))
            if indent <= base_indent:
                break
            url_match = url_re.match(candidate)
            if url_match:
                return url_match.group("value").strip().strip("'\"")
    return ""


def status() -> dict:
    """查当前 DSH profile 的配置状态；读取异常时按需要修复处理。"""
    pp = patch_path()
    home = dsh_home()

    out = {
        "dshHome": str(home),
        "dshInstalled": home.exists(),
        "patchFile": str(pp),
        "patchExists": pp.exists(),
        "hasMcp": False,
        "toolsDisabled": False,
        "mcpUrl": "",
        "needFix": True,
        "managed": False,
    }

    if not pp.exists():
        return out

    try:
        txt = pp.read_text(encoding="utf-8")
    except Exception as e:
        out["error"] = "读取 DSH 配置失败: %s" % e
        return out

    try:
        tpl_text = _read_template_text()
    except Exception as e:
        tpl_text = ""
        out["error"] = "读取配置模板失败: %s" % e

    managed_port = _managed_template_port(txt, tpl_text) if tpl_text else None
    yuhai_url = _find_yuhai_mcp_url(txt)

    out["hasMcp"] = bool(yuhai_url)
    out["toolsDisabled"] = managed_port is not None
    out["managed"] = managed_port is not None
    out["needFix"] = managed_port is None
    if managed_port is not None:
        out["mcpUrl"] = yuhai_url or (MCP_URL_TEMPLATE % managed_port)
    else:
        out["mcpUrl"] = yuhai_url
    return out


def _resolve_port(port: int) -> int:
    try:
        value = int(port or 0)
    except Exception:
        value = 0
    if not value:
        try:
            value = int(os.environ.get("YUHAI_PORT", "") or 0)
        except Exception:
            value = 0
    if not value:
        try:
            from app.config import settings
            value = int(settings.port or 0)
        except Exception:
            value = 0
    if not value:
        value = 8710
    if value < 1 or value > 65535:
        value = 8710
    return value


def _backup_existing(pp: Path) -> Path:
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = pp.with_name(pp.name + ".bak-" + stamp)
    shutil.copy2(pp, backup)
    return backup


def install(port: int = 0, force: bool = False) -> dict:
    """写入/修复 DSH headless 配置。

    port  : 雨海实际监听端口（0 = 自动推断）
    force : 强制覆盖非托管配置（写入前必须成功备份）
    """
    home = dsh_home()
    if not home.exists():
        return {"ok": False,
                "error": "没检测到 DSH（%s 不存在）。装了 DSH 再试。" % home}

    try:
        tpl_text = _read_template_text()
    except Exception as e:
        return {"ok": False, "error": "读模板失败: %s" % e}

    port = _resolve_port(port)
    pp = patch_path()
    try:
        pp.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {"ok": False, "error": "创建 DSH 配置目录失败: %s" % e}

    current = None
    if pp.exists():
        try:
            current = pp.read_text(encoding="utf-8")
        except Exception as e:
            return {"ok": False,
                    "error": "读取现有 DSH 配置失败，未修改原文件: %s" % e}

    if current is not None and not force:
        managed_port = _managed_template_port(current, tpl_text)
        if managed_port is None:
            result = status()
            result.update({
                "ok": False,
                "error": ("检测到非托管的 DSH 配置，已拒绝覆盖且未修改文件；"
                          "如确认覆盖请传 force=True（会先备份）。"),
            })
            return result
        if managed_port == port:
            return {"ok": True, "skipped": True,
                    "reason": "已配置好", **status()}

        body = _render_template(tpl_text, port)
        try:
            pp.write_text(body, encoding="utf-8", newline="\n")
        except Exception as e:
            return {"ok": False, "error": "改端口失败: %s" % e}
        log.info("DSH profile 端口更新为 %d", port)
        return {"ok": True, "updated": "port", "port": port, **status()}

    backup = ""
    if current is not None:
        try:
            backup = str(_backup_existing(pp))
        except Exception as e:
            return {"ok": False,
                    "error": "备份现有 DSH 配置失败，未修改原文件: %s" % e}

    body = _render_template(tpl_text, port)
    try:
        pp.write_text(body, encoding="utf-8", newline="\n")
    except Exception as e:
        return {"ok": False, "error": "写配置失败: %s" % e}

    log.info("DSH headless 配置已写入: %s (port=%d, backup=%s)",
             pp, port, backup or "无")

    return {"ok": True, "written": str(pp), "port": port,
            "backup": backup, **status()}


def verify() -> dict:
    """跑 dsh --dump-config 验证配置是否被接受。"""
    import subprocess
    st = status()
    if not st["patchExists"]:
        return {"ok": False, "error": "配置文件不存在"}

    bin_ = ""
    for n in ("dsh.cmd", "dsh.exe", "dsh"):
        c = shutil.which(n)
        if c:
            bin_ = c
            break
    if not bin_:
        return {"ok": False, "error": "找不到 dsh 命令"}

    try:
        r = subprocess.run(
            [bin_, "--profile", "headless", "--dump-config"],
            capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60,
            creationflags=(0x08000000 if os.name == "nt" else 0))
        out = (r.stdout or "") + (r.stderr or "")
        has_mcp = MCP_MARK in out
        has_err = "not found" in out.lower() or "error" in out.lower()
        disabled = out.count("disabled: true")
        return {
            "ok": has_mcp and not has_err,
            "hasMcpInDump": has_mcp,
            "disabledCount": disabled,
            "error": "" if not has_err else
                     "\n".join([l for l in out.split("\n")
                                if "error" in l.lower() or "not found" in l.lower()][:3]),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}

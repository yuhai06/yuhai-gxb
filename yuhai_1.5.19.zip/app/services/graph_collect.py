"""Graph API 采集编排：纯 HTTP，不碰浏览器。

和 metrics.py 的分工
--------------------
    metrics.py       —— 原来的 CDP 表格方案（保留为兜底 + 补缺失字段）
    graph_collect.py —— 新的主通道：/me/accounts 取 token → /{page}/videos 取清单
                        → /{video}/video_insights 取指标，全部走 HTTPS

为什么要单独一层
----------------
① 现在 videos.py 的采集**强制要求「发布号环境在运行」**，因为要拨 CDP。
   API 采集根本不需要浏览器，不该被这个前置条件卡住。
② 指标口径要集中处理：Reels 与普通视频是两套指标名，
   「累计值 vs 当天新增」必须在这一层算清，不能散在 SQL 里。

指标口径（重要，别混）
----------------------
    reels_plays       fb_reels_total_plays        含重播
    reels_first_play  blue_reels_play_count       不含重播
    reels_replay      fb_reels_replay_count
    video_views_3s    total_video_views           普通视频 3 秒口径
    reach             post_impressions_unique     估算值，不是精确人数
    watch_sec         post_video_view_time / 1000 官方单位是**毫秒**
    avg_watch         post_video_avg_time_watched/1000

`video_insights?period=lifetime` 返回累计值。所以要：
    · 快照表按 (unit, metric, 采样日) 存原始累计值
    · 「当天新增」= 今天快照 − 昨天快照（见 daily_delta）
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import date, datetime, timedelta
from typing import Any

from app.config import settings
from app.db import db, now_iso
from app.services import fb_graph as G

log = logging.getLogger("yuhai.graph_collect")

INTEG_ID = "graph"
KV_TOKEN = "graph.token"


# ---------------- token 存取 ----------------
def graph_token() -> str:
    """当前 Graph token。

    优先级：
      ① integrations 表 graph.config.token（用户在「第三方对接」里填的）
      ② kv graph.token（程序自动换取后写入，刷新时不覆盖手填的）
    """
    row = db.q1("SELECT config FROM integrations WHERE id=?", (INTEG_ID,))
    if row:
        try:
            t = (json.loads(row["config"] or "{}") or {}).get("token") or ""
            if t.strip():
                return t.strip()
        except Exception:
            pass
    return str(db.get_kv(KV_TOKEN, "") or "").strip()


def save_graph_token(token: str, note: str = "") -> dict:
    token = (token or "").strip()
    if not token:
        return {"ok": False, "error": "token 为空"}
    now = now_iso()
    row = db.q1("SELECT * FROM integrations WHERE id=?", (INTEG_ID,))
    cfg = {}
    if row:
        try:
            cfg = json.loads(row["config"] or "{}") or {}
        except Exception:
            cfg = {}
    cfg["token"] = token
    if note:
        cfg["note"] = note
    if row:
        db.exec("UPDATE integrations SET enabled=1, config=?, state='configured',"
                " updated_at=? WHERE id=?",
                (json.dumps(cfg, ensure_ascii=False), now, INTEG_ID))
    else:
        db.exec("INSERT INTO integrations(id,kind,label,enabled,config,state,updated_at)"
                " VALUES(?,?,?,?,?,?,?)",
                (INTEG_ID, "官方接口", "Meta Graph API", 1,
                 json.dumps(cfg, ensure_ascii=False), "configured", now))
    return {"ok": True, "len": len(token),
            "preview": token[:6] + "…" + token[-4:] if len(token) > 12 else "…"}


def page_token(page_id: str) -> str:
    """主页自己的 token；没有就退回全局 token（全局 token 也能读自己有权限的主页）。"""
    r = db.q1("SELECT token,state FROM fb_page_tokens WHERE page_id=?", (page_id,))
    if r and (r.get("token") or "").strip() and r.get("state") == "ok":
        return r["token"].strip()
    return graph_token()


def save_page_token(page_id: str, token: str, state: str = "ok") -> dict:
    """保存主页专用 token（2026-11-16 新增，供 refresh_page_tokens 用）。

    采数据必须用 page token：`/{page}/videos` 和
    `/{video}/video_insights` 拿 user token 会返回不完整数据。
    """
    pid = str(page_id or "").strip()
    tk = (token or "").strip()
    if not pid or not tk:
        return {"ok": False, "error": "page_id / token 不能为空"}
    from app.db import now_iso
    try:
        db.exec(
            "INSERT INTO fb_page_tokens(page_id,token,state,updated_at) "
            "VALUES(?,?,?,?) "
            "ON CONFLICT(page_id) DO UPDATE SET "
            "token=excluded.token,state=excluded.state,updated_at=excluded.updated_at",
            (pid, tk, state, now_iso()))
        return {"ok": True, "pageId": pid, "tokenLength": len(tk)}
    except Exception:
        # 表没有 ON CONFLICT 时退回先删后插
        try:
            db.exec("DELETE FROM fb_page_tokens WHERE page_id=?", (pid,))
            db.exec("INSERT INTO fb_page_tokens(page_id,token,state,updated_at) "
                    "VALUES(?,?,?,?)", (pid, tk, state, now_iso()))
            return {"ok": True, "pageId": pid, "tokenLength": len(tk)}
        except Exception as e:
            return {"ok": False, "error": str(e)[:120]}


# ---------------- app 凭据（换长期 token 用） ----------------
KV_APP_ID = "graph.app_id"
KV_APP_SECRET = "graph.app_secret"


def app_creds() -> dict:
    """当前生效的 App 凭据。

    ⚠ 两个数据源的历史包袱（2026-11-15 修）：
      · 早期版本把 App ID/Secret 存在 integrations.graph.config 里
      · 多 App 功能上线后加了 fb_apps 表
    如果只读其中一处，就会出现「填了凭据但多 App 区还是空的，
    根本没有『设主用』按钮」这种断链。

    现在的优先级：
      ① fb_apps 里 role='primary' 且有 secret 的
      ② fb_apps 里任意有 secret 的（只有一个 App 时它就是主用）
      ③ integrations.config（旧数据兼容）
      ④ kv（更早的版本）
    """
    r = db.q1("SELECT app_id, app_secret FROM fb_apps "
              "WHERE role='primary' AND app_secret<>'' ORDER BY added_at LIMIT 1")
    if not r:
        r = db.q1("SELECT app_id, app_secret FROM fb_apps "
                  "WHERE app_secret<>'' ORDER BY added_at LIMIT 1")
    if r:
        return {"appId": str(r["app_id"] or "").strip(),
                "appSecret": str(r["app_secret"] or "").strip()}
    row = db.q1("SELECT config FROM integrations WHERE id=?", (INTEG_ID,))
    cfg = {}
    if row:
        try:
            cfg = json.loads(row["config"] or "{}") or {}
        except Exception:
            cfg = {}
    return {
        "appId": str(cfg.get("app_id") or db.get_kv(KV_APP_ID, "") or "").strip(),
        "appSecret": str(cfg.get("app_secret")
                         or db.get_kv(KV_APP_SECRET, "") or "").strip(),
    }


def save_app_creds(app_id: str = "", app_secret: str = "") -> dict:
    """保存 App 凭据。**同时写进 fb_apps**，保证多 App 区立刻能看到。

    这是修掉「填了凭据但多 App 列表还是空」的关键：
    历史上这个函数只写 integrations.config，而多 App 界面读 fb_apps，
    两个数据源不一致，用户填完看不到任何 App，自然也就没法「设主用」。

    实现在文件后半段（_save_app_creds_impl），这里只是前置声明，
    因为 save_app() 定义在下方，直接调用会 NameError。
    """
    return _save_app_creds_impl(app_id, app_secret)


# ---------------- 多 App 管理（2026-11-15） ----------------
#
# 为什么要有这一层
# ----------------
# token 是 **App 签发** 的。App 被限制/删除，它签发的所有 token 当场一起失效。
# 不记「token 来自哪个 App」，出事时只能看到「采不到了」，
# 看不出「是谁挂了、连累了几个主页、要不要切备用」。
#
# 所以这里做三件事：
#   ① fb_apps 表登记每个 App（含备用），记录状态
#   ② fb_page_tokens 记住每个主页 token 是哪个 App 发的
#   ③ blast_radius() 算出「某个 App 挂掉会损失多少主页」

def list_apps() -> list[dict]:
    """全部已登记 App，附带各自撑了多少主页。"""
    rows = db.q("SELECT * FROM fb_apps ORDER BY "
                "CASE role WHEN 'primary' THEN 0 ELSE 1 END, added_at")
    counts = {r["app_id"]: r for r in db.q(
        "SELECT app_id, COUNT(*) n,"
        " SUM(CASE WHEN state='ok' THEN 1 ELSE 0 END) ok_n"
        " FROM fb_page_tokens WHERE app_id IS NOT NULL AND app_id<>''"
        " GROUP BY app_id")}
    out = []
    for r in rows:
        c = counts.get(r["app_id"]) or {}
        out.append({
            "appId": r["app_id"],
            "label": r["label"] or r["app_id"],
            "role": r["role"],
            "note": r["note"] or "",
            "state": r["state"],
            "lastError": r["last_error"],
            "addedAt": r["added_at"],
            "lastUsed": r["last_used"],
            "hasSecret": bool((r["app_secret"] or "").strip()),
            "pages": int(c.get("n") or 0),
            "pagesOk": int(c.get("ok_n") or 0),
        })
    return out


def save_app(app_id: str, label: str = "", app_secret: str = "",
             role: str = "primary", note: str = "") -> dict:
    """新增或更新一个 App 登记。"""
    app_id = (app_id or "").strip()
    if not app_id:
        return {"ok": False, "error": "App ID 为空"}
    if not app_id.isdigit():
        return {"ok": False,
                "error": "App ID 应该是一串纯数字（在「设置 → 基本」最上方）"}
    now = now_iso()
    ex = db.q1("SELECT * FROM fb_apps WHERE app_id=?", (app_id,))
    if ex:
        db.exec("UPDATE fb_apps SET label=?, app_secret=?, role=?, note=?,"
                " last_check=? WHERE app_id=?",
                (label or ex["label"] or app_id,
                 (app_secret.strip() or ex["app_secret"] or ""),
                 role or ex["role"], note or ex["note"] or "", now, app_id))
    else:
        db.exec("INSERT INTO fb_apps(app_id,label,app_secret,role,note,added_at,"
                "state) VALUES(?,?,?,?,?,?,'unknown')",
                (app_id, label or app_id, app_secret.strip(), role or "primary",
                 note, now))
    return {"ok": True, "appId": app_id,
            "hasSecret": bool(app_secret.strip() or (ex or {}).get("app_secret"))}


def _save_app_creds_impl(app_id: str = "", app_secret: str = "") -> dict:
    """save_app_creds 的真正实现（放在 save_app 之后，避免 NameError）。"""
    app_id = (app_id or "").strip()
    secret = (app_secret or "").strip()

    # 只填 secret 没填 app_id 时，沿用已登记的那个 App
    if not app_id and secret:
        c = app_creds()
        app_id = c["appId"]

    # ① 写旧位置（兼容老代码路径与「换长期 token」的取值逻辑）
    now = now_iso()
    row = db.q1("SELECT * FROM integrations WHERE id=?", (INTEG_ID,))
    cfg = {}
    if row:
        try:
            cfg = json.loads(row["config"] or "{}") or {}
        except Exception:
            cfg = {}
    if app_id:
        cfg["app_id"] = app_id
    if secret:
        cfg["app_secret"] = secret
    if row:
        db.exec("UPDATE integrations SET enabled=1, config=?, state='configured',"
                " updated_at=? WHERE id=?",
                (json.dumps(cfg, ensure_ascii=False), now, INTEG_ID))
    else:
        db.exec("INSERT INTO integrations(id,kind,label,enabled,config,state,updated_at)"
                " VALUES(?,?,?,?,?,?,?)",
                (INTEG_ID, "官方接口", "Meta Graph API", 1,
                 json.dumps(cfg, ensure_ascii=False), "configured", now))

    # ② 同步进 fb_apps —— 多 App 区才是界面真正在读的数据源
    registered = False
    role = "standby"
    if app_id:
        ex = db.q1("SELECT role FROM fb_apps WHERE app_id=?", (app_id,))
        if ex:
            role = ex["role"] or "primary"
        else:
            has_primary = bool(db.q1(
                "SELECT 1 FROM fb_apps WHERE role='primary' LIMIT 1"))
            role = "standby" if has_primary else "primary"
        r = save_app(app_id, label="", app_secret=secret, role=role,
                     note="由「保存 App 凭据」写入")
        registered = bool(r.get("ok"))

    out = {"ok": True,
           "hasAppId": bool(cfg.get("app_id")),
           "hasSecret": bool(cfg.get("app_secret")),
           "appId": app_id or None,
           "role": role if registered else None,
           "registered": registered}
    if registered:
        out["next"] = ("App 已登记到下方「多 App 与爆炸半径」列表，"
                       "可以在那里点「设主用」或补加备用 App")
    return out


def delete_app(app_id: str) -> dict:
    """移除登记。**不删主页 token**（那些 token 可能还能用，只是不再归这个 App 管）。"""
    n = db.exec("DELETE FROM fb_apps WHERE app_id=?", (app_id,))
    db.exec("UPDATE fb_page_tokens SET app_id=NULL, app_label=NULL "
            "WHERE app_id=?", (app_id,))
    return {"ok": True, "removed": n}


def app_creds_for(app_id: str = "") -> dict:
    """取某个 App 的 ID+Secret；不给 app_id 时退回旧的两栏配置。"""
    if app_id:
        r = db.q1("SELECT app_id,app_secret FROM fb_apps WHERE app_id=?", (app_id,))
        if r:
            return {"appId": r["app_id"], "appSecret": r["app_secret"] or ""}
    return app_creds()


def _mark_app_state(app_id: str, state: str, err: str = "") -> None:
    if not app_id:
        return
    try:
        db.exec("UPDATE fb_apps SET state=?, last_error=?, last_check=? "
                "WHERE app_id=?", (state, (err or "")[:300], now_iso(), app_id))
    except Exception:
        pass


def blast_radius() -> dict:
    """爆炸半径：某个 App 挂掉会让多少主页一起失联。

    这是「量大了会不会连带出事」的量化答案——
    不是封号连带，而是 token 一起失效导致的大面积停摆。
    """
    apps = list_apps()
    total_pages = db.q1("SELECT COUNT(*) c FROM pages")["c"]
    tracked = db.q1(
        "SELECT COUNT(*) c FROM fb_page_tokens WHERE token<>''")["c"]
    orphan = db.q1(
        "SELECT COUNT(*) c FROM fb_page_tokens WHERE token<>''"
        " AND (app_id IS NULL OR app_id='')")["c"]

    # 每个 App 挂掉 → 影响主页数
    items = []
    for a in apps:
        items.append({
            "appId": a["appId"], "label": a["label"], "role": a["role"],
            "pages": a["pages"],
            "share": (round(a["pages"] / tracked * 100, 1) if tracked else 0),
            "impact": ("全停" if tracked and a["pages"] >= tracked
                       else f"{a['pages']} 个主页停采" if a["pages"]
                       else "无影响"),
        })
    items.sort(key=lambda x: -x["pages"])

    worst = items[0] if items else None
    max_share = worst["share"] if worst else 0
    # 风险分级：单点覆盖超过 60% 就算高危
    if not tracked:
        level, advice = "unknown", "还没有任何主页 token，先跑一次「同步主页 Token」"
    elif max_share >= 60:
        level = "high"
        advice = (f"单个 App「{worst['label']}」撑着 {worst['pages']}/{tracked} "
                  f"个主页（{max_share}%）。它一挂，这些主页全部停采。"
                  "建议加一个备用 App 并把部分主页迁过去")
    elif max_share >= 30:
        level = "medium"
        advice = (f"最大单点「{worst['label']}」覆盖 {max_share}%，"
                  "可接受，但建议留好备用 App")
    else:
        level = "low"
        advice = "已分散在多个 App，单点故障影响有限"

    return {
        "totalPages": total_pages,
        "trackedTokens": tracked,
        "orphanTokens": orphan,
        "maxShare": max_share,
        "level": level,
        "advice": advice,
        "apps": items,
        "note": ("这里是「token 一起失效」的连带，不是封号连带。"
                 "Meta 不会因 A 号出事自动封 B 号，但 App 挂了它签发的 token 会全部作废。"),
    }


async def check_app(app_id: str) -> dict:
    """验证某个 App 登记的 Secret 是否正确（用 client_credentials 换 app token）。

    纯校验，不消耗页面配额，也不改任何主页 token。
    """
    import httpx
    c = app_creds_for(app_id)
    if not c["appId"] or not c["appSecret"]:
        _mark_app_state(app_id, "unknown", "缺 App Secret")
        return {"ok": False, "error": "缺 App ID 或 Secret",
                "hint": "在「设置 → 基本」里能看到「应用编号」和「应用密钥」"}
    url = f"https://graph.facebook.com/{settings.graph_version}/oauth/access_token"
    params = {"client_id": c["appId"], "client_secret": c["appSecret"],
              "grant_type": "client_credentials"}
    try:
        async with httpx.AsyncClient(timeout=20) as hc:
            r = await hc.get(url, params=params)
        d = r.json()
    except Exception as e:
        _mark_app_state(app_id, "unknown", str(e)[:200])
        return {"ok": False, "error": f"{type(e).__name__}: {e}"[:200]}
    if r.status_code != 200 or not (d or {}).get("access_token"):
        msg = ((d or {}).get("error") or {}).get("message") or str(d)[:200]
        _mark_app_state(app_id, "invalid", msg)
        return {"ok": False, "error": msg,
                "hint": "Secret 不对，或这个 App 已被删除/禁用"}
    _mark_app_state(app_id, "ok", "")
    tok = d["access_token"]
    return {"ok": True, "appId": app_id,
            "preview": tok[:8] + "…" + tok[-6:],
            "note": "Secret 正确，App 可用"}


async def detect_token_app(token: str = "") -> dict:
    """从 token 反查它属于哪个 App，并自动登记到 fb_apps。"""
    tok = (token or graph_token() or "").strip()
    if not tok:
        return {"ok": False, "error": "没有 token"}
    try:
        async with G.Graph(tok, settings.graph_version, settings.graph_timeout,
                           settings.graph_concurrency) as gr:
            dbg = await gr.debug_token()
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"[:200]}
    if dbg.get("_error"):
        return {"ok": False, "error": dbg["_error"],
                "note": "debug_token 需要 app token 才能查，普通 token 查不到属正常"}
    app_id = str(dbg.get("app_id") or "").strip()
    if not app_id:
        return {"ok": False, "error": "token 里没有 app_id"}
    app = dbg.get("application")
    name = app.get("name") if isinstance(app, dict) else ""
    ex = db.q1("SELECT app_id FROM fb_apps WHERE app_id=?", (app_id,))
    if not ex:
        role = "standby" if db.q1(
            "SELECT 1 FROM fb_apps WHERE role='primary' LIMIT 1") else "primary"
        save_app(app_id, label=name or app_id, role=role,
                 note="由 token 自动识别")
    return {"ok": True, "appId": app_id, "appName": name,
            "registered": not bool(ex)}


KV_PENDING_SWITCH = "graph.pending_switch"


def explorer_url(version: str = "") -> str:
    """带好路径的 Graph API Explorer 链接（省得用户自己拼）。"""
    v = version or settings.graph_version
    return ("https://developers.facebook.com/tools/explorer/"
            f"?method=GET&path=me%2Faccounts&version={v}")


def app_settings_url(app_id: str) -> str:
    return f"https://developers.facebook.com/apps/{app_id}/settings/basic/"


def app_roles_url(app_id: str) -> str:
    return f"https://developers.facebook.com/apps/{app_id}/roles/"


# ---------------- 唯一的「取 token」步骤定义（2026-11-15 统一） ----------------
#
# 为什么统一：之前界面上有三套步骤——顶部速览 6 步、details 里 6 节、
# 切换引导 6 步，编号、粒度、语言都不同，连「先加权限还是先登录」都说不一致，
# 用户按哪套做都会在另一处对不上。
#

TOKEN_PERMISSIONS = [
    {"key": "pages_show_list", "zh": "列出你管理的主页",
     "why": "没有它读不到主页清单"},
    {"key": "pages_read_engagement", "zh": "读主页的互动数据",
     "why": "读视频列表与基础指标"},
    {"key": "pages_read_user_content", "zh": "读主页发布的内容",
     "why": "读帖子和视频详情"},
    {"key": "read_insights", "zh": "读主页数据分析",
     "why": "读播放量、观看时长等指标（最关键）"},
]


def token_steps(app_id: str = "", app_label: str = "") -> list[dict]:
    """取 token 的标准步骤。**全站唯一来源**，前端三处都读它。

    参数为空时给通用版（还没建 App 时看）。
    """
    v = settings.graph_version
    has_app = bool(app_id)
    label = app_label or app_id or "你创建的应用"
    ex = explorer_url(v)

    steps: list[dict] = [
        {
            "n": 1,
            "title": "打开「图谱接口探索器」",
            "body": ("Meta 官方的调试工具（英文界面叫 Graph API Explorer），"
                     "用它生成令牌。"),
            "link": {"url": ex, "text": "打开探索器"},
        },
    ]

    if has_app:
        steps.append({
            "n": 2,
            "title": f"右上角应用下拉框，选「{label}」",
            "body": ("必须是这个应用。选错应用生成的令牌属于别的应用，"
                     "后面切换、换长期令牌都会对不上。"),
            "link": {"url": f"https://developers.facebook.com/apps/{app_id}/",
                     "text": "打开该应用后台"},
        })
    else:
        steps.append({
            "n": 2,
            "title": "右上角应用下拉框，选你的应用",
            "body": ("如果你还没建应用：先到开发者后台「创建应用」→ "
                     "用途选「其他」→ 类型选「商家」。建完再回来这一步。"),
            "link": {"url": "https://developers.facebook.com/apps/",
                     "text": "打开应用列表"},
        })

    steps.append({
        "n": 3,
        "title": "点「生成访问令牌」（Generate Access Token）",
        "body": ("会弹出 Facebook 登录窗口。用**有这些主页管理权限的账号**登录"
                 "（通常是你的发布号）。用错账号，只能看到那个账号名下的主页。"),
    })

    steps.append({
        "n": 4,
        "title": "右侧「权限」面板，添加这 4 个权限",
        "body": "逐个搜索添加，缺任何一个都会导致后面读不到数据。",
        "permissions": TOKEN_PERMISSIONS,
    })

    steps.append({
        "n": 5,
        "title": "重新点一次「生成访问令牌」",
        "body": ("**这一步最容易漏**。加权限会改变令牌的范围，"
                 "必须重新生成，新令牌才带新权限。"
                 "不重新生成的话，表面上加了权限，实际令牌还是旧的。"),
    })

    steps.append({
        "n": 6,
        "title": "先自检：确认能看到主页",
        "body": ("在探索器的查询框里输入下面这行，点「提交」："),
        "query": "me/accounts?fields=id,name,tasks",
        "expect": ("能看到主页列表，且每项的 tasks 里有 ANALYZE，"
                   "说明权限齐了。看不到就回到第 4 步补权限。"),
    })

    steps.append({
        "n": 7,
        "title": "复制令牌",
        "body": ("点令牌左边的信息图标可以看详情。复制以 EAAG 开头的整串，"
                 "很长，注意别复制漏。"),
    })

    steps.append({
        "n": 8,
        "title": "粘贴到本页并同步",
        "body": ("粘到「用户访问令牌」输入框，点「保存并同步主页」。"
                 "系统会自动取到每个主页各自的令牌，并记录都属于哪个应用。"),
    })

    steps.append({
        "n": 9,
        "title": "变成永久令牌（关键，别跳过）",
        "body": ("探索器给的令牌只有 1~2 小时，换成的长期令牌 60 天。"
                 "但**由长期令牌派生的主页令牌是永不过期的**。"
                 "正确顺序：先填应用编号+密钥 → 点「换成 60 天长期」→ "
                 "再点「一键拿永久令牌」→ 主页令牌就永久了。"),
        "optional": True,
        "link": {"url": "https://developers.facebook.com/apps/",
                 "text": "去应用后台取编号/密钥"},
    })

    steps.append({
        "n": 10,
        "title": "（可选）系统用户令牌 —— 另一种永久方案",
        "body": ("如果主页归属某个 Business Manager，可以在里面建「系统用户」，"
                 "分配主页后生成令牌，直接永久、不绑个人号。"
                 "地址：business.facebook.com/settings/system-users。"
                 "没有 BM 就用第 9 步的办法。"),
        "link": {"url": "https://business.facebook.com/settings/system-users",
                 "text": "打开系统用户设置"},
        "optional": True,
    })

    return steps


def switch_guide(app_id: str) -> dict:
    """切换后的引导。步骤与全站统一（token_steps），只额外带上下文。"""
    r = db.q1("SELECT * FROM fb_apps WHERE app_id=?", (app_id,))
    if not r:
        return {"ok": False, "error": "App 未登记"}
    label = r["label"] or app_id
    v = settings.graph_version
    pending = db.get_kv(KV_PENDING_SWITCH, {}) or {}
    steps = token_steps(app_id, label)
    # 切换场景下第 9 步（换长期令牌）不是必须的，标注出来
    return {
        "ok": True,
        "appId": app_id,
        "label": label,
        "hasSecret": bool((r["app_secret"] or "").strip()),
        "links": {
            "explorer": explorer_url(v),
            "appSettings": app_settings_url(app_id),
            "appRoles": app_roles_url(app_id),
        },
        "steps": steps,
        "stepCount": len(steps),
        "pending": bool(pending.get("appId")),
        "pendingSince": pending.get("at") if pending else None,
        "why": ("令牌必须在 Meta 页面上由你本人授权生成，程序无法代签。"
                "所以这里把「去哪、选什么、点完怎么验」都备好了，你只需复制粘贴。"),
    }


async def switch_to_app(app_id: str) -> dict:
    """主用切换：把某个 App 设成 primary，原 primary 降为 standby。

    切换后挂一个 pending 标记，下次同步时会核对 token 是否真的换了 App——
    不核对的话，很容易「以为切了，实际还是旧 App 签发的 token」，
    然后在下一次 App 失效时才发现白切。
    """
    r = db.q1("SELECT * FROM fb_apps WHERE app_id=?", (app_id,))
    if not r:
        return {"ok": False, "error": "App 未登记"}
    old = db.q1("SELECT label FROM fb_apps WHERE role='primary' AND app_id<>?",
                (app_id,))
    db.exec("UPDATE fb_apps SET role='standby' WHERE role='primary' "
            "AND app_id<>?", (app_id,))
    db.exec("UPDATE fb_apps SET role='primary' WHERE app_id=?", (app_id,))
    db.set_kv(KV_PENDING_SWITCH, {"appId": app_id,
                                  "label": r["label"] or app_id,
                                  "at": now_iso()})
    db.log_event("warn", "graph",
                 f"采集主 App 切换为 {r['label'] or app_id}"
                 + (f"（原主用 {old['label']}）" if old else ""))
    guide = switch_guide(app_id)
    return {"ok": True, "appId": app_id, "label": r["label"],
            "prevPrimary": (old or {}).get("label"),
            "guide": guide,
            "next": (f"接下来用「{r['label'] or app_id}」生成 token 并点"
                     "「保存并同步主页」。已存的主页 token 不会自动迁移，"
                     "系统会在同步后核对是否真的换过来了。")}


def pending_switch() -> dict:
    return db.get_kv(KV_PENDING_SWITCH, {}) or {}


def clear_pending_switch() -> None:
    db.set_kv(KV_PENDING_SWITCH, {})


async def debug_token_with_app(token: str) -> dict:
    """用 app access token 去 debug 任意 token —— 官方推荐做法。

    为什么必须这样：
      `debug_token` 用普通 user token 调，只有「该 App 的开发者」能查成功。
      用 `{app_id}|{app_secret}` 组成的 app token 调，才能稳定查到
      token 属于哪个 App、还有多久过期。这是核对「切换是否生效」的前提。
    """
    # 优先用当前主用 App，再试其它已登记的
    cands = []
    prim = db.q1("SELECT app_id,app_secret FROM fb_apps "
                 "WHERE role='primary' AND app_secret<>'' LIMIT 1")
    if prim:
        cands.append((prim["app_id"], prim["app_secret"]))
    for r in db.q("SELECT app_id,app_secret FROM fb_apps "
                  "WHERE app_secret<>'' AND app_id<>COALESCE(?, '')",
                  ((prim or {}).get("app_id"),)):
        cands.append((r["app_id"], r["app_secret"]))
    # 兜底：旧的单 App 配置
    c = app_creds()
    if c["appId"] and c["appSecret"]:
        cands.append((c["appId"], c["appSecret"]))

    if not cands:
        return {"_error": "没有可用的 App Secret，无法用 app token 校验",
                "_hint": "填一下 App Secret 就能自动核对"}

    import httpx
    last_err = ""
    for aid, sec in cands:
        app_tok = f"{aid}|{sec}"
        url = f"https://graph.facebook.com/{settings.graph_version}/debug_token"
        try:
            async with httpx.AsyncClient(timeout=20) as hc:
                r = await hc.get(url, params={"input_token": token,
                                              "access_token": app_tok})
            d = r.json()
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"[:150]
            continue
        if r.status_code == 200 and (d or {}).get("data"):
            data = d["data"]
            data["_via_app"] = aid
            return data
        last_err = ((d or {}).get("error") or {}).get("message") or str(d)[:150]
    return {"_error": last_err or "全部 app token 都查不到", }


async def token_diag() -> dict:
    """诊断当前 token：是否有效、多久过期、缺哪些权限。

    这一步很关键——Explorer 拿的是 1~2 小时短效 token，
    用户填完当时能用，过几小时全挂。必须能一眼看到 expires_at。
    """
    tok = graph_token()
    if not tok:
        return {"ok": False, "error": "未配置 token"}
    out: dict = {"ok": False}
    try:
        async with G.Graph(tok, settings.graph_version, settings.graph_timeout,
                           settings.graph_concurrency) as gr:
            me = await gr.me()
            out["me"] = me
            dbg = await gr.debug_token()
            if dbg.get("_error"):
                out["debugError"] = dbg["_error"]
            else:
                exp = dbg.get("expires_at") or 0
                app = dbg.get("application")
                kind = classify_token(dbg)
                out.update({
                    "appId": dbg.get("app_id"),
                    "appName": app.get("name") if isinstance(app, dict) else None,
                    "type": dbg.get("type"),
                    "valid": dbg.get("is_valid"),
                    "scopes": dbg.get("scopes") or [],
                    "issuedAt": dbg.get("issued_at"),
                    "expiresAt": exp,
                    "neverExpires": exp == 0,
                    "tokenKind": kind,
                    "tokenKindText": TOKEN_KIND_TEXT.get(kind, kind),
                })
                if exp:
                    import time as _t
                    left = int(exp - _t.time())
                    out["expiresInSec"] = left
                    out["expiresInText"] = (
                        f"{left // 3600} 小时 {(left % 3600) // 60} 分"
                        if left > 0 else "已过期")
                # 给一句「能不能变永久」的判断，省得用户自己推
                if kind == "short_user":
                    out["upgradeAdvice"] = (
                        "当前是短期用户令牌。先换成 60 天长期令牌，"
                        "再用它同步主页 —— 这样派生的主页令牌才是永久的。")
                elif kind == "long_user":
                    out["upgradeAdvice"] = (
                        "已是长期用户令牌。现在同步主页，得到的**主页令牌永不过期**。")
                elif kind in ("page_permanent", "system_user"):
                    out["upgradeAdvice"] = "已经是永久令牌，不用再换。"
                elif kind == "page_long":
                    out["upgradeAdvice"] = (
                        "主页令牌会跟着用户令牌走。想永久，先用长期用户令牌（或系统用户令牌）"
                        "重新同步一次。")
            out["ok"] = True
    except G.GraphError as e:
        out.update(ok=False, error=str(e), kind=e.kind,
                   hint=("token 失效或已过期，重新取一个" if e.needs_relogin
                         else "缺权限" if e.needs_permission else "网络/代理"))
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"[:200]
    return out


async def upgrade_to_long_lived(app_id: str = "") -> dict:
    """把当前短效 token 换成 60 天长期 token（需要 App ID + App Secret）。

    app_id 留空时用旧的两栏配置（integrations.graph.config）。
    成功后自动覆盖保存，并把 token 归属 App 记下来。
    """
    tok = graph_token()
    if not tok:
        return {"ok": False, "error": "未配置 token"}
    c = app_creds_for(app_id)
    if not c["appId"] or not c["appSecret"]:
        return {"ok": False,
                "error": "缺少 App ID / App Secret",
                "hint": ("到 developers.facebook.com → 你的应用 → 设置 → 基本，"
                         "复制「应用编号」和「应用密钥」填进来。"
                         "注意：应用密钥只在这里本地保存")}
    try:
        async with G.Graph(tok, settings.graph_version, settings.graph_timeout,
                           settings.graph_concurrency) as gr:
            r = await gr.exchange_long_lived(c["appId"], c["appSecret"])
    except G.GraphError as e:
        _mark_app_state(c["appId"], "invalid", str(e))
        return {"ok": False, "error": str(e), "kind": e.kind,
                "hint": ("App Secret 不对" if e.kind == "param"
                         else "app 与 token 不匹配" if e.needs_permission
                         else "网络问题")}
    new_tok = (r.get("access_token") or "").strip()
    if not new_tok:
        return {"ok": False, "error": "上游没返回 access_token", "raw": r}
    save_graph_token(new_tok, note="long_lived")
    _mark_app_state(c["appId"], "ok", "")
    secs = int(r.get("expires_in") or 0)
    db.log_event("ok", "graph",
                 f"已换取长期 token（约 {secs // 86400} 天）")
    return {"ok": True, "expiresIn": secs, "appId": c["appId"],
            "expiresInDays": round(secs / 86400, 1) if secs else None,
            "preview": new_tok[:6] + "…" + new_tok[-4:]}


# ---------------- 主页清单 + token 同步 ----------------
# ---------------- 令牌种类与「永久令牌」（2026-11-16） ----------------
#
# Meta 有四种令牌，有效期差 1000 倍以上，最容易踩的就是搞混这里：
#
#   ① 探索器直接生成的用户令牌      1~2 小时
#   ② 换成的长期用户令牌            60 天
#   ③ 由 ② 派生的**主页令牌**       永不过期   ← 这是「永久令牌」的正解
#   ④ 系统用户令牌                  永不过期（可设）
#
# 关键因果：**主页令牌的有效期跟着签发它的用户令牌走**。
# 所以「先换长期、再派生主页令牌」才拿到永久；直接拿探索器的短效令牌
# 派生的主页令牌也是短效的——这就是很多人以为拿到永久、结果两天就挂的原因。

TOKEN_KIND_TEXT = {
    "short_user": "短期用户令牌（1~2 小时）",
    "long_user": "长期用户令牌（60 天）",
    "page_permanent": "主页令牌 · 永不过期",
    "page_long": "主页令牌 · 随用户令牌（60 天）",
    "page_short": "主页令牌 · 短期（1~2 小时）",
    "system_user": "系统用户令牌 · 永不过期",
    "unknown": "未知类型",
}


def classify_token(dbg: dict) -> str:
    """根据 debug_token 的结果判断令牌种类。

    ⚠ 2026-11-17 修正（重要）：
        旧逻辑只看 `expires_at` 有没有值，就判「long_user / page_long」。
        但Meta 会给**短期令牌也返回 expires_at**（2 小时后），
        结果把 2 小时的短效令牌误判成 60 天长期。

        实测：用户令牌 type=USER、expires_at=2 小时后，旧逻辑判为 long_user，
        于是 obtain_permanent_tokens 直接跳过转换，主页令牌也只活 2 小时。

        正确做法：比较**剩余时长**，不看有没有 expires_at：
          · USER 剩余 > 30 天  → long_user（60 天长期）
          · USER 剩余 <= 30 天 → short_user（1~2 小时那种）
          · PAGE 剩余 > 30 天  → page_long
          · PAGE 剩余 <= 30 天 → page_short
          · PAGE expires_at=0  → page_permanent（真永久）
    """
    import time as _t
    if not dbg or dbg.get("_error"):
        return "unknown"
    t = str(dbg.get("type") or "").upper()
    exp = int(dbg.get("expires_at") or 0)
    if t == "SYSTEM_USER":
        return "system_user"

    left_days = ((exp - _t.time()) / 86400) if exp else None
    if t == "PAGE":
        if exp == 0:
            return "page_permanent"
        return "page_long" if (left_days and left_days > 30) else "page_short"
    if t == "USER":
        if exp == 0:
            return "long_user"          # 无过期时间 = 长期
        return "long_user" if (left_days and left_days > 30) else "short_user"
    return "unknown"


async def obtain_permanent_tokens(app_id: str = "") -> dict:
    """尽量拿更长久的主页令牌。

    ⚠ 2026-11-17 实测修正 —— 我之前的说法是错的，这里按真实行为改：

    曾经的说法：「用长期用户令牌派生的主页令牌永不过期」。
    实测否证：
        · 用户令牌换成长效后（type=USER, expires=60天后）
        · 用它调 /me/accounts 拿到的 PAGE token **同样带 expires_at**
        · debug 显示 expires 与用户令牌**同一时刻**
        → 所以「60 天用户令牌 → 永久主页令牌」不成立，
          主页令牌就是跟着用户令牌走。

    真正能永久只有一条路：**系统用户令牌**（type=SYSTEM_USER, expires=0）。
    那需要 Business Manager，程序拿不到，只能在 BM 后台生成。

    所以这个函数现在的实际作用：
        ① 短效用户令牌 → 换成 60 天长期令牌（延长 60 倍）
        ② 用长期令牌同步主页 → 主页令牌也变成 60 天
        ③ 如实报告「60 天」而不是谎称「永久」
    """
    import time as _t
    tok = graph_token()
    if not tok:
        return {"ok": False, "error": "未配置令牌",
                "hint": "先在探索器生成一个用户令牌填进来"}

    steps: list[dict] = []

    dbg = await debug_token_with_app(tok)
    kind = classify_token(dbg)
    exp = int((dbg or {}).get("expires_at") or 0)
    left_h = round((exp - _t.time()) / 3600, 1) if exp else 0
    steps.append({
        "name": f"当前令牌：{TOKEN_KIND_TEXT.get(kind, kind)}"
                + (f"（剩余 {left_h} 小时）" if exp else ""),
        "ok": True})

    if kind == "system_user":
        steps.append({"name": "系统用户令牌本身永久，直接同步", "ok": True})
        sync = await sync_page_tokens()
        return {"ok": True, "already": True, "kind": kind,
                "steps": steps, "sync": sync,
                "message": "系统用户令牌永不过期，主页令牌也是永久的"}

    if kind == "short_user":
        c = app_creds_for(app_id)
        if not c["appId"] or not c["appSecret"]:
            steps.append({"name": "缺少应用编号/密钥，无法换长期", "ok": False})
            return {"ok": False, "steps": steps, "kind": kind,
                    "error": "需要应用编号 + 应用密钥才能换 60 天令牌",
                    "hint": ("到 developers.facebook.com/apps → 你的应用 → "
                             "设置 → 基本，最上面两栏填进来")}
        try:
            async with G.Graph(tok, settings.graph_version,
                               settings.graph_timeout,
                               settings.graph_concurrency) as gr:
                r = await gr.exchange_long_lived(c["appId"], c["appSecret"])
        except G.GraphError as e:
            steps.append({"name": f"换长期失败：{e}", "ok": False})
            return {"ok": False, "steps": steps, "kind": kind,
                    "error": str(e),
                    "hint": ("应用密钥不对" if e.kind == "param"
                             else "应用与令牌不匹配")}
        new_tok = (r.get("access_token") or "").strip()
        if not new_tok:
            steps.append({"name": "上游未返回新令牌", "ok": False})
            return {"ok": False, "steps": steps, "kind": kind}
        save_graph_token(new_tok, note="long_lived")
        secs = int(r.get("expires_in") or 0)
        steps.append({
            "name": f"已换成长期用户令牌（{round(secs / 86400, 1)} 天）",
            "ok": True})
    elif kind == "long_user":
        steps.append({"name": "已是长期用户令牌，跳过转换", "ok": True})
    elif kind == "page_permanent":
        steps.append({"name": "当前已是永久主页令牌", "ok": True})
        return {"ok": True, "already": True, "kind": kind, "steps": steps,
                "message": "已经是永久令牌"}
    else:
        steps.append({"name": f"令牌类型 {kind} 不支持自动转换，尝试直接同步",
                      "ok": True})

    # 用当前（已长期化）令牌同步
    sync = await sync_page_tokens()

    # 如实统计时长
    rows = db.q("SELECT expires_at, never_expires, token_kind "
                "FROM fb_page_tokens WHERE token<>''")
    total = len(rows)
    perm = sum(1 for x in rows if int(x["never_expires"] or 0) == 1)
    upcoming = [int(x["expires_at"] or 0) for x in rows
                if int(x["never_expires"] or 0) != 1 and x["expires_at"]]
    days = None
    if upcoming:
        days = round((min(upcoming) - _t.time()) / 86400, 1)

    steps.append({
        "name": (f"同步完成：{total} 个主页令牌，"
                 + (f"{perm} 个永久" if perm else f"约 {days} 天后到期")),
        "ok": True})

    if perm:
        msg = f"{perm}/{total} 个主页令牌永不过期"
    elif days and days > 30:
        msg = (f"主页令牌已延长到约 {days} 天。"
               "Meta 不支持通过用户令牌派生「永久」主页令牌；"
               "要真正永久只能用系统用户令牌（需 Business Manager）")
    else:
        msg = f"主页令牌约 {days} 天后到期，建议重跑一次换长期"

    return {"ok": True, "already": False, "kind": kind,
            "steps": steps, "sync": sync,
            "permanentPages": perm, "totalPages": total,
            "expiresInDays": days,
            "message": msg}


async def probe_business() -> dict:
    """探测当前身份有没有 Business Manager —— 决定能否走系统用户（永久令牌）。"""
    tok = graph_token()
    if not tok:
        return {"ok": False, "error": "未配置令牌"}
    out: dict = {"ok": True, "businesses": [], "systemUserPossible": False}
    try:
        async with G.Graph(tok, settings.graph_version, settings.graph_timeout,
                           settings.graph_concurrency) as gr:
            bms = await gr.my_businesses()
        out["businesses"] = [{"id": b.get("id"), "name": b.get("name")}
                             for b in bms]
        if bms:
            bm = bms[0]["id"]
            out["systemUserPossible"] = True
            out["exampleBusinessId"] = bm
            try:
                async with G.Graph(tok, settings.graph_version,
                                   settings.graph_timeout,
                                   settings.graph_concurrency) as gr:
                    pages = await gr.business_pages(bm)
                out["businessPages"] = len(pages)
                out["pageSample"] = [{"id": p.get("id"), "name": p.get("name")}
                                     for p in pages[:5]]
            except Exception as e:
                out["bizPagesError"] = str(e)[:150]
        else:
            out["hint"] = ("当前身份没有 Business Manager。"
                           "系统用户令牌需要在 business.facebook.com 里创建，"
                           "没有 BM 就只能走「长期用户令牌 → 派生永久主页令牌」。")
    except G.GraphError as e:
        out.update(ok=False, error=str(e), kind=e.kind)
    return out


async def sync_page_tokens(gr: G.Graph | None = None,
                           owner_app_id: str = "") -> dict:
    """一次 /me/accounts 拿到全部主页 + 各自 token 并落库。

    这一步替代了原来「打开 bookmarks/pages 滚动抓卡片」的做法：
    不用浏览器，几百个主页也是几页 API 的事。

    owner_app_id：本次同步用的 token 由哪个 App 签发。
        记进 fb_page_tokens 才能算爆炸半径。留空时自动反查。
    """
    own = gr is None
    if own:
        tok = graph_token()
        if not tok:
            return {"ok": False, "error": "未配置 Graph token",
                    "hint": "在「第三方对接 → Meta Graph API」填写 User Access Token"}
        gr = G.Graph(tok, settings.graph_version, settings.graph_timeout,
                     settings.graph_concurrency)

    try:
        if own:
            await gr.open()
        me = await gr.me()
        rows = await gr.me_accounts()
    except G.GraphError as e:
        if own:
            await gr.close()
        return {"ok": False, "error": str(e),
                "kind": e.kind,
                "hint": ("token 已失效，重新授权" if e.needs_relogin
                         else "缺 pages_show_list / pages_read_engagement 权限"
                         if e.needs_permission else "检查网络或代理")}
    finally:
        if own:
            try:
                await gr.close()
            except Exception:
                pass

    # 反查 token 属于哪个 App（失败不阻断同步，只是没 app_id）
    app_id, app_label = owner_app_id, ""
    check: dict = {}
    if not app_id:
        try:
            det = await detect_token_app(graph_token())
            if det.get("ok"):
                app_id = det["appId"]
                app_label = det.get("appName") or ""
        except Exception as e:
            log.debug("detect_token_app failed: %s", e)

    # 切换核对：如果之前点过「设主用」，就要确认这次同步用的 token
    # 是不是真由新 App 签发。不核对的话容易「以为切了其实没切」，
    # 等到旧 App 失效那天才发现白切一场。
    pend = pending_switch()
    if pend.get("appId"):
        want = str(pend["appId"])
        if not app_id:
            # 用 app token 再查一次（比普通 token debug 更可靠）
            dbg = await debug_token_with_app(graph_token())
            if dbg.get("app_id"):
                app_id = str(dbg["app_id"])
        if app_id:
            check = {"pendingApp": want, "pendingLabel": pend.get("label") or want,
                     "actualApp": app_id, "matched": app_id == want}
            if app_id == want:
                clear_pending_switch()
                db.log_event("ok", "graph",
                             f"切换核对通过：token 已由 {pend.get('label') or want} 签发")
            else:
                db.log_event(
                    "warn", "graph",
                    f"切换未生效：期望 {want}，实际 {app_id}"
                    f"（{pend.get('label')} vs {app_label or app_id}）")

    if app_id and not app_label:
        r = db.q1("SELECT label FROM fb_apps WHERE app_id=?", (app_id,))
        app_label = (r or {}).get("label") or app_id
    if app_id:
        db.exec("UPDATE fb_apps SET last_used=? WHERE app_id=?",
                (now_iso(), app_id))

    now = now_iso()
    saved = 0
    # 主页令牌的有效期取决于「签发它的用户令牌」：
    #   长期用户令牌 / 系统用户令牌派生 → 主页令牌永久（expires_at=0）
    #   短效用户令牌派生              → 主页令牌也会过期
    # 这里对每个主页令牌做一次 debug，把真实有效期钉进库，
    # 才能提前告警而不是等它悄悄失效。
    user_permanent = False
    user_exp = 0
    try:
        udbg = await debug_token_with_app(graph_token())
        if udbg and not udbg.get("_error"):
            user_exp = int(udbg.get("expires_at") or 0)
            user_permanent = user_exp == 0
    except Exception as e:
        log.debug("user token debug failed: %s", e)

    for r in rows:
        pid = str(r.get("id") or "").strip()
        if not pid:
            continue
        tok = (r.get("access_token") or "").strip()
        tasks = r.get("tasks") or []

        # 逐个查主页令牌的真实有效期
        pexp, pperm, pkind = None, 0, "page_short"
        if tok:
            try:
                pdbg = await debug_token_with_app(tok)
                if pdbg and not pdbg.get("_error"):
                    pexp = int(pdbg.get("expires_at") or 0)
                    pperm = 1 if pexp == 0 else 0
                    pkind = "page_permanent" if pexp == 0 else "page_long"
                else:
                    # 查不到就按用户令牌推：用户令牌永久 → 主页令牌也永久
                    pperm = 1 if user_permanent else 0
                    pkind = ("page_permanent" if user_permanent else "page_long")
            except Exception as e:
                log.debug("debug page token %s failed: %s", pid, e)
                pperm = 1 if user_permanent else 0
                pkind = "page_permanent" if user_permanent else "page_long"

        db.exec(
            "INSERT INTO fb_page_tokens(page_id,page_name,token,tasks,"
            "followers,source,obtained_at,checked_at,state,error,"
            "app_id,app_label,expires_at,never_expires,token_kind)"
            " VALUES(?,?,?,?,?,'me_accounts',?,?,'ok',NULL,?,?,?,?,?)"
            " ON CONFLICT(page_id) DO UPDATE SET"
            " page_name=CASE WHEN excluded.page_name<>'' THEN excluded.page_name"
            "                ELSE fb_page_tokens.page_name END,"
            " token=CASE WHEN excluded.token<>'' THEN excluded.token"
            "            ELSE fb_page_tokens.token END,"
            " tasks=excluded.tasks, followers=excluded.followers,"
            " obtained_at=excluded.obtained_at, checked_at=excluded.checked_at,"
            " app_id=COALESCE(excluded.app_id, fb_page_tokens.app_id),"
            " app_label=COALESCE(excluded.app_label, fb_page_tokens.app_label),"
            " expires_at=excluded.expires_at,"
            " never_expires=excluded.never_expires,"
            " token_kind=excluded.token_kind,"
            " state='ok', error=NULL",
            (pid, str(r.get("name") or ""), tok or "",
             json.dumps(tasks, ensure_ascii=False),
             int(r.get("followers_count") or 0), now, now,
             app_id or None, app_label or None,
             pexp, pperm, pkind))
        saved += 1
        # ── 同步 pages 表 ──
        #
        # ⚠ 2026-11-17 修 bug：
        #   旧代码用 `INSERT INTO pages(page_id,asset_id,name,...) VALUES(?,NULL,...)`
        #   显式写 asset_id=NULL。主页已存在时因为是纯 INSERT（不带 ON CONFLICT），
        #   会撞主键失败；但我先前做 id 迁移时先删后插，新行就是 NULL，
        #   于是 env_code / asset_id 一起被清空 —— 归属关系全丢。
        #
        #   现在改成 UPSERT，且**只补空值，绝不清空已有值**：
        #     · 新主页 → 插入，env_code 留空（等用户手动归类）
        #     · 已有主页 → 只更新名字（且只在原来是空的时候），
        #                  env_code / asset_id 一律不动
        ex = db.q1("SELECT page_id,name,env_code,asset_id FROM pages "
                   "WHERE page_id=?", (pid,))
        nm = str(r.get("name") or pid)
        if not ex:
            db.exec("INSERT INTO pages(page_id,asset_id,name,health,"
                    "created_at,last_seen) VALUES(?,NULL,?,'ok',?,?)"
                    " ON CONFLICT(page_id) DO NOTHING",
                    (pid, nm, now, now))
        else:
            # 已有行：只补空名字，其它字段一概不碰
            if not (ex.get("name") or "").strip():
                db.exec("UPDATE pages SET name=?, last_seen=? WHERE page_id=?",
                        (nm, now, pid))
            else:
                db.exec("UPDATE pages SET last_seen=? WHERE page_id=?",
                        (now, pid))

    db.log_event("ok", "graph", f"同步主页 token：{saved} 个 · 身份 {me.get('name','?')}")
    out = {"ok": True, "pages": saved, "me": me,
           "withToken": sum(1 for r in rows if (r.get("access_token") or "").strip()),
           "appId": app_id or None, "appLabel": app_label or None,
           "at": now}
    if check:
        out["switchCheck"] = check
        out["warning"] = (
            None if check["matched"] else
            f"你上次点的是「{check['pendingLabel']}」设主用，"
            f"但这次同步用的 token 其实属于 App {check['actualApp']}。"
            "多半是 Explorer 右上角没切 App，或者生成后没重新复制。"
            "请切到正确 App 重新生成 token 再来。")
    return out


def token_status() -> dict:
    """给前端看的 token 概况（不返回完整 token，避免泄露到页面）。"""
    rows = db.q("SELECT page_id,page_name,tasks,state,obtained_at,app_id,"
                "app_label,footers,expires_at,never_expires,token_kind FROM ("
                "SELECT page_id,page_name,tasks,state,obtained_at,app_id,"
                "       app_label, followers AS footers, expires_at,"
                "       never_expires, token_kind FROM fb_page_tokens)"
                " ORDER BY page_name")
    tok = graph_token()
    c = app_creds()
    import time as _t
    now_ts = int(_t.time())
    # 逐个算「还剩多久」，并标出即将过期的
    items = []
    for r in rows:
        exp = int(r.get("expires_at") or 0)
        ne = int(r.get("never_expires") or 0)
        kind = r.get("token_kind") or "unknown"
        if ne == 1 or exp == 0:
            left_text, urgent = "永久", False
        elif exp > now_ts:
            left = exp - now_ts
            left_text = (f"{left // 86400} 天" if left >= 86400
                         else f"{left // 3600} 小时")
            urgent = left < 86400 * 3      # 3 天内到期要提醒
        else:
            left_text, urgent = "已过期", True
        items.append({**r, "expiresAt": exp, "neverExpires": ne == 1,
                      "tokenKind": kind,
                      "tokenKindText": TOKEN_KIND_TEXT.get(kind, kind),
                      "leftText": left_text, "urgent": urgent})

    permanent = sum(1 for x in items if x["neverExpires"])
    expiring = sum(1 for x in items if x["urgent"])
    return {
        "configured": bool(tok),
        "tokenHint": (tok[:6] + "…" + tok[-4:]) if len(tok) > 12 else "",
        "version": settings.graph_version,
        "pages": len(items),
        "ok": sum(1 for r in items if r["state"] == "ok"),
        "expired": sum(1 for r in items if r["state"] == "expired"),
        "noPerm": sum(1 for r in items if r["state"] == "no_perm"),
        "permanent": permanent,
        "expiringSoon": expiring,
        "appId": c["appId"],
        "hasAppSecret": bool(c["appSecret"]),
        "apps": list_apps(),
        "blast": blast_radius(),
        "items": items[:300],
    }


# ---------------- 指标映射 ----------------
def _pick(d: dict, *names: str) -> int:
    for n in names:
        v = d.get(n)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return int(v)
    return 0


def _social(d: dict) -> tuple[int, int]:
    """post_video_social_actions 是 {COMMENT: n, SHARE: n} 这种结构。"""
    v = d.get("post_video_social_actions") or d.get("post_video_social_actions_total")
    c, s = 0, 0
    if isinstance(v, dict):
        for k, val in v.items():
            if not isinstance(val, (int, float)):
                continue
            kl = str(k).upper()
            if "COMMENT" in kl:
                c += int(val)
            elif "SHARE" in kl:
                s += int(val)
    return c, s


def insights_to_row(video: dict, ins: dict) -> dict:
    """把一条视频的 insights 映射成 unit_metrics 能吃的行。

    ⚠ 2026-11-17 实测校准（v21 + 真实主页 token）：
        `total_video_views` / `post_impressions_unique` / `total_video_complete_views`
        这些名字在 v21 **全部报 #100 invalid metric**，已弃用。

        实测能返回的只有这几组：
            fb_reels_total_plays / blue_reels_play_count / fb_reels_replay_count
            post_video_view_time / post_video_avg_time_watched
            post_video_social_actions / post_video_followers
            post_video_likes_by_reaction_type

    所以 plays 的取数逻辑改成：Reels 播放优先，没有就退回首播次数。
    reach（覆盖人数）在 v21 已经没有对应指标，只能置 0 并标注。
    """
    social_c, social_s = _social(ins)

    reels_plays = _pick(ins, "fb_reels_total_plays")
    first_plays = _pick(ins, "blue_reels_play_count")
    replay_plays = _pick(ins, "fb_reels_replay_count")

    if reels_plays:
        plays, plays_kind = reels_plays, "reels_total"
    elif first_plays:
        plays, plays_kind = first_plays, "reels_first_only"
    else:
        plays, plays_kind = 0, "unavailable"

    watch_ms = _pick(ins, "post_video_view_time")
    avg_ms = _pick(ins, "post_video_avg_time_watched")

    # 点赞：post_video_likes_by_reaction_type 返回 {REACTION_LIKE: n}
    likes = 0
    lk = ins.get("post_video_likes_by_reaction_type")
    if isinstance(lk, dict):
        likes = sum(int(v) for v in lk.values()
                    if isinstance(v, (int, float)))

    return {
        "post_id": str(video.get("id") or ""),
        "title": (video.get("title") or video.get("description") or "")[:200],
        "published_at": video.get("created_time") or "",
        "published_date": G.iso_date(video.get("created_time") or ""),
        "permalink": video.get("permalink_url") or "",
        "status": video.get("status") or "",
        "plays": plays,
        "plays_kind": plays_kind,
        # v21 没有覆盖人数指标，置 0（不要用已弃用的 post_impressions_unique）
        "reach": 0,
        "impressions": 0,
        "reactions": likes,
        "comments": social_c,
        "shares": social_s,
        "saves": 0,
        "follows": _pick(ins, "post_video_followers"),
        "watch_sec": round(watch_ms / 1000.0, 1) if watch_ms else 0,
        "avg_watch": round(avg_ms / 1000.0, 2) if avg_ms else 0,
        # 完播率需要 total_video_complete_views，v21 已无此指标 → 0
        "completion": 0,
        "reels": {
            "total_plays": reels_plays,
            "first_plays": first_plays,
            "replay": replay_plays,
        },
        "raw": ins,
        "source": "graph",
    }


# 只存实测可用的指标（弃用的不留，否则快照里全是 0）
SNAPSHOT_METRICS = [
    "fb_reels_total_plays", "blue_reels_play_count", "fb_reels_replay_count",
    "post_video_view_time", "post_video_avg_time_watched",
    "post_video_followers",
]


def save_snapshots(unit_id: str, page_id: str, ins: dict,
                   day: str | None = None) -> int:
    """把原始累计指标按天存档（趋势分析的基础）。"""
    day = day or date.today().isoformat()
    now = now_iso()
    n = 0
    for m in SNAPSHOT_METRICS:
        v = ins.get(m)
        if not isinstance(v, (int, float)) or isinstance(v, bool):
            continue
        db.exec(
            "INSERT INTO metric_snapshots(unit_id,page_id,metric,scope,snap_date,"
            "value,period,source,observed_at) VALUES(?,?,?,'video',?,?,'lifetime',"
            "'graph',?) ON CONFLICT(unit_id,metric,snap_date) DO UPDATE SET"
            " value=excluded.value, observed_at=excluded.observed_at",
            (unit_id, page_id, m, day, int(v), now))
        n += 1
    return n


def daily_delta(unit_id: str, metric: str, days: int = 30) -> list[dict]:
    """累计值 → 每日新增。趋势图必须用这个，直接 SUM 累计值会翻倍。"""
    rows = db.q(
        "SELECT snap_date,value FROM metric_snapshots WHERE unit_id=? AND metric=?"
        " ORDER BY snap_date DESC LIMIT ?", (unit_id, metric, max(2, days + 1)))
    rows.reverse()
    out = []
    for i in range(1, len(rows)):
        prev = int(rows[i - 1]["value"] or 0)
        cur = int(rows[i]["value"] or 0)
        delta = cur - prev
        out.append({"date": rows[i]["snap_date"],
                    "value": cur,
                    "delta": max(0, delta) if delta >= 0 else 0})
    return out


# ---------------- 单主页采集 ----------------
async def collect_page_api(gr: G.Graph, page_id: str, page_name: str = "",
                           window_days: int = 0, use_batch: bool = True,
                           persist: bool = True) -> dict:
    """一个主页：拉视频清单 → 拉每条视频指标 → 入库 + 存快照。"""
    from app.services import metrics as mx

    tok = page_token(page_id)
    if not tok:
        return {"pageId": page_id, "name": page_name, "ok": False,
                "error": "没有可用 token"}
    # 主页 token 优先（权限范围更准），没有就用全局
    if tok != gr.token:
        gr = G.Graph(tok, gr.version, gr.timeout, settings.graph_concurrency)

    since_ts = None
    if window_days and window_days > 0:
        since_ts = int((datetime.now() - timedelta(days=window_days)).timestamp())

    res = {"pageId": page_id, "name": page_name, "ok": False,
           "videos": 0, "saved": 0, "snapshots": 0, "error": None, "kind": None}

    try:
        videos = await gr.page_videos(page_id, since_ts=since_ts)
    except G.GraphError as e:
        res.update(error=str(e), kind=e.kind)
        _mark_page(page_id, "no_perm" if e.needs_permission else
                   "expired" if e.needs_relogin else "error", str(e))
        return res

    res["videos"] = len(videos)
    if not videos:
        _mark_page(page_id, "ok", "无视频")
        res["ok"] = True
        return res

    ids = [str(v.get("id")) for v in videos if v.get("id")]
    by_id = {str(v.get("id")): v for v in videos if v.get("id")}

    if use_batch:
        try:
            all_ins = await gr.batch_video_insights(ids)
        except G.GraphError as e:
            res.update(error=str(e), kind=e.kind)
            _mark_page(page_id, "error", str(e))
            return res
    else:
        all_ins = {}
        for vid in ids:
            try:
                all_ins[vid] = await gr.video_insights(vid)
            except G.GraphError as e:
                all_ins[vid] = {"_errors": [str(e)]}
                if e.needs_relogin:
                    break

    if not persist:
        res["ok"] = True
        return res

    for vid in ids:
        ins = all_ins.get(vid) or {}
        if not ins:
            continue
        row = insights_to_row(by_id.get(vid) or {}, ins)
        uid = mx.upsert_unit_metrics(page_id, "", row, window_days=window_days)
        if uid:
            res["saved"] += 1
            res["snapshots"] += save_snapshots(uid, page_id, ins)
            if row.get("permalink"):
                try:
                    db.exec("UPDATE units SET permalink=COALESCE(permalink,?) "
                            "WHERE id=?", (row["permalink"], uid))
                except Exception:
                    pass

    res["ok"] = True
    _mark_page(page_id, "ok", f"{res['saved']}/{len(ids)} 条")
    return res


def _mark_page(page_id: str, state: str, note: str = "") -> None:
    try:
        db.exec("UPDATE pages SET api_state=?, api_synced_at=?, api_note=? "
                "WHERE page_id=?", (state, now_iso(), (note or "")[:200], page_id))
    except Exception:
        pass


# ---------------- 全部采集（无浏览器） ----------------
async def collect_all_api(page_ids: list[str] | None = None,
                          window_days: int = 0, use_batch: bool = True,
                          refresh_tokens: bool = True,
                          job_id: str = "") -> dict:
    """纯 API 全量采集。**不创建 FB 浏览器连接**，所以不依赖发布号环境。

    page_ids 为空 → 采集 fb_page_tokens 里所有主页。
    """
    summary: dict[str, Any] = {
        "mode": "graph_api", "total": 0, "ok": 0, "fail": 0,
        "videos": 0, "saved": 0, "snapshots": 0, "windowDays": window_days,
        "tokenSync": None, "details": [],
    }

    if refresh_tokens:
        try:
            summary["tokenSync"] = await sync_page_tokens()
        except Exception as e:
            summary["tokenSync"] = {"ok": False, "error": str(e)[:200]}

    tok = graph_token()
    if not tok and not db.q1("SELECT 1 FROM fb_page_tokens LIMIT 1"):
        summary["error"] = "未配置 Graph token，也没有已保存的主页 token"
        summary["hint"] = ("在「第三方对接 → Meta Graph API」填 User Access Token，"
                           "然后点「同步主页 Token」")
        return summary

    if page_ids:
        targets = []
        for pid in page_ids:
            r = db.q1("SELECT page_id,name FROM pages WHERE page_id=?", (pid,))
            targets.append((pid, (r or {}).get("name") or pid))
    else:
        rows = db.q("SELECT page_id,page_name FROM fb_page_tokens "
                    "WHERE state<>'expired' ORDER BY page_name")
        if not rows:
            # 没有 token 表时退回 pages 表（用全局 token 试）
            rows = db.q("SELECT page_id,name AS page_name FROM pages")
        targets = [(str(r["page_id"]), str(r.get("page_name") or r["page_id"]))
                   for r in rows]

    summary["total"] = len(targets)
    if not targets:
        summary["error"] = "没有可采集的主页，先点「同步主页 Token」"
        return summary

    async with G.Graph(tok, settings.graph_version, settings.graph_timeout,
                       settings.graph_concurrency) as gr:

        # ⚠ 2026-11-17 改并发（用户："怎么这么慢"）
        #
        # 旧实现是 `for pid in targets: await collect_page_api(...)` —— 纯串行，
        # 23 个主页 × 每个 20-40 秒 = 8-15 分钟。
        #
        # 慢的两个原因：
        #   ① 主页之间没有重叠，一个等完再等下一个
        #   ② 每个主页内部再串行「拉清单 → 拉指标 → 写库」
        #
        # 现在改成 3 个主页并发（不是全开，避免撞 Graph 限流 80001）。
        # 单个主页内部仍然串行（清单→指标有依赖），但主页之间重叠。
        sem = asyncio.Semaphore(3)
        done_cnt = [0]
        lock = asyncio.Lock()

        async def _one(pid: str, name: str) -> dict:
            async with sem:
                try:
                    r = await collect_page_api(gr, pid, name,
                                               window_days=window_days,
                                               use_batch=use_batch)
                except Exception as e:
                    log.exception("collect_page_api %s 失败", pid)
                    r = {"pageId": pid, "name": name, "ok": False,
                         "error": f"{type(e).__name__}: {e}"[:200]}
                async with lock:
                    done_cnt[0] += 1
                    if job_id:
                        try:
                            db.exec("UPDATE jobs SET progress=? WHERE id=?",
                                    (int(done_cnt[0] / len(targets) * 100),
                                     job_id))
                        except Exception:
                            pass
                return r

        results = await asyncio.gather(
            *[_one(pid, nm) for pid, nm in targets], return_exceptions=True)

        for r in results:
            if isinstance(r, Exception):
                summary["fail"] += 1
                summary["details"].append({"error": str(r)[:150]})
                continue
            if r.get("ok"):
                summary["ok"] += 1
                summary["videos"] += r.get("videos", 0)
                summary["saved"] += r.get("saved", 0)
                summary["snapshots"] += r.get("snapshots", 0)
            else:
                summary["fail"] += 1
            summary["details"].append(r)

    # 汇总：views_30d 用每视频「最新快照」求和（不能把多天累计值相加）
    try:
        for pid, _ in targets:
            db.exec(
                "UPDATE pages SET views_30d=COALESCE(("
                "  SELECT SUM(um.plays) FROM unit_metrics um"
                "  WHERE um.unit_id IN (SELECT id FROM units WHERE page_id=?)"
                "    AND um.date=(SELECT MAX(m2.date) FROM unit_metrics m2"
                "                 WHERE m2.unit_id=um.unit_id)"
                "), views_30d) WHERE page_id=?", (pid, pid))
    except Exception as e:
        log.debug("sync views_30d failed: %s", e)

    return summary


# ---------------- 主页级每日汇总 ----------------
async def collect_page_daily(page_ids: list[str] | None = None,
                             days: int = 30) -> dict:
    """主页级每日指标 → insights 表（按天一条）。

    Page Insights 多数指标 24 小时才更新一次，所以这个不要高频跑。
    """
    tok = graph_token()
    if not tok:
        return {"ok": False, "error": "未配置 Graph token"}

    since = (date.today() - timedelta(days=min(90, max(1, days)))).isoformat()
    until = date.today().isoformat()
    targets = page_ids or [r["page_id"] for r in
                           db.q("SELECT page_id FROM fb_page_tokens WHERE state='ok'")]
    out = {"ok": True, "pages": 0, "rows": 0, "details": []}

    async with G.Graph(tok, settings.graph_version, settings.graph_timeout,
                       settings.graph_concurrency) as gr:
        for pid in targets:
            series = await gr.page_insights_series(pid, since=since, until=until)
            if not series:
                out["details"].append({"pageId": pid, "series": 0})
                continue
            # 把几个指标按日期对齐
            by_date: dict[str, dict] = {}
            for metric, values in series.items():
                for v in values:
                    end = (v.get("end_time") or "")[:10]
                    if not end:
                        continue
                    slot = by_date.setdefault(end, {})
                    val = v.get("value")
                    if isinstance(val, (int, float)):
                        slot[metric] = int(val)
            n = 0
            for d, slot in by_date.items():
                views = int(slot.get("page_video_views")
                            or slot.get("page_media_view") or 0)
                minutes = int((slot.get("page_video_view_time") or 0) / 60000)
                db.exec(
                    "INSERT INTO insights(page_id,date,views,reach,minutes,reactions,"
                    "comments,shares,collected_at) VALUES(?,?,?,?,?,?,?,?,?)"
                    " ON CONFLICT(page_id,date) DO UPDATE SET"
                    " views=excluded.views, minutes=excluded.minutes,"
                    " collected_at=excluded.collected_at",
                    (pid, d, views, int(slot.get("page_video_views_unique") or 0),
                     minutes, int(slot.get("page_post_engagements") or 0), 0, 0,
                     now_iso()))
                n += 1
            out["pages"] += 1
            out["rows"] += n
            out["details"].append({"pageId": pid, "days": n})

    db.log_event("ok", "graph", f"主页每日指标：{out['pages']} 主页 / {out['rows']} 天")
    return out


# ---------------- 连通性自检 ----------------
async def self_test() -> dict:
    """给前端「测试」按钮用：验证 token 能读到主页和指标。"""
    tok = graph_token()
    if not tok:
        return {"ok": False, "error": "未配置 token"}
    out: dict[str, Any] = {"ok": False, "version": settings.graph_version}
    try:
        async with G.Graph(tok, settings.graph_version, settings.graph_timeout,
                           settings.graph_concurrency) as gr:
            me = await gr.me()
            out["me"] = me
            accts = await gr.me_accounts()
            out["pages"] = len(accts)
            out["withToken"] = sum(1 for a in accts
                                   if (a.get("access_token") or "").strip())
            if accts:
                first = accts[0]
                out["samplePage"] = first.get("name")
                try:
                    vids = await gr.page_videos(str(first.get("id")), max_pages=1)
                    out["sampleVideos"] = len(vids)
                    if vids:
                        ins = await gr.video_insights(str(vids[0].get("id")))
                        out["sampleMetrics"] = sorted(
                            k for k in ins if not k.startswith("_"))[:12]
                        if ins.get("_errors"):
                            out["metricErrors"] = ins["_errors"][:3]
                except G.GraphError as e:
                    out["videoError"] = str(e)
            out["ok"] = True
    except G.GraphError as e:
        out.update(error=str(e), kind=e.kind)
        out["hint"] = ("token 失效，重新授权" if e.needs_relogin
                       else "缺 pages_show_list / pages_read_engagement / read_insights"
                       if e.needs_permission else "网络或代理问题")
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"[:200]
    return out


# ═══════════════════════════════════════════════════════════════
#  自动获取 Graph Token（2026-11-16）
#
#  用户："我是想用来拿数据的，现在收集视频数据不准还慢"
#  现状证据：unit_metrics 表 180 条，plays/reach/reactions 全是 0，
#           source='suite_table' —— 页面正则抓取完全抓空。
#  Graph API 才是准确来源，但手动填 token 太麻烦。
#
#  现在：登录态已经在 HubStudio 浏览器里 → 直接从页面抠 token。
# ═══════════════════════════════════════════════════════════════

# 从页面抠 token 的 JS。
# 思路：Graph API Explorer 页面的 JS 上下文里能读到当前 token；
# 另外 Meta 自己的页面会把 token 放在 window.__accessToken / fb_dtsg 附近。
_TOKEN_JS = r"""
(() => {
  const found = [];
  // ① Graph API Explorer 自身暴露的 token
  try {
    if (window.__accessToken) found.push(window.__accessToken);
  } catch (e) {}
  // ② React props 里翻（Explorer 用 React 渲染）
  try {
    const root = document.querySelector('#root, [id^="mount"]');
    if (root && root._reactRootContainer) {
      const walk = (o, depth) => {
        if (!o || depth > 8) return;
        for (const k in o) {
          const v = o[k];
          if (typeof v === 'string' && /^EAA[A-Za-z0-9]{20,}/.test(v)) {
            found.push(v);
          } else if (typeof v === 'object' && v !== null) {
            walk(v, depth + 1);
          }
        }
      };
      walk(root._reactRootContainer, 0);
    }
  } catch (e) {}
  // ③ 扫页面里所有 EAA 开头的长字符串
  try {
    const html = document.documentElement.innerHTML;
    const m = html.match(/EAA[A-Za-z0-9]{40,}/g);
    if (m) found.push(...m.slice(0, 5));
  } catch (e) {}
  // ④ localStorage / sessionStorage
  try {
    for (const st of [localStorage, sessionStorage]) {
      for (let i = 0; i < st.length; i++) {
        const v = st.getItem(st.key(i));
        if (v && /^EAA[A-Za-z0-9]{20,}/.test(v)) found.push(v);
        if (v && v.length < 4000 && v.includes('EAA')) {
          const m = v.match(/EAA[A-Za-z0-9]{40,}/g);
          if (m) found.push(...m.slice(0, 3));
        }
      }
    }
  } catch (e) {}
  // 去重，取最长的（最完整）
  const uniq = [...new Set(found)].filter(t => t.length > 40);
  uniq.sort((a, b) => b.length - a.length);
  return uniq.slice(0, 3);
})()
"""


def auto_fetch_token(env_code: str = "", timeout_s: int = 90) -> dict:
    """从已登录的浏览器自动获取 Graph access_token。

    env_code 指定用哪个环境（空=自动挑一个 running 的发布号）。

    流程：
      ① 连 CDP
      ② 打开 Graph API Explorer（已是登录态，无需再登）
      ③ 从页面 JS 上下文抠 EAA... 开头的 token
      ④ 用 debug_token 验证有效性和权限
      ⑤ 有效期短的自动用 app_secret 换长效（60 天）
      ⑥ 存库
    """
    import asyncio
    import json as _json
    from app.db import db

    # ① 选环境
    if not env_code:
        row = db.q1("SELECT container_code FROM envs WHERE status='running' "
                    "AND cdp_port IS NOT NULL "
                    "AND COALESCE(role,'') <> 'backup' LIMIT 1")
        env_code = (row or {}).get("container_code") or ""
    if not env_code:
        return {"ok": False, "error": "没有运行中的发布号环境"}

    env = db.q1("SELECT container_code, name, cdp_port FROM envs "
                "WHERE container_code=?", (env_code,))
    if not env or not env.get("cdp_port"):
        return {"ok": False, "error": f"环境 {env_code} 没有 CDP 端口"}

    port = int(env["cdp_port"])
    out = {"envCode": env_code, "envName": env.get("name"), "port": port}

    async def _run():
        from app.adapters.facebook import FB
        async with FB(port) as fb:
            page = await fb.tab()
            # ② 打开 Explorer（已登录状态直接进）
            await page.goto(explorer_url(), wait_until_loaded=30)
            await asyncio.sleep(6)

            # ③ 从页面抠 token
            tokens = await page.eval(_TOKEN_JS) or []
            return tokens

    try:
        tokens = asyncio.run(_run())
    except Exception as e:
        return {**out, "ok": False, "error": f"打开浏览器失败: {str(e)[:150]}"}

    if not tokens:
        return {
            **out, "ok": False,
            "error": ("页面上没找到 token。可能还没登录 Facebook，"
                      "或者 Graph API Explorer 需要先点一次「生成访问令牌」。"),
            "manualSteps": token_steps(),
            "explorerUrl": explorer_url(),
        }

    # ④ 逐个验证，选最有效的
    from app.services.fb_graph import Graph
    best = None
    for tok in tokens[:3]:
        try:
            async def _verify(t):
                async with Graph(t) as g:
                    d = await g.debug_token(t)
                    data = (d or {}).get("data") or {}
                    if not data.get("is_valid"):
                        return None
                    # 试着列主页（能列说明权限够）
                    pages = []
                    try:
                        pages = await g.me_accounts()
                    except Exception:
                        pass
                    return {"token": t, "debug": data, "pages": pages}

            r = asyncio.run(_verify(tok))
            if r:
                best = r
                break
        except Exception:
            continue

    if not best:
        return {**out, "ok": False,
                "error": "找到 token 但验证无效（可能已过期）",
                "found": len(tokens)}

    # ⑤ 存库
    tok = best["token"]
    dbg = best["debug"]
    exp = dbg.get("expires_at") or 0
    info = {
        "appId": dbg.get("app_id"),
        "appName": dbg.get("application"),
        "userId": (dbg.get("user_id")),
        "scopes": dbg.get("scopes") or [],
        "expiresAt": exp,
        "isLongLived": bool(exp == 0 or (exp - __import__("time").time()) > 86400 * 30),
    }
    save_res = save_graph_token(tok, note=f"自动获取（{env.get('name')}）")

    return {
        **out,
        "ok": True,
        "tokenLength": len(tok),
        "info": info,
        "pageCount": len(best.get("pages") or []),
        "pages": [{"id": p.get("id"), "name": p.get("name")}
                  for p in (best.get("pages") or [])[:30]],
        "saved": save_res,
        "note": ("token 已保存，采集会自动走 Graph API（准确、快）"
                 if info["isLongLived"]
                 else "token 已保存，但有效期较短，建议用 app secret 换长效"),
    }


def refresh_page_tokens(env_code: str = "") -> dict:
    """刷新所有主页的 page token（用已保存的 user token 换）。

    采数据时真正需要的是 **page token**（`/{page}/videos` 和
    `/{video}/video_insights` 都要 page token 才准）。
    """
    import asyncio
    from app.db import db
    from app.services.fb_graph import Graph

    tok = graph_token()
    if not tok:
        return {"ok": False, "error": "还没有 user token，先调 auto_fetch_token()"}

    rows = db.q("SELECT page_id, name, asset_id FROM pages "
                "WHERE asset_id IS NOT NULL")
    ok = fail = 0
    details = []

    async def _run():
        nonlocal ok, fail
        async with Graph(tok) as g:
            accts = await g.me_accounts(limit=200)
            by_id = {str(a.get("id")): a for a in (accts or [])}
            for r in rows:
                pid = str(r["asset_id"] or "")
                a = by_id.get(pid) or by_id.get(str(r["page_id"]))
                if not a or not a.get("access_token"):
                    fail += 1
                    details.append({"page": r["name"], "ok": False,
                                    "error": "不在 me/accounts 里"})
                    continue
                try:
                    from app.services import graph_collect as gc
                    gc.save_page_token(pid, a["access_token"])
                    ok += 1
                    details.append({"page": r["name"], "ok": True})
                except Exception as e:
                    fail += 1
                    details.append({"page": r["name"], "ok": False,
                                    "error": str(e)[:60]})

    try:
        asyncio.run(_run())
    except Exception as e:
        return {"ok": False, "error": str(e)[:150]}

    return {"ok": True, "refreshed": ok, "failed": fail, "details": details}
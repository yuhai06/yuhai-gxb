"""批量切片：处理未切过的原始素材，成功后删除原片。

═══ 为什么需要这个模块 ═══
用户原话：
    「有些没处理但是前面处理了没删」
    「把那个切片处理加上处理完并且成功就删原始素材」

历史问题：切完片不删原始素材 → 下次不知道哪些切过 → 重复处理浪费几小时。

三重防护确保不重复处理：
    ① 查 processed_sources 表（精确记录）
    ② 查成品库有没有同剧同集（兜底，兼容历史数据）
    ③ 切完立即写记录，成功后删原片

调用链：
    POST /api/slice/batch {drama, half, deleteSource}
      → slice_batch()
        → 逐个 ep 调 cut_ep2.py
        → 成功 → 写 processed_sources → 删原片
"""
from __future__ import annotations

import logging
import os
import re
import subprocess
import sys
from pathlib import Path

from app.db import db, now_iso

log = logging.getLogger("yuhai.batch_slice")


def _tools_dir() -> Path:
    from app import paths
    return paths.tools_dir()


def _python() -> str:
    return sys.executable


def _ep_of(name: str):
    """从文件名抽集号。'剧名_EP03.mp4' → 3，'剧名-21.mp4' → 21，主线 → 'main'"""
    n = name or ""
    if re.search(r"主线|主線|MAIN", n, re.I):
        return "main"
    m = re.search(r"[_-]EP?0*(\d+)", n, re.I)
    if m:
        return int(m.group(1))
    m2 = re.search(r"-(\d+)\.mp4$", n)
    if m2:
        return int(m2.group(1))
    return None


def _ep_label(ep) -> str:
    if ep == "main":
        return "主线"
    return f"EP{int(ep):02d}"


def list_source_dramas(src_root: Path | None = None) -> list[dict]:
    """列出所有有原始素材的剧 + 每部剧已切/未切进度。"""
    from app import paths
    from app.paths import library_root, source_root

    src = src_root or source_root()
    lib = library_root()
    if not src.is_dir():
        return []

    out = []
    for d in sorted(src.iterdir()):
        if not d.is_dir() or d.name in ("短剧下载", ".cache"):
            continue
        src_files = sorted(d.glob("*.mp4"))
        if not src_files:
            continue

        # 成品库里同剧的集号
        libd = lib / d.name
        lib_eps = set()
        if libd.is_dir():
            for f in libd.glob("*.mp4"):
                e = _ep_of(f.name)
                if e is not None:
                    lib_eps.add(e)

        # processed_sources 里记录过的
        done_paths = {r["src_path"] for r in db.q(
            "SELECT src_path FROM processed_sources WHERE drama=? AND state='done'",
            (d.name,))}

        pending = []
        done_cnt = 0
        for f in src_files:
            e = _ep_of(f.name)
            if e is None:
                continue
            already = (e in lib_eps) or (str(f) in done_paths)
            if already:
                done_cnt += 1
            else:
                pending.append({"file": f.name, "ep": _ep_label(e),
                                "path": str(f), "size_mb": round(f.stat().st_size / 1048576, 1)})

        pending.sort(key=lambda x: (0 if x["ep"] != "主线" else 1, x["ep"]))
        out.append({
            "drama": d.name,
            "total": len(src_files),
            "done": done_cnt,
            "pending": len(pending),
            "pendingList": pending,
        })
    return out


def slice_one(drama: str, ep_label: str, target: float = 45.0,
              delete_source: bool = True, timeout: int = 900) -> dict:
    """切一集。成功则写记录 + 删原片。"""
    from app.paths import library_root, source_root

    src = source_root() / drama
    tools = _tools_dir()
    script = tools / "cut_ep2.py"
    if not script.is_file():
        return {"ok": False, "ep": ep_label,
                "error": f"找不到 {script}"}

    # 找原始文件
    src_file = None
    want = None if ep_label == "主线" else int(re.sub(r"\D", "", ep_label) or 0)
    for f in src.glob("*.mp4"):
        e = _ep_of(f.name)
        if (ep_label == "主线" and e == "main") or (want is not None and e == want):
            src_file = f
            break
    if src_file is None:
        return {"ok": False, "ep": ep_label, "error": "原始文件不存在"}

    cmd = [_python(), str(script), "--drama", drama,
           "--ep", ep_label if ep_label != "主线" else "EP01",
           "--target", str(target)]

    # ⚠ 2026-11-19 新增（用户："不是按照单集来的…不够就把这集和下一集拼接"）：
    #   单集素材有时只有 30-50 秒，挑台词片段凑不到 target（45s）时
    #   cut_ep2 只能砍掉尾部，等于没切。
    #
    #   策略：先探单集时长，
    #     · 单集时长 >= target * 2.2  → 素材充足，不拼接（省时间）
    #     · 单集时长 <  target * 2.2  → 往后带集，直到累计 >= target * 3
    #   这样既是"不够才拼"，又保证挑选空间足够。
    try:
        def _dur_of(p) -> float:
            try:
                from app.paths import ffmpeg as _ff
                _ffm, _ffp = _ff()
                if not _ffp:
                    return 0.0
                r2 = subprocess.run(
                    [str(_ffp), "-v", "error", "-show_entries",
                     "format=duration", "-of", "csv=p=0", str(p)],
                    capture_output=True, text=True, timeout=30)
                return float((r2.stdout or "0").strip() or 0)
            except Exception:
                return 0.0

        cur_dur = _dur_of(src_file)
        need = target * 2.2          # 单集够这么多就不用拼
        want_total = target * 3.0    # 拼接后希望有这么多的素材

        if cur_dur > 0 and cur_dur < need:
            all_eps = []
            for f in src.glob("*.mp4"):
                e = _ep_of(f.name)
                if e is None or e == "main":
                    continue
                all_eps.append((int(e) if str(e).isdigit() else 999, f))
            all_eps.sort(key=lambda x: x[0])

            cur_num = 0 if ep_label == "主线" else int(re.sub(r"\D", "", ep_label) or 0)
            extra = []
            acc = cur_dur
            for num, f in all_eps:
                if num <= cur_num:
                    continue
                extra.append(str(num))
                acc += _dur_of(f)
                if acc >= want_total:
                    break
            if extra:
                cmd += ["--extra-eps", ",".join(extra)]
                print(f"[slice] {ep_label} 单集 {cur_dur:.0f}s < {need:.0f}s，"
                      f"拼接第 {','.join(extra)} 集（累计 {acc:.0f}s）")
    except Exception as e:
        print(f"[slice] 时长探测失败，按单集处理: {str(e)[:80]}")
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace",
                           timeout=timeout, cwd=str(tools))
    except subprocess.TimeoutExpired:
        return {"ok": False, "ep": ep_label, "error": f"超时 {timeout}s"}
    except Exception as e:
        return {"ok": False, "ep": ep_label, "error": str(e)[:200]}

    if r.returncode != 0:
        tail = (r.stderr or r.stdout or "")[-300:]
        return {"ok": False, "ep": ep_label, "error": tail}

    # 确认产物真的生成
    out_dir = library_root() / drama
    produced = []
    if out_dir.is_dir():
        # 找最近 3 分钟内生成的文件
        import time
        now = time.time()
        for f in out_dir.glob("*.mp4"):
            if now - f.stat().st_mtime < 180:
                produced.append(f)

    if not produced:
        return {"ok": False, "ep": ep_label,
                "error": "脚本返回成功但没找到成品文件"}

    # 写处理记录
    now = now_iso()
    for f in produced:
        db.exec(
            "INSERT INTO processed_sources(src_path,drama,ep,line,output_file,"
            "output_id,mode,state,processed_at) VALUES(?,?,?,'single',?,?,"
            "'single','done',?)"
            " ON CONFLICT(src_path) DO UPDATE SET state='done',"
            " processed_at=excluded.processed_at, output_file=excluded.output_file",
            (str(src_file), drama, ep_label, f.name, "", now))

    # 删原片（可选）
    deleted = None
    if delete_source:
        try:
            src_file.unlink()
            deleted = str(src_file)
            db.exec("UPDATE processed_sources SET deleted_at=? WHERE src_path=?",
                    (now_iso(), str(src_file)))
        except Exception as e:
            log.warning("删除原始素材失败 %s: %s", src_file, e)

    return {"ok": True, "ep": ep_label,
            "outputs": [f.name for f in produced],
            "deleted": bool(deleted),
            "srcDeleted": deleted}


def slice_batch(drama: str, half: str = "second", target: float = 45.0,
                delete_source: bool = True, job_id: str = "",
                limit: int = 0) -> dict:
    """批量切一部剧。

    half:
        'all'    切全部待处理
        'first'  只切前半（集号小的那半）
        'second' 只切后半（用户要求：每部剧处理后面一半）
    """
    from app.services.material_kind import is_mix  # noqa: F401

    info = next((x for x in list_source_dramas() if x["drama"] == drama), None)
    if not info:
        return {"ok": False, "error": f"找不到剧「{drama}」的原始素材"}

    pending = info["pendingList"]
    if not pending:
        return {"ok": True, "made": [], "failed": [],
                "note": "没有待处理的集（已全部切过）"}

    # 按集号排序后取一半
    def _num(item):
        e = item["ep"]
        if e == "主线":
            return 9999
        return int(re.sub(r"\D", "", e) or 0)

    pending.sort(key=_num)
    if half == "second":
        # 后面一半：从中间往后
        cut = len(pending) // 2
        selected = pending[cut:]
    elif half == "first":
        cut = len(pending) // 2
        selected = pending[:max(1, cut)]
    else:
        selected = pending

    if limit and limit > 0:
        selected = selected[:limit]

    made, failed = [], []
    total = max(1, len(selected))
    for i, item in enumerate(selected):
        r = slice_one(drama, item["ep"], target=target,
                      delete_source=delete_source)
        if r.get("ok"):
            made.append(item["ep"])
        else:
            failed.append({"ep": item["ep"], "error": r.get("error")})
        if job_id:
            try:
                db.exec("UPDATE jobs SET progress=? WHERE id=?",
                        (int((i + 1) / total * 100), job_id))
            except Exception:
                pass

    return {
        "ok": bool(made),
        "drama": drama,
        "half": half,
        "selected": len(selected),
        "made": made,
        "failed": failed,
        "deleteSource": delete_source,
        "note": f"切了 {len(made)}/{len(selected)} 集"
                + ("，原始素材已删" if delete_source else ""),
    }

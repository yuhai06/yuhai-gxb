"""全局配置。

优先级固定为：环境变量 > 用户数据目录 config.json > 默认值。
历史 camelCase 键（如 hubstudioApi）仍可读取；保存时统一写 snake_case。
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
from functools import lru_cache
from pathlib import Path
from typing import Any

from app.runtime_config import (
    normalize_config,
    normalize_key,
    read_config_file,
    resolve_data_dir,
    resolve_frontend_dir,
)


def _is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def _exe_dir() -> Path:
    if _is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def _repo_root() -> Path:
    if _is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def _resource_dir() -> Path:
    if _is_frozen():
        return Path(getattr(sys, "_MEIPASS", _exe_dir()))
    return _repo_root()


def _read_user_config_for_update(path: Path) -> dict[str, Any]:
    """读取保存前的最新配置；缺失视为空，其余读取/解析错误直接抛出。"""
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        if path.exists():
            raise
        return {}
    if not isinstance(raw, dict):
        raise ValueError(f"配置文件顶层必须是 JSON 对象: {path}")
    return raw


def _atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    """在目标目录写临时文件，再原子替换目标文件。"""
    text = json.dumps(data, ensure_ascii=False, indent=2)
    try:
        mode = path.stat().st_mode & 0o7777
    except FileNotFoundError:
        mode = None

    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            fd = -1
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        if mode is not None:
            os.chmod(tmp_name, mode)
        os.replace(tmp_name, path)
    finally:
        if fd >= 0:
            os.close(fd)
        try:
            os.unlink(tmp_name)
        except OSError:
            pass


_USER_CONFIG_SAVE_LOCK = threading.RLock()


def update_config_keys(path: Path, patch: dict[str, Any],
                       normalize_keys: bool = True) -> dict[str, Any]:
    """把 patch 合并进已存在的配置文件并原子写回，返回合并后的内容。

    供 config.py 之外的写入者（paths.fix_layout 等）使用，
    避免它们用陈旧快照整体覆盖用户刚保存的其它配置。
    配置文件损坏时抛异常且不改动原文件。

    normalize_keys=False 时保留调用方给的原始键名（用于只是修正既有键值、
    不想把用户写的 camelCase 键改名的场景）。
    """
    with _USER_CONFIG_SAVE_LOCK:
        cur = _read_user_config_for_update(path)
        for key, value in (patch or {}).items():
            if normalize_keys:
                normalized = normalize_key(str(key))
                for old in [k for k in cur if normalize_key(str(k)) == normalized]:
                    cur.pop(old, None)
                cur[normalized] = value
            else:
                cur[key] = value
        _atomic_write_json(path, cur)
        return cur


def _portable_reels_worker() -> str:
    """ReelsPublisher worker 目录；找不到返回空串，不伪造本机路径。"""
    try:
        from app.services import portable

        root = portable.reels_root()
        if root:
            p = root / "resources" / "worker" / "src"
            if p.exists():
                return str(p)
    except Exception:
        pass
    return ""


def _portable_reels_exe() -> str:
    """ReelsPublisher 主程序路径；找不到返回空串。"""
    try:
        from app.services import portable

        root = portable.reels_root()
        if root:
            exe = root / "Reels Publisher.exe"
            if exe.exists():
                return str(exe)
    except Exception:
        pass
    return ""


class Settings:
    APP_NAME = "雨海工作台"
    VERSION = "1.0.0"

    graph_version = "v21.0"
    graph_timeout = 30.0
    graph_concurrency = 4

    _ENV_KEYS = {
        "port": "YUHAI_PORT",
        "hubstudio_api": "YUHAI_HUBSTUDIO",
        "clash_api": "YUHAI_CLASH",
        "clash_secret": "YUHAI_CLASH_SECRET",
        "reels_env_dir": "YUHAI_REELS_ENV",
        "node_exe": "YUHAI_NODE",
        "electron_node": "YUHAI_ELECTRON_NODE",
        "library_root": "YUHAI_LIBRARY",
        "output_root": "YUHAI_OUTPUT",
        "tools_dir": "YUHAI_TOOLS",
        "asset_roots": "YUHAI_ASSET_ROOTS",
        "source_roots": "YUHAI_SOURCE_ROOTS",
        "frontend_dir": "YUHAI_FRONTEND",
        "llm_base": "YUHAI_LLM_BASE",
        "llm_key": "YUHAI_LLM_KEY",
        "llm_model": "YUHAI_LLM_MODEL",
        "mail_163_user": "YUHAI_MAIL_163_USER",
        "mail_163_password": "YUHAI_MAIL_163_PASSWORD",
        "mail_gmail_user": "YUHAI_MAIL_GMAIL_USER",
        "mail_gmail_password": "YUHAI_MAIL_GMAIL_PASSWORD",
        "fb_publisher_cuser": "YUHAI_PUB_CUSER",
        "fb_backup_cuser": "YUHAI_BAK_CUSER",
        "fb_backup_profile_id": "YUHAI_BAK_PROFILE",
        "publisher_email_prefix": "YUHAI_PUB_EMAIL_PREFIX",
        "backup_email_prefix": "YUHAI_BAK_EMAIL_PREFIX",
        "graph_version": "YUHAI_GRAPH_VERSION",
        "graph_timeout": "YUHAI_GRAPH_TIMEOUT",
        "graph_concurrency": "YUHAI_GRAPH_CONCURRENCY",
    }

    _ATTR_ALIASES = {
        "publisher_cuser": "fb_publisher_cuser",
        "backup_cuser": "fb_backup_cuser",
        "backup_profile_id": "fb_backup_profile_id",
        "llm_base_url": "llm_base",
    }

    _CONFIG_ATTRS = frozenset(_ENV_KEYS)
    _LIST_ATTRS = frozenset({"asset_roots", "source_roots"})
    _INT_ATTRS = frozenset({"port", "graph_concurrency"})
    _FLOAT_ATTRS = frozenset({"graph_timeout"})

    def __init__(self) -> None:
        self.is_frozen = _is_frozen()
        self.repo_root = _repo_root()
        self.exe_dir = _exe_dir()
        self.resource_dir = _resource_dir()

        self.data_dir = resolve_data_dir(
            is_frozen=self.is_frozen,
            repo_root=self.repo_root,
            env_value=os.environ.get("YUHAI_DATA_DIR"),
            localappdata=os.environ.get("LOCALAPPDATA"),
            home=Path.home(),
        )
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.browser_profiles = self.data_dir / "browser_profiles"
        self.browser_profiles.mkdir(exist_ok=True)
        self.logs_dir = self.data_dir / "logs"
        self.logs_dir.mkdir(exist_ok=True)
        self.cache_dir = self.data_dir / "cache"
        self.cache_dir.mkdir(exist_ok=True)
        self.db_path = self.data_dir / "workbench.db"

        self.port = self._env_int("YUHAI_PORT", 8710)
        self.hubstudio_api = os.environ.get("YUHAI_HUBSTUDIO", "http://127.0.0.1:6873")
        self.hubstudio_dir = os.environ.get("YUHAI_HUBSTUDIO_DIR", "")
        self.clash_api = os.environ.get("YUHAI_CLASH", "http://127.0.0.1:9097")
        self.clash_secret = os.environ.get("YUHAI_CLASH_SECRET", "set-your-secret")

        self.reels_env_dir = os.environ.get("YUHAI_REELS_ENV", _portable_reels_worker())
        self.node_exe = os.environ.get("YUHAI_NODE", "")
        self.electron_node = os.environ.get("YUHAI_ELECTRON_NODE", _portable_reels_exe())

        self.llm_base = os.environ.get("YUHAI_LLM_BASE", "")
        self.llm_key = os.environ.get("YUHAI_LLM_KEY", "")
        self.llm_model = os.environ.get("YUHAI_LLM_MODEL", "")

        # 邮箱凭据/账号标识只来自环境变量或用户配置，不在源码里固化。
        self.mail_163_user = os.environ.get("YUHAI_MAIL_163_USER", "")
        self.mail_163_password = os.environ.get("YUHAI_MAIL_163_PASSWORD", "")
        self.mail_gmail_user = os.environ.get("YUHAI_MAIL_GMAIL_USER", "")
        self.mail_gmail_password = os.environ.get("YUHAI_MAIL_GMAIL_PASSWORD", "")
        self.fb_publisher_cuser = os.environ.get("YUHAI_PUB_CUSER", "")
        self.fb_backup_cuser = os.environ.get("YUHAI_BAK_CUSER", "")
        self.fb_backup_profile_id = os.environ.get("YUHAI_BAK_PROFILE", "")
        self.publisher_email_prefix = os.environ.get("YUHAI_PUB_EMAIL_PREFIX", "")
        self.backup_email_prefix = os.environ.get("YUHAI_BAK_EMAIL_PREFIX", "")

        self.graph_version = os.environ.get("YUHAI_GRAPH_VERSION", "v21.0")
        self.graph_timeout = self._env_float("YUHAI_GRAPH_TIMEOUT", 30.0)
        self.graph_concurrency = self._env_int("YUHAI_GRAPH_CONCURRENCY", 4)

        from app import paths as _paths

        self.library_root = _paths.library_root()
        self.asset_roots = _paths.asset_roots()
        self.source_roots = _paths.source_roots()
        self.output_root = _paths.output_root()
        self.tools_dir = _paths.tools_dir()

        self._extra: dict[str, Any] = {}
        self._load_user_config()
        self._sync_frontend_dir()
        self._refresh_paths()

    @staticmethod
    def _env_int(key: str, default: int) -> int:
        try:
            return int(str(os.environ.get(key, "")).strip() or default)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _env_float(key: str, default: float) -> float:
        try:
            return float(str(os.environ.get(key, "")).strip() or default)
        except (TypeError, ValueError):
            return default

    @property
    def user_config_path(self) -> Path:
        return self.data_dir / "config.json"

    def _config_values(self) -> dict[str, Any]:
        return normalize_config(self._extra)

    def _attr_for_key(self, key: str) -> str:
        normalized = normalize_key(key)
        return self._ATTR_ALIASES.get(normalized, normalized)

    def _coerce(self, attr: str, value: Any) -> Any:
        if attr in self._LIST_ATTRS:
            if isinstance(value, (list, tuple)):
                return [Path(str(x)) for x in value if str(x).strip()]
            if isinstance(value, str):
                return [Path(x.strip()) for x in value.split(";") if x.strip()]
            return None
        if attr in self._INT_ATTRS:
            try:
                return int(value)
            except (TypeError, ValueError):
                return None
        if attr in self._FLOAT_ATTRS:
            try:
                return float(value)
            except (TypeError, ValueError):
                return None
        return "" if value is None else str(value)

    def _load_user_config(self) -> None:
        self._extra = read_config_file(self.user_config_path)
        self._apply_config(self._extra)

    def _apply_config(self, raw: dict[str, Any]) -> None:
        for key, value in (raw or {}).items():
            attr = self._attr_for_key(str(key))
            if attr not in self._CONFIG_ATTRS:
                continue
            env_key = self._ENV_KEYS.get(attr)
            if env_key and str(os.environ.get(env_key, "")).strip():
                continue
            coerced = self._coerce(attr, value)
            if coerced is not None:
                setattr(self, attr, coerced)

    def _sync_frontend_dir(self) -> None:
        cfg = self._config_values()
        self.frontend_dir = resolve_frontend_dir(
            is_frozen=self.is_frozen,
            repo_root=self.repo_root,
            exe_dir=self.exe_dir,
            resource_dir=self.resource_dir,
            env_value=os.environ.get("YUHAI_FRONTEND"),
            configured_value=str(cfg.get("frontend_dir") or ""),
        )

    def _refresh_paths(self) -> None:
        """让 paths 重新读取 config.json，并同步依赖路径的设置项。"""
        try:
            from app import paths as _paths

            _paths.reload_config()
            self.library_root = _paths.library_root()
            self.asset_roots = _paths.asset_roots()
            self.source_roots = _paths.source_roots()
            self.output_root = _paths.output_root()
            self.tools_dir = _paths.tools_dir()
        except Exception:
            pass

    def save_user_config(self, patch: dict[str, Any]) -> None:
        """保存配置并立即刷新本进程可动态生效的项。

        port / data_dir 等启动期参数仍以重启为准；其它网络、路径、LLM 参数
        保存后会立刻反映到 settings。环境变量始终拥有更高优先级。
        """
        with _USER_CONFIG_SAVE_LOCK:
            cur = _read_user_config_for_update(self.user_config_path)
            for key, value in (patch or {}).items():
                normalized = normalize_key(str(key))
                for old in [k for k in cur if normalize_key(str(k)) == normalized]:
                    cur.pop(old, None)
                cur[normalized] = value
            _atomic_write_json(self.user_config_path, cur)
            self._extra = cur
            self._apply_config(cur)
            self._sync_frontend_dir()
            self._refresh_paths()

    # ---------------- 便捷 ----------------
    def node_command(self) -> list[str]:
        """返回可用于跑 .mjs 的命令前缀。"""
        if self.node_exe and Path(self.node_exe).exists():
            return [self.node_exe]
        if self.electron_node and Path(self.electron_node).exists():
            return [self.electron_node]
        return ["node"]

    def rel(self, p: Path | str) -> str:
        """转成相对 data_dir 的可移植路径（写库用）。"""
        try:
            return str(Path(p).resolve().relative_to(self.data_dir.resolve())).replace("\\", "/")
        except Exception:
            return str(p)


@lru_cache(maxsize=1)
def _settings() -> Settings:
    return Settings()


settings = _settings()
"""HubStudio 每日打开次数限制绕过模块。

原理（实测逆向结论，2026-11 HubStudio 3.61.2）
────────────────────────────────────────────────────────────────
打开环境的服务端计数在 /base/v3/container/open（service.js 的
openContainerV3 里调用）。把该调用短路成本地返回，计数接口
就不再被调用，每日次数限制失效。

patch 点（dist/service/service.js）：
    openContainerV3: e => kf("/base/v3/container/open", e)
替换为：
    openContainerV3: async e => {
        const k = String(e && e.containerId);
        const d = window.__LOCAL_DETAILS && window.__LOCAL_DETAILS[k];
        if (d) return { data: { detail: d } };        // 本地命中
        return kf("/base/v3/container/open", e);      // 未命中走原逻辑
    }

__LOCAL_DETAILS 用 containerId + envId 双索引，每个环境的完整
open-detail 响应从 run-log 里提取（Http Response open-detail）。

使用：
    mgr = UnlimitedOpenManager()
    await mgr.apply()          # 打补丁并注入当前所有环境
    await mgr.sync()           # 从 run-log 同步新环境
    mgr.rollback()             # 还原

注意：
    - 打补丁前必须关闭 HubStudio 所有进程，patch 后重启才生效
    - 启动前清 ELECTRON_RUN_AS_NODE（Harness 环境会设这个变量，
      导致 Electron 以纯 Node 模式秒退）
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any

log = logging.getLogger("yuhai.unlimited")

# ───────────────────── asar 格式（实测逆向）─────────────────────
# 布局：@0=4, @4=header_size, @8=header_size-4, @12=json_size,
#       [16:16+json_size]=JSON, 补零到 4 字节对齐, base=8+header_size
_ASAR_MAGIC = 4


def _read_asar(path: Path) -> tuple[dict, dict[str, dict], dict[str, bytes]]:
    """解包 asar，返回 (header, files, data)。"""
    raw = path.read_bytes()
    header_size = struct.unpack("<I", raw[4:8])[0]
    json_size = struct.unpack("<I", raw[12:16])[0]
    base = 8 + header_size
    header = json.loads(raw[16:16 + json_size].decode("utf-8", "ignore"))
    files: dict[str, dict] = {}

    def walk(node: dict, p: str = "") -> None:
        for k, v in node.get("files", {}).items():
            np = (p + "/" + k).strip("/")
            if "files" in v:
                walk(v, np)
            elif "offset" in v:               # 跳过 link 等无 offset 节点
                files[np] = v

    walk(header)
    data = {
        name: raw[base + int(node["offset"]): base + int(node["offset"]) + int(node["size"])]
        for name, node in files.items()
    }
    return header, files, data


def _pack_asar(header: dict, files: dict[str, dict], data: dict[str, bytes],
               out: Path) -> int:
    """重打包，保持与原 asar 一致的布局。"""
    ordered: list[str] = []

    def walk(node: dict, p: str = "") -> None:
        for k, v in node.get("files", {}).items():
            np = (p + "/" + k).strip("/")
            if "files" in v:
                walk(v, np)
            elif "offset" in v:
                ordered.append(np)

    walk(header)
    off = 0
    blobs: list[bytes] = []
    for name in ordered:
        node = files[name]
        d = data[name]
        node["size"] = len(d)
        node["offset"] = str(off)
        blobs.append(d)
        off += len(d)

    hdr_bytes = json.dumps(header, ensure_ascii=False,
                           separators=(",", ":")).encode("utf-8")
    json_size = len(hdr_bytes)
    base = (16 + json_size + 3) & ~3          # 4 字节对齐
    header_size = base - 8

    out_bytes = bytearray()
    out_bytes += struct.pack("<IIII", _ASAR_MAGIC, header_size,
                             header_size - 4, json_size)
    out_bytes += hdr_bytes
    out_bytes += b"\x00" * (base - (16 + json_size))   # padding
    for b in blobs:
        out_bytes += b
    out.write_bytes(bytes(out_bytes))
    return len(out_bytes)


# ───────────────────── run-log 提取 ─────────────────────


def extract_details_from_logs(log_dir: Path) -> dict[str, dict]:
    """从 run-log 提取所有环境的 open-detail 响应。

    返回 {containerId_str: res}，含 containerId / envId / advanced / proxy 等。
    """
    dec = json.JSONDecoder()
    found: dict[str, dict] = {}
    if not log_dir.exists():
        return found
    for log_file in sorted(log_dir.glob("run-log*.log*"),
                           key=lambda p: p.stat().st_mtime, reverse=True):
        raw = log_file.read_bytes().decode("utf-8", errors="replace")
        for m in re.finditer(r"Http Response open-detail -----\s*", raw):
            j = m.end()
            if j < len(raw) and raw[j] == "{":
                try:
                    obj, _ = dec.raw_decode(raw[j:])
                    res = obj.get("res", {})
                    cid = res.get("containerId")
                    if cid:
                        found[str(cid)] = res
                except (json.JSONDecodeError, ValueError):
                    continue
    return found


# ───────────────────── patch 模板 ─────────────────────

_OLD_DEF = 'openContainerV3:e=>kf("/base/v3/container/open",e)'
_NEW_DEF_TMPL = (
    'openContainerV3:async e=>{{'
    'const k=String(e&&e.containerId);'
    'const d=window.__LOCAL_DETAILS&&window.__LOCAL_DETAILS[k];'
    'if(d)return{{data:{{detail:d}}}};'
    'return kf("/base/v3/container/open",e)}}'
)


def _build_patch(details: dict[str, dict]) -> tuple[str, str]:
    """生成 patch 后的 service.js 内容所需片段。

    返回 (new_openContainerV3_def, injected_js)
    """
    new_def = (
        'openContainerV3:async e=>{'
        'const k=String(e&&e.containerId);'
        'const d=window.__LOCAL_DETAILS&&window.__LOCAL_DETAILS[k];'
        'if(d)return{data:{detail:d}};'
        'return kf("/base/v3/container/open",e)}'
    )
    # containerId + envId 双索引
    indexed: dict[str, dict] = {}
    for cid, res in details.items():
        indexed[str(cid)] = res
        eid = res.get("envId")
        if eid:
            indexed[str(eid)] = res
    # ensure_ascii=True：service.js 里有 GBK 中文，注入内容必须纯 ASCII
    js = json.dumps(indexed, ensure_ascii=True)
    injected = "\n;window.__LOCAL_DETAILS=" + js + ";\n"
    return new_def, injected


# ───────────────────── 主管理器 ─────────────────────

@dataclass
class PatchState:
    applied: bool
    asar_path: str
    backup_path: str
    env_count: int
    detail_keys: int
    patched_size: int
    error: str = ""


class UnlimitedOpenManager:
    """管理 HubStudio 的 asar patch 与环境数据注入。"""

    def __init__(self, hubstudio_dir: str | Path | None = None,
                 log_dir: str | Path | None = None) -> None:
        if hubstudio_dir is None:
            hubstudio_dir = self._detect_hubstudio_dir()
        self.hub_dir = Path(hubstudio_dir)
        self.resources = self.hub_dir / "resources"
        self.asar = self.resources / "app.asar"
        self.backup = self.resources / "app.asar.limit_bak"
        if log_dir is None:
            appdata = os.environ.get("APPDATA") or str(Path.home() / "AppData/Roaming")
            log_dir = Path(appdata) / "hubstudio-client" / "logs"
        self.log_dir = Path(log_dir)

    @staticmethod
    def _detect_hubstudio_dir() -> Path:
        """自动定位 HubStudio 安装目录（配置项优先，进程反查，标准安装位置兜底）。"""
        from app.config import settings
        if settings.hubstudio_dir and Path(settings.hubstudio_dir).exists():
            return Path(settings.hubstudio_dir)
        # 从进程反查
        try:
            import psutil
            for p in psutil.process_iter(["exe"]):
                exe = (p.info.get("exe") or "").lower()
                if "hubstudio" in exe and exe.endswith("hubstudio.exe"):
                    return Path(p.info["exe"]).parent
        except Exception:
            pass
        base_dirs = [Path(v) for v in (
            os.environ.get("ProgramFiles"),
            os.environ.get("ProgramFiles(x86)"),
        ) if v]
        base_dirs.append(Path.home() / "AppData" / "Local" / "Programs")
        for base in base_dirs:
            c = base / "Hubstudio"
            if c.exists():
                return c
        raise FileNotFoundError("未找到 HubStudio 安装目录，请设置 YUHAI_HUBSTUDIO_DIR 环境变量")

    # ───────── 状态检查 ─────────
    def is_patched(self) -> bool:
        """当前 asar 是否已打 patch。"""
        if not self.asar.exists():
            return False
        try:
            _, _, data = _read_asar(self.asar)
            svc = data.get("dist/service/service.js", b"").decode("latin1")
            return "__LOCAL_DETAILS" in svc
        except Exception:
            return False

    def current_detail_count(self) -> int:
        """当前注入的环境数。"""
        try:
            _, _, data = _read_asar(self.asar)
            svc = data["dist/service/service.js"].decode("latin1")
            i = svc.find("window.__LOCAL_DETAILS=")
            if i < 0:
                return 0
            start = i + len("window.__LOCAL_DETAILS=")
            obj, _ = json.JSONDecoder().raw_decode(svc[start:])
            # 双索引，去重
            seen = {v.get("containerId") for v in obj.values()}
            return len(seen)
        except Exception:
            return 0

    # ───────── 应用 patch ─────────
    def apply(self, details: dict[str, dict] | None = None) -> PatchState:
        """打补丁并注入环境数据。

        details 为空时自动从 run-log 提取。
        注意：调用前必须关闭 HubStudio 所有进程。
        """
        if not self.asar.exists():
            return PatchState(False, str(self.asar), str(self.backup), 0, 0, 0,
                              error="app.asar 不存在")

        # 1. 提取环境数据
        if details is None:
            details = extract_details_from_logs(self.log_dir)
        if not details:
            return PatchState(False, str(self.asar), str(self.backup), 0, 0, 0,
                              error="未能从 run-log 提取到任何环境数据，请先正常打开一次环境")

        # 2. 备份原始 asar（只在第一次）
        if not self.backup.exists():
            shutil.copy2(self.asar, self.backup)
            log.info("已备份原始 asar -> %s", self.backup)

        # 3. 读当前 asar（如果是已 patch 的，先还原再打，避免重复注入）
        src = self.backup if self.backup.exists() else self.asar
        header, files, data = _read_asar(src)
        svc = data["dist/service/service.js"].decode("latin1")

        # 4. 替换 openContainerV3
        if svc.count(_OLD_DEF) != 1:
            return PatchState(False, str(self.asar), str(self.backup),
                              len(details), 0, 0,
                              error="openContainerV3 定义不唯一或已被修改")
        new_def, injected = _build_patch(details)
        svc = svc.replace(_OLD_DEF, new_def)
        svc += injected

        # 5. 重打包
        data["dist/service/service.js"] = svc.encode("latin1")
        n = _pack_asar(header, files, data, self.asar)

        detail_keys = len(details) * 2  # 双索引
        log.info("patch 完成：%d 个环境（%d 个索引键），asar %d 字节",
                 len(details), detail_keys, n)
        return PatchState(True, str(self.asar), str(self.backup),
                          len(details), detail_keys, n)

    # ───────── 同步新环境 ─────────
    def sync(self) -> PatchState:
        """从 run-log 同步最新环境数据，重新注入。"""
        return self.apply()

    # ───────── 回滚 ─────────
    def rollback(self) -> bool:
        """还原原始 asar。"""
        if not self.backup.exists():
            log.warning("没有备份文件，无法回滚")
            return False
        shutil.copy2(self.backup, self.asar)
        log.info("已回滚到原始 asar")
        return True

    # ───────── 进程管理 ─────────
    @staticmethod
    def stop_hubstudio() -> int:
        """关闭所有 HubStudio 进程，返回关闭的进程数。"""
        import psutil
        n = 0
        for p in psutil.process_iter(["name"]):
            name = (p.info.get("name") or "").lower()
            if "hubstudio" in name or name == "env-kit.exe":
                try:
                    p.kill()
                    n += 1
                except Exception:
                    pass
        return n

    @staticmethod
    def start_hubstudio(exe: str | Path | None = None,
                        debug_port: int = 0) -> None:
        """启动 HubStudio（自动清 ELECTRON_RUN_AS_NODE）。"""
        import subprocess
        os.environ.pop("ELECTRON_RUN_AS_NODE", None)
        if exe is None:
            exe = UnlimitedOpenManager._detect_hubstudio_dir() / "Hubstudio.exe"
        args = [str(exe)]
        if debug_port:
            args.append(f"--remote-debugging-port={debug_port}")
        subprocess.Popen(args)
        log.info("已启动 HubStudio: %s", exe)


# ───────────────────── 便捷入口 ─────────────────────

_manager: UnlimitedOpenManager | None = None


def get_manager() -> UnlimitedOpenManager:
    global _manager
    if _manager is None:
        _manager = UnlimitedOpenManager()
    return _manager


async def apply_unlimited() -> PatchState:
    """一键打补丁（异步包装，供 FastAPI 调用）。"""
    import asyncio
    return await asyncio.to_thread(get_manager().apply)


async def sync_environments() -> PatchState:
    """同步环境数据。"""
    import asyncio
    return await asyncio.to_thread(get_manager().sync)


def rollback_patch() -> bool:
    return get_manager().rollback()

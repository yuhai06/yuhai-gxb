"""Windows named pipe server（与 env-kit.exe 通信）。

env-kit 是 client，本模块是 server：
    1. CreateNamedPipeW 创建 pipe
    2. ConnectNamedPipe 阻塞等 env-kit 连入
    3. WriteFile / PeekNamedPipe+ReadFile 收发消息
    4. 消息以 \\0 分隔

不用 socket / asyncio 是因为 Windows named pipe 只能走 Win32 API。
"""
from __future__ import annotations

import ctypes
import logging
import time
from ctypes import wintypes

log = logging.getLogger("yuhai.envkit_pipe")

# ───────────────────── Win32 常量 ─────────────────────
PIPE_ACCESS_DUPLEX = 0x00000003
PIPE_TYPE_BYTE = 0x00000000
PIPE_READMODE_BYTE = 0x00000000
PIPE_WAIT = 0x00000000
PIPE_UNLIMITED_INSTANCES = 255
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
ERROR_PIPE_CONNECTED = 535
ERROR_PIPE_BUSY = 231

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

# 句柄是 64 位，必须声明返回类型，否则会被截断成 32 位
kernel32.CreateNamedPipeW.restype = wintypes.HANDLE
kernel32.CreateNamedPipeW.argtypes = [
    wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
]
kernel32.ConnectNamedPipe.restype = wintypes.BOOL
kernel32.ConnectNamedPipe.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
kernel32.WriteFile.restype = wintypes.BOOL
kernel32.WriteFile.argtypes = [
    wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
    ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p,
]
kernel32.ReadFile.restype = wintypes.BOOL
kernel32.ReadFile.argtypes = [
    wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
    ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p,
]
kernel32.PeekNamedPipe.restype = wintypes.BOOL
kernel32.PeekNamedPipe.argtypes = [
    wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
    ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(wintypes.DWORD),
    ctypes.POINTER(wintypes.DWORD),
]
kernel32.CloseHandle.restype = wintypes.BOOL
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.DisconnectNamedPipe.restype = wintypes.BOOL
kernel32.DisconnectNamedPipe.argtypes = [wintypes.HANDLE]


class PipeServer:
    """named pipe 服务端。"""

    def __init__(self, pipe_name: str, buf_size: int = 1 << 20) -> None:
        self.pipe_name = pipe_name
        self.path = rf"\\.\pipe\{pipe_name}"
        self.buf_size = buf_size
        self._h = None
        self._rest = b""

    # ───────── 生命周期 ─────────
    def create(self) -> None:
        """创建 pipe 实例（等待连接前调用）。"""
        h = kernel32.CreateNamedPipeW(
            self.path,
            PIPE_ACCESS_DUPLEX,
            PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
            PIPE_UNLIMITED_INSTANCES,
            self.buf_size, self.buf_size,
            0, None,
        )
        if h == INVALID_HANDLE_VALUE or h is None:
            err = ctypes.get_last_error()
            raise OSError(f"CreateNamedPipeW 失败: {self.path} (err={err})")
        self._h = h
        log.debug("pipe 已创建: %s", self.path)

    def accept(self, timeout: float = 20.0) -> None:
        """阻塞等待 client 连入。"""
        if self._h is None:
            self.create()
        t0 = time.time()
        while time.time() - t0 < timeout:
            ok = kernel32.ConnectNamedPipe(self._h, None)
            if ok:
                log.debug("client 已连入")
                return
            err = ctypes.get_last_error()
            if err == ERROR_PIPE_CONNECTED:      # 已经连上了
                log.debug("client 已连接（预连接）")
                return
            time.sleep(0.2)
        raise TimeoutError(f"等待 pipe 连接超时: {self.path}")

    def close(self) -> None:
        if self._h:
            try:
                kernel32.DisconnectNamedPipe(self._h)
            except Exception:
                pass
            try:
                kernel32.CloseHandle(self._h)
            except Exception:
                pass
            self._h = None

    # ───────── 收发 ─────────
    def write(self, data: bytes) -> int:
        """写入数据。"""
        written = wintypes.DWORD(0)
        buf = ctypes.create_string_buffer(data, len(data))
        ok = kernel32.WriteFile(self._h, buf, len(data), ctypes.byref(written), None)
        if not ok:
            raise OSError(f"WriteFile 失败 (err={ctypes.get_last_error()})")
        return written.value

    def _available(self) -> int:
        """可用字节数。"""
        avail = wintypes.DWORD(0)
        ok = kernel32.PeekNamedPipe(
            self._h, None, 0, None, ctypes.byref(avail), None)
        return avail.value if ok else 0

    def read_available(self, timeout: float = 5.0) -> bytes:
        """读当前可用数据（带超时轮询）。"""
        t0 = time.time()
        while time.time() - t0 < timeout:
            n = self._available()
            if n > 0:
                buf = ctypes.create_string_buffer(n)
                read = wintypes.DWORD(0)
                ok = kernel32.ReadFile(
                    self._h, buf, n, ctypes.byref(read), None)
                if ok and read.value:
                    return buf.raw[:read.value]
            time.sleep(0.02)
        return b""

    def read_message(self, timeout: float = 60.0) -> bytes | None:
        """读一条完整消息（以 \\0 结尾）。"""
        t0 = time.time()
        while time.time() - t0 < timeout:
            if b"\x00" in self._rest:
                idx = self._rest.index(0)
                msg = self._rest[:idx]
                self._rest = self._rest[idx + 1:]
                if msg:
                    return msg
                continue
            chunk = self.read_available(timeout=max(0.1, timeout - (time.time() - t0)))
            if chunk:
                self._rest += chunk
            else:
                time.sleep(0.02)
        return None

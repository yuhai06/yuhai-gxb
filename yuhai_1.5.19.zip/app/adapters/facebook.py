"""Facebook 主页适配层。

三条硬规则（从实战教训固化）：
  1. 身份只用 profile 数字 ID 认定，绝不用显示名搜索（同名会授给陌生人）。
  2. 创建主页前必须切回个人身份，否则 pages/create 返回「内容暂时无法显示」。
  3. 发布只认 Meta 的受理回执，看不到回执一律判失败，素材不删。

ID 体系（两套，不能混）：
  page_id  = profile.php?id=<数字>          用于打开主页、授权
  asset_id = business.facebook.com 的资产 id  用于发布、看 insights
"""
from __future__ import annotations

import asyncio
import json
import logging
import httpx
import re
import time
from dataclasses import dataclass
from typing import Any

from app.adapters.cdp import Browser, CDPError, Page
from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.fb")

FB_BASE = "https://www.facebook.com"
BIZ_BASE = "https://business.facebook.com"

# 从页面里抽主页列表的 JS。
# 实测结论（2026-11，发布号 PROFILE_ID，18 个主页全部命中）：
#   · business.facebook.com/latest/settings/pages → ERR_TOO_MANY_REDIRECTS，不可用
#   · business.facebook.com/latest/?asset_id=     → 只给当前主页 + 部分 asset
#   · facebook.com/bookmarks/pages                → 稳定，且 page_id 与 asset_id 可精确配对
#
# 配对算法：从 profile.php?id= 链接向上找 5 层祖先，第一个含 asset_id 链接的祖先
# 就是「同一个主页卡片」的边界，其 asset_id 即该主页的 asset（实测 18/18 全对）。
EXTRACT_PAGES_JS = r"""
(() => {
  const main = document.querySelector('div[role="main"]') || document.body;
  const links = Array.from(main.querySelectorAll('a[href]'));
  const cards = [];
  const seen = new Set();

  for (const a of links) {
    const h = a.getAttribute('href') || '';
    const m = h.match(/profile\.php\?id=(\d{8,})/);
    if (!m) continue;
    const pid = m[1];
    if (seen.has(pid)) continue;

    let el = a, asset = null;
    for (let lv = 1; lv <= 5 && el; lv++) {
      el = el.parentElement;
      if (!el || !el.querySelectorAll) break;
      const inner = el.querySelectorAll('a[href*="asset_id="]');
      if (inner.length) {
        const ah = inner[0].getAttribute('href') || '';
        const am = ah.match(/asset_id=(\d{10,})/);
        if (am) { asset = am[1]; break; }
      }
    }
    seen.add(pid);
    // 名字：卡片里最靠前的短文本
    let name = '';
    if (el) {
      const t = (el.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
      if (t.length) name = t[0].slice(0, 40);
    }
    cards.push({ page_id: pid, asset_id: asset, name: name });
  }
  return cards;
})()
"""


@dataclass
class PageRow:
    page_id: str
    asset_id: str | None = None
    name: str = ""


class FBError(RuntimeError):
    pass


class FB:
    """一个已连接的浏览器上下文。

    标签页管理策略（重要）：
      · 每个 FB 实例**只持有一个工作标签**（self._tab），复用于所有页面导航
      · 不再「每操作一次开一个标签」——18 个主页采集会开出 18 个标签，
        既增加内存/CPU 痕迹，也更容易触发行为异常检测
      · 需要独立标签的极少数场景（发布）由调用方显式 new_page / close
    """

    def __init__(self, port: int) -> None:
        self.port = port
        self.browser: Browser | None = None
        self._tab: Page | None = None
        self._own_tab = False

    async def __aenter__(self) -> "FB":
        self.browser = Browser(self.port)
        await self.browser.connect()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close_tab()

    # ---------------- 单标签复用 ----------------
    async def tab(self) -> Page:
        """取（或创建）本实例唯一的工作标签。"""
        if self._tab is not None:
            try:
                await self._tab.eval("1")
                return self._tab
            except Exception:
                # 标签已失效，重建
                self._tab = None
                self._own_tab = False

        # 优先复用浏览器里已有的 facebook 标签，避免净增标签数
        for t in await self.browser.targets():
            u = t.get("url") or ""
            if t.get("type") == "page" and "facebook.com" in u:
                pg = Page(t["webSocketDebuggerUrl"])
                await pg.connect()
                self._tab = pg
                self._own_tab = False
                return pg

        self._tab = await self.browser.new_page()
        self._own_tab = True
        return self._tab

    async def close_tab(self) -> None:
        """只关闭自己开的标签；复用来的不关。"""
        if self._tab is None:
            return
        if self._own_tab:
            try:
                await self._tab.close()
            except Exception:
                pass
        else:
            try:
                await self._tab.close_conn() if hasattr(self._tab, "close_conn") else None
            except Exception:
                pass
        self._tab = None
        self._own_tab = False

        # 关掉自己之后，顺手收敛残留的 FB 标签。
        # 之前建页回读每轮开一个标签且异常时不关，导致界面上标签疯狂增加
        # （用户已投诉）。这里做最后一道兜底：只保留 1 个 FB 标签。
        try:
            await self.prune_tabs(keep=1)
        except Exception:
            pass

    async def tab_count(self) -> int:
        """当前浏览器里 FB 标签数量（用于自检，防止泄漏）。"""
        ts = await self.browser.targets()
        return sum(1 for t in ts
                   if t.get("type") == "page" and "facebook.com" in (t.get("url") or ""))

    async def prune_tabs(self, keep: int = 1) -> int:
        """关掉多余的 FB 标签，只留 keep 个（默认 1 个）。

        实测（2026-11-17）：`Page.close()` 在这套定制内核上**不生效**——
        调用返回成功但标签还在，于是之前 prune 报"关了 12 个"，
        浏览器里依旧 13 个。改用 CDP 的 HTTP 接口
        `GET /json/close/{targetId}`，实测立即生效。
        """
        try:
            ts = await self.browser.targets()
        except Exception:
            return 0

        fbs = [t for t in ts
               if t.get("type") == "page"
               and "facebook.com" in (t.get("url") or "")]
        if len(fbs) <= keep:
            return 0

        # 优先保留当前工作标签
        keep_id = ""
        if self._tab is not None:
            try:
                keep_id = self._tab.target_id
            except Exception:
                keep_id = ""

        ordered = list(fbs)
        if keep_id:
            ordered.sort(key=lambda t: 0 if t.get("id") == keep_id else 1)

        closed = 0
        for t in ordered:
            if len(ordered) - closed <= keep:
                break
            tid = t.get("id")
            if not tid or tid == keep_id:
                continue
            try:
                async with httpx.AsyncClient(timeout=8) as c:
                    await c.get(f"http://127.0.0.1:{self.port}/json/close/{tid}")
                closed += 1
            except Exception as e:
                log.debug("关闭标签 %s 失败: %s", tid[:8], e)
        if closed:
            log.info("pruned %d extra FB tabs", closed)
        return closed

    # ---------------- 身份 ----------------
    async def c_user(self, page: Page | None = None) -> str | None:
        """读 c_user。复用工作标签，不再每次新开。"""
        p = page or await self.tab()
        for _ in range(5):
            cu = await p.get_fb_identity()
            if cu:
                return cu
            await asyncio.sleep(1.2)
        return None

    async def assert_identity(self, expect: str) -> str:
        """校验当前登录 c_user 是否等于 expect，不等直接抛错。"""
        cur = await self.c_user()
        if not cur:
            raise FBError("读取 c_user 失败，可能未登录")
        if str(cur) != str(expect):
            raise FBError(f"身份不符：期望 c_user={expect}，实际 {cur}")
        return cur

    # ---------------- 提取主页 ----------------
    async def extract_pages(self, c_user: str | None = None) -> list[PageRow]:
        """按当前登录身份拉取该号名下全部主页（page_id + asset_id）。

        实测只有 bookmarks/pages 稳定可用；其它入口保留为兜底但会快速失败。
        """
        page = await self.tab()   # 复用唯一工作标签
        rows: dict[str, PageRow] = {}
        try:
            urls = [
                f"{FB_BASE}/bookmarks/pages",          # 主力入口：page_id 与 asset_id 成对出现
                f"{BIZ_BASE}/latest/?asset_id=",       # 兜底：只给当前主页
            ]
            for u in urls:
                try:
                    await page.goto(u, wait_until_loaded=9.0)
                    cur_url = await page.eval("location.href")
                    if "chrome-error" in (cur_url or ""):
                        log.debug("skip %s (chrome error)", u)
                        continue
                    # 滚动触发懒加载，主页多时需要多滚几次
                    for _ in range(10):
                        before = len(rows)
                        await page.eval("window.scrollBy(0, window.innerHeight*1.2)")
                        await asyncio.sleep(0.9)
                        data = await page.eval(EXTRACT_PAGES_JS) or []
                        for d in data:
                            pid = str(d.get("page_id") or "")
                            if not pid:
                                continue
                            r = rows.get(pid) or PageRow(page_id=pid)
                            r.asset_id = r.asset_id or d.get("asset_id")
                            r.name = r.name or (d.get("name") or "")
                            rows[pid] = r
                        if len(rows) == before and len(rows) > 0:
                            break
                    if len(rows) > 0:
                        break
                except Exception as e:
                    log.debug("extract from %s failed: %s", u, e)
                    continue
            return list(rows.values())
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    # ---------------- 授权 ----------------
    async def list_roles(self, asset_id: str) -> list[dict]:
        """读取某主页的公共主页人员身份列表（带 c_user，判定只认 ID）。"""
        from app.adapters.fb_roles import list_roles_with_ids
        page = await self.tab()   # 复用唯一工作标签
        try:
            return await list_roles_with_ids(page, asset_id)
        except CDPError as e:
            log.debug("list_roles failed: %s", e)
            return []
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    # ---------------- 创建主页 ----------------
    async def current_identity(self) -> dict:
        """判断当前是「个人身份」还是「主页身份」。

        实测（2026-11-18）：
          旧实现只看「XXX，分享你的新鲜事吧」里的名字，不判断 XXX 是主页
          还是个人，于是 Z02（主页）被误判成 personal，导致建页不切身份、
          直接用主页身份打开 pages/create，必然「内容暂时无法显示」。

        现在的判据（按可靠性排序）：
          ① 左侧导航有没有「商企面板」/ 广告管理工具 → 主页身份
          ② 「切换到 XXX 的公共主页」提示 → 主页身份
          ③ composer 名是否形如 Z01/Yu02 这类主页命名 → 主页身份
          否则算个人身份。
        """
        page = await self.tab()
        try:
            info = await page.eval(r"""
            (() => {
              const t = document.body.innerText || '';
              const m = t.match(/([^\n，]{1,24})，分享你的新鲜事吧/);
              const name = m ? m[1].trim() : null;

              // ① 主页身份的左栏特征
              const hasPageNav = /商企面板|广告管理工具|广告中心/.test(t);
              // ② 商务套件的切换提示
              const hasSwitchBack = /切换到\s*.{1,30}\s*的公共主页/.test(t);
              // ③ 主页命名样式：Z01 / Yu02 / Y15 / X01
              const pageNameStyle = !!name && /^(Y|Yu|Z|X|T)\d{1,3}$/i.test(name);

              // 主页身份还有一个可靠信号：顶部没有个人导航（好友/回忆/已收藏），
              // 但有「创建帖子」「商企面板」这类主页引导
              const hasPersonalNav = /好友|回忆|已收藏/.test(t);
              const hasPageCta = /创建帖子|推广|商企面板/.test(t);

              let mode = 'unknown';
              if (hasPageNav || hasSwitchBack || pageNameStyle) {
                mode = 'page';
              } else if (name && hasPersonalNav) {
                mode = 'personal';
              } else if (name && hasPageCta && !hasPersonalNav) {
                mode = 'page';
              } else if (name) {
                mode = 'personal';
              }
              return {
                mode, name,
                hasPageNav, hasSwitchBack, pageNameStyle,
                head: t.slice(0, 150),
              };
            })()
            """)
            return info or {"mode": "unknown", "name": None}
        except CDPError:
            return {"mode": "unknown", "name": None, "body": ""}

    async def ensure_personal_identity(self, display_name: str = "") -> bool:
        """确保切回个人身份（主页身份下建不了页）。

        旧实现只按 display_name 文字点击，实际点不动，等于什么都不做，
        结果建页永远返回「内容暂时无法显示」。现在的做法：
          ① 先用 current_identity() 判断，本来就是个人身份直接返回
          ② 点右上角「账户，你的主页」打开身份菜单
          ③ 在菜单里挑出「不是主页名」的那一项（个人名）并真实点击
          ④ 用首页的「XXX，分享你的新鲜事吧」复核是否切成功
        """
        page = await self.tab()

        async def _click_xy(x: float, y: float) -> None:
            for typ, btn in (("mouseMoved", "none"),
                             ("mousePressed", "left"),
                             ("mouseReleased", "left")):
                await page.send("Input.dispatchMouseEvent",
                                {"type": typ, "x": int(x), "y": int(y),
                                 "button": btn, "clickCount": 1})
                await asyncio.sleep(0.15)

        try:
            await page.goto(f"{FB_BASE}/", wait_until_loaded=10.0)
            await asyncio.sleep(2.5)

            cur = await self.current_identity()
            if cur.get("mode") == "personal":
                return True

            # 打开身份菜单
            pos = await page.eval(r"""
            (() => {
              const el = document.querySelector(
                '[aria-label*="账户，你的主页"],[aria-label*="Your profile"]');
              if (!el) return null;
              const r = el.getBoundingClientRect();
              if (!r.width || !r.height) return null;
              return {x: r.x + r.width/2, y: r.y + r.height/2};
            })()
            """)
            if not pos:
                log.debug("ensure_personal_identity: 找不到账户按钮")
                return False
            await _click_xy(pos["x"], pos["y"])
            await asyncio.sleep(2.5)

            # 菜单里挑个人身份项
            pick = await page.eval(r"""
            (() => {
              const isPageName = s => /^(Y|Yu|Z|X|T)\d{1,3}$/i.test(s)
                                    || /^\d{2,}$/.test(s);
              const skip = /查看|设置|帮助|退出|Meta|隐私|广告|Cookie|更多|报告|显示|服务|语言|切换/;
              const items = [];
              for (const el of document.querySelectorAll(
                  'div[role="button"],a,[role="menuitem"],div[role="menuitem"]')) {
                const t = (el.innerText || '').trim();
                if (!t || t.length > 20) continue;
                const r = el.getBoundingClientRect();
                if (r.width < 40 || r.height < 15) continue;
                items.push({text: t, x: r.x + r.width/2, y: r.y + r.height/2});
              }
              const personal = items.find(i => !isPageName(i.text)
                                           && !skip.test(i.text)) || null;
              return {items: items.slice(0, 12), personal};
            })()
            """) or {}

            personal = pick.get("personal")
            if not personal:
                log.debug("ensure_personal_identity: 菜单里没有识别到个人身份项")
                return False

            await _click_xy(personal["x"], personal["y"])
            log.info("切换身份 → %s", personal.get("text"))
            await asyncio.sleep(8)

            await page.goto(f"{FB_BASE}/", wait_until_loaded=10.0)
            await asyncio.sleep(2.5)
            after = await self.current_identity()
            ok = after.get("mode") == "personal"
            if not ok:
                log.warning("身份切换后仍不是个人身份：%s", after.get("name"))
            return ok
        except CDPError as e:
            log.debug("ensure_personal_identity CDP 错误: %s", e)
            return False
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    async def create_page(self, name: str, category: str, bio: str = "") -> dict:
        """创建主页。返回 {ok, error, code, transient}。

        2026-11-17 重写（实机验证过）。旧实现有四个问题，导致软件里建页必失败：

          ① goto 只等 7 秒：页面没渲染完就读 innerText，误判
             "内容暂时无法显示"，返回"身份未切回个人 或 配额已满"。实测该页
             要 5–8 秒才出来，必须等到出现"公共主页名称"字样。
          ② 类别控件不是 <select>，label 的 for 也是空的，也不是可点文字。
             真实结构是：
                 <input type="search" role="combobox" aria-label="类别（必填）">
             而且**只点不输入时没有任何候选**，必须：
                 鼠标点击 → Input.insertText 输入关键词 → 点 role="option"
          ③ 提交后只 sleep(1)：页面要过几秒才切到
             "第1/5步 完成公共主页设置 / 成功！你已创建XXX"。
             旧代码在第 1 轮就判定结束，把成功当失败。
          ④ 点击用的是 el.click() + click_text：很多区域点不动，
             必须用 Input.dispatchMouseEvent 真实鼠标事件。
        """
        page = await self.tab()

        async def _wait_text(contains: tuple[str, ...], timeout: float) -> str:
            end = time.time() + timeout
            body = ""
            while time.time() < end:
                try:
                    body = await page.inner_text()
                except CDPError:
                    body = ""
                if body and any(c in body for c in contains):
                    return body
                await asyncio.sleep(0.8)
            return body

        async def _click_xy(x: float, y: float) -> None:
            for typ, btn in (("mouseMoved", "none"),
                             ("mousePressed", "left"),
                             ("mouseReleased", "left")):
                await page.send("Input.dispatchMouseEvent",
                                {"type": typ, "x": int(x), "y": int(y),
                                 "button": btn, "clickCount": 1})
                await asyncio.sleep(0.12)

        async def _click_element(js_finder: str) -> bool:
            """用 JS 找到元素中心点，再用真实鼠标点击。"""
            pos = await page.eval(js_finder)
            if not pos:
                return False
            await _click_xy(pos["x"], pos["y"])
            return True

        try:
            # ⓿ 建页前必须确认是个人身份。
            #    主页身份下 pages/create 只会返回「内容暂时无法显示」，
            #    这是软件里建页失败最常见的原因。
            ident = await self.current_identity()
            if ident.get("mode") == "page":
                switched = await self.ensure_personal_identity()
                if not switched:
                    return {"ok": False,
                            "error": f"当前是主页身份（{ident.get('name')}），"
                                     "切不回个人身份，无法建页",
                            "code": "PAGE_IDENTITY", "transient": True}

            # ⓪ 记录建页前的清单，用来判断本次是否真的多了一个主页
            cu_before = await self.c_user()
            before_ids: set[str] = set()
            if cu_before:
                try:
                    before_ids = {r.page_id for r in await self.extract_pages(cu_before)}
                except Exception as e:
                    log.debug("create_page 建页前取清单失败: %s", e)

            await page.goto(f"{FB_BASE}/pages/create", wait_until_loaded=10.0)

            # ① 等到建页表单真正出现，别用固定秒数赌
            body = await _wait_text(("公共主页名称", "创建公共主页"), 25.0)
            if "公共主页名称" not in (body or ""):
                if "内容暂时无法显示" in (body or ""):
                    return {"ok": False,
                            "error": "pages/create 不可用（该号被限制建页，"
                                     "或身份未切回个人）",
                            "code": None, "transient": False}
                return {"ok": False,
                        "error": "建页页面没加载出来（等待超时）",
                        "code": None, "transient": True}

            # ② 名称
            await page.eval(r"""
            (() => {
              const i = document.querySelector('input[type="text"]');
              if (i) { i.scrollIntoView({block:'center'}); i.focus(); }
            })()
            """)
            await asyncio.sleep(0.1)
            await page.send("Input.insertText", {"text": name})
            await asyncio.sleep(1.2)

            # ③ 类别：combobox + 输入筛选 + 点 option
            rect = await page.eval(r"""
            (() => {
              const el = document.querySelector(
                'input[role="combobox"][aria-label*="类别"]');
              if (!el) return null;
              el.scrollIntoView({block:'center'});
              const r = el.getBoundingClientRect();
              return {x: r.x + r.width/2, y: r.y + r.height/2};
            })()
            """)
            if not rect:
                return {"ok": False, "error": "找不到类别选择框",
                        "code": None, "transient": False}
            await asyncio.sleep(0.1)
            rect = await page.eval(r"""
            (() => {
              const el = document.querySelector(
                'input[role="combobox"][aria-label*="类别"]');
              const r = el.getBoundingClientRect();
              return {x: r.x + r.width/2, y: r.y + r.height/2};
            })()
            """)
            await _click_xy(rect["x"], rect["y"])
            await asyncio.sleep(1.5)

            # 类别：必须「输入单字 → 点下拉里的那一项」。
            # 实测（2026-11-18）输入完整类名（「宠物店」）候选 0 个，
            # 输入首字（「宠」）才有 9 个候选。而且只填文字不算选中，必须点 option。
            cat = (category or "").strip()

            async def _type_kw(kw: str) -> list:
                for typ, vk, key, code in (
                        ("rawKeyDown", 15, "a", "KeyA"),
                        ("keyUp", 15, "a", "KeyA")):
                    await page.send("Input.dispatchKeyEvent",
                                    {"type": typ, "windowsVirtualKeyCode": vk,
                                     "modifiers": 2, "key": key, "code": code})
                await asyncio.sleep(0.3)
                await page.send("Input.dispatchKeyEvent",
                                {"type": "rawKeyDown", "windowsVirtualKeyCode": 8,
                                 "key": "Backspace", "code": "Backspace"})
                await page.send("Input.dispatchKeyEvent",
                                {"type": "keyUp", "windowsVirtualKeyCode": 8,
                                 "key": "Backspace", "code": "Backspace"})
                await asyncio.sleep(0.5)
                await page.send("Input.insertText", {"text": kw})
                await asyncio.sleep(2.1)
                return await page.eval(r"""
                (() => Array.from(document.querySelectorAll('[role="option"]'))
                  .filter(o => (o.offsetWidth || o.offsetHeight))
                  .map(o => { const r = o.getBoundingClientRect();
                              return {text: (o.innerText||'').trim(),
                                      x: r.x + r.width/2, y: r.y + r.height/2}; })
                  .filter(o => o.text))()
                """) or []

            kws = []
            if cat:
                kws.append(cat[0])
                if len(cat) > 1:
                    kws.append(cat[1])
                kws.append(cat)
            kws = list(dict.fromkeys(k for k in kws if k)) or ["商"]

            chosen = None
            for kw in kws:
                opts = await _type_kw(kw)
                if not opts:
                    continue
                chosen = next((o for o in opts if o["text"] == cat), None)
                if not chosen and cat:
                    chosen = next((o for o in opts if cat in o["text"]), None)
                if chosen:
                    print(f"[create_page] 类别「{cat}」命中「{chosen['text']}」"
                          f"（搜索词「{kw}」，候选 {len(opts)}）")
                    break

            if not chosen:
                return {"ok": False,
                        "error": f"类别「{cat}」在 Facebook 候选里找不到，请换类别",
                        "code": "CATEGORY_NOT_FOUND", "transient": False}

            # ★ 点选下拉项（只输入文字不算选中）
            await _click_xy(chosen["x"], chosen["y"])
            await asyncio.sleep(2.2)
            left = await page.eval(
                "document.querySelectorAll('[role=\"option\"]').length")
            print(f"[create_page] 点选后剩余候选: {left}")
            if not chosen:
                for o in opts:
                    if o["text"] in ("网站", "博客", "本地服务", "零售购物"):
                        chosen = o
                        break
            if not chosen and opts:
                chosen = opts[0]
                chosen = opts[0]
            if not chosen:
                return {"ok": False,
                        "error": f"类别「{category}」没有候选项",
                        "code": None, "transient": False}

            await _click_xy(chosen["x"], chosen["y"])
            await asyncio.sleep(1.8)

            # 校验两个必填项都已通过
            check = await page.inner_text()
            if "输入公共主页名称（必填）有效" not in (check or ""):
                return {"ok": False, "error": "主页名称未通过校验",
                        "code": None, "transient": False}
            if "输入类别（必填）有效" not in (check or ""):
                return {"ok": False, "error": "类别未选中（校验未通过）",
                        "code": None, "transient": False}

            # ④ 简介
            if bio:
                if await page.eval(r"""
                (() => {
                  const t = document.querySelector('textarea');
                  if (!t) return false;
                  t.scrollIntoView({block:'center'}); t.focus(); return true;
                })()
                """):
                    await asyncio.sleep(0.5)
                    await page.send("Input.insertText", {"text": bio})
                    await asyncio.sleep(0.8)

            # ⑤ 提交（真实鼠标点击）
            #    实测坑：scrollIntoView 是异步的，滚动后立刻取的坐标会失效，
            #    点了个空。必须「滚动 → 等待 → 重新测量 → 校验未被禁用 → 再点」，
            #    并且提交没反应时重试，不能只点一次就断言失败。
            clicked = False
            for attempt in range(3):
                await page.eval(r"""
                (() => {
                  const all = Array.from(document.querySelectorAll(
                    'div[role="button"],button,[role="button"]'));
                  for (const b of all) {
                    if ((b.innerText||'').trim() === '创建公共主页'
                        && (b.offsetWidth || b.offsetHeight)) {
                      b.scrollIntoView({block:'center'});
                      return true;
                    }
                  }
                  return false;
                })()
                """)
                await asyncio.sleep(0.9)

                info = await page.eval(r"""
                (() => {
                  const all = Array.from(document.querySelectorAll(
                    'div[role="button"],button,[role="button"]'));
                  for (const b of all) {
                    if ((b.innerText||'').trim() !== '创建公共主页') continue;
                    if (!(b.offsetWidth || b.offsetHeight)) continue;
                    const r = b.getBoundingClientRect();
                    return {x: r.x + r.width/2, y: r.y + r.height/2,
                            disabled: b.getAttribute('aria-disabled') === 'true'
                                      || b.disabled === true};
                  }
                  return null;
                })()
                """)
                if not info:
                    if attempt == 2:
                        return {"ok": False,
                                "error": "找不到「创建公共主页」按钮",
                                "code": None, "transient": False}
                    await asyncio.sleep(1.5)
                    continue

                if info.get("disabled"):
                    # 必填项还没被接受，等一下再看
                    await asyncio.sleep(2.0)
                    continue

                await _click_xy(info["x"], info["y"])
                clicked = True
                await asyncio.sleep(3.0)

                body_now = await page.inner_text()
                if ("成功！你已创建" in (body_now or "")
                        or "第1/5步" in (body_now or "")
                        or "出错了" in (body_now or "")):
                    break
                # 还停在表单页 → 重试

            if not clicked:
                return {"ok": False,
                        "error": "创建按钮一直处于禁用状态（必填项未通过校验）",
                        "code": None, "transient": True}

            # ⑥ 判定成功：以「主页清单里真的多了一个」为准，不看提示文案。
            #    实测（Y11）：提交后页面不一定出现「成功！你已创建」，
            #    后续步骤页（第1/5步）也可能不渲染，但主页确实建成了。
            #    所以这里只做两件事：
            #      ① 明确的服务端拒绝关键词 → 失败
            #      ② 回读该号主页清单，出现新 page_id → 成功
            #    后续的「第1/5步 完善资料」不去管，交给用户自己要不要填。

            # 递交后给 FB 一点处理时间
            await asyncio.sleep(1.0)

            body_after = ""
            try:
                body_after = await page.inner_text() or ""
            except CDPError:
                body_after = ""

            # 限额提示要最先识别：命中后继续点只会延长 FB 的冷却时间。
            rate_hit = [k for k in ("尝试创建公共主页的次数过多",
                                    "次數過多", "次数过多", "请稍等几分钟",
                                    "稍後再試", "稍后再试", "操作过于频繁",
                                    "rate limit", "too many")
                        if k.lower() in (body_after or "").lower()]

            reject_hit = [k for k in ("出错了", "请确保你遵守",
                                      "你已达到", "已达上限", "暂时无法创建")
                          if k in body_after]

            # 回读清单确认是否真的多了一个主页。
            # 需要独立标签：工作标签此刻停在 pages/create，直接复用读
            # bookmarks/pages 常拿不到最新清单（Y11/Y17/Z02/Z03 都踩过）。
            #
            # ⚠ 只在**整个回读过程**开一个标签、复用到底，最后必关。
            #   之前每轮都 new_page，界面上会看到标签疯狂增加（用户已投诉）。
            tab2 = None
            try:
                async with self.browser as br:
                    tab2 = await br.new_page("about:blank")
            except Exception as e:
                log.debug("建页回读标签创建失败: %s", e)
                tab2 = None

            async def _read_pages_fresh() -> list:
                if tab2 is None:
                    return []
                try:
                    rows2: dict[str, PageRow] = {}
                    await tab2.goto(f"{FB_BASE}/bookmarks/pages",
                                    wait_until_loaded=12.0)
                    for _ in range(1):
                        data = await tab2.eval(EXTRACT_PAGES_JS) or []
                        for d in data:
                            pid = str(d.get("page_id") or "")
                            if not pid:
                                continue
                            pr = rows2.get(pid) or PageRow(page_id=pid)
                            pr.asset_id = pr.asset_id or d.get("asset_id")
                            pr.name = pr.name or (d.get("name") or "")
                            rows2[pid] = pr
                        await tab2.eval(
                            "window.scrollBy(0, window.innerHeight*1.2)")
                        await asyncio.sleep(0.1)
                    return list(rows2.values())
                except Exception as e:
                    log.debug("回读清单失败: %s", e)
                    return []

            # 最多等约 10 秒（FB 建页后清单有延迟）
            try:
                for round_i in range(12):
                    rows_fresh = await _read_pages_fresh()
                    new_rows = [r for r in rows_fresh
                                if r.page_id and r.page_id not in before_ids]
                    if new_rows:
                        r0 = new_rows[0]
                        log.info("create_page 确认成功: %s %s",
                                 r0.page_id, r0.name)
                        return {"ok": True, "error": None, "code": None,
                                "transient": False,
                                "pageId": r0.page_id, "pageName": r0.name,
                                "assetId": r0.asset_id,
                                "confirmedBy": "page-list-fresh"}
                    if round_i == 2:
                        # 兜底：退回工作标签读一次
                        try:
                            rows_w = await self.extract_pages(cu_before)
                            new_w = [r for r in rows_w
                                     if r.page_id and r.page_id not in before_ids]
                            if new_w:
                                r0 = new_w[0]
                                return {"ok": True, "error": None, "code": None,
                                        "transient": False,
                                        "pageId": r0.page_id,
                                        "pageName": r0.name,
                                        "assetId": r0.asset_id,
                                        "confirmedBy": "page-list-worktab"}
                        except Exception:
                            pass
                    await asyncio.sleep(5.0)
            finally:
                # 无论走哪条返回路径，回读标签都必须关掉，防止标签越开越多
                if tab2 is not None:
                    try:
                        await tab2.close()
                    except Exception:
                        pass

            if rate_hit:
                return {"ok": False,
                        "error": f"Facebook 频率限制：{rate_hit[0]}。"
                                 "需要等待冷却（通常几分钟到几小时），"
                                 "这段时间不要连续重试，否则会延长限制。",
                        "code": "RATE_LIMITED", "transient": False,
                        "cooldown": True,
                        "cooldownMinutes": 10}

            if reject_hit:
                return {"ok": False,
                        "error": f"服务端拒绝：{reject_hit[0]}（多为当日配额已满）",
                        "code": 1175030, "transient": False}

            if "内容暂时无法显示" in body_after:
                return {"ok": False, "error": "内容暂时无法显示",
                        "code": None, "transient": False}

            return {"ok": False,
                    "error": "已点击创建，但主页清单里没出现新主页",
                    "code": None, "transient": True,
                    "confirmedBy": "page-list"}
        except CDPError as e:
            return {"ok": False, "error": f"CDP: {e}", "code": None,
                    "transient": True}
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    # ---------------- 发布 ----------------
    async def _find_upload_input(self, page, timeout_s: float = 30.0) -> int:
        """找 reels_composer 的视频上传 input，返回 nodeId（找不到返回 0）。

        **实测关键发现**（2026-11-07）：
            reels_composer 页面上 `input[type=file]` 数量为 **0**。
            input 是**点击「添加视频」按钮后才动态创建**的，不是预先存在于 DOM。
            之前直接 querySelector 必然失败 → 报「未找到上传输入框」。

        另外：页面上可能有封面照片的 input（accept=image/*），
        必须**排除它**，只认 accept 含 video 的。

        策略（按顺序）：
            ① 先看已有 video input（有的版本会预建）
            ② 点「添加视频 / Add video / 上传视频」按钮 → 等 input 出现
            ③ 兜底：点整个「影音内容」区块里的按钮
            ④ 遍历 iframe
        每步都校验 accept 含 video，避免抓到封面图的 input。
        """
        import asyncio as _a

        VIDEO_SELS = [
            'input[type="file"][accept*="video"]',
            'input[type="file"][accept*="mp4"]',
        ]

        async def _probe() -> int:
            """返回第一个 accept 含 video 的 input nodeId，没有则 0。"""
            try:
                doc = await page.send("DOM.getDocument", {"depth": -1})
                root_id = doc["root"]["nodeId"]
                # 逐个 file input 检查 accept
                r = await page.send("DOM.querySelectorAll", {
                    "nodeId": root_id, "selector": 'input[type="file"]'})
                ids = (r or {}).get("nodeIds") or []
                for nid in ids:
                    try:
                        # 取该节点的 accept 属性
                        attr = await page.send("DOM.getAttributes", {"nodeId": nid})
                        attrs = attr.get("attributes") or []
                        # attributes 是 [name, value, name, value...]
                        d = dict(zip(attrs[0::2], attrs[1::2]))
                        acc = (d.get("accept") or "").lower()
                        if "video" in acc or "mp4" in acc:
                            return int(nid)
                    except Exception:
                        continue
            except Exception as e:
                log.debug("probe input: %s", e)
            return 0

        async def _click_add_video() -> None:
            """点「添加视频」按钮，触发 input 创建。"""
            js = """(() => {
                const texts = ['添加视频', 'Add video', '上传视频', 'Upload video',
                               '添加影音内容', 'Add media'];
                const all = [...document.querySelectorAll(
                    'div[role=button], button, [aria-label], span')];
                for (const el of all) {
                    const t = (el.innerText || el.getAttribute('aria-label') || '').trim();
                    if (texts.some(x => t === x || t.startsWith(x))) {
                        if (el.tagName === 'SPAN' && el.parentElement) {
                            el.parentElement.click();
                        } else {
                            el.click();
                        }
                        return t;
                    }
                }
                return '';
            })()"""
            try:
                hit = await page.eval(js)
                if hit:
                    log.info("clicked add-video button: %s", hit)
            except Exception as e:
                log.debug("click add video: %s", e)

        deadline = _a.get_running_loop().time() + timeout_s

        # ① 已有 video input？
        nid = await _probe()
        if nid:
            log.info("video input already present")
            return nid

        # ② 点添加视频 → 轮询等 input
        await _click_add_video()
        while _a.get_running_loop().time() < deadline:
            await _a.sleep(1.5)
            nid = await _probe()
            if nid:
                log.info("video input created after click")
                return nid
            # 页面可能因为点击又渲染了一次，再试一次点击
            await _click_add_video()

        # ③ iframe 兜底
        try:
            frames = await page.send("Page.getFrameTree") or {}

            def walk(ft: dict) -> list[str]:
                out = [ft["frame"]["id"]]
                for c in (ft.get("childFrames") or []):
                    out.extend(walk(c))
                return out

            for fid in walk(frames.get("frameTree") or {}):
                try:
                    d2 = await page.send("DOM.getDocument",
                                         {"depth": -1, "frameId": fid})
                    rid = d2["root"]["nodeId"]
                    for sel in VIDEO_SELS:
                        r2 = await page.send("DOM.querySelector", {
                            "nodeId": rid, "selector": sel})
                        n2 = (r2 or {}).get("nodeId")
                        if n2:
                            log.info("video input found in frame %s", fid)
                            return int(n2)
                except Exception:
                    continue
        except Exception as e:
            log.debug("iframe probe: %s", e)

        return 0

    async def publish_reel(self, asset_id: str, video_path: str,
                           caption: str, page_label: str,
                           env_code: str = "", page_id: str = "") -> dict:
        """走 reels_composer 单条链路：创建 → 编辑 → 分享，只认受理回执。

        全程拟人化 + 每步过 guard；命中跳脸立即返回，不再继续。
        """
        from app.adapters import humanize as hz
        from app.adapters import guard as gd

        page = await self.tab()   # 复用唯一工作标签
        try:
            await hz.pacer.wait(env_code or asset_id)
            await page.goto(f"{BIZ_BASE}/latest/reels_composer?asset_id={asset_id}",
                            wait_until_loaded=10.0)
            await hz.human_delay("read")

            # 先过 guard：如果打开就是验证页，立刻中止
            v = await gd.guard(page, env_code, page_id)
            if v.tripped:
                return {"ok": False, "error": v.message, "stage": "guard",
                        "guard": v.as_dict()}

            # 发布位置校验（更稳健的两级判断）
            #
            # 之前只做 `page_label in body` 文本匹配，有两个问题：
            #   ① 主页名很短的（Y01）会误命中页面里任何含该串的文本
            #   ② reels_composer 的 UI 不一定把主页名渲染成可匹配文本，
            #      导致明明切对了也判失败（实测 18 条全是「位置不是 Yxx」）
            #
            # 现在的判据：
            #   ① URL 里带了正确的 asset_id          → 直接通过（最可靠）
            #   ② 页面文本含主页名                   → 通过
            #   ③ 页面文本含 "无法发布/No permission" → 明确失败
            body = await page.inner_text()
            try:
                url_now = await page.eval("location.href") or ""
            except Exception:
                url_now = ""
            url_hit = bool(asset_id) and str(asset_id) in str(url_now)

            if not url_hit and page_label:
                # 主页名匹配：要求独立出现（前后不是字母数字，避免 Y01 命中 Y012）
                import re as _re
                pat = _re.compile(
                    r"(?<![A-Za-z0-9])" + _re.escape(page_label) + r"(?![A-Za-z0-9])")
                if not pat.search(body or ""):
                    # 再给一次机会：页面里有没有明确的"无权限"提示
                    if _re.search(r"没有权限|无法发布|No permission|can't post",
                                  body or "", _re.I):
                        return {"ok": False,
                                "error": f"{page_label} 无发布权限（{asset_id}）",
                                "stage": "locate"}
                    # 文本没命中但 URL 也没命中 → 记录但不阻断，
                    # 因为 reels_composer 的渲染方式可能不含主页名。
                    # 真正的发布结果由「受理回执」判定（create→share 后的回执）。
                    log.warning("publish_reel: 位置文本未命中 %s (asset=%s)，"
                                "继续按 asset 发布", page_label, asset_id)

            # 上传：设置 file input（内核级操作，无法拟人化）
            #
            # 实测问题：reels_composer 的 input 常常是**延迟渲染**或**在 iframe 里**，
            # 一次性 querySelector 会失败（报「未找到上传输入框」）。
            # 改成：轮询等它出现 → 主文档查不到就遍历所有 iframe → 都查不到再给一次重载机会。
            node_id = await self._find_upload_input(page)
            if not node_id:
                return {"ok": False, "error": "未找到上传输入框（等了 20 秒）",
                        "stage": "upload"}
            await page.send("DOM.setFileInputFiles", {
                "nodeId": node_id, "files": [video_path]})
            await hz.human_delay("op")

            # 等处理完成（轮询期间也过 guard，防止中途被跳脸）
            ready = False
            for _ in range(10):
                await asyncio.sleep(1.0)
                t = await page.inner_text()
                if re.search(r"处理失败|上传失败|couldn't upload", t, re.I):
                    return {"ok": False, "error": "视频上传/处理失败", "stage": "process"}
                no_pct = not re.search(r"\d{1,3}\s*%", t)
                if no_pct and ("下一页" in t or "分享" in t):
                    ready = True
                    break
                if re.search(r"\b100\s*%", t):
                    await asyncio.sleep(15.0)
                    ready = True
                    break
            if not ready:
                return {"ok": False, "error": "视频处理超时", "stage": "process"}

            v = await gd.guard(page, env_code, page_id)
            if v.tripped:
                return {"ok": False, "error": v.message, "stage": "guard",
                        "guard": v.as_dict()}

            # 描述：拟人打字
            if caption:
                await page.eval(r"""
                (() => {
                  const b = document.querySelector('div[contenteditable="true"]');
                  if (b) b.focus();
                })()
                """)
                await hz.human_type(page, caption)
                await hz.human_delay("op")

            # 必须点顶部「分享」步骤（不是「下一页」）—— 用拟人点击
            await self._click_text_human(page, "分享")
            await hz.human_delay("read")

            # 底部「分享」按钮：走曲线点击
            pos = await page.eval(r"""
            (() => {
              const btns = Array.from(document.querySelectorAll('[role="button"]'));
              const hits = btns.filter(e => (e.innerText||'').trim() === '分享');
              for (const el of hits) {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.y > 100)
                  return {x: r.x + r.width/2, y: r.y + r.height/2};
              }
              return null;
            })()
            """)
            if pos:
                await hz.human_click(page, pos["x"], pos["y"])
            await hz.human_delay("op")

            # 等受理回执
            for _ in range(40):
                await asyncio.sleep(5.0)
                t = await page.inner_text()
                if re.search(r"正在处理\s*Reels|处理完成后，Reels\s*便会发布", t):
                    return {"ok": True, "acceptance": "processing", "stage": "accepted"}
                if re.search(r"Reels\s*已发布|发布成功|已分享|Published", t):
                    return {"ok": True, "acceptance": "published", "stage": "accepted"}
                if re.search(r"无法处理你的所有|无法根据选定发布选项分享", t):
                    return {"ok": False,
                            "error": "Meta 拒绝发布（无法处理你的所有 Reels）",
                            "stage": "rejected"}
                if re.search(r"发生错误|出错了|Something went wrong", t):
                    v = await gd.check(page, env_code, page_id)
                    return {"ok": False, "error": "Meta 报错" + (
                        f"（{v.message}）" if v.tripped else ""),
                        "stage": "rejected", "guard": v.as_dict() if v.tripped else None}
            return {"ok": False, "error": "未观察到受理回执", "stage": "no_receipt"}
        except CDPError as e:
            return {"ok": False, "error": f"CDP: {e}", "stage": "cdp"}
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    async def _click_text_human(self, page, text: str) -> bool:
        """按文字找元素，用曲线鼠标点击。"""
        from app.adapters import humanize as hz
        pos = await page.eval(r"""
        (() => {
          const want = %s;
          const els = Array.from(document.querySelectorAll('*'));
          for (const el of els) {
            const t = (el.innerText || '').trim();
            if (t !== want) continue;
            if (el.children.length > 2) continue;
            const r = el.getBoundingClientRect();
            if (r.width < 2 || r.height < 2) continue;
            return {x: r.x + r.width/2, y: r.y + r.height/2,
                    top: r.y, h: r.height};
          }
          return null;
        })()
        """ % json.dumps(text))
        if not pos:
            return False
        await hz.human_click(page, pos["x"], pos["y"])
        return True


# ---------------- 入库 ----------------
def upsert_pages(rows: list[PageRow], env_code: str = "") -> int:
    ts = now_iso()
    n = 0
    for r in rows:
        db.exec(
            """INSERT INTO pages(page_id,asset_id,name,health,env_code,last_seen)
               VALUES(?,?,?,'ok',?,?)
               ON CONFLICT(page_id) DO UPDATE SET
                 asset_id=COALESCE(excluded.asset_id, pages.asset_id),
                 name=CASE WHEN excluded.name<>'' THEN excluded.name ELSE pages.name END,
                 env_code=CASE WHEN excluded.env_code<>'' THEN excluded.env_code ELSE pages.env_code END,
                 last_seen=excluded.last_seen""",
            (r.page_id, r.asset_id, r.name or "", env_code, ts),
        )
        n += 1
    return n

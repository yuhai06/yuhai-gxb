"""环境指纹生成器 —— 从 env_id 派生出**自洽**的一整套设备指纹。

为什么需要这一层（本机实测，2026-11-16）：
    用 Chrome 起两个独立 --user-data-dir，探测 22 个指纹位，
    **0 个不同、22 个全部相同**（canvas hash / audio sum / webgl renderer /
    hardwareConcurrency / screen / tz / fonts 全一样）。
    也就是说「独立 profile」只是把 cookie 隔开了，设备身份完全没隔开 ——
    两个号在同一台机器上，对站点而言是同一台设备。

    自建要补的就是这一层：**每个环境一套稳定、自洽、互不相同的设备身份**。

三条铁律：
    ① 稳定性 > 随机性：同一 env_id 每次必须得出同一套值。每次刷新指纹 = 换设备 =
       比不换更像异常（真实用户的显卡不会一天变三次）。Hubstudio 的
       /api/v1/env/refresh-fingerprint 是显式动作，不是自动行为。
    ② 自洽性 > 丰富度：UA 的 Chrome 版本必须等于内核版本；WebGL renderer 里的
       GPU 型号必须是真实存在的型号；核数/内存/分辨率/GPU 要像同一台机器；
       时区/语言/字体要跟代理出口国家对得上。不自洽的假指纹比不伪装更容易被挑出来。
    ③ 只改「取值」，不改「行为」：不要 patch CanvasRenderingContext2D.prototype
       这类会被 Function.prototype.toString 抓到的原型链。所有 hook 都包
       toString 伪装。
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, asdict
from typing import Any


# ---------------------------------------------------------------- 一致的数据池
# GPU：必须是真实存在的型号，且 vendor 前缀要跟 ANGLE 的写法一致
GPU_POOL: list[dict[str, Any]] = [
    # NVIDIA 独显本（配 6-8 核 / 16 GB）
    {"vendor": "Google Inc. (NVIDIA)",
     "renderer": "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Laptop GPU (0x00002560) Direct3D11 vs_5_0 ps_5_0, D3D11)",
     "cores": [8, 12, 16], "mem": [8, 16]},
    {"vendor": "Google Inc. (NVIDIA)",
     "renderer": "ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 (0x00001F82) Direct3D11 vs_5_0 ps_5_0, D3D11)",
     "cores": [6, 8, 12], "mem": [8, 16]},
    {"vendor": "Google Inc. (NVIDIA)",
     "renderer": "ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 (0x00002880) Direct3D11 vs_5_0 ps_5_0, D3D11)",
     "cores": [12, 16, 20], "mem": [16, 32]},
    # Intel 核显（办公本，配 4-8 核 / 8-16 GB）
    {"vendor": "Google Inc. (Intel)",
     "renderer": "ANGLE (Intel, Intel(R) UHD Graphics 620 (0x00003EA0) Direct3D11 vs_5_0 ps_5_0, D3D11)",
     "cores": [4, 8], "mem": [8, 16]},
    {"vendor": "Google Inc. (Intel)",
     "renderer": "ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x00009A49) Direct3D11 vs_5_0 ps_5_0, D3D11)",
     "cores": [8, 12], "mem": [8, 16]},
    {"vendor": "Google Inc. (Intel)",
     "renderer": "ANGLE (Intel, Intel(R) HD Graphics 530 (0x00001912) Direct3D11 vs_5_0 ps_5_0, D3D11)",
     "cores": [4, 8], "mem": [8]},
    # AMD 核显/独显
    {"vendor": "Google Inc. (AMD)",
     "renderer": "ANGLE (AMD, AMD Radeon(TM) Graphics (0x00001638) Direct3D11 vs_5_0 ps_5_0, D3D11)",
     "cores": [8, 12, 16], "mem": [8, 16]},
    {"vendor": "Google Inc. (AMD)",
     "renderer": "ANGLE (AMD, AMD Radeon RX 6600 (0x000073FF) Direct3D11 vs_5_0 ps_5_0, D3D11)",
     "cores": [8, 12], "mem": [16]},
]

# 屏幕：Windows 上常见分辨率组合（宽, 高, 可用高, DPR）
SCREEN_POOL: list[tuple[int, int, int, float]] = [
    (1920, 1080, 1032, 1.0),
    (1920, 1080, 1040, 1.0),
    (1366, 768, 728, 1.0),
    (1536, 864, 824, 1.0),
    (1600, 900, 860, 1.0),
    (1440, 900, 860, 1.0),
    (2560, 1440, 1392, 1.0),
    (2560, 1440, 1400, 1.25),
    (2880, 1800, 1740, 1.5),
]

# 时区 / 语言：跟代理出口国家绑定（这是最容易被抓的一处不自洽）
REGION_PROFILES: dict[str, dict[str, Any]] = {
    "US": {"tz": ["America/New_York", "America/Chicago", "America/Los_Angeles",
                  "America/Denver", "America/Phoenix"],
           "langs": ["en-US,en"], "ui": "en-US", "offset": ["-300", "-360", "-480", "-420", "-420"]},
    "GB": {"tz": ["Europe/London"], "langs": ["en-GB,en"], "ui": "en-GB", "offset": ["0", "-60"]},
    "DE": {"tz": ["Europe/Berlin"], "langs": ["de-DE,de,en"], "ui": "de-DE", "offset": ["-60", "-120"]},
    "FR": {"tz": ["Europe/Paris"], "langs": ["fr-FR,fr,en"], "ui": "fr-FR", "offset": ["-60", "-120"]},
    "NL": {"tz": ["Europe/Amsterdam"], "langs": ["nl-NL,nl,en"], "ui": "nl-NL", "offset": ["-60", "-120"]},
    "BR": {"tz": ["America/Sao_Paulo"], "langs": ["pt-BR,pt,en"], "ui": "pt-BR", "offset": ["-180"]},
    "JP": {"tz": ["Asia/Tokyo"], "langs": ["ja-JP,ja,en"], "ui": "ja-JP", "offset": ["-540"]},
    "SG": {"tz": ["Asia/Singapore"], "langs": ["en-SG,en"], "ui": "en-SG", "offset": ["-480"]},
    "CA": {"tz": ["America/Toronto", "America/Vancouver"],
           "langs": ["en-CA,en"], "ui": "en-CA", "offset": ["-300", "-480"]},
    "AU": {"tz": ["Australia/Sydney", "Australia/Melbourne"],
           "langs": ["en-AU,en"], "ui": "en-AU", "offset": ["-600", "-660"]},
}

# 字体：按 locale 给不同集合（Windows 英文机 vs 中文机差异明显）
FONT_SETS: dict[str, list[str]] = {
    "west": ["Arial", "Calibri", "Cambria", "Candara", "Comic Sans MS", "Consolas",
             "Constantia", "Corbel", "Courier New", "Ebrima", "Franklin Gothic Medium",
             "Gabriola", "Gadugi", "Georgia", "Impact", "Ink Free", "Javanese Text",
             "Leelawadee UI", "Lucida Console", "Lucida Sans Unicode", "Malgun Gothic",
             "Microsoft Himalaya", "Microsoft JhengHei", "Microsoft New Tai Lue",
             "Microsoft PhagsPa", "Microsoft Sans Serif", "Microsoft Tai Le",
             "Microsoft YaHei", "MingLiU-ExtB", "Mongolian Baiti", "MS Gothic",
             "MV Boli", "Myanmar Text", "Nirmala UI", "Palatino Linotype",
             "Segoe MDL2 Assets", "Segoe Print", "Segoe Script", "Segoe UI",
             "Segoe UI Emoji", "Segoe UI Historic", "Segoe UI Symbol", "SimSun",
             "Sitka", "Sylfaen", "Symbol", "Tahoma", "Times New Roman",
             "Trebuchet MS", "Verdana", "Webdings", "Wingdings", "Yu Gothic"],
}


@dataclass
class Fingerprint:
    """一个环境完整的设备身份。所有字段必须互相自洽。"""
    env_id: str
    seed: str = ""

    # 来自宿主机内核（不能编，必须等于真实内核版本）
    chrome_version: str = "152.0.0.0"
    ua: str = ""
    ua_full_version: str = ""

    # 硬件
    platform: str = "Win32"
    cores: int = 8
    memory: int = 8
    screen_w: int = 1920
    screen_h: int = 1080
    avail_h: int = 1032
    dpr: float = 1.0

    # 图形
    webgl_vendor: str = ""
    webgl_renderer: str = ""
    webgl_max_texture: int = 16384
    webgl_max_renderbuffer: int = 16384
    max_line_width: float = 1.0

    # 地域
    timezone: str = "America/New_York"
    tz_offset_min: int = 300          # 注意：JS 的 getTimezoneOffset 是「UTC - 本地」，负数在 UTC 东侧
    languages: str = "en-US,en"
    ui_locale: str = "en-US"
    country: str = "US"
    geo: dict[str, Any] = field(default_factory=dict)

    # 字体
    fonts: list[str] = field(default_factory=list)

    # 噪声种子（canvas / audio / clientRects 都用它，保证同环境稳定、跨环境不同）
    noise_seed: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _det(seed: str, salt: str) -> int:
    """确定性哈希 → 整数。同 seed 同 salt 必得同值。"""
    h = hashlib.sha256(f"{seed}|{salt}".encode()).digest()
    return int.from_bytes(h[:8], "big")


def _pick(seq, seed: str, salt: str):
    return seq[_det(seed, salt) % len(seq)]


def build(env_id: str, *, country: str = "US",
          chrome_version: str = "152.0.0.0",
          ua_template: str | None = None) -> Fingerprint:
    """由一个 env_id 派生出一整套自洽指纹。

    env_id 必须稳定（用 Hubstudio 的 containerCode 或自建注册表里的 env_key）。
    国家决定时区/语言，其余全部派生。同一个 env_id + 同一个国家 → 永远同一套。
    """
    seed = f"yuhai:{env_id}"
    reg = REGION_PROFILES.get(country.upper()) or REGION_PROFILES["US"]

    gpu = _pick(GPU_POOL, seed, "gpu")
    cores = _pick(gpu["cores"], seed, "cores")
    mem = _pick(gpu["mem"], seed, "mem")
    scr = _pick(SCREEN_POOL, seed, "screen")

    # 时区与语言必须成对取，不能各自随机（否则出现 Asia/Tokyo + en-US 这种组合）
    idx = _det(seed, "tzidx") % len(reg["tz"])
    tz = reg["tz"][idx]
    offset = int(reg["offset"][min(idx, len(reg["offset"]) - 1)])

    major = chrome_version.split(".")[0]
    patch_part = chrome_version
    ua = ua_template or (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        f"(KHTML, like Gecko) Chrome/{major}.0.0.0 Safari/537.36"
    )

    return Fingerprint(
        env_id=env_id,
        seed=seed,
        chrome_version=chrome_version,
        ua=ua,
        ua_full_version=patch_part,
        cores=cores,
        memory=mem,
        screen_w=scr[0], screen_h=scr[1], avail_h=scr[2], dpr=scr[3],
        webgl_vendor=gpu["vendor"],
        webgl_renderer=gpu["renderer"],
        # 纹理上限跟 GPU 档次绑定：独显 16384，核显常见 16384/8192
        webgl_max_texture=16384 if "RTX" in gpu["renderer"] or "GTX" in gpu["renderer"] else _pick([8192, 16384], seed, "tex"),
        webgl_max_renderbuffer=16384,
        max_line_width=1.0,
        timezone=tz,
        tz_offset_min=offset,
        languages=reg["langs"],
        ui_locale=reg["ui"],
        country=country.upper(),
        geo={"lat": round(39.0 + (_det(seed, "lat") % 1600) / 100, 4),
             "lon": round(-123.0 + (_det(seed, "lon") % 3500) / 100, 4),
             "accuracy": 50 + _det(seed, "acc") % 900},
        fonts=FONT_SETS["west"],
        noise_seed=_det(seed, "noise") % (2 ** 31),
    )


def coherence_report(fp: Fingerprint) -> list[str]:
    """自洽性自检。返回问题列表，空列表 = 通过。

    这份检查项来自「被站点抓过的真实错配」：
      · UA 版本 ≠ 内核版本           → navigator.userAgentData 与 UA 对不上
      · 时区与出口国家不符            → IP 在美东，时区在东京（最高频的死法）
      · 语言与 IP 国家不符            → 同上
      · 核数/内存与 GPU 档次不匹配    → 4 核配 RTX 4060（真实机器不会这么配）
      · DPR 与分辨率不匹配            → 1366x768 配 DPR 2（不存在这样的屏）
    """
    problems: list[str] = []
    major = fp.chrome_version.split(".")[0]
    if f"Chrome/{major}." not in fp.ua:
        problems.append(f"UA 里的 Chrome 主版本与内核 {major} 不一致")
    if fp.dpr > 1.0 and fp.screen_w <= 1366:
        problems.append(f"{fp.screen_w}x{fp.screen_h} 配 DPR {fp.dpr} 不合理（低分屏不会是高分屏缩放）")
    if "RTX 40" in fp.webgl_renderer and fp.cores < 8:
        problems.append("RTX 40 系配 <8 核不合理")
    if fp.cores > 12 and fp.memory < 16:
        problems.append("高核数配 8 GB 内存不合理")
    if fp.screen_w >= 2560 and fp.memory < 16:
        problems.append("2K+ 屏配 8 GB 内存不合理")
    reg = REGION_PROFILES.get(fp.country, {})
    if reg and fp.timezone not in reg.get("tz", []):
        problems.append(f"时区 {fp.timezone} 不在国家 {fp.country} 的候选集合里")
    if reg and fp.languages != reg.get("langs"):
        problems.append(f"语言 {fp.languages} 与国家 {fp.country} 的标准组合 {reg.get('langs')} 不符")
    return problems


if __name__ == "__main__":
    # 演示：同 env 稳定、跨 env 不同
    a1 = build("ENV_CODE_A", country="US")
    a2 = build("ENV_CODE_A", country="US")
    b = build("ENV_CODE_B", country="BR")
    assert a1.to_dict() == a2.to_dict(), "同 env_id 必须稳定"
    print("env ENV_CODE_A →", a1.webgl_renderer[:60], "| cores", a1.cores,
          "| mem", a1.memory, "|", a1.timezone, "|", f"{a1.screen_w}x{a1.screen_h}@{a1.dpr}")
    print("env ENV_CODE_B →", b.webgl_renderer[:60], "| cores", b.cores,
          "| mem", b.memory, "|", b.timezone, "|", f"{b.screen_w}x{b.screen_h}@{b.dpr}")
    print("两环境指纹是否不同:", a1.to_dict() != b.to_dict())
    print("自洽检查 A:", coherence_report(a1) or "通过")
    print("自洽检查 B:", coherence_report(b) or "通过")
    print("同 env 二次构建是否稳定:", a1.to_dict() == a2.to_dict())

"""env-kit 直驱模块：完全不启动 HubStudio 主程序，直接驱动浏览器内核。

原理（实测逆向结论，2026-11 HubStudio 3.61.2）
────────────────────────────────────────────────────────────────
HubStudio 的浏览器内核由 env-kit.exe（Go 编写）通过 Windows named pipe
驱动。主程序（Electron）与 env-kit 之间用 AES-128-CBC 加密通信。

协议：
    1. 本模块创建 pipe server：\\.\pipe\env-kit-biz<random>
    2. 启动 env-kit.exe -gt <pipe名> -it <pipe名>
    3. env-kit 作为 client 连入
    4. 发 Init（含 config），之后发 OpenBrowser 等指令

加密：
    Init：AES-128-CBC + PKCS7
        key = "iGWPdMIQu7s89aYr" / iv = "kqBHZMtLgCG784sV"
        发送 = base64(key + iv + ciphertext)
    业务：AES-128-CBC + 零填充
        key = "I*&sd!@#~.d8,s9&-*U(M^@"[2:18]
        iv  = "I*&sd!@#~.d8,s9&-*U(M^@"[4:20]
        发送 = base64(ciphertext)，接收解密后 trim 尾部 \\x00

指纹与 Cookie：
    env-kit 收到 OpenBrowser 后会自己从服务端下载
    （/api/es/c/fingerprint/download、/api/es/c/cookie/download），
    这些是数据接口，不消耗打开次数，也不需要 HubStudio 登录态。
"""
from __future__ import annotations

import base64
import json
import logging
import os
import random
import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

log = logging.getLogger("yuhai.envkit_direct")

# ───────────────────── 加密原语 ─────────────────────

def _aes_encrypt(key: bytes, iv: bytes, data: bytes, zero_pad: bool = False) -> bytes:
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    if zero_pad:
        pad = (16 - len(data) % 16) % 16
        data = data + b"\x00" * pad
    else:
        pad = 16 - len(data) % 16
        data = data + bytes([pad]) * pad
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    enc = cipher.encryptor()
    return enc.update(data) + enc.finalize()


def _aes_decrypt(key: bytes, iv: bytes, data: bytes) -> bytes:
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    dec = cipher.decryptor()
    out = dec.update(data) + dec.finalize()
    end = len(out)
    while end > 0 and out[end - 1] == 0:
        end -= 1
    return out[:end]


_INIT_KEY = b"iGWPdMIQu7s89aYr"
_INIT_IV = b"kqBHZMtLgCG784sV"
_BIZ_RAW = b"I*&sd!@#~.d8,s9&-*U(M^@"
_BIZ_KEY = _BIZ_RAW[2:18]
_BIZ_IV = _BIZ_RAW[4:20]


def _encrypt_init(plain: str) -> str:
    ct = _aes_encrypt(_INIT_KEY, _INIT_IV, plain.encode("utf-8"), zero_pad=False)
    return base64.b64encode(_INIT_KEY + _INIT_IV + ct).decode("ascii")


def _biz_encrypt(plain: str) -> str:
    ct = _aes_encrypt(_BIZ_KEY, _BIZ_IV, plain.encode("utf-8"), zero_pad=True)
    return base64.b64encode(ct).decode("ascii")


def _biz_decrypt(b64: str) -> str:
    return _aes_decrypt(_BIZ_KEY, _BIZ_IV, base64.b64decode(b64)).decode(
        "utf-8", errors="replace")


# ───────────────────── 主驱动器 ─────────────────────

@dataclass
class DirectKernelInstance:
    container_id: str
    env_id: str
    debug_port: int
    kernel_path: str
    webdriver_path: str
    download_path: str
    status: str = "running"


class EnvKitDirect:
    """直接驱动 env-kit，完全不启动 HubStudio 主程序。"""

    def __init__(self, env_kit_path: str | Path | None = None,
                 core_dir: str | Path | None = None,
                 work_dir: str | Path | None = None) -> None:
        if env_kit_path is None:
            env_kit_path = self._find_env_kit()
        self.env_kit = Path(env_kit_path)
        self.core_dir = Path(core_dir) if core_dir else self.env_kit.parent
        self.work_dir = Path(work_dir) if work_dir else (
            Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "yuhai_envkit")
        self.work_dir.mkdir(parents=True, exist_ok=True)
        for d in ["cache", "persistence", "logs"]:
            (self.work_dir / d).mkdir(exist_ok=True)
        self._proc: subprocess.Popen | None = None
        self._pipe = None
        self._ready = False
        self._handlers: dict[str, list] = {}   # RequestId -> 回调

    @staticmethod
    def _find_env_kit() -> Path:
        from app.config import settings
        candidates: list[Path] = []
        if settings.hubstudio_dir:
            candidates.append(Path(settings.hubstudio_dir) / "resources" / "assets" / "sdk" / "env-kit.exe")
        base_dirs = [Path(v) for v in (
            os.environ.get("ProgramFiles"),
            os.environ.get("ProgramFiles(x86)"),
        ) if v]
        base_dirs.append(Path.home() / "AppData" / "Local" / "Programs")
        for base in base_dirs:
            candidates.append(base / "Hubstudio" / "resources" / "assets" / "sdk" / "env-kit.exe")
        for c in candidates:
            if c.exists():
                return c
        # 从进程反查
        try:
            import psutil
            for p in psutil.process_iter(["exe"]):
                exe = (p.info.get("exe") or "").lower()
                if exe.endswith("env-kit.exe"):
                    return Path(p.info["exe"])
        except Exception:
            pass
        raise FileNotFoundError("未找到 env-kit.exe")

    def _build_config(self) -> dict:
        """构造 Init 的 config。

        关键：CachePath 必须指向 HubStudio 真实的 profile 目录，
        否则内核拿到空 profile 会初始化失败并退出 10009。
        直驱时需先关闭 HubStudio 主程序，避免 profile 争用。
        """
        appdata = Path(os.environ.get("APPDATA") or (Path.home() / "AppData/Roaming"))
        real_cache = appdata / "hubstudio-client" / "sdk" / "cache"
        real_persist = appdata / "hubstudio-client" / "sdk" / "persistence"
        # 若真实目录不存在则退回工作目录
        cache_path = str(real_cache) if real_cache.exists() else str(self.work_dir / "cache")
        persist_path = str(real_persist) if real_persist.exists() else str(self.work_dir / "persistence")
        return {
            "ClientVersion": "v3.61.2",
            "IPCEncryptKey": "I*&sd!@#~.d8,s9&-*U(M^@",
            "IPCEncryptVector": "I*&sd!@#~.d8,s9&-*U(M^@",
            "FilePathConfig": {
                "CachePath": cache_path,
                "PersistencePath": persist_path,
                "LogPath": str(self.work_dir / "logs"),
                "DefaultCorePath": str(self.core_dir),
            },
            "MachineInfo": {"MachineCode": "MachineCode"},
            "MoveCore": False,
            "RunningMode": 2,
            "Service": {
                "ES": {
                    "Host": "https://main-hubstudio-api.hubstudio.vip",
                    "Key": "g0MW7KcyAX6DaEBT5fsP",
                    "Biz": "magicbox",
                },
                "BrowserCoreDownloader": "https://cdn-browser.fzzixun.com",
            },
            "Custom": {"ProductName": "Hubstudio"},
            "I18N": {},
        }

    # ───────── 生命周期 ─────────
    def start(self) -> None:
        """创建 pipe + 启动 env-kit + 完成 Init。"""
        from app.adapters.envkit_pipe import PipeServer

        pipe_name = f"env-kit-biz{random.random()}"
        self._pipe = PipeServer(pipe_name)
        self._pipe.create()
        log.info("pipe server 已创建: %s", self._pipe.path)

        env = {**os.environ, "GOTRACEBACK": "crash"}
        env.pop("ELECTRON_RUN_AS_NODE", None)
        self._proc = subprocess.Popen(
            [str(self.env_kit), "-gt", pipe_name, "-it", pipe_name],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        log.info("env-kit 已启动 pid=%s", self._proc.pid)

        self._pipe.accept(timeout=25)
        log.info("env-kit 已连入 pipe")

        config = self._build_config()
        init_msg = {"Action": "Init", "Module": "EnvKit", "Data": config}
        self._pipe.write(_encrypt_init(json.dumps(init_msg)).encode() + b"\x00")
        log.info("Init 已发送")
        self._ready = True

        # 等 env-kit 初始化（它会算机器码、加载内核列表）
        self._drain_until(timeout=12)

        # 关键补充：BrowserManager/Init（带 BlockList），真实流程里这一步
        # 在 Init 之后、OpenBrowser 之前。缺它会导致内核 10009。
        try:
            bl = self._load_blocklist()
            if bl is not None:
                data = {**config, "BlockList": bl}
                resp = self._send_biz("Init", "BrowserManager", data, wait=20)
                log.info("BrowserManager/Init 响应: Status=%s", resp.get("Status"))
        except Exception as e:
            log.warning("BrowserManager/Init 失败（继续）: %s", e)

    @staticmethod
    def _load_blocklist() -> dict | None:
        """从真实客户端配置读 BlockList（站点黑白名单）。"""
        try:
            import sqlite3
            appdata = os.environ.get("APPDATA") or str(Path.home() / "AppData/Roaming")
            db = Path(appdata) / "hubstudio-client" / "ELECTRON_DB_LOCAL_STORAGE"
            if not db.exists():
                return None
            con = sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True)
            cur = con.cursor()
            cur.execute("select value from localstorage where key='ENV_KIT_SDK_CONFIG'")
            row = cur.fetchone()
            con.close()
            if row:
                return json.loads(row[0]).get("BlockList")
        except Exception as e:
            log.debug("读 BlockList 失败: %s", e)
        return None

    def _drain_until(self, timeout: float) -> list[dict]:
        """读取并解析指定时间内收到的所有消息。"""
        msgs: list[dict] = []
        t0 = time.time()
        while time.time() - t0 < timeout:
            raw = self._pipe.read_message(timeout=1.0)
            if raw is None:
                continue
            obj = self._parse(raw)
            if obj:
                msgs.append(obj)
        return msgs

    @staticmethod
    def _parse(raw: bytes) -> dict | None:
        try:
            text = raw.decode("utf-8", errors="replace")
            if text.startswith("%"):
                return json.loads(text[1:].replace("\x00", ""))
            return json.loads(_biz_decrypt(text))
        except Exception as e:
            log.debug("解析消息失败: %s | %s", e, raw[:120])
            return None

    def _send_biz(self, action: str, module: str, data: dict,
                  wait: float = 90.0) -> dict:
        """发送业务消息，等到 RequestId 匹配的最终响应。

        期间会收到 OnRunningBrowser 等进度通知，一并收集。
        返回第一个 Status==0 且 Action==action 的响应（成功），
        或失败响应。
        """
        if not self._ready:
            raise RuntimeError("env-kit 未就绪")
        req_id = str(uuid.uuid4())
        msg = {"Action": action, "Module": module, "RequestId": req_id, "Data": data}
        self._pipe.write(_biz_encrypt(json.dumps(msg)).encode() + b"\x00")
        log.debug(">> %s reqId=%s", action, req_id)

        t0 = time.time()
        last_err = None
        while time.time() - t0 < wait:
            raw = self._pipe.read_message(timeout=2.0)
            if raw is None:
                continue
            obj = self._parse(raw)
            if not obj:
                continue
            rid = obj.get("RequestId")
            st = obj.get("Status")
            msg_type = obj.get("Action") or ""
            log.debug("<< %s status=%s reqId=%s", msg_type, st, rid)

            if rid != req_id:
                continue       # 进度通知，忽略
            # 这是本次请求的响应
            if st == 0:
                return obj
            last_err = obj
            # 失败也返回（让上层报错）
            if st != 0 and msg_type == action:
                return obj
        if last_err:
            return last_err
        raise TimeoutError(f"{action} 等待响应超时")

    # ───────── 打开浏览器 ─────────
    def open_browser(self, detail: dict, headless: bool = False) -> DirectKernelInstance:
        """直接启动浏览器内核。

        detail 是 open-detail 的完整响应。
        """
        adv = detail.get("advanced") or {}
        ua_info = detail.get("userAgentInfoVo") or {}
        ua_data = None
        if ua_info.get("userAgentData"):
            try:
                ua_data = json.loads(ua_info["userAgentData"]) \
                    if isinstance(ua_info["userAgentData"], str) else ua_info["userAgentData"]
            except Exception:
                ua_data = None

        data = {
            "UserId": str(detail.get("userId") or ""),
            "OwnerId": str(detail.get("userId") or ""),
            "ContainerId": detail.get("envId"),
            "BizContainerId": str(detail.get("containerId") or ""),
            "BrowserType": detail.get("uaType") or 1,
            "Envs": [],
            "ExecArgs": ["--no-sandbox", "--use-mock-keychain"],
            "Version": str(abs(int(detail.get("coreVersion") or 152))),
            "Bit": 2,
            "Raw": {"is_open_new_window": True, "remove_pinned_on_startup": True},
            "SyncType": detail.get("syncCookiesType") or 1,
            "Custom": {
                "PasswordVisible": False,
                "Network": {
                    "FrontProxies": [{"ProxyType": "direct", "Id": "0"}],
                    "ProxyInfo": {"ProxyType": "direct"},
                    "IsLuminati": False,
                },
                "Advanced": {
                    "DeviceVo": json.dumps(detail.get("deviceVo")) if detail.get("deviceVo") else "",
                    "ParamVo": json.dumps(detail.get("paramVo")) if detail.get("paramVo") else "",
                    "UserAgentData": ua_data,
                    "DefaultTemplate": json.dumps(adv),
                    "SpeechSynthesisList": [],
                    "Ip": (detail.get("attribution") or {}).get("lastUsedIp") or "",
                },
                "UrlConfig": {
                    "FirstDefaultUrl": "about:blank",
                    "HomePageUrl": "about:blank",
                    "NewTabDefaultUrl": "about:blank",
                },
                "ButtonRedirect": {},
                "BuiltinPluginConfig": {"OtherPlugin": []},
                "PreferenceRaw": {"translate.enabled": False, "autofill.profile_enabled": False},
                "Detail": detail,
                "Window": {"Screenx": 0, "Screeny": 0, "Width": 1000, "Height": 1000},
                "SupportWebDriver": True,
                "EncryptLocalStorage": False,
                "BrowserIconPath": "",
                "EnvironmentCornerMark": "",
                "DisabledPluginMenu": False,
                "DisabledAutoSavePassword": False,
                "BlockDevtools": False,
                "DevelopMode": True,
                "NativeMessage": detail.get("nativeMessage") or [],
                "DisableVoice": False,
                "ReadOnly": False,
                "BrowserTitle": detail.get("containerName") or "DirectKernel",
                "EnableExtensionOnStartUp": False,
                "PresetCookie": [],
            },
        }
        if headless:
            data["Headless"] = True

        resp = self._send_biz("OpenBrowser", "BrowserManager", data, wait=120)
        log.info("OpenBrowser 响应: %s", json.dumps(resp)[:500])

        st = resp.get("Status")
        if st != 0:
            raise RuntimeError(
                f"启动失败: {resp.get('StatusMsg') or resp.get('err')} (Status={st})")

        d = resp.get("Data") or {}
        return DirectKernelInstance(
            container_id=str(d.get("ContainerId") or detail.get("envId") or ""),
            env_id=str(detail.get("envId") or ""),
            debug_port=int(d.get("DebugPort") or 0),
            kernel_path=d.get("KernelPath") or "",
            webdriver_path=d.get("Webdriver") or "",
            download_path=d.get("DownloadPath") or "",
        )

    def stop(self) -> None:
        """停止 env-kit（会连带关闭内核进程）。"""
        if self._proc:
            try:
                self._proc.kill()
            except Exception:
                pass
            self._proc = None
        if self._pipe:
            try:
                self._pipe.close()
            except Exception:
                pass
            self._pipe = None
        self._ready = False

    def is_ready(self) -> bool:
        return self._ready and self._proc is not None and self._proc.poll() is None


# 全局单例
_direct: EnvKitDirect | None = None


def get_envkit_direct() -> EnvKitDirect:
    global _direct
    if _direct is None:
        _direct = EnvKitDirect()
    return _direct

"""免主界面浏览器启动模块（替代 HubStudio 主界面打开方式）。

原理：
    不打开 HubStudio 主界面窗口，让 HubStudio 以「托盘模式」在后台运行，
    然后通过本地 API 直接驱动它启动浏览器环境。用户看到的是：
    - 没有 HubStudio 主界面窗口
    - 浏览器环境正常打开（指纹、代理、Cookie 全保留）
    - 配合 unlimited_open patch，每日次数限制也一并绕过

实现：
    1. 启动 HubStudio（正常启动，主窗口会被自动最小化到托盘）
    2. 用 /api/v1/browser/start 直接启动环境
    3. 返回 CDP 端口，供 Playwright/Puppeteer 连接

与 env-kit 直驱方案的区别：
    env-kit 直驱需要完整逆向 pipe 协议（已破解），但内核初始化需要
    完整登录态数据（Detail/账号列表等），目前会触发 10009 退出。
    本方案走 HubStudio 官方完整流程，100% 稳定，且不需要主界面。
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import psutil

log = logging.getLogger("yuhai.direct_browser")


@dataclass
class BrowserInstance:
    container_code: str
    container_id: str
    env_id: str
    cdp_port: int
    browser_path: str
    webdriver_path: str
    download_path: str
    proxy_type: str
    ip: str
    status: str = "running"


class DirectBrowser:
    """免主界面启动浏览器环境。"""

    def __init__(self, api_base: str = "http://127.0.0.1:6873") -> None:
        self.api_base = api_base.rstrip("/")
        self._hub_exe: Path | None = None

    # ───────── 进程管理 ─────────
    @staticmethod
    def _candidate_paths() -> list[Path]:
        """候选 Hubstudio.exe 路径（配置项优先，环境变量与用户目录兜底）。"""
        from app.config import settings
        paths: list[Path] = []
        if settings.hubstudio_dir:
            paths.append(Path(settings.hubstudio_dir) / "Hubstudio.exe")
        base_dirs = [Path(v) for v in (
            os.environ.get("ProgramFiles"),
            os.environ.get("ProgramFiles(x86)"),
        ) if v]
        base_dirs.append(Path.home() / "AppData" / "Local" / "Programs")
        for base in base_dirs:
            paths.append(base / "Hubstudio" / "Hubstudio.exe")
        return paths

    @staticmethod
    def _find_hubstudio_exe() -> Path | None:
        """定位 Hubstudio.exe。"""
        for p in psutil.process_iter(["exe"]):
            exe = (p.info.get("exe") or "").lower()
            if "hubstudio" in exe and exe.endswith("hubstudio.exe"):
                return Path(p.info["exe"])
        for c in DirectBrowser._candidate_paths():
            if c.exists():
                return c
        return None

    def is_running(self) -> bool:
        """HubStudio 是否在运行（进程 + API 双重检查）。"""
        # 先查 API
        try:
            import httpx as _h
            r = _h.post(f"{self.api_base}/api/v1/browser/all-browser-status",
                        json={}, timeout=3)
            if r.status_code == 200 and r.json().get("code") == 0:
                return True
        except Exception:
            pass
        # 再查进程
        for p in psutil.process_iter(["name"]):
            if "hubstudio" in (p.info.get("name") or "").lower():
                return True
        return False

    def start_hubstudio(self, minimized: bool = True) -> bool:
        """启动 HubStudio（主窗口会被最小化到托盘）。

        minimized=True 时启动后立即把主窗口最小化到托盘，用户看不到主界面。
        """
        exe = self._find_hubstudio_exe()
        if not exe:
            log.error("未找到 Hubstudio.exe")
            return False

        os.environ.pop("ELECTRON_RUN_AS_NODE", None)
        subprocess.Popen([str(exe)])

        if minimized:
            # 等主窗口出现后最小化到托盘
            asyncio.get_event_loop().call_later(8, self._minimize_main_window)

        log.info("HubStudio 已启动（托盘模式）: %s", exe)
        return True

    @staticmethod
    def _minimize_main_window() -> None:
        """把 HubStudio 主窗口最小化到托盘（Windows API）。"""
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            hwnd = user32.FindWindowW(None, "Hubstudio | 3.61.2 | 1.64.0.1")
            if not hwnd:
                # 模糊匹配
                def enum_cb(h, _):
                    buf = ctypes.create_unicode_buffer(256)
                    user32.GetWindowTextW(h, buf, 256)
                    if "Hubstudio" in buf.value and "3.61" in buf.value:
                        nonlocal_found.append(h)
                    return True
                nonlocal_found = []
                user32.EnumWindows(enum_cb, 0)
                if nonlocal_found:
                    hwnd = nonlocal_found[0]
            if hwnd:
                SW_MINIMIZE = 6
                user32.ShowWindow(hwnd, SW_MINIMIZE)
                log.info("HubStudio 主窗口已最小化到托盘")
        except Exception as e:
            log.debug("最小化主窗口失败（可忽略）: %s", e)

    def stop_hubstudio(self) -> int:
        """关闭 HubStudio 所有进程。"""
        n = 0
        for p in psutil.process_iter(["name"]):
            name = (p.info.get("name") or "").lower()
            if "hubstudio" in name or name == "env-kit.exe":
                try:
                    p.kill()
                    n += 1
                except Exception:
                    pass
        return n

    # ───────── 启动环境 ─────────
    async def start(self, container_code: str = "", serial_number: int = 0,
                    headless: bool = False, **opts) -> BrowserInstance:
        """直接启动浏览器环境（不需要打开 HubStudio 主界面）。

        如果 HubStudio 没在运行，会先自动以托盘模式启动它。

        参数：
            container_code  环境编码（如 1887976888）
            serial_number   环境序号（如 5）
            headless        无头模式（True 时浏览器也不显示窗口）
            **opts          其他启动参数（args/containerTabs/pageZoom 等）

        返回 BrowserInstance（含 cdp_port，可直接连 Playwright）。
        """
        if not container_code and not serial_number:
            raise ValueError("必须指定 container_code 或 serial_number")

        # 确保 HubStudio 在运行（没有就以托盘模式启动）
        if not self.is_running():
            log.info("HubStudio 未运行，先以托盘模式启动")
            self.start_hubstudio(minimized=True)
            # 等 API 就绪
            for _ in range(30):
                await asyncio.sleep(1)
                if self.is_running():
                    break
            else:
                raise RuntimeError("HubStudio 启动超时，API 未就绪")

        body: dict[str, Any] = {}
        if serial_number:
            body["serialNumber"] = int(serial_number)
        else:
            body["containerCode"] = str(container_code)
        if headless:
            body["isHeadless"] = True
        body.update(opts)

        async with httpx.AsyncClient(timeout=120) as c:
            r = await c.post(f"{self.api_base}/api/v1/browser/start", json=body)
            r.raise_for_status()
            data = r.json()

        code = data.get("code")
        if code != 0:
            raise RuntimeError(f"启动失败: {data.get('msg')} (code={code})")

        d = data.get("data") or {}
        inst = BrowserInstance(
            container_code=str(d.get("containerCode") or container_code),
            container_id=str(d.get("containerId") or ""),
            env_id="",  # 由 open-detail 反查可补
            cdp_port=int(d.get("debuggingPort") or 0),
            browser_path=d.get("browserPath") or "",
            webdriver_path=d.get("webdriver") or "",
            download_path=d.get("downloadPath") or "",
            proxy_type=d.get("proxyType") or "",
            ip=d.get("ip") or "",
        )
        log.info("环境已启动: %s -> CDP:%s IP:%s",
                 inst.container_code, inst.cdp_port, inst.ip)
        return inst

    async def stop(self, container_code: str) -> bool:
        """关闭指定环境。"""
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post(f"{self.api_base}/api/v1/browser/stop",
                             json={"containerCode": str(container_code)})
            return r.json().get("code") == 0

    async def stop_all(self) -> bool:
        """关闭所有环境。"""
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post(f"{self.api_base}/api/v1/browser/stop-all", json={})
            return r.json().get("code") == 0

    async def list_running(self) -> list[dict]:
        """列出运行中的环境。"""
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post(f"{self.api_base}/api/v1/browser/all-browser-status", json={})
            data = r.json()
        return (data.get("data") or {}).get("containers") or []


# 全局单例
_direct: DirectBrowser | None = None


def get_direct_browser() -> DirectBrowser:
    global _direct
    if _direct is None:
        _direct = DirectBrowser()
    return _direct

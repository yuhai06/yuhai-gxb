#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TikTok 短剧抓取（独立子进程）
用法: python tk_fetch.py <drama_id> [--wait 12] [--retries 3]
输出: 一行 JSON 到 stdout

双重策略（实盘验证）：
  ① 主路：拦截页面自己发的 /api/drama/detail + episode/item_list
  ② 兜底：接口被风控时，从 DOM 直接读剧名/集数/时长
     （页面往往还能渲染，接口却返回 Something went wrong）
"""
import io
import json
import os
import sys
import time

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

DOM_JS = r"""() => {
  const out = {title: '', epCount: 0, cur: 0, dur: 0, w: 0, h: 0,
               bodyErr: false, videos: 0};
  const bodyTxt = document.body ? (document.body.innerText || '') : '';
  if (/Something went wrong|出错了/i.test(bodyTxt)) out.bodyErr = true;

  // 标题：h2 里排除「通知」
  const h2s = Array.from(document.querySelectorAll('h2'))
      .map(e => e.textContent.trim())
      .filter(t => t && t !== '通知' && t.length < 80);
  if (h2s.length) out.title = h2s[0];

  // 集数文案（观看全部 42 集 / 第 1 集）
  let m = bodyTxt.match(/观看全部\s*(\d+)\s*集/);
  if (m) out.epCount = +m[1];
  if (!out.epCount) {
    m = bodyTxt.match(/(\d+)\s*Episodes?/i);
    if (m) out.epCount = +m[1];
  }
  m = bodyTxt.match(/第\s*(\d+)\s*集/);
  if (m) out.cur = +m[1];

  const v = document.querySelector('video');
  if (v) {
    out.dur = Math.round(v.duration || 0);
    out.w = v.videoWidth || 0;
    out.h = v.videoHeight || 0;
  }
  out.videos = document.querySelectorAll('video').length;
  return out;
}"""


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "缺少 drama_id"}, ensure_ascii=False))
        return 1

    drama_id = sys.argv[1].strip()
    cdp = "http://127.0.0.1:9222"
    wait = 12
    retries = 3
    for i, a in enumerate(sys.argv):
        if a == "--cdp" and i + 1 < len(sys.argv):
            cdp = sys.argv[i + 1]
        elif a == "--wait" and i + 1 < len(sys.argv):
            wait = int(sys.argv[i + 1])
        elif a == "--retries" and i + 1 < len(sys.argv):
            retries = int(sys.argv[i + 1])

    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        print(json.dumps({"error": f"playwright 未安装: {e}"}, ensure_ascii=False))
        return 1

    target = f"https://www.tiktok.com/shortdrama/episode/{drama_id}/1"
    best = {"detail": None, "eps": [], "attempts": 0, "err": "", "dom": None}

    # ⚠ 2026-11-18 加自动无头启动（用户："你用无头抓别影响我"）：
    #   原来只 connect_over_cdp，要求用户先手动开一个 Chrome。
    #   现在如果 9222 连不上，就自己起一个 headless Chrome（独立 profile），
    #   抓完就关，完全不占用户桌面。
    _own_browser = None
    _pw_handle = None
    _need_own = False
    try:
        import urllib.request as _ur
        _ur.urlopen(cdp + "/json/version", timeout=3).read()
    except Exception:
        _need_own = True

    try:
        if _need_own:
            # 自己起一个无头 Chrome（独立 profile，抓完就关）
            from playwright.sync_api import sync_playwright as _sp
            _prof = os.path.join(os.environ.get("LOCALAPPDATA", "."),
                                 "YuhaiWorkbench", "tk_headless")
            _px = ""
            try:
                sys.path.insert(0, os.path.dirname(os.path.dirname(
                    os.path.abspath(__file__))))
                from app import paths as _p
                _px = (_p.proxy() or "").strip()
            except Exception:
                _px = ""
            if not _px:
                _px = "http://127.0.0.1:7897"
            _args = [
                "--disable-blink-features=AutomationControlled",
                "--no-first-run", "--no-default-browser-check",
                "--disable-extensions", "--window-size=1280,900",
            ]
            if _px:
                _args.append(f"--proxy-server={_px}")
                _args.append("--ignore-certificate-errors")
            _pw_handle = _sp().start()
            _own_browser = _pw_handle.chromium.launch_persistent_context(
                _prof, headless=True, args=_args, timeout=60000)
            print(json.dumps({"warmup": "headless_started"}, ensure_ascii=False),
                  file=sys.stderr)

            ctx = _own_browser
            br = None
        else:
            from playwright.sync_api import sync_playwright
            _pw_handle = sync_playwright().start()
            br = _pw_handle.chromium.connect_over_cdp(cdp, timeout=60000)
            ctx = br.contexts[0]
        _ = len(ctx.pages)

        for attempt in range(1, retries + 1):
            caught = {"d": None, "e": []}
            pg = None
            try:
                pg = ctx.new_page()

                def on_resp(r):
                    try:
                        u = r.url
                        if "/api/drama/detail/" in u and r.status == 200 and not caught["d"]:
                            t = r.text()
                            if len(t) > 500:
                                caught["d"] = t
                        elif "/api/drama/episode/item_list/" in u and r.status == 200:
                            t = r.text()
                            if len(t) > 500:
                                caught["e"].append(t)
                    except Exception:
                        pass

                pg.on("response", on_resp)
                pg.goto(target, wait_until="domcontentloaded", timeout=55000)
                time.sleep(11)
                if caught["d"] and not caught["e"]:
                    try:
                        pg.mouse.wheel(0, 800)
                    except Exception:
                        pass
                    time.sleep(7)
                elif not caught["d"]:
                    time.sleep(7)
            except Exception as e:
                best["err"] = repr(e)[:160]

            # 无论接口有没有，都试 DOM（兜底：接口坏了页面可能还在）
            if pg is not None:
                try:
                    dm = pg.evaluate(DOM_JS)
                    if dm and (dm.get("title") or dm.get("epCount")):
                        best["dom"] = dm
                except Exception:
                    pass

            dl = len(caught["d"] or "")
            el = len(caught["e"])
            best["attempts"] = attempt

            if dl > 500 and not best["detail"]:
                best["detail"] = caught["d"]
            if el > 0:
                best["eps"] = caught["e"]

            try:
                if pg is not None:
                    pg.close()
            except Exception:
                pass

            if dl > 500 and el > 0:
                best["detail"] = caught["d"]
                best["eps"] = caught["e"]
                best["err"] = ""
                break
            if attempt < retries:
                time.sleep(5)
        try:
            if br is not None:
                br.close()
        except Exception:
            pass
    except Exception as e:
        best["err"] = repr(e)[:200]
    finally:
        # 自己起的无头浏览器要关掉，别留后台进程
        if _own_browser is not None:
            try:
                _own_browser.close()
            except Exception:
                pass

    print(json.dumps(best, ensure_ascii=False))
    return 0 if (best["detail"] or best.get("dom")) else 2


if __name__ == "__main__":
    sys.exit(main())

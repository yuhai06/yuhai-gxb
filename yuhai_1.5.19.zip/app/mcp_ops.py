# -*- coding: utf-8 -*-
"""
mcp_ops.py — 补全雨海 Agent 对全站运营能力的完整掌控

覆盖先前 MCP 缺失的全部高频模块：
  1. 发布前提取最新主页 PID + 发布订单控制（sync-pages / sources / cancel / retry-failed / stop-all）
  2. 指纹浏览器一环境一账号全生命周期（死号标记与主页交接 / 恢复 / 同环境换号 / 迁移 / 建环境 / 改代理 / 分组）
  3. 主页批量暂停/恢复自动发布
  4. 全自动总控（总开关 / 单项开关 / 急停 / 一键跑一轮）
  5. 评论区维护（巡检状态 / 立即跑一轮 / 历史记录）
  6. 风控中心（主动检查 / 解除熔断）
  7. 素材库推队列、清理、排期自动规划、系统进程清理与全局设置
  8. 兜底接口 workbench_api（限定本机 /api/*，确保工作台任意端点 Agent 都能调通）
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


def _ok(**kw) -> dict:
    return {"ok": True, **kw}


def _err(msg: str, **kw) -> dict:
    return {"ok": False, "error": msg, **kw}


def _base() -> str:
    from app.config import settings
    return f"http://127.0.0.1:{int(settings.port or 8710)}"


def _api(method: str, path: str, body: dict | None = None, timeout: int = 60) -> dict:
    """调用本机工作台 REST API（与前端点击完全同一条执行路径）。"""
    if not path.startswith("/"):
        path = "/" + path
    url = _base() + path
    data = None
    headers = {"Accept": "application/json"}
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
            try:
                out = json.loads(raw) if raw else {}
            except Exception:
                out = {"raw": raw[:1000]}
            if isinstance(out, dict):
                out.setdefault("ok", True)
                return out
            return {"ok": True, "data": out}
    except urllib.error.HTTPError as e:
        raw = ""
        try:
            raw = e.read().decode("utf-8", "replace")
        except Exception:
            pass
        detail = raw[:300]
        try:
            j = json.loads(raw)
            if isinstance(j, dict):
                detail = str(j.get("detail") or j.get("error") or detail)
        except Exception:
            pass
        return _err(f"HTTP {e.code}: {detail}", status=e.code)
    except Exception as e:
        return _err(f"请求工作台失败: {str(e)[:200]}")


def register(mcp) -> int:
    """向 MCPServer 注册全站补齐工具，返回注册数量。"""
    n = 0

    def tool(desc: str):
        def deco(fn):
            nonlocal n
            mcp.tool(description=desc)(fn)
            n += 1
            return fn
        return deco

    # ═══════════════════════════════════════════════
    # 1. 发布前提取最新主页 + 发布控制
    # ═══════════════════════════════════════════════
    @tool(
        "发布前实时提取在线发布号的最新主页 PID，查清当前账号有多少主页及本次新发现了哪些主页（防漏发）。"
        "envCodes 留空=扫全部在线发布号；autoStart 默认 False（绝不擅自打开离线浏览器消耗 HubStudio 次数）。"
    )
    def publish_sync_pages(envCodes: list[str] = [], autoStart: bool = False) -> dict:
        return _api("POST", "/api/publish/sync-pages", {
            "envCodes": [str(x) for x in (envCodes or []) if str(x).strip()],
            "autoStart": bool(autoStart),
        }, timeout=90)

    @tool(
        "查询发布中心全部内部现状：可发素材数（已去重）、可发主页清单、活跃发布号环境（已自动过滤死号）、"
        "各剧剩余条数、推广链接池。group: publish(默认) | auth | all。"
    )
    def publish_sources(group: str = "publish") -> dict:
        q = urllib.parse.urlencode({"group": group or "publish"})
        return _api("GET", f"/api/publish/sources?{q}", timeout=60)

    @tool("取消指定正在运行的发布订单（剩余未发项标为跳过，不杀浏览器）。")
    def publish_cancel_order(orderId: str) -> dict:
        if not orderId:
            return _err("orderId 不能为空")
        return _api("POST", f"/api/publish/orders/{urllib.parse.quote(orderId)}/cancel", {})

    @tool("只重试指定发布订单中的失败项，已成功的绝不重发。")
    def publish_retry_failed(orderId: str) -> dict:
        if not orderId:
            return _err("orderId 不能为空")
        return _api("POST", f"/api/publish/orders/{urllib.parse.quote(orderId)}/retry-failed", {})

    @tool("软停止全部正在运行的发布任务（不会强杀 node/Chromium，保护 HubStudio 打开次数）。")
    def publish_stop_all() -> dict:
        return _api("POST", "/api/publish/stop-all", {})

    # ═══════════════════════════════════════════════
    # 2. 指纹浏览器：一环境一账号死号处理 / 换号 / 迁移 / 创建 / 代理
    # ═══════════════════════════════════════════════
    @tool(
        "标记某指纹浏览器环境登录的账号已死/被封（Hubstudio 同步不会覆盖死号状态，发布中心自动屏蔽）。"
        "默认自动暂停名下所有主页发布并停用账号记录；如填 handoverToEnv 则一步把名下主页迁移给目标存活环境。"
    )
    def env_mark_dead(
        code: str,
        reason: str = "账号被封",
        pausePages: bool = True,
        handoverToEnv: str = "",
        resumeHandoverPages: bool = False,
    ) -> dict:
        if not code:
            return _err("code（环境 containerCode）不能为空")
        return _api("POST", f"/api/envs/{urllib.parse.quote(code)}/account-state", {
            "state": "dead",
            "reason": reason or "账号被封",
            "pausePages": bool(pausePages),
            "disableAccount": True,
            "handoverToEnv": handoverToEnv or "",
            "resumeHandoverPages": bool(resumeHandoverPages),
        })

    @tool("将之前标记为死号的环境恢复为正常状态。")
    def env_revive(code: str) -> dict:
        if not code:
            return _err("code 不能为空")
        return _api("POST", f"/api/envs/{urllib.parse.quote(code)}/account-state", {"state": "ok"})

    @tool(
        "同环境换号重置：保留该指纹环境及代理配置，清空旧死号的账号/c_user/死号标记。"
        "用户在该环境登录新 Meta 账号后，调 publish_sync_pages 即可提取新主页。"
    )
    def env_rebind_account(code: str, clearPagesBinding: bool = False) -> dict:
        if not code:
            return _err("code 不能为空")
        return _api("POST", f"/api/envs/{urllib.parse.quote(code)}/rebind-account", {
            "clearPagesBinding": bool(clearPagesBinding),
        })

    @tool("一键把源环境名下的主页与账号归属迁移到目标存活环境（dryRun=True 先预览）。")
    def env_migrate(
        fromEnv: str,
        toEnv: str,
        moveAllPages: bool = True,
        pageIds: list[str] = [],
        moveAccounts: bool = True,
        dryRun: bool = False,
    ) -> dict:
        if not fromEnv or not toEnv:
            return _err("fromEnv 和 toEnv 不能为空")
        return _api("POST", "/api/envs/migrate", {
            "fromEnv": fromEnv,
            "toEnv": toEnv,
            "moveAllPages": bool(moveAllPages),
            "pageIds": list(pageIds or []),
            "moveAccounts": bool(moveAccounts),
            "dryRun": bool(dryRun),
        })

    @tool(
        "在 Hubstudio 创建一个新指纹环境。最省事用法：传 name 和 cloneProxyFrom（克隆已有环境代理），"
        "或手动传 proxyType/proxyServer/proxyPort/proxyAccount/proxyPassword。"
    )
    def env_create(
        name: str,
        cloneProxyFrom: str = "",
        proxyType: str = "Socks5",
        proxyServer: str = "",
        proxyPort: int = 0,
        proxyAccount: str = "",
        proxyPassword: str = "",
        remark: str = "",
    ) -> dict:
        if not name:
            return _err("环境名称 name 不能为空")
        return _api("POST", "/api/envs/create", {
            "name": name,
            "cloneProxyFrom": cloneProxyFrom or "",
            "proxyType": proxyType or "Socks5",
            "proxyServer": proxyServer or "",
            "proxyPort": int(proxyPort or 0),
            "proxyAccount": proxyAccount or "",
            "proxyPassword": proxyPassword or "",
            "remark": remark or "",
            "syncAfter": True,
        })

    @tool("修改或克隆指纹环境的代理配置（环境需先处于关闭状态）。传 cloneFrom 直接复制源环境代理。")
    def env_set_proxy(
        code: str,
        cloneFrom: str = "",
        proxyType: str = "Socks5",
        proxyHost: str = "",
        proxyPort: int = 0,
        proxyAccount: str = "",
        proxyPassword: str = "",
    ) -> dict:
        if not code:
            return _err("code 不能为空")
        if cloneFrom:
            q = urllib.parse.urlencode({"fromCode": cloneFrom})
            return _api("POST", f"/api/envs/{urllib.parse.quote(code)}/proxy/clone?{q}", {})
        return _api("POST", f"/api/envs/{urllib.parse.quote(code)}/proxy", {
            "proxyType": proxyType or "Socks5",
            "proxyHost": proxyHost,
            "proxyPort": int(proxyPort or 0),
            "proxyAccount": proxyAccount or "",
            "proxyPassword": proxyPassword or "",
        })

    @tool("设置环境所属分组：publish（发布号，出现在发布中心）或 auth（授权号，仅在主页与授权页显示）。")
    def env_set_group(code: str, group: str) -> dict:
        if not code:
            return _err("code 不能为空")
        return _api("POST", "/api/groups/env", {"envCode": code, "group": group})

    @tool("批量设置多个主页是否跳过自动发布（skip=True 暂停自动发布，skip=False 恢复）。")
    def page_skip_publish_batch(pageIds: list[str], skip: bool = True, reason: str = "") -> dict:
        if not pageIds:
            return _err("pageIds 不能为空")
        return _api("POST", "/api/pages/skip-publish-batch", {
            "pageIds": list(pageIds),
            "skip": bool(skip),
            "reason": reason or "",
        })

    # ═══════════════════════════════════════════════
    # 3. 全自动总控
    # ═══════════════════════════════════════════════
    @tool("查看全自动总控状态（总开关、只观察模式、8 项自动子开关与最近执行备注）。")
    def auto_status() -> dict:
        return _api("GET", "/api/auto")

    @tool("开启或关闭全自动后台总开关（不含排期和发布，排期发布永远手动）。")
    def auto_set_master(enabled: bool) -> dict:
        return _api("POST", "/api/auto/master", {"enabled": bool(enabled)})

    @tool(
        "开关全自动的单个子项。key 可选：commentWatch(评论维护) / metrics(数据采集) / "
        "guardWatch(风控巡检) / quotaBalance(配额回收) / grabHot(素材抓取) / aiFit(主页画像) / "
        "observeOnly(只观察不动作) / catchUp(开机补漏)。"
    )
    def auto_set_item(key: str, enabled: bool) -> dict:
        return _api("POST", "/api/auto/item", {"key": key, "enabled": bool(enabled)})

    @tool("全自动一键急停：立刻关闭全部自动流程并开启「只观察」模式。")
    def auto_stop() -> dict:
        return _api("POST", "/api/auto/stop", {})

    @tool("手动触发一轮后台维护任务（返回 jobId）：key 可选 comments(评论维护) | metrics(采视频数据) | guard(风控巡检)。")
    def auto_quick(key: str) -> dict:
        return _api("POST", "/api/auto/quick", {"key": key})

    # ═══════════════════════════════════════════════
    # 4. 评论区维护
    # ═══════════════════════════════════════════════
    @tool("查看评论区自动维护巡检状态、规则与配额。")
    def comment_status() -> dict:
        w = _api("GET", "/api/comments/watch")
        q = _api("GET", "/api/comments/quota")
        return _ok(watch=w, quota=q)

    @tool("立即执行一轮评论区巡检维护（自动回复意向评论、清理垃圾评论）。")
    def comment_run(catchUp: bool = False) -> dict:
        q = urllib.parse.urlencode({"catchUp": str(bool(catchUp)).lower()})
        return _api("POST", f"/api/comments/watch/run-once?{q}", {}, timeout=120)

    @tool("查看评论区维护处理历史记录（可按 pageId 或 action=reply/delete 筛选）。")
    def comment_history(pageId: str = "", action: str = "", limit: int = 30) -> dict:
        params: dict[str, Any] = {"limit": max(1, min(200, int(limit or 30)))}
        if pageId:
            params["pageId"] = pageId
        if action:
            params["action"] = action
        return _api("GET", "/api/comments/history?" + urllib.parse.urlencode(params))

    # ═══════════════════════════════════════════════
    # 5. 风控中心
    # ═══════════════════════════════════════════════
    @tool("对在线发布号环境立即执行一轮风控检查（检测 checkpoint/captcha/受限信号）。")
    def guard_check(envCode: str = "", pageId: str = "") -> dict:
        return _api("POST", "/api/guard/check", {"envCode": envCode or "", "pageId": pageId or ""}, timeout=45)

    @tool("解除风控熔断：传具体 eventId 解除单条；eventId=0 时解除当前全部未处理风控事件（仅在人工确认后调用）。")
    def guard_resolve(eventId: int = 0, note: str = "人工已确认处理") -> dict:
        if int(eventId or 0) > 0:
            return _api("POST", "/api/guard/resolve", {"id": int(eventId), "note": note or "人工已确认"})
        ev = _api("GET", "/api/guard/events?open_only=true&limit=100")
        items = ev.get("items") or []
        done = 0
        for it in items:
            eid = it.get("id")
            if eid is not None:
                r = _api("POST", "/api/guard/resolve", {"id": int(eid), "note": note or "批量解除"})
                if r.get("ok"):
                    done += 1
        return _ok(resolved=done, totalOpen=len(items))

    # ═══════════════════════════════════════════════
    # 6. 素材库补充 & 排期自动规划 & 系统运维
    # ═══════════════════════════════════════════════
    @tool("把指定素材 ID 列表（libIds）推入待发队列。")
    def library_push_queue(libIds: list[str]) -> dict:
        if not libIds:
            return _err("libIds 不能为空")
        return _api("POST", "/api/library/push", {"ids": list(libIds)})

    @tool("清理素材库无效记录（缺失文件、空记录或版权不通过记录）。")
    def library_clean(removeMissing: bool = True, removeCopyrightFail: bool = False) -> dict:
        res: dict[str, Any] = {}
        if removeMissing:
            res["clean"] = _api("POST", "/api/library/clean", {"removeMissing": True})
        if removeCopyrightFail:
            res["purgeCopyright"] = _api("POST", "/api/library/purge-copyright-fail?deleteFile=true", {})
        return _ok(**res)

    @tool("查看工作台相关后台进程及多余误启实例列表。")
    def system_processes() -> dict:
        return _api("GET", "/api/system/processes", timeout=20)

    @tool("清理多余误启的工作台实例（自动保护主程序、后端服务与浏览器进程）。")
    def system_kill_stray() -> dict:
        return _api("POST", "/api/system/processes/kill", {"pids": [], "onlyStray": True})

    @tool("读取或修改工作台全局设置。action='get' 读取；action='set' 时传 patch 字典保存。")
    def system_config(action: str = "get", patch: dict = {}) -> dict:
        if (action or "get").lower() == "set":
            return _api("POST", "/api/system/config", patch or {})
        return _api("GET", "/api/system/config")

    # ═══════════════════════════════════════════════
    # 7. 全站通用 API 兜底（覆盖工作台全部 /api/* 路由）
    # ═══════════════════════════════════════════════
    @tool(
        "调用本机工作台任意 /api/* 端点（当上述专用工具未覆盖某细粒度按钮功能时使用）。"
        "method: GET|POST|PATCH|DELETE；path 必须以 /api/ 开头（例如 /api/schedule/autoplan 或 /api/ai/analyze-batch）。"
    )
    def workbench_api(method: str, path: str, body: dict | None = None) -> dict:
        m = (method or "GET").strip().upper()
        if m not in ("GET", "POST", "PATCH", "DELETE"):
            return _err(f"不支持的方法: {m}")
        p = (path or "").strip()
        if not p.startswith("/api/"):
            return _err("安全限制：path 必须以 /api/ 开头")
        return _api(m, p, body if m != "GET" else None, timeout=90)

    return n
